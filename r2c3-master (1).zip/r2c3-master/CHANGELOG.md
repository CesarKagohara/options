## 1.70.0 (em andamento)

- INTP007 - Inclusao do atributo DadosControleContrato.qtdeUrs (HABILITA_INTP007_INFORMAR_QTD_URS)

## 1.69.8 (2021-07-13)

- RRC0019/ARRC022 - Erro 081 para quando o EC enviado não é encontrado nas tabelas de cache da CTZ

## 1.69.7 (2021-07-13)

- RRC0019/ARRC022 - Erro 081 para quando o EC enviado não é encontrado nas tabelas de cache da CTZ

## 1.69.7 (2021-07-13)

- V_CTZECIC - melhorias de performance para inserção na base (prod)

## 1.69.6 (2021-07-13)

- INTP010 - (PROD - batch_id 20250812224) - Limitar na geração do id_unidd_recbv para parametros com ano igual a 9999

## 1.69.5 (2021-07-13)

- [RRC0019/ARRC022/Recalculo] - Logs para a busca de recebíveis livres e ativos

## 1.69.4 (2021-07-12)

- [RRC0019/RECALCULO] - alteração de final recebedor pele baso não encontra frações consttittuidas

## 1.69.3 (2021-07-12)

- V_CTZECIC - melhorias de performance para inserção na base e criação dos subhandlers
- RRC0019 / ARRC022 - inclusão de parametro de sistema para habilitar troca alcance geral do contrato para alcance especifico (HABILITA_TROCA_ALC_GERAL_ESPECIFICO)
- [Centralizada] - Ajustes na notificação Anuencia.
- RRC0019 / ARRC022 - ajuste para permitir trocar o alcance geral do contrato para alcance especifico. (validação troca de credenciadora)
- V_PRERCL1/V_PRERCL2: Ajuste para considerar frações somente a partir da data de referencia;
- V_RECLDES: Ajuste para considerar frações somente a partir da data de referencia;
- Nullpointer no tratamento do retorno da INTP008 Recalculo
- ARRC001 - Não retornar erro ERRC0214 para frações livres HOJE que tenham fumaça no ONTEM

## 1.69.2 (2021-07-11)

- RRC0005/RRC0019/ARRC022 - Corrigido tratamento para parâmetro QTD_SEGUNDOS_DESCARTA_PEDIDO_AGENDA

## 1.69.1 (2021-07-11)

- RRC0005/RRC0019/ARRC022 - Corrigido tratamento para parâmetro QTD_SEGUNDOS_DESCARTA_PEDIDO_AGENDA

## 1.69.0 (2021-07-10)

- Grade horária - Criação do tipo de grade para execução. Grade do tipo Padrão (P) valida no inputListener e a grade do tipo Execução(X) valida dentro do handler. Não existindo grade de Execução(X) não há ocorrência de erro no grupo do handler. Os codigos de erro permanecem os mesmos para grade (013 e 079)
- [V_RECALCL/V_RECALCI] - Ajuste para não salvar as tabelas acessórias da operação
- RRC0019 / ARRC022 - ajuste para permitir trocar o alcance geral do contrato para alcance especifico
- ARRC030 - MELHORIA - troca dos endpoints da centralizada para enviar para novos de atualização e baixa (EC x IC e  IC x ARRJ)
- [RTC45950] - [R2C3 - ARRC030- 1.68.26] - É retornado erro de DataException: [-791: Error validating XML] ao enviar CodInstitdrArrajPgto fora do dominio (999)
- [RTC45951] - [R2C3 - ARRC030- 1.68.26] - É retornado erro de Duplicate key value violates unique constraint "pk_estbmnt_comcl" ao enviar Grupo_ARRC030_ArrajPgto 2 vezes com o mesmo CodInstitdrArrajPgto
- RRC0005/RRC0019/ARRC022 - Inclusão de parâmetro QTD_SEGUNDOS_DESCARTA_PEDIDO_AGENDA indicando tempo em uma agenda recebida (credenciadora + recebedor + arranjo via INTP004 ou INTP005) é considerada expirada, para que as rotinas solicitem novamente as agendas (INTP010)
- ARRC001 - Retirada da validação ERRC0055 para CIELO (01027058) no cenário específico de operação ativa, mas não estar associada a UR no ontem
- RRC0005/RRC0019/ARRC022 - Inclusão de parâmetros SLOW_TRACK_SLA_INTEROP_RESPOSTA e SLOW_TRACK_QTD_UNIDD_RECBVS relacionados a aumento no tempo de SLA de operações com muitas URs

## 1.68.26 (2021-07-08)

- V_RECALCL/V_RECALCI - Ajuste para processar todas as operações de um mesmo CNPJ

## 1.68.25 (2021-07-08)

- ARRC001 - (PROD - root_id 237683568) - NPE

## 1.68.24 (2021-07-07)

- ARRC001 - ERRC0214 - Não recusar quando fração livre enviada no hoje estiver associada a uma operação de antecipação no ontem

## 1.68.23 (2021-07-07)

- ARRC001 - ERRC0214 - Não recusar quando fração livre enviada no hoje estiver associada a uma operação de antecipação no ontem

## 1.68.22 (2021-07-07)

- Tratamento no envio da agenda rejeitar quando ocorrer erro ERRC0055 e ERRC0038
- Validação de erro ERRC0158 quando ocorre o envio de domínio de operação inválido (RRC0019 e ARRC022)
- ARRC001 - ERRC0214 - Não recusar quando a fração livre enviada no hoje estiver com o valor maior do que o valor livre do ontem (quando estavir como 0.0)
- INTP004 / INTP005 - CIP falando - ajuste no envio da agenda para enviar com o CNJP da CIP (04391007000132) em vez do CNPJ "adega do pica-pau" (29011780000157) quando precisa ter ofuscamento de contratos CIP

## 1.68.21 (2021-07-07)

- ARRC001 - (PROD - root_id 234493889) - NPE

## 1.68.20 (2021-07-06)

- ARRC030 - Inclusão de parâmetro de sistema para validar se usa endpoints novos ou velhos da centralizada (HABILITA_ENVIO_CTZ_ARRC030_NOVOS_ENDPOINTS)

## 1.68.19 (2021-07-06)

- Ajuste INTP004 e INTP005 para envio de percentual inválido - ERRO ERRC0038 (interop 051)
- [RTC-45908] - INTP004 validação Credenciadora/subCredenciadora
- ARRC001 - ERRC0214 - Não recusar quando for enviado fração livre com fumaça no ontem. Neste cenário apagar a fumaça
- ARRC030 - MELHORIA - ajuste xsd para poder aceitar lista de arranjos
- ARRC030 - MELHORIA - ajuste no arquivo para validar se lista de arranjos veio para fazer tratativas apenas com lista de arranjos, caso não venha utiliza todos os arranjos da base
- ARRC030 - MELHORIA - troca dos endpoints da centralizada para enviar para novos (EC x IC e  IC x ARRJ) 

## 1.68.18 (2021-07-06)

- ARRC001 - ERRC0214 - Não recusar quando for enviado fração livre com fumaça no ontem. Neste cenário apagar a fumaça

## 1.68.17 (2021-07-06)

- INTP008 - Inclusão de tratamento de erro para desconsiderar processamento quando existe motivo de recusa

## 1.68.16 (2021-07-06)

- INTP005 - Alterado nivel de log

## 1.68.15 (2021-07-06)

- Ajuste XSD - solicitação para aceitar apenas uma repetição na ARRC023
- RRC0008 - Corrigido consulta das frações constituidas para enviar somente a DT_REF atual

## 1.68.14 (2021-07-05)

-[INTP007 Cip Ouvindo - RTC45905] quando enviada uma cessão que zera o saldo da UR, estava criando fumaça zerada
- correção consulta frações

## 1.68.12 (2021-07-05)

- INTP005/INTP004 validação Credenciadora/subCredenciadora 

## 1.68.11 (2021-07-05)

- ARRC001 - ERRC0214 - Não recusar quando a fração for livre com valor 0.0 ou quando estiver liquidada
- INTP005 (IdBatch divergente do recebido na INTP010)
- INTP001 - Entrega da deman\da de Notificacao de Penhora (INTP001).
- Troca versão api e swagger bilateral - de: 0.0.34 / para: 0.0.35 

## 1.68.10 (2021-07-05)

- INTP004 / INTP005 - ajuste para passar relação ec X arranjo por credenciadora para lateBatch para inserção na tabela ESTBMNT_COMCL - problema detectado em prod

## 1.68.9 (2021-07-05)

- RRC0020 - Corrigido consultas sem o IC_SIT = 'A' na tabela OP_TITLAR_DOMCL_UNIDD_RECBV

## 1.68.8 (2021-07-05)

- ARRC001 - Corrigido método que copia frações do ONTEM para o HOJE (PROD - batch_id = 226851065). java.io.IOException: Tried to send an out-of-range integer as a 2-byte value: 32888 at org.postgresql@42.2.18//org.postgresql.core.PGStream.sendInteger2(PGStream.java:347)

## 1.68.7 (2021-07-04)

- ARRC001 - DELETE das fumaças criadas no ONTEM quando a mesma é enviada constituida no HOJE

## 1.68.6 (2021-07-04)

- ARRC001 - ERRC0214 - Envio de agenda com domicilio livre e domicilio constituido em que ontem os dois estavam constituidos
- INTP007 Cip ouvindo - Cessão estava negando por falta de saldo mas enviava a INTP008 como se tivesse sido aceito e sem a prioridade no grupo efeito

## 1.68.5 (2021-07-04)

- ARRC001 - ERRC0214 - Envio de agenda com domicilio livre e domicilio constituido em que ontem os dois estavam constituidos

## 1.68.4 (2021-07-03)

- [RTC45878] - [R2C3 - INTP013 - v.1.67.31 Atlante v.5.7.2] - Tabela op_cancelt não salva informação de efeito contrato
- [RTC45894] - [R2C3 - RRC0020 - 1.68.0] - Valor constituido que foi cancelado parcialmente pela RRC0020 não é cancelado na tabela de fracao_unidd_recbv_op_110
- [RTC45897] - [R2C3 - RRC0006 - 1.68.0] - Valor constituido que foi cancelado parcialmente de uma Penhora pela RRC0006 não é cancelado na tabela de fracao_unidd_recbv_op_728
- [RTC45900] - [R2C3 RRC0020 INTEROP 1.68.2] Cancelamento parcial deve gerar INTP007 com a foto do contrato que ficou

## 1.68.3 (2021-07-03)

- Versao fechada pelo Jenkins

## 1.68.2 (2021-07-03)

- [INTP007/INTP008] - Ajuste na montagem do payload da INTP007 e consequente validação da INTP008 para operações com dois titulares do mesmo base
- [RTC45885] - R2C3[1.68.0]-ATL[5.7.5] - RRC0010 - Valores duplicados
- [RTC45886] - R2C3[1.68.0]-ATL[5.7.5] - RRC0010 - Valor 0.00 para as tag's VlrLivreAntecCreddrSub e VlrLivreTot de UR's livres
- Troca versão api e swagger centralizada - versão 3.0.3
- V_CTZMNEI - varredura para buscar relação EC x IC na base centralizada e povoar tabela ESTABELECIMENTO_COMERCIAL_INSTITUICAO_CREDENCIADORA_STAGE
- V_CTZICAR - varredura para buscar relação IC x ARRJ na base centralizada e povoar tabela INSTITUICAO_CREDENCIADORA_ARRANJO
- V_CTZESTC - modificação da varredura para enviar para os novos endpoints EC x IC e IC x ARRJ para envio para base centralizada

## 1.68.1 (2021-07-03)

- Versão invalida (desconsiderar)

## 1.68.0 (2021-07-01)

- Divisão da tabela FRACAO_UNIDD_RECBV_OP em FRACAO_UNIDD_RECBV_OP e FRACAO_UNIDD_RECBV_OP_FUMACA 
- ID_UNIDD_RECBV com novo algoritmo de formação de valor 
- V_ROLAGEM - Removida

## 1.67.34 (2021-07-01)

- Compatibilidade com Atlante 5.7.5
- [RRC0019/ARRC022] - Inclusao do parametro HABILITA_CARGA_IC_ARRANJO para buscar a relação entre credenciadoras e arranjo da tabela INSTITUICAO_CREDENCIADORA_ARRANJO
- [RRC0005] Antecipação Gestão Participante - os campos referentes a liquidação devem ser preenchidos na tabela de fração (VlrEftLiq, DtAnt, DtEftLiq, etc)

## 1.67.33 (2021-07-01)

- Recalculo Participante
- INTP007 Cip Ouvindo. No retorno da INTP008, para cessão, o titular estava incorreto
- V_RECALCL/V_RECALCI - Corrigido tratamento de controle de EC para o recalculo
- Tratamento na busca da base centralizada quando não retorna EC (EC retona null) - Ajuste na RRC0011 --> ERRC0081 e RRC0019 (opt-in) --> sem ocorrência mas finaliza o job
- ARRC001 - ERRC0214 - Retornar erro ao enviar fração (hoje) livre com valor e não liquidada porém com fração (ontem) ativa, em operação e não liquidada

## 1.67.32 (2021-06-30)

- ARRC023 - Thread sleep no método context.countInputRecords() para evitar falta de sincronismo entre Atlante x MQ. Ajuste temporário.
- V_RECALCL/V_RECALCI - Tratamento para nao processar operacoes canceladas depois da execucao da V_PRERCL1 e V_PRERCL2

## 1.67.31 (2021-06-29)

- ARRC022/RRC0019 - INTP007 cip falando - Ajuste para que sejam geradas fumaças somente para os arranjos solicitados na INTP010
- V_RECALCL/V_RECALCI - Otimização na consulta de operações para recalculo
- ARRC001 - ERRC0214 - Ajuste para não copiar do ontem as frações fumaça
- ARRC001 - ERRC0214 - Ajuste para não retornar erro nas frações com valor 0.0
- V_ROLAGEM - Ajuste para copiar somente as frações com dt_prevt_liquid >= dt_ref

## 1.67.30 (2021-06-29)

- RRC0020 - Otimização na consulta das URs para cancelamento de operações gestão participante

## 1.67.29 (2021-06-29)

- V_RECALCL/V_RECALCI - Otimização na consulta de operações para recalculo

## 1.67.28 (2021-06-28)

- Tratamento do sitRet (002) quando não tem adesão na ARRC023.
- RRC0020 - ajuste para cancelar somente a operação quando não tem agenda nem operação titular credenciador

## 1.67.27 (2021-06-27)

- INTP008 CIP OUVINDO: Otimização na consulta da solicitações de interoperabilidade
- RRC0020 - PROD java.util.NoSuchElementException: No value present quando não possui fração não livre para cancelamento
- ARRC001 - ERRO0214 - Corrigido copia das colunas ID_CNPJ_TITLAR_BASE e ID_CNPJ_RECBDR_BASE do ontem para hoje

## 1.67.26 (2021-06-27)

- Versão invalida (desconsiderar)

## 1.67.25 (2021-06-27)

- Versão invalida (desconsiderar)

## 1.67.24 (2021-06-26)

- INTP008 CIP OUVINDO: Suporte a multiplas frações na mesma UR da outra IMF

## 1.67.23 (2021-06-26)

- RRC0028 - Otimização no registro de opt-ins na base centralizada

## 1.67.22 (2021-06-26)

- INTP005 - Retirada da validação de data de criação igual a data de referencia

## 1.67.21 (2021-06-25)

- ARRC031 - PROD BATCH ID 172848743 - ajuste para enviar URs dentro do arquivo quando o ispb do credenciador não é igual ao inicio do cnpj completo

## 1.67.20 (2021-06-25)

- Tratamento de adesão para cada grupo de repetição da ARRC022 (não será mais único na entrada). Os erros ARRC015, ERRC018, ERRC030, ERRC031 ocorrerão na tag IdentdNegcRecbvl para cada grupo de repetição.

## 1.67.19 (2021-06-25)

- RRC0003 / RRC0004 / RRC0008 / ARRC031 - Ajuste para enviar id_efeito_contrato quando não houver id_Negc_Recbv_Extn na operação no campo IdentdNegcRecbvl
- RRC0020 - PROD - ajuste para tirar distinct da consulta e ajuste para fazer o distinct no java
- [V_RECALCL] - Diminuição na criação de JOBs e encadeamento de JOBs com o mesmo cpf/cnpj base

## 1.67.18 (2021-06-25)

- [V_RECALCL] - Diminuição na criação de JOBs e encadeamento de JOBs com o mesmo cpf/cnpj base

## 1.67.17 (2021-06-24)

- [ARRC001] - Inclusao do parametro HABILITA_ARRC001_VALIDA_URS_LIVRES_ONTEM para validar se as URs livres do hoje estavam alocadas em operações ontem (se sim retornar ERRC0214)
- [V_RECALCL] - Inlusao da tabela RRC_OWN.OP_RECALCL_INVALID para armazenar os erros ocorridos durante o recalculo
- Correção no mecanismo de interop INTP007 do recalculo.
- Ajuste no FracaoUnidadeRecebivelOperacaoDAOImpl para sempre gravar os ids base do usuário final recebedor e titular
- [RRC0020] - Ajustes na validação para não devolver registro recusado no RET sem o devido código de erro

## 1.67.16 (2021-06-24)

- V_ARRC018 - (PROD - batch_id 159169282) - java.lang.NullPointerException at br.org.cipbancos.rrc.negocio.InformaAgendaRecebiveisNegocio.criarGrupoDomicilioBancarioInstituicao2(InformaAgendaRecebiveisNegocio.java:611)
- RRC0019/ARRC022/INTP007/INTP013 Quando a ocorre algum problema na INTP007, deveria enviar a INTP013

## 1.67.15 (2021-06-24)

- V_ARRC018 - (PROD - batch_id 159169282) - java.lang.NullPointerException at br.org.cipbancos.rrc.negocio.InformaAgendaRecebiveisNegocio.criarGrupoDomicilioBancarioInstituicao2(InformaAgendaRecebiveisNegocio.java:611)

## 1.67.14 (2021-06-23)

- ARRC018 - ajuste para não enviar grupo Grupo_ARRC018_NegcRecbvlInst quando operação está liquidada
- ARRC001 - ajuste na validação do erro ERRC0059 na chave do domicilio bancario - adicionado na chave para validação DtEftLiquid, VlrEftLiquid e VlrPrevtLiquid
- Melhorias no controle de concorrencia (Estabelecimento processando)
- INTP007 Cip Falando - Ajuste para marcar o contrato como enviado somente se receber a INTP008

## 1.67.13 (2021-06-22)

- INTP007 - Corrigido validação de existencia de id-efeito-contrato para operações de alteração

## 1.67.12 (2021-06-22)

- RRC0028 - inclusao de filtro para gerar opt-ins somente para credenciadoras do cache ou que tenham agenda

## 1.67.11 (2021-06-22)

- ARRC001 - INTP004 ajuste IllegalArgumentException("Nao foi encontrado operacao (ou titular domicilio) para o id_op: xxxx")
- V_CTZECIC - varredura ECxIC
- RRC0020 - ajuste para cancelamento com troca de cessão
- RRC0019 - inclusao de filtro para gerar opt-ins somente para credenciadoras do cache ou que tenham agenda

## 1.67.10 (2021-06-21)

- /api/opt - Inclusao do campo tipoDocumentoUsuarioFinalRecebedorOuTitular (AnuenciaOutputDTO) no retorno de registro de anuencia da base centralizada (swagger_centralizadora_3.0.1.yaml)

## 1.67.9 (2021-06-21)

- /api/ec - Inclusao dos campos documentoCredor e tipoDocumentoCredor (AnuenciaOutputDTO) no retorno de registro de anuencia da base centralizada (swagger_centralizadora_3.0.1.yaml)

## 1.67.8 (2021-06-21)

- Versão invalida (desconsiderar)

## 1.67.7 (2021-06-20)

- RRC0019/ARRC022 Correção na geração de optin para a gestão ER
- RRC0006 / RRC0008 / RRC0011 / RRC0012 / RRC0013 / RRC0025 - Tratamento de grade horária no RET, após o aceite de PRO. Ocorrem os mesmos erros apresentados no ERR (Parâmetro - VALIDA_GRADE_HORARIA_HANDLER).
- RRC0020 - ajustes recalculo para passar apenas URs que precisam ser recalculadas que foram canceladas
- [GERAL] - Corrigido atualização de fração para atualizar corretamente as colunas id_atl_root, id_funcdd, nm_arq, id_part_orig, id_part_admtd, id_part_princ
- Nova Tabela de EC vs Credenciadora
- Parametro  para troca de EC vs Credenciador ou Estabelecimento_Comercial PARAMETRO_TABELA_CARGA_ESTABELECIMENTO_COMERCIAL (S - habilita a tabela de carga)
- [V_RECALCL] - Inclusao de parametro HABILITA_VALIDACAO_RECALCULO_OPERACAO_JA_ATUALIZADA para desconsiderar operações atualizadas no mesmo dia (data corrente) e antes da varredura

## 1.67.6 (2021-06-18)

- RRC0020 - ajuste cancelamento total para não enviar 003 e 009
- RRC0021 - Correcao validacao ERRC0055 
- [ARRC022] - Nullpointer na alteração de contrato quando interopera
- [RRC0019/ARRC022] - Nullpointer no processamento de urs que sairam da operação ( AbstractConstituicao.java:1159 ) 
- [RRC0019/ARRC022] - Correção na geração de OPTIN para operações gestão registradora

## 1.67.5 (2021-06-18)

- [V_RECALCL] - Alterado sub-batch de solicitação de agendas (interop) de late-batch para sub-batch

## 1.67.4 (2021-06-17)

- RRC0005 / RRC0010 / RRC0020 / RRC0021 / RRC0023 / RRC0027 - Tratamento de grade horária no RET, após o aceite de PRO. Ocorrem os mesmos erros apresentados no ERR (Parâmetro - VALIDA_GRADE_HORARIA_HANDLER).
- Inclusão de cache de credor e crendenciador nas buscas da base local centralizada
- [RRC0020] - Ajuste cancelamento parcial por titular
- [RRC0021/RRC0008] Ajuste na consulta de usuario final recebedor base

## 1.67.3 (2021-06-17)

- [RTC45792] - [R2C3 - RRC0020 - 1.67.2] - Sistema não está retornando msgs RRC0009 e RRC0003 com dados do contrato que sofreu o cancelamento parcial de suas URs, somente é enviado a 0009/0003 do contrato recalculado
- [V_RECALCL] - Alterado sub-batch de solicitação de agendas (interop) de late-batch para sub-batch

## 1.67.2 (2021-06-17)

- [RRC0020] - refatoração + ajustes no cancelamento parcial de cessao 
- [RRC0020] - Para cancelamento parcial com indicardor de liquidacao igual a N lançar erro ERRC0013 - adicionado parametro de sistema DESABILITA_CANCELAMENTO_PARCIAL para caso precise religar essa validação
- [RRC0020] - otimização consultas das frações da operação a ser cancelada
- [RRC0019/ARRC022] - ajuste para suportar o controle de EC (ESTBMNT_PROCSSND_*) para base com muitas filiais

## 1.67.1 (2021-06-16)

- [RTC45788] - INTP010 - Ajuste no retorno de erro de grade horária

## 1.67.0 (2021-06-16)

- INTP004 / INTP007 / INTP010 / INTP011 - Tratamento de grade horária quando vem solicitação externa para a CIP. Codigos de erro Interop 9868(ERRC0013) e Interop  9918(ERRC079)
- RRC0019 e ARRC022 - Tratamento de grade horária no RET, após o aceite de PRO. Ocorrem os mesmos erros apresentados no ERR.
- Parâmetros para validar a grade de INTEROP e no RET (VALIDA_GRADE_HORARIA_INTEROP, VALIDA_GRADE_HORARIA_HANDLER)
- Quebra por ur no post da INTP004 na varredura de credenciadora offline

## 1.66.7 (2021-06-16)

- RRC0019/RRC0005/ARRC022 - Desativado a execução de opt-out automatico para os registros recusados

## 1.66.6 (2021-06-16)

- RRC0019/RRC0005/ARRC022 - bugfix de consulta que nao estava utilizando a partição com a dtref
- RRC0006 - Correção de NullPointerException

## 1.66.6 (2021-06-16)

- RRC0019/RRC0005/ARRC022 - bugfix de consulta que nao estava utilizando a partição com a dtref
- RRC0006 - Correção de NullPointerException

## 1.66.5 (2021-06-16)

- [RRC0020] - Para cancelamento parcial com indicardor de liquidacao igual a N lançar erro ERRC0013
- [RTC45784] [R2C3 - RRC0020 - 1.63.2] - Ao cancelar 4 URs (2 arranjos 003 e 004 e 2 datas) de contrato de Gravame PART para recalcular contrato de Gravame ER, sistema não está voltando o saldo cancelado das 2 URs do arranjo 003 para o livre, dessa forma nao ocorre o recalculo do Gravame ER
- [RRC0020] - Ajuste erro de fraçãos em idUr na atualizacao

## 1.66.4 (2021-06-16)

- [PRERECALCULO] - Ajuste nas consultas para que operações de alcance geral que não constituiram valor sejam recalculadas
- [RRC0019] - Melhorada distribuição de EC no controle de estabelecimentos em processamento
- [RRC0020] - Ajuste no cancelamento total de cessao

## 1.66.3 (2021-06-15)

- RRC006/RRC0020/ARRC023 - ajuste cancelamento total troca de cessão
- V_OPTOUTM - java.lang.NumberFormatException:  root 22340115 - HINT

## 1.66.2 (2021-06-15)

- RRC006/RRC0020/ARRC023 - ajuste cancelamento total troca de cessão

## 1.66.1 (2021-06-15)

- V_OPTOUTM - varreduta optout automatico
- RRC006/RRC0020/ARRC023 - ajustes de performance

## 1.66.0 (2021-06-14)

- [RRC0019/RRC0005/ARRC022] - Inclusao de parametro HABILITA_ENVIO_INTP011 indicando se deve enviar (ou nao) a INTP011 dos pedidos de agenda e dos opt-ins automaticos
- [RRC0009] Ajuste na configuração do splitter para não quebrar o xsd
- [INTPO07][RTC45780] **CIP OUVINDO** Ajuste na validação de entrada da alteração
- [INTP004] Em caso de envio de agenda duplicada, a mesma será atualizada.
- [RRC0006/RRC0020/ARRC023] - remoção do cancelamento automatico de opt-out
- [RECALCULO] - ajustes para geração dos arquivos 003 e 009 e/ou apenas salvar nas tabelas da entregop para enviar posteriormente

## 1.65.0 (2021-06-14)

- [RRC0019/ARRC022] - parametro de cache de LISTA_COD_ARRANJOS_CACHE

## 1.64.2 (2021-06-14)

- V_ENTRGOP - Retirado validacao de origem recalculo (ou gestão registradora) para o envio da RRC0003

## 1.64.1 (2021-06-13)

- R2C3[1.60.11]-ATL[5.7.1] - INTEROP - Ao enviar um POST /contestacao - cip falando, o sistema está disparando a INTP012 com o campo cpfCnpjDestino sem os zeros a esquerda
- [RRC0008/RRC0021] - HABILITA_INTEROP_0008_0021 (filtro para interoperar sem identdOp)
- RRC0019/RRC0005/ARRC022/RECALCULO - Ajuste no serializado de EC para controlar por CNPJ completo

## 1.64.0 (2021-06-13)

- Versão invalida (desconsiderar)

## 1.63.3 (2021-06-13)

- RRC0006 - ajuste para trativa de exception para validação de participante
- RRC0006/RRC0020/ARRC023 - ajuste para trativa de exception cenários de erro
- [RTC45777] - [R2C3 - RRC0006 / RRC0020 - 1.63.2] - Ao executar alguns cenários da RRC0006 e RCC0020, o sistema retorna o erro ERRC0108
- V_RECLDES / V_RECLPEN- refactorings da desalocação e entregop para envio das RRC0009

## 1.63.2 (2021-06-13)

- [RTC45772] - [R2C3 - RRC0020 - 1.63.1] - Ao executar alguns cenários da RRC0020 no robô, estão retornando o erro java.util.NoSuchElementException: No value present no Atlante
- [RTC45773] - [R2C3 - RRC0020 - 1.63.1] - O sistema esta retornando o RRC0020E sem o código de erro
- [RTC45774] - [R2C3 - RRC0006 - 1.63.1] - É retornado erro de br.org.cipbancos.rrc.exception.ParticipanteAdministradoException ao validar o codErro ERRC0018
- [RTC45775] - [R2C3 - RRC0006 - 1.63.1] - É retornado erro de NullPointerException ao validar o codErro ERRC0160 (IndrCancelVlrTotal = S informando Grupo_RRC0006_RegRecbvl)
- [RTC45776] - [R2C3 - RRC0020 - 1.63.1] - Ao cancelar parcialmente por UR contrato de Cessão ER/PART as frações canceladas continuam ativas e o saldo é enviado para o livre para recalculo de outro contrato que está aguard saldo livre, dessa forma ficam 2 contratos com a mesma fração ativa
- V_RECALCL - Habilitado sub-handler de finalização de operação

## 1.63.1 (2021-06-12)

- RRC006/RRC0020/ARRC023 - ajustes de performance

## 1.63.0 (2021-06-12)

- RRC0021/RRC0008 Deploy Bug RRC008 (ajuste para respeitar o campo  nr_qtd_dia_lmt_ur)
- RRC0021/RRC0008 Deploy Bug RRC008 (ajuste para respeitar o campo  nr_qtd_dia_lmt_ur)
- Compatibilidade com Atlante 5.7.2
- [MELHORIA] - V_MNTIFNC / V_MNTCRED - Ajuste para enviar a hora corrente na dataFim quando o status do participante for INATIVO, previamente o horário estava fixado às 23:59:59.

## 1.62.2 (2021-06-11)

- RRC0019/ARRC022 - Corrigido problema de duplicidade de opt-ins (INTP011)
- Deploy Bug RRC008

## 1.62.1 (2021-06-11)

- RRC0019/ARRC022 - Inclusão da validação ERRC0147
- RRC0019/ARRC022 - Corrigido problema de duplicidade de opt-ins (INTP011)

## 1.62.0 (2021-06-11)

- RRC0019/ARRC022 - Diminuição de consultas de opt-ins
- ARRC018 - Ajustes para não mandar URs duplicadas nos grupos usuário final recebedor e grupo titular
- RRC0005 - Correcao NPE

## 1.61.9 (2021-06-10)

- [PRERECALC] Bypass de operações sem usuário final recebedor

## 1.61.8 (2021-06-10)

- Versão queimada, deu erro no Jenkins e foi para a próxima.

## 1.61.7 (2021-06-10)

- RRC0019/ARRC022 - Otimizado insert em bloco de opt-ins

## 1.61.6 (2021-06-10)

- [RRC0020] [ARRC023] - melhoria de performance
- [RECALCULO] - inclusão tabela de blacklist para ignorar operações marcadas
- RRC0019/ARRC022 - Otimização na verificação da existência de opt-ins já cadastrados ao inserir/alterar operações
- [INTP011] - ajustes para optout não mandar requisição para centralizada, caso a opt-in para optout não exista na base, lançar erro ERRC0174

## 1.61.5 (2021-06-10)

- Versão invalida (desconsiderar)

## 1.61.4 (2021-06-09)

- V_CTZESTC - Alteração para diminuir o volume de envio para a base centralizado
- RRC0019/ARRC022 - Alterado createLateBatch para createBatch quando ocorre erros de envios de INTP010
- Alterado insert de estabelecimentos comerciais para lote

## 1.61.3 (2021-06-09)

- Correçao das consultas na tabelas do schema rrc_ctz 

## 1.61.2 (2021-06-09)

- [RRC0006] [RRC0020] [ARRC023] - Validação de participante diferente da operacao no cancelamento

## 1.61.1 (2021-06-08)

- [RRC0020] - correção da r1 via api
- [RRC0006] [RRC0020] - Validação de participante diferente da operacao no cancelamento

## 1.61.0 (2021-06-08)

- Ajustes varredura V_CTZESTC melhoria de performance
- RRC0019 - Corrigido envio indevido de erro ERRC0081 quando EC esta na CIP e CERC e na operação, gestao participante com alcance geral, foi enviado apenas credenciadora da CIP
- RRC0019/ARRC022 - Inclusão de recurso de timeout para inclusão de EC na tabela de rrc_own.ESTBMNT_PROCSSND
- Particionamento da tabela RRC_CTZ.ESTABELECIMENTO_COMERCIAL em tabelas de ESTABELECIMENTO_COMERCIAL_000 até ESTABELECIMENTO_COMERCIAL_999

## 1.60.13 (2021-06-07)

- [RRC0020] - melhoria de consulta para cancelamento agrupamento das urs e adição de parametro de data_referencia
- [INTEROP] - TRACE ID com parametro (parametro HABILITA_TRACE_ID = 'S') -- necessita da tabela BATCH_TRACE do atlante
- [OPT_IN] - consulta de retorna mais de um registro  (org.springframework.dao.IncorrectResultSizeDataAccessException: Incorrect result size: expected 1, actual 4)

## 1.60.12 (2021-06-07)

- Ajustes varredura V_CTZESTC para montar payloads menores para base centralizada
- RRC0019 - Tratamento de erro para concorrencia no serializador de EC

## 1.60.11 (2021-06-07)

- RRC0010 - (PROD root_id 10000349439) - Caused by: br.org.cipbancos.rrc.exception.ValidationException at br.org.cipbancos.rrc.handler.rrc0010.RRC0010Handler.buscarEstabelecimentoComercial(RRC0010Handler.java:411)

## 1.60.10 (2021-06-07)

- Ajuste do Erro na RRC0019 via API quando existe um espaço no campo agencia ex: " 0983" da erro number format exception. batch 20003333425
- ARRCTIPOS.xsd - Inclusao de hifen (opcional) para CtPgto

## 1.60.9 (2021-06-06)

- INTP007 - Tratamento de erro (batch invalido) de concorrência para enviar contratos com o mesmo id-operacao-efeito

## 1.60.8 (2021-06-06)

- INTP007 - Otimização na conversão da INTP007 para mensagem RRC0019

## 1.60.7 (2021-06-06)

- ARRC031 - melhoria nas consultas de fumaça para quando tem vários usuários finais recebedores
- ajustes para pegar somente participantes ativos na base
- Validações intp007 IdEfeitoContrato e IdContratoExterno

## 1.60.6 (2021-06-05)

- RRC0008(API) - Duplicando resultados na consulta por id operação.

## 1.60.5 (2021-06-04)

- ARRC022/ARRC023 - Tratamento para evitar erro java.io.FileNotFoundException: File '/MIFS_LOGS/.../records.txt' does not exist

## 1.60.4 (2021-06-04)

- [MELHORIA] - V_CTZCRDR / V_CTZCRDD - Ajuste para remover o request paginado a API da centralizada.

## 1.60.3 (2021-06-04)

- ARRC022/ARRC023 - Corrigido a TAG <IdentdPartAdmtd> para RET com interop
- [INTP012] - CIP FALANDO - atualizaçao do campo cpfCnpjUsuarioFinalRecebedorOuTitular, pegando da tabela opt_in e nao do payload da RRC0027

## 1.60.2 (2021-06-03)

- [V_CTZOPIN] - varredura - buscar optins centralizada
- [V_CTZANUE] - varredura - carregar na tabela de opt_in os opt_ins da tabela de stage não existentes na tabela oficial
- [V_CTZANUE] - parametro para rodar automaticamente apos a V_CTZOPIN ou via CONTROLM
- [MELHORIA] - V_MNTIFNC / V_MNTCRED - Ajustes para enviar dataFim quando o status do participante for INATIVO e nome reduzido na razão social.
- [MELHORIA] - V_CTZCRDR / V_CTZCRDD - Ajuste para pegar a data ínicio do range de datas das varreduras a partir da data de última atualização dos participantes mais recente nas tabelas da centralizada.

## 1.60.1 (2021-06-02)

- ARRC018 - Filtrar registros da destinatario_opt_in apenas da CIP. Este tratamento vai evitar o envio de registros duplicados.
- RRC0011 - Banco MOOZ  - não estava interoperando - hext root ids 10085832059 e 10086700000
- Ajuste na tabela de stage de urs de operações participante via API

## 1.60.0 (2021-06-02)

- Compativel com Atlante 5.7.1

## 1.59.3 (2021-06-01)

- ARRC001 - Corrigido ARRC001RET com validação inválida de XSD devido a erros ERRC0055

## 1.59.2 (2021-06-01)

- [EV1150368] - RRC0008/RRC0021 - ajustes paginação

## 1.59.1 (2021-06-01)

- [MELHORIA] - V_MNTIFNC / V_MNTCRED - Ajuste no formato das datas para ISO 8601.

## 1.59.0 (2021-06-01)

- ARRC018 - Retirada da consulta nas frações fumaça para calculo do <VlrPercNegcdConstitr>. Se for operação gravame, utilizar valor da operação senão utilizar 0.0
- [RTC45718] [R2C3 RRC0019 MQ 1.58.1] - Corrigido o processamento da INTP008 quando por percentual e é retornado zero no recebível da outra registradora para não retornar na R1
- NullPointer na CentralizadoraNegocioImpl possivelmente causado por falta esperada de alguma configuração

## 1.58.11 (2021-05-31)

- ARRC001 - (HINT - root_id 21726001) - Corrigido agrupamento de registros no ARRC001
- RRC0019 - (HEXT - root_id 20001800041) - Erro ao processar operação com muitas URs

## 1.58.10 (2021-05-31)

- ARRC018 - ajuste de envio de IndicadorDomicilio
- ARRC018 - Removido as frações (livres com valor zero) inseridas de forma automatica pela ARRC001 (para suportar a constituição das operações)
- RRC0019 - Mudança de subbatch para latebatch do RegistroOperacaoStageSub

## 1.58.9 (2021-05-30)

- ARRC031 - Corrigido agrupamento dos titulares

## 1.58.8 (2021-05-30)

- ARRC031 - Otimização para processar mais JOBs por BATCH

## 1.58.7 (2021-05-30)

- Versão fechada indevidamente

## 1.58.6 (2021-05-30)

- [RRC0008/ RRC0021] - alteração de parametros para quantidade de dias limite de ur de : getNrQtdDiaFumcRecalc / para: getNrQtdDiaLmtUr()
- ARRC031 - Otimização para gerar arquivos muito grandes. Inclusao de delimitador por quantidade de operações baseado na param_sist. TAMANHO_SPLIT_ENVIO_ARRC031

## 1.58.5 (2021-05-29)

- Ajuste ARRC018 para enviar registros apenas de registros da Registradora CIP.

## 1.58.4 (2021-05-29)

- Otimização varredura de envio de EC para base centralizada
- Remoção das triggers para as tabelas destinatario index.
- RRC0019 - api - remoção da obrigatoriedade no swagger da ag para tipo de conta igual a pagamento
- [RTC45718] [R2C3 RRC0019 MQ 1.58.1] - Corrigido o processamento da INTP008 quando por percentual e é retornado zero no recebível da outra registradora para não retornar na R1
- [ARRC001] - [EV1151415] - O participante Crefisa informou que ao realizar o processamento do arquivo ARRC001_06000186_20210526_00001_RET recebeu o erro error on line 22 at column 228653: Opening and ending tag mismatch: Grupo_ARRC001RET_UniddRecbvlRecsdo line 0 and Grupo_ARRC001RET_UsuFinalRecbdr
- INTEROP - TRACE_ID (inserido, mas comentado, está com erros no atlante ainda)
- RRC0008/RRC0021 - ajuste para retornar URs somente dentro do limite parametrizado para frações fumaça (ajuste)

## 1.58.3 (2021-05-28)

- RRC0008/RRC0021 - ajuste para retornar URs somente dentro do limite parametrizado para frações fumaça

## 1.58.2 (2021-05-28)

- ARRC022/RRC0019 - Corrigido serializador de EC
- [EV941591 / EV1147193] - ARRC022/RRC0019 - Tratamento de erro para timeout ao enviar INTP010
- ARRC001/INTP004 - Criado parâmetro para desabilitar o envio da INTP004
- BASE_CENTRALIZADA - Removido UK da tabela RRC_CTZ.ESTABELECIMENTO_COMERCIAL com tratamento de duplicidade nas consultas
- RRC0013 - ajuste para só lançar o erro ERRC0071 se o participante que mandar o cancelamento for o mesmo que tiver operações na base em aberto - HEXT root id 22070183
- item da planilha 392 - RRC0008/RRC0021 - ajuste retornar URs somente dentro do limite parametrizado para o participante na tabela inst_cad
- item da planilha 395 - RRC0008/RRC0021 - ajuste retornar URs somente dentro do limite parametrizado para o participante na tabela inst_cad

## 1.58.1 (2021-05-27)

- [EV731611] - RRC0005 - ajuste só montar o bloco de URL se tiver URs disponiveis para mandar na situação de recusa
- [EV1146434] - O participante Itaú mencionou ter recepcionado a mensagem RRC0009 sem o campo Grupo_RRC009_DomclBanc.
- [RTC45708] - Ao alterar a operação, alterando os dados do domicilio, não há a atualização dos dados do domicilio na tabela de fração
- [RTC45717] - Ao enviar uma operação com titular pelo base é gerado o pedido de agenda(INTP010) sem informar o campo de titular
- ARRC031/ARRC032 - Corrigido quebra de linha antes da TAG <SISARQ>

## 1.58.0 (2021-05-25)

- [EV1151415] - ARRC001 ARRC001_01027058_20210519_09922 - Identificamos no arquivos ARRC001 que está sendo recusado as URs por “ERRC0035 - Valor previsto de liquidação inválido ou não informado” quando enviamos o valor zerado para o saldo restante do EC que possui negociação.
- ARRC001 - Melhoria para não retornar erro ERRC0055 quando o idOp informado na fração de hoje não for o mesmo da fração de ontem.
- INTP011 - Retirada da validação do numero de controle do opt-in na base centralizada.
- RRC0003 - Incluido quebra de linha antes da TAG <SISMSG>
- Remoção da tabela UNIDD_RECBV
- Remoção de consulta de participante por consulta depreciada.

## 1.57.5 (2021-05-25)

- [RTC45704] - [R2C3 - INTP005 v.1.57.4 Atlante v.5.4.0] - Gravame Gestão ER - Sistema está apresentando erro na consulta com contrato titular por CNPJ Base - RRC0019/ARRC022 - Ajuste no processamento da constituicao quando o titular é pelo base e os finais recebedores são pelo completo
- RRC0019/ARRC022 com INTEROP: Inclusão com titular pelo completo e alteração com titular pelo base causava nullpointer na geração de frações fumaça
- [EV1151937] - [ARRC0018] Recebemos um arquivo ARRC0018 com a tag Grupo_ARRC018_NegcRecbvOutrasInst / PriorddNegcRecbvl duplicada. Problema relacionado ao controle de processamento por EC causando processamento concorrente nas URs
- Alteração na inserção da destinatário recálculo, para inserir apenas as frações contituídas.
- [EV1150486] - RRC0010 - Alteracao do metodo obterIdPartPorNrCnpj
- [EV1148201] - RRC0010 - Alteracao do metodo obterIdPartPorNrCnpj
- ARRC031 - Ajuste para quebra de linha (incluir credenciadoras na param_sist ISPBS_LINE_FEED_HABILITADOS)

## 1.57.4 (2021-05-23)

- ARRC022/ARRC023 - Corrigido geração de RET quando ocorre reproc de BATCH

## 1.57.3 (2021-05-22)

- EV1150368 [RRC0021]  BRADESCO - Na primeira chamada da RRC0021, enviamos parâmetro de chamada para pagina 001 / 50 urs de retorno.
- [item 116 da planilha] - [INTEROP] erro 204 não mapeado
- Funcionalidade: RRC0019 [ROOT 325095102/323991103] -  O participante Sofisa realizou o envio de duas inclusões de contrto e não identificamos o retorno.
- [EV1146416] RRC0019 SICOOB - O participante SICOOB realizou o envio de três contratos e identificou os erros abaixo, poderiam verificar?
- Ajustes recalculo para evitar deadlock em HEXT e finalizar a varredura

## 1.57.2 (2021-05-21)

- RRC0019/ARRC022 - Alcance Geral - Retirada dos ECs com arranjos inativos

## 1.57.1 (2021-05-21)

- Remoção da PK da tabela destianatario_recalculo e remoção o insert com "on conflict".
- ARRC023 - HEXT (root_id 20027531000) - java.lang.NullPointerException	buscarPorRecebivel(FracaoUnidadeRecebivelOperacaoDAOImpl.java:852)

## 1.57.0 (2021-05-21)

- [RTC45609] - Ajuste na geração da RRC0018 na inclusao das frações do Grupo_RRC0008R1_Constitr.
- [RTC45685] - Sistema está retornando as frações fumaças de diferentes domicílios no mesmo Grupo_ARRC031_DomclBanc
- [RTC45686] - Sistema está retornando as frações fumaças de diferentes Titulares no mesmo Grupo_ARRC031_Titlar
- [RTC45684] - [R2C3 - RRC0003 - 1.55.3] - Mensagem RRC0003 não está respeitando o parametro nr_qtd_dia_lmt_ur = 5 e está retornando 3 frações fumaças a mais
- [RTC45672] - [RRC0003] Sistema está retornando apenas frações fumaças de 3 dias úteis na msg RRC0003 disparada após o recalculo
- ARRC001 - Substituido consulta na REFERENCE_DATE por chamada ao método context.getPreviousReferenceDate();
- RRC0003 - Ajuste para somente mandar fração se ela não estiver liquidada
- V_ARRC031 - Inclusao dos estimulos de varredura no diretorio /ativvar
- V_CRDDOFF - Inclusao de varredura para credenciadora offline
- Compativel com atlante 5.4.0

## 1.56.2 (2021-05-20)

- V_ROLAGEM - HEXT (root_id 20024569000) - org.springframework.dao.IncorrectResultSizeDataAccessException: Incorrect result size: expected 1, actual 2

## 1.56.1 (2021-05-20)

- ARRC018 - HEXT (root_id 20024439000) - org.postgresql.util.PSQLException: ERROR: relation "op" does not exist
 
## 1.56.0 (2021-05-20)

- [RTC45698] - Ajuste ARRC018 - Enviado CNPJ registradora incorreto no grupo NegcRecbvlInst(operação)
- Compativel com atlante 5.3.0
- INTP005E - Finalizar Interop quando agenda posição enviada com erros estruturais (json)

## 1.55.17 (2021-05-19)

- [RRC0019/ARRC022] - Corrigido envio de INTP011 para os opt-ins automaticos

## 1.55.16 (2021-05-19)

- [RRC0019/ARRC022] - Ajuste no filtro de pedido de agenda para não ser feito se gestão participante "alcance geral"

## 1.55.15 (2021-05-19)

- [RRC0005] - Sempre enviar a 0003 para operações que são alteradas para penhora
- [RTC45696] - INTP010 - HINT (root_id 21438004) - org.postgresql.util.PSQLException: ERROR: missing FROM-clause entry for table "op"

## 1.55.14 (2021-05-19)

- [EV1146578] - RRC0005 - Correcao operacao recusada sem codigo de erro
- [EV994998] - RRC0019/ARRC022 - O Participante Sofisa informou que está recebendo agenda de credenciadoras que ele não solicitou opt-in
- [RTC45670] - [R2C3 RRC0010/INTP005 API 1.54.0] br.org.cipbancos.atlante.output.http.config.impl.OutputHttpConfigurationItemException
- ARRC031 - Inclusao da propriedade OutputHandle.OUTPUT_CUSTOM_MASK nos arquivos ARRC031 gerados
- EV1150368 [RRC0021]  BRADESCO - Na primeira chamada da RRC0021, enviamos parâmetro de chamada para pagina 001 / 50 urs de retorno.

## 1.55.13 (2021-05-18)

- RRC0019/ARRC022 - Retirada de chamadas desnecessarias para a base centralizada

## 1.55.11 (2021-05-18)

- RECALCULO - Operações que não possuem titulares válidos não serão recalculadas;
- RRC0019/ARRC022/RRC005 - Validação para não permitir operação com valor zero
- [EV671351] - ARRC022 - sem ret por base centralizada indisponível.
- [EV1146436] - RRC0013 - O participante Bradesco está tomando o erro EGEN0050 ao tentar realizar um OPT-OUT.
- [RTC45689] - R2C3[1.55.5]-ATL[5.1.90] - Varredura V_ARRC018 - INTEGRADO - Erro ao enviar agenda CIP ouvindo
- INTP006 - Notificação pós contratada post - cip ouvindo - Validação incorreta
- RRC0015 - O participante Getnet mencionou estar recebendo a mensagem de abertura após as 13h mas com o texto da mensagem informando sempre o horario das 13h.
- RRC0016 - O participante Getnet mencionou estar recebendo a mensagem de abertura após as 13h mas com o texto da mensagem informando sempre o horario das 13h.
- RRC0019/ARRC022 - Inclusao de validação (ERRC0081) das registradoras do EC com as registradoras das credenciadoras da opeação (Gestão Participante)

## 1.55.10 (2021-05-17)

- RRC0005 - Ajuste para HEXT

## 1.55.9 (2021-05-17)

- Remoção da atualização de EC quando consultado na base centralizada

## 1.55.8 (2021-05-17)

- Recalculo - HEXT - Corrigido datasource de acesso à fração

## 1.55.8 (2021-05-17)

- Ajuste RRC0022 quando te retorno vazio de estabelecimentos comerciais ou erro na busca da base centralizada.

## 1.55.7 (2021-05-17)

- V_PRERCL1/V_PRERCL2 - HEXT - Incluido filtro para processar apenas operações da CIP
- RRC0019 (API) - Inclusao de validação para obrigar o envio de pelo meno 1 usuario final recebedor

## 1.55.6 (2021-05-17)

- INTP010/RRC0010 - HEXT - Bugfix para 1000 tabelas

## 1.55.5 (2021-05-17)

- HEXT - Bugfix para 1000 tabelas

## 1.55.4 (2021-05-17)

- RRC0020 - tratativa para cancelamento parcial por titular via interop
- RTC-45685 - [R2C3 - ARRC031 - 1.55.2] - Sistema está retornando as frações fumaças de diferentes domicílios no mesmo Grupo_ARRC031_DomclBanc
- RTC-45686 - [R2C3 - ARRC031 - 1.55.3] - Sistema está retornando as frações fumaças de diferentes Titulares no mesmo Grupo_ARRC031_Titlar

## 1.55.3 (2021-05-16)

- salvando apenas payloads necessários na base
- ajustes testes integrados
- item da planilha 324 - RRC0010 - sem retorno de informações dentro do arquivo - HEXT root id 342055151
- [EV1148201] - RRC0010 - sem retorno de informações dentro do arquivo - SAFRA HEXT root id 348477131 e 347735112
- [RTC45649] - [R2C3 RRC0010 API / MQ alcance geral 1.53.11] O sistema retorna RRC0010R1 com SitReqRet = 4 na consulta de EC com URs na CIP e na CERC
- [RTC45668] - [R2C3 RRC0010 MQ/API INTEROP 1.54.0] Consulta como Cielo (CIP) retorna agenda da Stone (CERC)
- [RTC45676] - [R2C3 RRC0021 1.55.1] Consulta por IdentdOp para gravame com mais de um grupo titular retorna br.org.cipbancos.atlante.worker.RecordHandlerInvocationException: br.org.cipbancos.atlante.fw.ApplicationInvocationException: java.lang.NumberFormatException: null

## 1.55.2 (2021-05-15)

- Ajuste na 0021 referente a busca por titular.

## 1.55.1 (2021-05-15)

- [EV1030797] - RRC0013 - Ajuste na validação de opt-out para o caso de operação cadastrada sem cnpj creddr ou sem arrjo
- [RTC45674] - Corrige o erro do sistema está retornando a tag CPF_CNPJPartNegcdr com o CNPJ da CIP 29011780000157 na ARRC031
- [RTC45675] - Alteracao do layout da ARRC032


## 1.55.0 (2021-05-15)

- INTP004 Cip falando - Indicador ordem efeito 0 quando a fração está liquidada.
- Melhoria 1000 tabelas FRACAO_UNIDD_RECBV_OP
- [RTC45674] - Corrige o erro do sistema está retornando a tag CPF_CNPJPartNegcdr com o CNPJ da CIP 29011780000157 na ARRC031

## 1.54.0 (2021-05-14)

- ARRC001 - Coloca e-mail de RES:  Resolução 4734 - Dúvida Gravame - Valor da Garantia Constituida - 12/05/2021 - (Ajuste para lançar erro ERRC0035 qunado valor previsto de liquidação menor que zero)
- [EV1147685] - RRC0010 - não estava enviando interop para todas as consultas - HEXT rootId 330845141
- [45663] - [R2C3 - ARRC031 - 1.53.14] - Tags IndrTpOpOrigem e Grupo_ARRC031_OpOrigem são enviadas mesmo o contrato sendo um simples Gravame sem operações de Cessão sobre Gravame ou Renegociação
- [45664] - [R2C3 - RRC0003 - 1.53.14] - Sistema não está retornando a fração fumaça do 5º dia útil na RRC0003
- [45665] - [R2C3 - ARRC031 - 1.53.14] - Sistema está retornando todas as frações fumaça do contrato, não deveria retornar as fumaças enviadas na msg RRC0003
- [45666] - [R2C3 - ARRC031 - 1.53.14] - Para cada fração fumaça do contrato, é enviado um grupo Grupo_ARRC031_NegcRecbvl no arquivo ARRC031

## 1.53.14 (2021-05-13)

- RRC0019 - Correcao NPE inclusao gravame
- ARRC031 - Redução do tráfego da mensagem RRC0003
- [EV1147668] - RRC0021 - na consulta de UR voltar apenas uma UR para consulta

## 1.53.13 (2021-05-13)

- [EV1146709] - Funcionalidade: RRC0010 - bilateral  Roots: (315551102 / 315594102 / 315609100 / 315609101 / 315595101 / 315627100 / 315653101 / 315690100 / 315767108 / 315763114 / 315808100 / 316158101 / 316291100 / 316333100 / 316336100 / 316339100 / 316395100 / 316400100 / 316453100 / 316466101 / 316502101 / 316511100 / 316522100 / 316542100)  Safra realizou alguns envios mas não geramos retorno.
- [EV1147193] - ARRC022 - sem ret
- [EV941591] - [ARRC022 / RRC0019] -  o participante Banco do Brasil encaminhou algumas operações de gravame, no entanto, não geramos o retorno.
- [EV729971] - Validacao 'inserir anuencia' antes do envio
- [EV1147069] - RRC0019 - Nullpointer do Itau (NUOPs: 90400888202105120814326-90400888202105120814331, L0CQ0CQ1210512048467-60701190202105123185187, L0CQ0CQ1210512048468-60701190202105123185188, L0CQ0CQ1210512048469-60701190202105123185190, L0CQ0CQ1210512048471-60701190202105123185192, L0CQ0CQ1210512048472-60701190202105123185193, L0CQ0CQ1210512048472-60701190202105123185193, L0CQ0CQ1210512048475-60701190202105123185196, L0CQ0CQ1210512048474-60701190202105123185195, L0CQ0CQ1210512048474-60701190202105123185195, L0CQ0CQ1210512048476-60701190202105123185197)

## 1.53.12 (2021-05-12)

- EV1147212 - Gravame e Cessao ER com aceite incondicional e alcance específico deve gerar fumaça sempre
- RRC0008/RRC0021 - verifica se a agenda já está no cache antes de fazer interop e pedido de agendas
- item 275 da planilha - INTP007/INTP0008 - HEXT ROOT 164793144 A CERC informou ter recebido o callback de Contrato informando Erro 0056
- INTP004/INTP005 - Envio de contratos CIP com ofuscamento de informações

## 1.53.11 (2021-05-11)

- [EV1143917] - RRC0010 - fluxo com interop pedido de agenda é para todas as credenciadoras do cache + todas as credenciadoras que possuem agenda no dia

## 1.53.10 (2021-05-11)

- [EV994998] - [RRC0019] - O Participante Sofisa informou que está recebendo agenda de credenciadoras que ele não solicitou opt-in
- [EV941591] - RRC0019/ARRC022 - Agora o pedido de agenda é para todas as credenciadoras do cache + todas as credenciadoras que possuem agenda no dia
- CRE2055L - Problema na RRC0019 - CERC (sem evento) - Valor zerado na fração

## 1.53.9 (2021-05-10)

- [RTC45636] - [R2C3 - ARRC002/RRC0006 - 1.53.7] - Sistema está retornando erro de NullPointer Exception ao enviar baixa de URs cedidas ou ao cancelar parcialmente pela RRC0006 uma UR num contrato de Antecipação
- RRC0010 - API - Correção fluxo interop

## 1.53.8 (2021-05-10)

- [PLANILHA-273] - RRC0020 / RRC0029 - VOTORANTIM ROOT 178655202, RRC0029 sendo enviada para o participante administrado ao invés do principal
- [INTP004]  RTC45633 - [R2C3 - INTEROP post/agenda R2C3[1.53.7]-ATL[5.1.89] - CIP Ouvindo -  Sistema esta retornando java.lang.NullPointerException quando não preenchido campo digito/conta

## 1.53.7 (2021-05-08)

- V_RECALCL - HEXT (root_id 270334100) - java.lang.NullPointerException

## 1.53.6 (2021-05-08)

- RRC0019/ARRC022/RRC0005 GEST ER e RECALCULO - Ao inativar uma fração, o hash não estava sendo atualizado causando duplicatekey nas alterações
- RRC0019/ARRC022/RRC0005 GEST ER e RECALCULO - Ajuste na logica para saber se a operação está sozinha na UR ao definir se vai ou não utilizar a mesma
- RRC0019/ARRC022/RRC0005 GEST ER e RECALCULO - INTP007 - Ajuste na montagem do payload quando a operacao é por percentual
- RRC0019/ARRC022/RRC0005 GEST ER e RECALCULO - Ajuste na montagem do bean para não incluir dados inativos da operação;
- Ajuste INTP011 onde ocorre erro null ou optOut devido a não ter credenciador e esta nulo quando vai buscar no banco.
- [EV723238] - ajuste na INTP005 para não recusar a agenda inteira quando recebermos URs duplicadas

## 1.53.5 (2021-05-07)

- RRC0019 - HEXT (batch_id 197394126) - java.lang.NullPointerException at java.base/java.util.LinkedList$ListItr.next(LinkedList.java:897)
- Ajuste na INTP004 para mandar titular do contrato e não titular da conta no grupo efeito contrato - HEXT root ID 192107

## 1.53.4 (2021-05-07)

- [RTC45576] - Sistema não volta o saldo de contrato de cessão cancelado parcialmente para o saldo livre
- [RTC45626] - RRC0021 - Remover chamada duplicada para o RRC0021Handler que impactava a consulta sem idOp

## 1.53.3 (2021-05-06)

- RRC0019 - HEXT (batch_id 191689103) - Banrisul - java.lang.ArithmeticException: / by zero
- ARRC023 - HEXT (batch_id 191239109) - org.springframework.dao.IncorrectResultSizeDataAccessException: Incorrect result size: expected 1, actual 3

## 1.53.2 (2021-05-06)

- [NPE_NR_AG] - ARRC018 - Correcao NPE quando nr_ag nulo.
- [EV654265] - RRC0010/RRC0020 - Envio do correlationId para retornos de mensagem de INTEROP

## 1.53.1 (2021-05-06)

- [RTC45576] - Sistema não volta o saldo de contrato de cessão parcialmente para o saldo livre
- [RTC45565] - Sistema está constituindo as mesmas URs para 2 contratos diferentes na chamada do recalculo após cancelamento parcial por UR.
- [EV665850] - RRC0019/ARRC022 RECALCULO - Retornos da INTP008 quando por percentual e é fumaça agora deve considerar que se 100% significa que continua fumaça.
- [EV669055] - INTP005 - validação da agencia em brancoS
- RRC0019/ARRC022 Alteração e RECALCULO - Ao alterar uma operação que possua frações liquidadas, estas estão sendo consideradas como constituida
- [EV723238] - ajuste na INTP005 para não recusar a agenda inteira quando recebermos URs duplicadas
- [RTC45619] - ARRC018 - Alterado o preenchimento do CNPJER a partir da fracao op 0 ao inves da UR com fracao op 0

## 1.53.0 (2021-05-05)

- [EV654265] - RRC0019 - Envio do correlationId para retornos de mensagem de INTEROP
- RRC0019/ARRC022 - Corrigido tratamento de interop para agendas recusadas em que a operação foi aceita

## 1.52.14 (2021-05-05)

- RRC0019/ARRC022 - Tratamento de erro ERRC0045 quando enviado renegociação
- [RRC0003] - Criado parâmetro para filtrar fumaças dentro de um número de dias, exclusivo para varredura de recálculo

## 1.52.13.1 (2021-05-05)

- INTP011 - Inclusao de parametro HABILITA_INTP011_VALIDACAO_BASE_CENTRALIZADA

## 1.52.13 (2021-05-04)

- INTEROP - Refactoring do mecanismo
- [EV1030797/EV671839] - RRC0013 - Correção de BadSqlGrammarException no caso de opt-in com cnpj base
- [EV648417] - ARRC018 / INTP004 - Removida PK da fração para evitar conflitos na gravação de agendas interop com liquidações com dados iguais

## 1.52.12 (2021-05-03)

- [EV1030797/EV671839] - RRC0013 - Ajuste na validação do opt-out para não se basear mais nas frações, e sim nas tabelas de registro das operações
- [EV672005] - ARRC001 - Ajuste na recepção da agenda para contratos por percentual

## 1.52.11 (2021-05-03)

- EV668886 - ARRC023 - HEXT (root_id 150341150) - Ret com recusado, mas com IdentdOpCancel
- [RTC45612] - INTP004 - CIP Ouvindo -  Sistema não está aceitando letra campo digitoConta

## 1.52.10 (2021-05-03)

- EV671351 - ARRC022 - HEXT - Arquivos sem RET

## 1.52.9 (2021-05-03)

- ARRC023 - HEXT (root_id 140114181) - java.lang.ClassCastException: class org.apache.xerces.dom.ElementImpl cannot be cast to class java.lang.String

## 1.52.8 (2021-05-03)

- [EV940060] - RRC0021 / RRC0008 (consulta retornando dados da operação como fração onde não deveria (/unidades-recebiveis-a-constituir, /unidades-recebiveis))
- [EV1030626] - RRC0021 / RRC0008 (consulta retornando dados da operação como fração onde não deveria (/unidades-recebiveis-a-constituir, /unidades-recebiveis))

## 1.52.7 (2021-05-03)

- ARRC001 - HEXT (root_id 134413100) - java.util.ConcurrentModificationException

## 1.52.6 (2021-05-02)

- ARRC018 - Safra - Problema de opt-in nao gerando ARRC018

## 1.52.5 (2021-05-02)

- [EV872678] - Ajustes na centralizadora para pesquisa de Estabelecimento Comercial de Documento OnLine - HEXT root 125142105

## 1.52.4 (2021-05-02)

- ARRC018 - HEXT (root_id 122873100) - java.lang.IllegalStateException: Duplicate key 3999999990001644 (attempted merging values R and T)

## 1.52.3 (2021-05-02)

- [RTC45616] - Não valida o campo idEfeitoContratosRenegociados - INTP007
- [RTC45578] e [RTC45579] - validação contrato
- [EV651579] - BufferOverflow - trocada a estrutura que armazena os bytes de interop
- [EV936808 / EV846420] - ARRC023 - Participante ABC realizou o cancelamento de diversos contrato e foram gerados varios arquivos RET
- [PLANILHA-249] - ARRC023 - Participante Industrial realizou o envio de um cancelamento de contrato e não foi gerado RET
- ARRC001 - NullPointerException em HEXT (root_id 118565101)

## 1.52.2 (2021-05-01)

- ARRC001 - NullPointerException em HEXT (root_id 118565101)

## 1.52.1 (2021-04-30)

- EV665845 - Ajuste das prioridades das fumaças para URs não encontradas que sairam e voltaram para a operação
- Correcao BUG Paginacao RRC0010
- [EV872678] - Ajustes na centralizadora para pesquisa de Estabelecimento Comercial de Documento OnLine
- [R2C3 - RRC0008 - 1.51.2] - Frações Fumaça que ficaram de fora do range de 5 dias úteis confgurado para o Participante são retornadas no Grupo_RRC0008R1_RegRecbvl

## 1.52.0 (2021-04-30)

- EV1032478 - Gravame Gestão participante com aceite incondicional deve gerar fumaça mesmo sem agenda
- INTP007/INTP008 RRC0019/ARRC022 - Refatoração para melhoria de performance
- Correção da paginação nas mensagens RRC0008, RRC0010 e RRC0021
- Criação de XSD para ARRC031 e ARRC032 
- Redução de trafego RRC0003
- [RTC45592] - nullpointer se eu enviar indicador de regra de divisão = 'v' minúsculo por api
- [RTC45607] -  validação do campo conta em branco INTEROP
- [RTC45612] - INTP004 - CIP Ouvindo -  Sistema não está aceitando letra campo digitoConta

## 1.51.4 (2021-04-30)

- [EV1002061] - ARBU
- Item 233 da planilha... no credisan
- [EV1030626] - FUNCIONALIDADE:RRC0021  ID ROOT:101995163 E 101985163   CIP está retornando um JSON incompleto
- [RRC0019] - API - remoção do prefixo /api no link relacionado enviado na resposta das operações
- [RTC45610] - digito não obrigatório para INTP004
- Problema indentificado em HEXT root 106153100 - inserir anuencia online - quando data fim é igual a data de referencia do sistema foi adicionado tratativa para colocar data fim igual ao dia seguindo 
- [RRC0008/RRC0021] - EV848665, EV940060, EV1002652, EV750858, EV1030626, EV840744


## 1.51.3 (2021-04-29)

- [RTC45605] [INTEROP] - INTP002 - 12 conta invalida Tipo CI, CG
- [EV669055] - validação de credenciadoras
- [RTC45607] - conta em branco
- [RTC45608] - campo dígito obrigatório
- [RTC45585] - [RRC0008] / [RRC0021] - Nullpointer no mapa das consultas
- [INTEROP] - Ajuste no retorno das mensagens de error
- [EV671351] - ARRC022 -ROOT 13388170/13565101/13388163/13421157/13468158/13419115 O participante Rendimento encaminhou diversos arquivos ARRC022 via CD e transmitimos o retorno do arquivo (RET) 
- [EV932937] - RRC00019 - Funcionalidade: RRC0019 NUOPS - 61186680202104230090003, 61186680202104230090004, 61186680202104230090005, 61186680202104230090006 Mensagem sem processamento e sem R1
- [EV996420] - RRC0019 - Funcionalidades: RRC0019 ROOT 93431106 O participante Sofisa enviou uma inclusão de contrato pra TAG e não identificamos a geração da R1.
- [EV671839] - RRC0013 - Inclusão de verificação se o códArranjo do opt_in manual bate com o da operacao ativa para junto com outras validações lançar o erro ERRC0071
- [EV1002061] - RRC0019 - Participantes BS2, ARBI e CREDISAN - sem resposta de RET ou R1 do arquivo - ajustes feitos na INTEROP para mandar retorno mesmo quando recebemos alguma interop com erro

## 1.51.2 (2021-04-28)

- V_Rolagem - ajuste na query rolarFracaoNaoConstituidaSemAgendaAtual para não usar a tabela Unidade de Recebivel e usar a tabela de Fracao Unidade Recebivel.
- [RTC45570] - [R2C3 - INTEROP RRC0010 v.1.48.3 - Atlante v.5.1.79.9] - RRC0010R1 - INTEROP está trazendo vazio o retorno da consulta
- [RTC45595] - [R2C3 - INTP011 v1.51.0 - Atlante v5.1.79.11] - CIP Ouvindo - Está gravando o id da registradora ao invés do ID do participante na tabela opt_out
- [EV588581 / EV619657 / EV594413] - RRC0010 / INTP010 - Consulta pelo cnpj base está enviando o base na interop ao invés do cnpj completo
- INTEROP - Ajuste de campo conta + dígito (CIP OUVINDO)
- [RTC45585] - [RRC0008] / [RRC0021] - Nullpointer no mapa das consultas
- [INTP004] - fração salvando dados no nrct e não em cr_ct_pgto em conta pagamento
- ARRC018/DestinoOptInLateBatch - Adicionado lista de titulares à UR reduzida para avaliar destinos corretos no late batch.
- Redução de trafego RRC0003 e RRC0008 - Inclusão da regra para efetuar a conta de dias apenas para dia úteis, desconsiderando o final de semana.

## 1.51.1 (2021-04-27)

- RRC0019/ARRC022 - INTEROP [INTP011] - NullPointer cnpjRegistradora
- [RTC45590] - [R2C3 - RRC0005 - 1.50.4] - Msg RRC0005R1 de Antecipação não é finalizada no atlante e são disparadas 3 RRC0009 e RRC0003 com os dados do contrato de Gravame  OG PART afetado pela antecipação
- Ajuste na rotina de recalculo para o arquivo RRC0005 Gestão ER

## 1.51.0 (2021-04-27)

- INTEROP - Refactoring
- RRC0005/RRC0019/ARRC022 - Controle de processamento por EC
- ARRC001 - Tratamento para data limite de data prevista de liquidacao (01-01-2099)

## 1.50.6 (2021-04-27)

- RRC0005 - [EV675661-EV650938 ] **Reserva PARTICIPANTE** com aceite incondicional agora gera todas as fumaças independente do cache
- [RRC0003 e RRC0008] - Redução do tráfego de dados
- DestinoOptInLateBatch - Ajuste devido a rejeições de agenda com código de erro 0029. Filtrados os resultados que retornam sem o numero de controle da cetralizada
- [RTC45590] - [R2C3 - RRC0005 - 1.50.4] - Msg RRC0005R1 de Antecipação não é finalizada no atlante e são disparadas 3 RRC0009 e RRC0003 com os dados do contrato de Gravame  OG PART afetado pela antecipação

## 1.50.5 (2021-04-25)

- V_RECALCL - Separação de JOBs por CPF-CNPJ-BASE
- [RTC45570] - INTP011/RRC0010 - Ajuste no cadastro do idPartAdm de opt_in na base de dados quando enviado pela INTP011 (antes estava gravando o idPartAdm da registradora)
- Ajustes recalculo para envio da 003 e 009
- [RTC45587] - [R2C3 - RRC0021 - 1.50.4] - O sistema esta retornando NullPointerException
- [EV632376] - script para limpar a base com dados a mais na tabela op_titular_creddr
- [EV872678] - script para inativar opt_int da Lista Credencidora

## 1.50.4 (2021-04-23)

- RRC0019/ARRC0022 - Correção da persistencia da operação quando alteração
- RRC0019/ARRC0022/RRC0005 - Correção da persistencia da operação quando alteração
- RRC0019/ARRC0022 ERRC0051 deve ser lançado ao mudar o alcance do contrato na alteração
- [ARRC018] Inclusao da flag ORIGEM para quando for RECALCULO buscar as informacoes na tabela DESTINATARIO_RECALCULO
- [RTC45570] - RRC0010 - Ajuste na RRC0010R1 que estava saindo sem corpo e com sitReq=1
- [MELHORIA] - RRC0020 - Implementado erro 'SLA de resposta atingido' para cancelamentos via API.
- [MELHORIA] - V_MNTCRED - Ajuste no json da centralizada para aceitar respostas com HttpStatus = 400 - BAD_REQUEST.
- [MELHORIA] - V_CTZCRDD - Inclusão de logs para acompanhamento de exceções na gravação das credenciadoras nas tabelas inst_cad e part_cad.
- Ajuste na dinâmica do recalculo da 005 e 019 de forma a usar as URs como base para achar as operações para recalcular/mandar a 003/009

## 1.50.3 (2021-04-22)

- [EV729464] - RRC0008 GETNET Funcionalidade: RRC0008 - Na verdade o problema era na RRC0019/ARRC022 por percentual. Favor rodar uma regressao
- [item 183] - ARRC023 - Corrigido envio de RET com operações aceitas/recusadas quando ocorre interop

## 1.50.2 (2021-04-22)

- V_RECLDES - HEXT - Erro 59596437

## 1.50.1 (2021-04-22)

- V_RECLDES - HEXT - Erro 59596437

## 1.50.0 (2021-04-22)

- [EV671069] - Ajuste no processo de constituicao para subtrair corretamente o valor solicitado na UR quando constitui mais de uma fração
- [EV786516] - CIELO - ITEM 174 - RRC0005 Penhora: Estava validando domicílio do gravame e não deveria
- [EV671069] - Ajuste no processo de constituicao para subtrair corretamente o valor solicitado na UR quando constitui mais de uma fração
- [EV786516] - CIELO - ITEM 174 - RRC0005 Penhora: Estava validando domicílio do gravame e não deveria
- [EV727180 / EV748378] - RRC0010 - Inclusao de tratamento de erros nao previstos ao consultar ECs na base centralizada
- [EV660811] - RRC0020 - Ajuste para enviar a RRC0003 somente das operações afetadas pelo cancelamento - Gestão Participante
- [RTC45572] - RRC0010 - Ajuste na RRC0010R1 para mostrar o "GrupoRRC0010R1DomclBancInst" via MQ e o "domicilios" via HTTP no caso de participante administrado igual participante operacao (IF)
- [EV751353] RRC0018 - Ajuste VlrOnusResTec
- [EV750858 / EV721212 / EV722920 / EV723343 ] - RRC0008 / RRC0021 - consultas sem retorno, mas com status 200
- [EV671839] - Ao enviarmos um OPTOUT, a CIP está retornando o erro ERRC0071 para arranjos que não possuem contrato ATIVO
- [RTC45563] - [R2C3 - ARRC002 - 1.47.4] - Sistema está retornando erro de PSQLException: ERROR: syntax error at or near ")" ao enviar ARRC002 com UR liquidada
- [RTC45564] - [R2C3 - ARRC002 - 1.47.4] - Sistema está retornando erro deNoSuchElementException: No value present ao validar as regras ERRC0015, ERRC0030, ERRC0031 e ERRC0018
- [EV731611] - RRC0005 - Favor verificar o porque a chamada GET para consultar o ecebiveis após recusa da operação voltou com o codigo API "404"

## 1.49.0 (2021-04-20)

- [EV668886 / EV681603 / EV759377 / RTC45533] - ARRC023 - Rendimento informa que enviou arquivo sem RET.
- [EV665859] - Devolvemos com erro 060, mas na TAG de aceite da operação em vez da tag recusada  - Root 4765100
- [EV672032 / EV668243] - ARRC022 - Corrigido envio de RET com operações aceitas/recusadas quando ocorre interop e/ou quando não há envio de resposta pelas outras registradoras

## 1.48.3 (2021-04-19)

- RRC0005 Ajustes na fumaça da Penhora (EV675907 Penhora Gestão PART - NOK)
- [EV642446] - INTP008 - Validacao do campo NrVlrLivreConst > 0 para calculo do vlrSolicitadoInterop
- [EV671839] - Ao enviarmos um OPTOUT, a CIP está retornando o erro ERRC0071 para arranjos que não possuem contrato ATIVO

## 1.48.2 (2021-04-17)

- Ajuste Recalculo no addJob
- Ajustes no recalculo para mandar a 003 e para corrigir erro em hext root id 37779131

## 1.48.1 (em andamento)

- [EV675907] - RRC0005 - **Penhora** com aceite incondicional agora é aceita sempre, gera todas as fumaças independente do cache e não dá os erros 0205 e 0060
- [EV675661 / EV650938] - RRC0005 - **Reserva** com aceite incondicional agora gera todas as fumaças independente do cache

## 1.48.0 (2021-04-17)

- INTEROP - Retirada da gravação em disco dos arquivos de interop
- [EV672032] - ARRC022 - Corrigido envio de RET com operações aceitas/recusadas quando ocorre interop
- [EV664146] - RRC0010 - Inclusão de item "operacoesOutrasInstituicoes" na RRC0010R1 da consulta online via HTTP
- [RTC45494] - [R2C3 - RRC0008 - 1.41.1] - Sistema informa SitRetReq 1 quando deveria informar SitRetReq 4
- [EV671351] - Envio de retorno de mensagem 022RET para canal API

## 1.47.4 (2021-04-16)

- [EV675355] - Ajuste no processamento da INTP008 que estava criando fumaça indevidamente.
- [EV672823] - Inserir anuência online estava mandan horarios nas datas errado - atualizado DTINI para retornar sempre 00:00:00.000 e DTFIM para 23:59:59.999
- [EV652298] - RRC0019 / ARRC022 BTG Cenario 2 - BTG - Nas operações de Gravame utilizando valor, o retorno está apresentando dois blocos, sendo Registo Recebível e Constituir. Como devemos interpretar essa operação, como acatada ou fumaça? NUOP 30306294202104070028739
- [EV701050] - ARRC018

## 1.47.3 (2021-04-16)

- Ajuste nas varreduras de preRecalculo/Penhora/Desalocação para aceitar parametro com id Op para testes em HINNT 
- Ajustes no recalculo de Alteração para pegar as operações pelas URs para o Arquivo ARRC002
- [EV670842] - Ajuste na RRC0019/ARRC022 estava tentando gravar na fração no campo NR_PERC_CALC valores a cima de 100%
- [EV645378] ARRC018 - Informar o CNPJER da responsável pela agenda
- [EV652632] - Participante Getnet realizou uma inclusão e um cancelamento no dia 07.04, na consulta deveria retornar dados do contrato cancelado

## 1.47.2 (2021-04-15)

- RRC0019/ARRC022: Ajustes na logica para utilizacao do cache de credenciadoras para o alcance geral e solicitação de agenda
- [EV650710] - RRC0008 - Ajuste no retorno da API na RRC0008 quando a resposta ainda não se tem a resposta da requisicão
- [EV667239] - RRC0019

## 1.47.1 (2021-04-14)

- RRC0021 - Ajuste no retorno de consultas quando a fração está vazia.
- Ajuste na geração da RRC0010E - envio para o destinatário correto
- Ajuste na INTP013 - Otimização da query de atualização de status do opt-in

## 1.47.0 (2021-04-13)

- RRC0010 - Inclusao de parametro HABILITA_TABELAS_INDICES_RRC0010 (padrao = N) para otimizar as consultas
- RECALCULO - Melhorias e integração com as rotinas de totalizacao
- INTP004/INTP005 Cip Ouvindo: criação da fração livre quando esta não vem nas agendas  
- RRC0005 - API: Corrigida a montagem do bean que é passado para o handler.
- MELHORIA - V_RECLPEN - Recalculo de Penhora
- [EV652025] - RRC0010 - O participante Santander realizou o cancelamento total de uma operação e ao realizar a consulta da agenda do EC, os valores das URs não foram informados no campo VlrLivre e VlrLivreTot
- [INTEROP] correção de logs/remoção de locks nas tabelas interop
- [INTEROP] INTP004 adicionada validação cc sem agencia.

## 1.46.1 (2021-04-13)

- RRC0019/ARRC022 - Corrigido validação de credenciadora para retornar apenas credenciadoras ativas
- EV650874/EV665073 - Erro ao gerar resposta R1 durante interop (INTP010 / INTP005) quando a solicitação chega pelo canal MQ
- EV653997/EV653986 - RRC0019/ARRC022 - Corrigido efetivação da operação (RRC0019R1) quando há agenda em credenciadora da CIP e não há agenda para credenciadora das outras registradoras
- RRC0019/ARRC022 - Corrigida consulta na tabela ESTBMNT_COMCL para retornar ECs com agenda e assim enviar corretamente a INTP010 (se alguma vez enviou agenda para credenciadora)

## 1.46.0 (2021-04-11)

- ARRC022 - Implementado mecanismo para apagar os arquivos temporarios de output gerados
- RRC0019/ARRC022 - Inclusao de parametro FRACAO_UPDATE_QTD_LOTE (padrao = 1000) para particionar o lote de atualizacao das parcelas

## 1.45.2 (2021-04-11)

- RRC0003 - Retirada validacao de credenciadora para operacao que nao sao geradas fracoes (fumaça/constituida)
- INTEROP - Retirada a chamada do InteropConfirmReceptionActionHandler
- EV642386 - ARRC022
- EV642427 - RRC0019
- EV648416 - RRC0019
- EV648486 - RRC0019   
- EV651909 - RRC0019
- EV652737 - RRC0019
- EV654206 - RRC0019
- EV664381 - RRC0019
- EV664589 - RRC0019
- EV651511 - RRC0019
- EV651500 - RRC0019
  
## 1.45.1 (2021-04-10)

- EV651456 / EV650874 / EV652415 - Erro ao gerar resposta R1 durante interop (INTP010 / INTP005)

## 1.45.0 (2021-04-09)

- INTP011 - Criação de sub-handler para envio assincrono de INTP011 (via RRC0019 e RRC0011)
- INTP004/INTP005 (CPI ouvindo) - Persistir os dados em disco para passar para o sub-handler

## 1.44.4 (2021-04-09)

- RRC0019/ARRC022 - Inclusao de parametro TAMANHO_SPLIT_ENVIO_INPT011 (padrao = 10) para particionar o envio de INTP011

## 1.44.3 (2021-04-09)

- RECALCULO - Inlcusao de parametro HABILITA_RECALCULO (padrao = S)

## 1.44.2 (2021-04-09)

- Ajuste na RRC0019/ARRC022 para OPT IN Automatico - Problema detectado em HEXT, ROOT ID 279294245

## 1.44.1 (2021-04-09)

- INTP007 (CIP ouvindo) - Tratamento para agencia com mais de 4 numeros
- Ajuste na RRC0010R1 - Adicionado mapa para evitar repetitivas consultas à tabela optin
- INTP007 (CIP falando) - Desconsiderar o envio de contratos de interop quando nao foram geradas fraces fumaça/constituida

## 1.44.0 (2021-04-08)

- [RECALCULO] - Varredura de desconsituição para operações com e sem interop
- Ajuste na ARRC022 - Problema detectado em HEXT, ROOT ID 270334168
- RRC0010/RRC0019/ARRC022 - Correção na INTEROP para fluxos envolvendo duas registradoras

## 1.43.12 (2021-04-08)

- [RTC43254] - Sistema não está respeitando a prioridade dos gravames na hora de alocar as URs para o contrato de Penhora
- [RTC45512] - [R2C3 - INTEROP RRC0003- v.1.43.8 Atlante v.5.1.79.9] - Sistema está retornando erro 791: Error validating XML ao tentar disparar mensagem RRC0003 na interop
- [INTEROP] - [INTP007] - [INTP008] - [RRC0019/ARRC022]- Ajuste de validação das interops
- [INTEROP] - [INTP004] - [INTP005] (CIP ouvindo) - validação de frações para troca de titularidade
- [INTEROP] - [INTP008] - [RRC0019/ARRC022]- nullpointer
- [REBATEDOR] - inclusão de rebatedor TAG
- [EV616973] - Correção após reteste para não enviar RRC0003 duas vezes quando do cancelamento pela funcionalidade RRC0020
- [RTC43345] - Após cancelamento total da operação que possui um OPT-IN automático, sistema não criou registro na tabela OPT_OUT e não enviou a msg RRC0029
- [RTC45486 RTC45487 RTC45488 RTC45489] RRC0006 e RRC0020 - Validação dos participantes
- [EV651484] - RRC0021

## 1.43.10 (2021-04-07)

- [RRC0019/ARRC022/RECALCULO] Ajuste para desconstituir fumaça quando não é mais necessária
- [RTC45512] - [R2C3 - INTEROP RRC0003- v.1.43.8 Atlante v.5.1.79.9] - Sistema está retornando erro 791: Error validating XML ao tentar disparar mensagem RRC0003 na interop
- [RTC45441] - Adicionando código de erro ERRC0060 no retorno da tag Grupo_RRC0005R1_NegcRecbvlRecsdo
- [EV648838] - ARRC022
- [EV642378] - RRC0019
- [EV648761] - RRC0021
- [EV648768] - ARRC018
 
## 1.43.9 (2021-04-07)

- [RECALCULO] - Ajustes no recalculo para processamento das operações usando o mecanismo da alteração
- [EV601909] - RRC0021 - Consulta não está retornando frações, retornando o filtro **IC_SIT = 'A'**
- Ajuste no RRC0019SubOptInAutomatico para tratar quando voltar voltar com erro da centralizada, lançamento de execeção para evitar NPE
- Ajuste na geração do RRC0019R1 para não mandar a tag <Grupo_RRC0019R1_NegcRecbvlActo> vazia
- Ajuste na RRC0010R1 - Problema detectado em HEXT, ROOT ID 266681167
- [RTC45441] - Adicionando código de erro ERRC0060 no retorno da tag Grupo_RRC0005R1_NegcRecbvlRecsdo
- [EV645383] - RRC0021

## 1.43.8 (2021-04-05)

- ARRC001 - Correção no tratamento de fracoes enviadas na agenda

## 1.43.7

- [RTC45501] - Incluindo todos as filiais na lista de cnpjs completos no método de tratar cnpj base
- [RTC43331] - RRC0020 - Disparar o recalculo após cancelamento total de contrato
- [EV598268] - RRC0005 - Antecipação: correção da organização de frações nas urs respeitando o domicílio
- V_RECLDES - Ajustado para trabalhar com a tabela OP_PRE_RECLC
- MELHORIA - Criação de parametro de sistema para envio ou não da RRC0009 pelo recalculo

## 1.43.6 (2021-04-05)

- MELHORIA - V_RECLDES - ENVIO DAS NOTIFICAÇÃO DE OPERAÇÕES DE GESTÃO CIP/PARTICIPANTE - CESSÃO / GRAVAME CESSÃO FIDUCIÁRIA / RESERVA (009 / 003)
- INTP007 - Correção de constiuição de antecipação e penhora para permitir informar a UR duas vezes para composicao de gravame e livre
- ERRC0205 - Inclusao de validação do parâmetro nas rotinas de constituição de operação

## 1.43.5 (2021-04-04)

- ARRC001 - Ajuste para buscar o titular no "ontem" para fração de operação com fumaça por base
- INTEROP - Otimização na consulta dos "blobs" de interop
- [RTC45503](https://cvds.cip-bancos.org.br/ccm/web/projects/R2C3#action=com.ibm.team.workitem.viewWorkItem&id=45503) - RRC0010 - Ajuste para funcionar INTEROP via API

## 1.43.4

- INTP004 - Ajuste no envio de idControleRequisicao unico para cada INTP004 gerada no envio de ARRC001
- RRC0010 - Api - Corrigido mecanismo interop
- RRC0019 - Correçao no tipo de retorno indicado em RRC0019E.xsd (Linha 248: de CNPJ_CPFCodErr para CNPJ_CNPJBase_CPFErr)
- ARRC001 - Retirada de validação de constituir para a atualizacao do titular de hoje

## 1.43.3

- RRC0028 - Não registrar a anuencia na base centralizada quando for CNPJ base
- INTP008 - Envio de contrato para a interop deve aceitar HTTP 200 e 202

## 1.43.2

- RRC0028 - Revisao para só enviar INTP011 para contratos que nao sejam de interop (INTP007)

## 1.43.1

- INTP006 - HEXT - Ajuste para enviar INTP006E quando retorna erro ERRC0205
- RRC0005 - HEXT - Antecipação - Correção no envio do erro ERRC0154
- [RTC45493](https://cvds.cip-bancos.org.br/ccm/web/projects/R2C3#action=com.ibm.team.workitem.viewWorkItem&id=45493) - Removendo criação de OutputHandle sem record que estava gerando erro -791: Error validating XML na saída para Output-MQ
- [EV616161] - Recálculo não enviava RRC0003 de operação gestão participante após cancelamento de URs via ARRC002 durante reteste do evento EV616161 em HEXT
- [EV601909] - RRC0021 - Consulta não está retornando frações, removido o filtro **IC_SIT = 'A'**
- [RTC45497](https://cvds.cip-bancos.org.br/ccm/web/projects/R2C3#action=com.ibm.team.workitem.viewWorkItem&id=45497) - RRC0010 - Ajuste de NumberFormatException no envio de RRC0010 com cnpjUsuFinalRecbdr preenchido com cnpj base e cnpjCreddr nulo
- [RTC45453](https://cvds.cip-bancos.org.br/ccm/web/projects/R2C3#action=com.ibm.team.workitem.viewWorkItem&id=45453) - Incluindo validação para verificar se a flag HABILITA_PARALELISMO_CNPJ_COMPLETO está ativa antes de tratar cnpj base

## 1.43.0

- [RTC45431] - INTP007 gravame gestão registradora tem que o valor tem ser 100 quando é fumaça não tem agenda assim como sai na 19R1
- [EV616973] - Correção após reteste HEXT
- [EV601034] - ARRC018 - Incluido validacao do optin titular ou recebedor atraves da tabela destinatario_opt_in
- [RTC45298] - Refaz a correcao do erro RTC45298: Sistema não está retornando o <Grupo_RRC0021R1_Titlar> na RRC0021R1
- [RTC42500] - ARRC020 - Campo nr_vlr_tot da fração livre ficou zerado e não foi atualizado com o valor que foi cancelado
- [RTC39659] - RRC0019 Inclusao de op_titlar_domcl (gestao registradora) quando fracao sofre alteracao de domicilio. 
- [RTC45485] - Funcionalidade RRC0010 - Ajuste de NullPointer quando a RRC0010 é enviada com codArranjo nulo
- MELHORIA - Recalculo - TOTALIZAÇÃO DE OPERAÇÕES - Varreduras V_PRERCL1 e V_PRERCL2
- ARRC001 - Correção na inclusão na destinatario-opt-in para instituições cadastradas em duas registradoras
- RRC0019/ARRC022 - Inclusao de tratamento para trazer apenas estabelecimentos com arranjos ativos
- Ajuste XSD para remoççao de pattern de validação de formato de data (intervalo do ano) - Foi retirado a pedido da Natalia. Qualquer validação de data deve ser realizada no codigo e não no XSD para evitar impacto em outras funcionalidades.

## 1.42.1 (2021-03-31)

- ARRC022 - HEXT - NullPointerException no root_id 246029164

## 1.42.0

- RRC0021 - Remove alteração referente ao RTC45298, pois a mesma conflitava com a feature de redução de payload
- RRC0020 - Remoção de chamadas residuais na tabela de UR.
- RRC0005 - Penhora e Antecipação - Ajuste para resdolver corretamente a chave da UR para o processo de constituição
- RRC0011/INTP011/ARRC001 - Incluida coluna IC_TP_DEST na tabela OPT_IN e DESTINATARIO_OPT_IN
- RTC45492/RRC0010 - Incluir informações faltantes no arquivo

## 1.41.1

- Item 18 da planilha do Itau para a ARRC018

## 1.41.0 (2021-03-31)

- [RTC45484] Ajuste para validacao de optin somente por IF/NIF na RRC0010
- [RTC45468] - [R2C3 - INTEROP RRC0019  v.1.39.5 Atlante v.5.1.79.3] - Gravame Gestão ER   - Sistema está retornando erro 791: Error validating XML ao receber patch de alteração contrato interop
- [RTC45469] - [R2C3 - INTEROP RRC0019  v.1.39.5 Atlante v.5.1.79.3] - Gravame Gestão ER   - Sistema está enviando valores incorretos na INTP007 de alteração de contrato
- [RTC45472] - [R2C3 - INTEROP ARRC022  v.1.39.5 Atlante v.5.1.79.3] - Cessão Gestão PART  - Sistema está enviando valores incorretos na INTP007 de alteração de contrato
- [RTC45470] - [R2C3 - INTEROP ARRC022  v.1.39.5 Atlante v.5.1.79.3] - Gravame Gestão PART - Sistema está enviando valores incorretos na INTP007 de alteração de contrato
- [RTC45482] Ajuste na prioridade das frações penhoradas/antecipadas
- [RTC45483] Ajuste para não pular prioridades
- [RTC45476] - Ajuste no envio da INTP007 para enviar somente frações da registradora de destino
- [RTC45195] - RRC0010 retorna NullPointerException ao efetuar a consulta pelo filtro CNPJ_CNPJBase_CPFTitlar
- HEXT - LOGS para avaliacao do root 240857164
- RRC0019/ARRC022 - Correção no registro das credenciadoras inseridas na OP_TITLAR_CREDDR para alcande geral
- RRC0019/ARRC022 - Inclusao da tabela OP_OPT_IN para armazenar os opt-ins automaticos
- RRC0019/ARRC022/RRC0005 - Todas as funcionalidades - Mudança da regra para tratamento do percentual. Agora é calculado a partir do valor livre
    - Na alteração, somente sofrerá mudança se a operação estiver sozinha na UR, caso contrário, será mantido o já constituído e serão modificadas somente URS que obedeçam essa condição

## 1.40.5

- Inclusao do tratamento do ERRC0199 fora do SLA analisando o status code da request e caso esteja no range de 300 a 399 sera add o erro EGEN0050.
- [INTEROP] - Inclusao do tratamento do ERRC0199 fora do SLA analisando o status code da request e caso esteja no range de 300 a 399 sera add o erro EGEN0050.
- [RTC43258] Ajustes para participante credenciadora, validacoes id_op == 0
- [EV611962] - O participante Itau realizou o reteste do evento EV584637 e a mensagem RRC0020 foi processada com erro "Nao foram encontradas URs, e por isso o contrato nao pode ser enviado."

## 1.40.4

- RRC0003 - Enviar a mensagem somente quando houve fração constituida ou a constituir para a credenciadora

## 1.40.3

- [RTC45298] - Correcao do erro RTC45298: Sistema não está retornando o <Grupo_RRC0021R1_Titlar> na RRC0021R1
- [RTC45467] - Sistema está retornando as frações fumaça considerando fumaças com data até DtRef + valor do parâmetro do Participante
- [EV624036] Correcao envio indevido 28 quando optin nao é automatico
- [EV601909 / EV616161] - ARRC002 não estava enviando o arquivo 009 após o recalculo

## 1.40.2

- [RTC45473] - ARRC002
- [RTC43258] Replicacao da validacao do participante administrado - RRC0010R1
- MELHORIA - Consulta de operações em lote para 008/021.

## 1.40.1

- INTP008- Ajuste na geracao de fumaça
- [RTC45451] - Erro de validação de XML quando CNPJ_CNPJBase_CPFUsuFinalRecbdr e CNPJ_CNPJBase_CPFTitlar = CNPJ Base, alterando tipo do elemento de retorno no XSD para permitir CNPJ Base com CodErro

## 1.40.0

- RRC0010 - Particionamento de JOBs para consulta por CNPJ base
- [RTC45474] - Sistema está retornando RET aceito ao enviar ARRC002 com UR inexistente na base, correcao na montagem do arquivo ARRC002RET

## 1.39.8

- RRC0019 - INTP007/INTP008 - Ajustes

## 1.39.7

- [RRC0019/ARRC022/RRC0005] - [RTC-45217] Alteração percentual ficava com excesso quando a quantidade de URS dimunui na solicitação de alteração.
- RRC0008/RRC0021 - Parametrização para retorno de payload reduzido caso não seja informado o identificador de operação
- RTC-45293 - Na Interope a fração fumaça tem que ficar com o valor 100
- [RTC45412] Erro de validação do XML ao enviar RRC0008 para simular o erro ERRC0098, inclusão de atributo no XSD da mensagem RRC0008E
- V_MNTCRED - Varredura de manutenção de credenciadoras CIP -> Centralizada ajustada.
- V_CTZCRDD - Varredura de manutenção de credenciadoras CIP <- Centralizada ajustada.
- ARRC002 - Sistema está atualizando o ic_sit para B nas frações fumaças dos contratos que possuem URs que sofreram baixa pela ARRC002
- RRC0008/RRC0021 - Parametrização para retorno de payload reduzido caso não seja informado o identificador de operação
- MELHORIA - Varredura ENTREGA OPERACAO - ajustes na varredura para pegar opperações de gestão participantes e envitar a 009 para fração alteradaras na 001
- MELHORIA - Varredura ENTREGA OPERACAO - melhoria de performance e ajsute na PK da tabela

## 1.39.6

- [RTC45416] Erro ao validar XML ao enviar RRC0010 para simular erro ERRC0144, incluido atributo no XSD
- [RTC45439] NPE ao enviar RRC0012 apos 19 com GestPart; incluido campo ao mapper
- ARRC018 - Otimização na consulta de opt-in
- ARRC002 - Retirada da UNIDD_RECBV e otimização do fluxo de processamento

## 1.39.5

- RRC0005/RRC0019/ARRC022 - Inclusao/Ateração de operações gestão participante também salvam registros na tabela op_titlar_domcl_usu_finl_recbdr (otimizar consulta da RRC0008 e RRC0021)
- EV642130 - ARRC018 - Corrigido envio de CNPJbase no grupo <Grupo_ARRC018_UsuFinalRecbdr><CNPJ_CPFUsuFinalRecbdr>]

## 1.39.4

- [INTEROP INTP007 INTP008 INTP005 RRC0019/ARRC022]
    - TODAS: o calculo do percentual, quando interop, deve ser baseado no LIVRE no momento da constituição(regra será revista para identificar possíveis furos)
    - INTP005 cip falando:
        - Ao enviar a agenda, deve ser considerado a regra de divisão do contrato de forma a enviar o percentual quando este for o caso;
        - O valor calculado para a operação percentual deve se baseado no LIVRE no momento da constituição;
    - INTP005 cip ouvindo:
        - Ajuste nos registos enviados por percentual para calcular o valor previsto de liquidação corretamente(ainda pendente de mais ajustes para a cessao)
    - INTP007/INTP008 CIP falando:
        - Correção do envio do percentual para operações de inclusao e alteração para considerar os valores correntes de percentual solicitado na negociacao
        - Melhoria na associação da UR da negociação ao envio da INTP007 para setar corretamente o percentual
    - INTP007/INTP008 CIP ouvindo:
        - Adicionado um tratamento para recalcular o valor das frações oriundas de INTEROP para o calculo do percentual ser baseado no valor LIVRE no momento da constituicao e não no valor total
        - Ajuste no calculo do valor livre para o caso acima para que a agenda
    - RRC0019/ARRC022:
        - Ajuste na constituição no processo de alteração quando o valor do percentual é superior ao valor total da negociação para que este seja alterado corretamente

- [RTC45442] NPE ao enviar arquivo com IdentOp e CNPJ_CNPJBase_CPFTitlar
- [RTC45432] - [R2C3 - RRC0021 - 1.38.1] - Sistema não está considerando o parametro de dias de fumaça na INST_CAD para as fumaças que são retornadas na RRC0021
- [RTC45413] Corrigida chave para retorno grupo negc que impedia dele ser incluido quando URs semelhantes eram obtidas
- [EV616973] - Prezados, o participante BS2 encaminhou uma mensagem de cancelamento parcial para a Credenciadora Cielo e foram geradas duas mensagens RRC003 com a mesma informação.

## 1.39.3

- ARRC001 - Tratamento para frações fumaça com CNPJ base no "ontem" e que foram enviadas "hoje"
- [RTC45454] Ajuste testes RRC0011 e ARRC0022
- INTP006/RRC0005 - HEXT - Erro root_id 222840191
- RRC0019/ARRC022 - Retirada da leitura dos payload de requisicao e resposta ao finalizar a interop

## 1.39.2

- [RTC44826] - Na alteração estava deixando alterar fração cancelada.
- [RTC45445] - [R2C3 - INTEROP RRC0019 - v.1.38.6 Atlante v.5.1.79.3] - Gravame Gestão ER - Sistema enviando valores de fumaça incorretos na INTP007 na alteração de contrato
- [RTC44826] - Na alteração estava deixando alterar fração cancelada.
- [RTC45436] - Ajuste no codigo SituacaoRetornoRequisicao (tag: SitRetReq) de x para 00x
- [RTC44826] - Na alteração estava deixando alterar fração cancelada.
- [CRONOGRAMA] - Retirada da UR para as operações de credenciadora(RRC0005)
- RRC0019/ARRC022 - Retirada da leitura dos payload de requisicao e resposta ao finalizar a interop
- LOG - Alterado nivel padrao de log para WARN (br.org.cipbancos.rrc e br.org.cipbancos.atlante)
- [GestPart] - 222054166 / 22206216 java.lang.NullPointerException no AbstractConstituiicaoGestPart:131
- [INTP007] Cip falando, titular não enviado para alteração de cessao
- [RRC0005] Gestão registradora completa - Inclusao e alteração

## 1.39.1

- RRC0019/ARRC022 - Correção das fluxos de erro de interop (RRC0019E e ARRC022RET)
- [RTC45452] Ajuste busca participante RRC0010R1

## 1.39.0

- [RTC45257] - Divergências nos valores da UR na RRC0010R1
- [RTC45258] - Tag VlrComprtdOutrInst do Grupo_RRC0010_Titlar e Grupo_RRC0010R1_NegcRecbvOutrasInst nao sao retornados
- [RTC45448] - Sistema nao esta retornando comprometido outra instituicao
- RRC0019/ARRC022 - Alterada a geração das frações para gerar apenas para as credenciadoras que tenham agenda
- RRC0006/RRC0020 - Remoção do uso da tabela de UR e otimização da busca das frações
- RRC0019 - HEXT - Erro no processamento do root_id 218919167
- RRC0021 - HEXT - Tratamento de ERROS (root_id = 219627932)
- ARRC022 - Otimização - Ajuste para inserir/alterar frações em lote
- RRC0010 - Retirada da busca às tabelas indices
- ARRC001 - Tratamento para frações fumaça com CNPJ base no "ontem" e que foram enviadas "hoje"
- Retirada das validações envolvendo o código de erro ERRC0147
- Inclusão da referencia ao datasource ATL_SYS. Retirada do schema rrc_atl das consultas do Atlante.

## 1.38.6

- [RTC45437] - Validacao de objeto nulo na RRC0010R1

## 1.38.5

- [INTP005] - Correção no tratamento de UR de interop com efeito de contrato de cessao
- [RTC45399] - [R2C3 - INTEROP ARRC022 - v.1.36.0 Atlante v.5.1.85] - Gravame Gestão Part - Sistema gravando UR no valor incorreto na base de dados
- [RTC45398] - Seguirá a mesma regra da fumaça para a constituicao
- [RTC45396]- [R2C3 - INTEROP ARRC022 - v.1.36.0 Atlante v.5.1.85] - Cessão Gestão Part - Sistema gravando UR no valor incorreto na base de dados
- [INTP007/INTP008] - Ajustes no processamento do percenual
- RRC0019/ARRC022 - Ajustes de performance

## 1.38.4

- Versao gerada por build quebrado da 1.38.3

## 1.38.3

- [EV588581 / EV619657] - RRC0010 não está exibindo os campos VlrComprtdOutrInst e VlrComprtdInst
- [RRC0005] - Ajustes na validação e tratamento de domicílios na gestão participante

## 1.38.2

- [RRC0012] - Ajuste p/ validação ERRC0202 não ser lançada no caso de fração livre e em caso de gestão participante validações ERRC0202 e ERRC0092 são feitas baseadas na tabela op_titlar_domcl_unidd_recbv
- [ARRC002] - correção de consulta de fração para baixa de ur
- Por solicitacao da Natalia, considerar apenas os 4 digitos mais significativos do campo "agencia" no recebimento de agendas de outras registradoras.
- [RRC0005] Retirada da UR RRC0005 Gestão Participante.
- [RRC0019/ARRC022] - gravação correta dos campos de participante e percentual em todos os casos
- [RTC45403] -[R2C3 - RRC0019 - 1.36.0] - Sistema está retornando os erros ERRC0141/ERRC0140 ao enviar Gravame/Cessão por Percentual quando a soma do % informado na tag VlrPercNegcd nas URs é maior que o valor do contrato
- [RTC45297] - Correcao do erro de nullpointer relacionado ao processamento da RRC0021 quando o arquivo enviado informa apenas usuario final recebedor
- [RTC41630] - Corrige validação do campo DescContstc da RRC0027, pois apesar de ser opcional não deveria aceitar o envio do campo sem valor atribuido
- [RTC45400] - Adiciona verificacao de optin para o usuariofinalrecebedor no output da mensagem ARRC018

## 1.38.1

- [RTC45426] INTP008 - Ajuste na geração de fumaça da diferença da operação enviada. Estava gerando 100 para Valor e a diferença para percentual
- [RTC41490] - [R2C3 - RRC0020 Layout - 1.4.18] O sistema não gera EGEN0043 quando as tags CNPJ_CNPJBase_CPFTitlar, CNPJ_CPFUsuFinalRecbdr e CNPJ_CPFTitularVendd_NegcdrRecbvl estão vazias.
- [RTC41491] - [R2C3 - RRC0020 Layout - 1.4.18] O sistema não gera EGEN0043 quando o ano da tag DtPrevtLiquid tiver 5 dígitos ou estiver entre 0001 e 1899.
- [RTC-44326] - [R2C3 - rrc0010 - 1.25.0] - Sistema esta retornando VlrComprtdInst > 0 sendo que ha somente valor livre e na tag VlrLivreUsuFinalRecbdr esta = 0
- [RTC45415] - Alteracao do mapeamento do erro ERRC0059 do Grupo_RRC0019_RegRecbvl para DtPrevtLiquid para gestao de participante
- [RTC44171] - correção nos ids dos participantes no retorno da RRC0014 e da RRC0024
- [RTC41409] - [R2C3 - INTEROP /notificacao/anuencia - v.1.3.13 Atlante v.5.1.38] - CIP ouvindo - Sistema está permitindo inclusão de optin duplicado
- [EV601909] - O participante teve o código de Api 412 porém não foi apontado em nenhum lugar qual erro ocorreu
- [EV594408] - Inclusão de envio de mensagem de notificação de optin (RRC0028) para o remetente quando o mesmo for IF/NF
- [INTP007] CIP Ouvindo: O titular dos contratos de cessão estavam ficando com o CNPJ da registradora que enviou
- [INTP007] CIP Falando: quando por percentual, deve enviar o valor do percentual e não o valor
- Ajuste nullpointer RRC0019 com interop

## 1.38.0

- Implementação varredura V_RECLDES - desalocação excesso.
- [RTC42917] - [R2C3 - INTEROP /notificacao/anuencia - v.1.13.11 Atlante v.5.1.52] - CIP ouvindo - Sistema não está atualizando data de última alteração do optin
- [EV599900] - RRC0020 - Troca do erro genérico (ERRC9999) por erro de SLA (ERRC0200) para erros decorrentes da interoperabilidade, como demora ou falta de resposta por parte das outras registradoras.
- [RTC41126] - [R2C3 - RRC0005 - 1.3.8.1] - Sistema não deixou as frações que foram antecipadas do Gravame Gestão ER com prioridade 2 ao enviar antecipação de URS gravamadas não informando DtEftLiquidAntec e VlrEftLiquidAntec
- [RTC45413] - [R2C3 - RRC0010 - 1.36.0] Nem todas as execuções do mesmo cenário o sistema gera Grupo_RRC0010R1_NegcRecbvlInst
- [RTC-42917] - [R2C3 - INTEROP /notificacao/anuencia - v.1.13.11 Atlante v.5.1.52] - CIP ouvindo - Sistema não está atualizando data de última alteração do optin
- [INTP005] - RETIRADA DA VALIDAÇÃO 048 (Não devemos recusar agendas vazias recebidas na INTP005)
- [RRC0010] - AJUSTE NO PAYLOAD DA INTP010
- [INTEROP] - remoção da validação do formato data de referencia e data criacao , alteração de data_referencia por data_criacao na interop
- [INTEROP] - remoção de insert desnecessário

## 1.37.0

- [RTC42783] - INTEROP /post/contrato - CIP ouvindo - Sistema não permite incluir contrato de agência com mais de 4 dígitos.
- [RTC42916] - [R2C3 - INTEROP /notificacao/anuencia - v.1.13.9 Atlante v.5.1.52] - CIP ouvindo - Sistema não está atualizando data fim optin quando optout recebido tem data  fim futura
- [RTC43739] - INTEROP /agenda - CIP ouvindo não esta retornando INTP002 quando dataEfetivaLiquidacao invalida.
- [RTC45293] - INTP008 fumaça por porcentagem esta gravando valor previsto liquidação errado tem que ser 100 nessa situação.
- [RTC45397] - [R2C3 ARRC018 1.36.0] O sistema gerou <VlrLivreUsuFinalRecbdr> negativo quando há contrato com IndrRegrDivs = P (EV614268)
- [RTC45401] - [R2C3 - RRC0019 - 1.36.0] - Sistema não está considerando o valor do contrato e está constituindo 100% do valor livre que está na UR quando enviada RRC0019 Gestão Participante Gravame ou Cessão
- [RTC45402] - [R2C3 - RRC0019 - 1.36.0] - Sistema está gravando no campo NR_PERC o % de constituição da UR comparando com o valor da operação quando enviada RRC0019 Gestão Participante Cessão por Valor
- [RTC45403] - [R2C3 - RRC0019 - 1.36.0] - Sistema está retornando os erros ERRC0141/ERRC0140 ao enviar Gravame/Cessão por Percentual quando a soma do % informado na tag VlrPercNegcd nas URs é maior que o valor do contrato
- [EV593637] - Correcao do cenario de inclusao de duas operacoes na mesma UR porem vlrComprtdInst nao era atualizado
- [EV612363, EV613793] - Correção do cenario de inclusao do mesmo documento em duas credenciadoras em momentos diferentes, que causava chave primaria duplicada no processamento da ARRC030. Teste groovy criado na ARRC030, com o nome do evento EV613793.
- [EV617405] - Casas decimais com 44 posicoes na RRC0004.
- RRC0010 - Particionamento das respostas por CNPJ completo conforme parametrização
- RRC0003 - Ajuste no agrupamento de titulares e domicílios para geração correta da saída
- INTP008 - Melhoria na vinculação da INTP007 e INTP008 para corrigir a validação
- RRC0003 - Ajuste na geração da saída quando a operação é pelo base
- RRC0019/ARRC022 - Redução na quantidade de agendas solicitadas
- RRC0027 - Tratamento de ClassCastException
- RRC0019/ARRC022/RRC0021 - Criação da lógica da fumaça baseada no parâmetro de cada participante
- INTEROP - Inclusao do parâmetro HABILITA_INTEROP_DATA_EM_ARQUIVO para gravar os dados da INTEROP em filesystem e nao em BD

## 1.36.0

- [INTP008] - Cip Ouvindo, Refatorada. Resolve:
   - [RTC45318]
   - [RTC45320]
   - [RTC45333] - Duplicate Key
   - Qualquer outro relacionado ao processamento da INTP008 via RRC0019/ARRC0022
- [RTC41116] -  VlrComprtdOutrInst e VlrComprtdInst no Grupo_RRC0019R1_UniddRecbvlDisp na RRC0019R1 recusada
- [RTC45312] Division by zero quanto não há valor livre
- [RRC0019] - Alteração e cessão gestão registradora implementada
- [INTEROP] - remoção de lock nas tabelas para interop
- RRC0019/ARRC022 - Otimização para inserir/atualizar frações
- [EV615464] - RRC0019 lançando erro 205 para troca de titularidade para URs com cnpj registradora da CIP
- [EV610311] - Prezados, o participante Cielo recebeu o arquivo ARRC018_01027058_20210301_00062 sem dados de UR, conforme evidencia em anexo. Por gentileza verificar.
- [EV610319] - Reteste do evento EV593131. Mensagem RRC0010R1 foi enviada com o campo <CNPJ_CPFTitlar>84016200</CNPJ_CPFTitlar> preenchido com somente 8 posições.
- [EV614268] - ARRC018 (refatoração: a varredura nao utiliza mais a tabela UNIDD_RECBV) - O arquivo esta sendo reportado com valores negativos no campo <VlrLivreUsuFinalRecbdr>-420300.00</VlrLivreUsuFinalRecbdr>.
- [EV598559] - Ajuste na baixa de UR para o caso de operação TC ser baixada por cnpjTitularAnterior
- [EV591560] - RRC0010R1 - Consulta de URs retornando tag SitRetReq = 4 (SEM_RESULTADO)

## 1.35.5

- [RRC0019 - Gravame ER] - Funcionalidade refatorada para inclusão e alteração
- [RRC0019 - Cessao ER] - Funcionalidade refatorada para inclusão. ** Esta pendente a alteracao **

## 1.35.4

- Ajuste de NullPointer na validação da desconstituição em caso de CnpjCreddr inválido (RRC0012)
- [EV590872] - [R2C3 - RRC0013 - 1.30.0] - Opt-out de opt-in pelo CNPJ base.
- V_MNTIFNC - Varredura de manutenção de IFs/NFs CIP -> Centralizada ajustada.
- V_CTZCRDR - Varredura de manutenção de IFs/NFs CIP <- Centralizada ajustada.
- [EV612734] - Correçao da tag "ISPBBcoRecbdr" no arquivo "ARRC001.xsd" para suportar codErro em caso de recusa. Ajustes menores em "ARRC022.xsd" e "RRC0005E.xsd".
- [RTC41603] - O sistema não gera EGEN0043 quando as tags CNPJ_CPFUsuFinalRecbdr e CNPJ_CPFTitlarCt estão vazias, ano da DtEftLiquid com 5 dígitos e entre 0001 a 1899
- [RTC43737] -  CIP ouvindo não esta retornando INTP002 quando dataCriacao invalida

## 1.35.3

- [EV608992] - Prezados, o participante Cielo alegou estar recebendo várias mensagens RRC0003 de alteração no momento de abertura da grade, no entanto, não retorna as URs na consulta.
- ARRC001 - Tratamento para NR_PERC com porcentagem 1.00 ou 100.00

## 1.35.2

- [Ajuste de Teste] - Implementação da validação ERRC0202 e ajuste da ERRC0092 (RRC0012)
- [Ajuste de Teste] - TestRRC0006.groovy "SUCESSO"
- [Ajuste nome PK script 1.35.0]
- [EV614291] - RRC0019/ARRC022 - TC - Gestão Participante - Inclusão. Corrigido valor da coluna NR_PERC da fracao para operacoes com regra de divisao VALOR (sempre 1.0)
             - ARRC001 - Corrigido valor da coluna NR_PERC para utilizar o valor de ontem (fracoes com id_op)

## 1.35.1

- [EV606854] - Correção de cenário de cancelamento total quando só há fumaça para cancelar
- [EV601595] - Passamos a recusar agendas vazias vindas na INTP004 e INTP005.
- [RTC41116] - correcao no filtro

## 1.35.0

- Trocar o addOutput para RemoteOutput. (concluído)
- SubBatch onde for possível (INTP11, INTP10) - (concluído)
- Inserir o LateBatch o disparo da 11 com RemoteOuput - concluído
- Validar com Calado, se sobrou alguma funcionalidade que não foi feita a configuração para utilização do Split na 003, na 19R1, 010R1, 008R1, 021R1, 009 -concluído
- Revisão do Modelo de Dados da Interop, se necessário; (Concluido)
- [EV601595] - Passamos a recusar agendas vazias vindas na INTP004 e INTP005.

## 1.34.2

- [RTC45329] - [R2C3 - ARRC022 - 1.33.1] - Ao enviar ARRC022 de Gravame Participante para gerar RET recusado é retornado a tag SitRetReq = 003, mesmo não tendo grupo de aceito no arquivo
- [RTC41116] - Incluido tags VlrComprtdOutrInst na RRC0019R1

## 1.34.1

- Ajuste da Base Centralizada para aceitar status code 207 (similar a status code 200)
- [EV601623] - tratativa para reconhecer e aceitar multistatus no statuscode do HTTP (207)
- Ajuste na varredura de atualização ECs na base centralizada

## 1.34.0

- ARRC022 - Otimização relacionado a gravação dos resultados parciais de processamento em disco e nao no BD
- RRC0019/ARRC022 - Processamento e Gravame e Cessao ER para usar o mesmo strategy

## 1.33.1

[EV611779] - Correção da validação do indicador de cessionario autorizado para a inclusao de cessao
[RRC0019/ARRC0022] Gestão Participante- volta do métido de inserir por lote ao invés do copyu
- Limitação ARRC030 para o limite de 100 registros conforme solicitado pela Natália.

## 1.33.0

- [EV599392] - DuplicateKey - tentativa de remover erros de duplicidade.
- [RTC45311] - [R2C3 - RRC0005 - 1.32.6] - Valor da tag VlrNegcd na RRC0005R1 está vindo com o valor que sobrou de livre na UR, porém o correto é retornar o valor que foi constituído
- RRC0019/ARRC022 - Refactoring para receber lista de registros no handler
- [RTC41116] - Incluido tags VlrComprtdOutrInst na RRC0019R1

## 1.32.8

- [INTP008] - Ajuste nas frações de interop para a alteração
- [RRC0019/ARRC022] - Gravame ER - Regressão: data de início da operação não deve ser considerada quando esta for a data de referência
- [RTC43083] - Inserindo log para facilitar analise

## 1.32.7

- [RTC45300] - [R2C3 - INTEROP ARRC022 - v.1.32.4 Atlante v.5.1.78] - Gestão Part - sistema apresenta RET recusado por participante não correspondente na alteração de contrato
- [EV606854] - Frações fumaças não estavam sendo canceladas quando participante manda um cancelamento total
- [EV600995] - Valor livre total do titular não contemplava valor de outras instituições.

## 1.32.6

- [RTC45288] - [BUGFIX] - [INTP011 - 1.32.2] - Sistema apresenta erro EGEN0050.
- [RTC45290] - [BUGFIX] - [INTP012 - v1.32.2] - Mensagem enviada grava a requisição no campo de nome do arquivo na base.
- [RTC45294] - [BUGFIX] - [R2C3 - INTP012] - Sistema não salva registro OptIn na busca pela centralizada.
- [EV599756 - EV599946] - ajuste na varredura 018 para não duplicar o grupo GrupoARRC018DomclBancInst e adicionado GrupoARRC018NegcRecbvlInst para virar uma lista dentro da tag GrupoARRC018DomclBancInst
- [EV589122] - RRC0019 não estava retornando o erro ERRC0159 quando só tinha esse erro na validação.
- Implementacao da varredura que envia, via INTP004, apenas as URs a constituir aos participantes.
- [RTC43083] - Corrigido parcialmente. Inativando fracoes nao utilizadas após recalculo de cessao.
- RRC0019/ARRC022 - Otimização Gravame/Participante/Alteração
- RRC0019/ARRC022 - Cessao/Participante/Alteração: refatorada
- Compatibilidade Atlante 5.1.79 (late-batch - mensagem - fluxo unitario)
- [RTC44368] - [R2C3 - ARRC018 - 1.26.3] - Foram encontradas divergências no arquivo ARRC018 ao validar o EV583040 para recebivel da IF recebedora da ARRC018
- [EV600995] - Testes integradados para garantir que estava certo a correção já efeturada no EV592523

## 1.32.5

- Compatibilidade com envio de String para os Handlers
- [RTC45268] - [R2C3 - RRC0019 - 1.32.1] - Sistema está criando operação de Gravame OG Gestão Participante sem frações ao utilizar agenda já liquidada
- [EV606854] - Operação de Penhora não cria fumaças quando não há URs na data de referência

## 1.32.4

- [RTC45268] - [R2C3 - RRC0019 - 1.32.1] - Sistema está criando operação de Gravame OG Gestão Participante sem frações ao utilizar agenda já liquidada

## 1.32.3

- [GERAL]   - mudança dos métodos de insert e update de frações
- [RRC0019] - CESSAO ER - Ajuste para fazer interoperar corretamente
- [RTC45268] - [R2C3 - RRC0019 - 1.32.1] - Sistema está criando operação de Gravame OG Gestão Participante sem frações ao utilizar agenda já liquidada
- [EV607471] - Links de URLs sairao sempre na RRC0008
- [EV598098] - Duplicidadde de registros na RRC0008 - Crava-se a credenciadora consultate para trazer apenas seus registros.
- RRC0019/ARRC022 - Otimização - Revisão de utilização do parallelStream()

## 1.32.2

- [RTC44368] - [R2C3 - ARRC018 - 1.26.3] - Foram encontradas divergências no arquivo ARRC018 ao validar o EV583040 para recebivel da IF recebedora da ARRC018
- RRC0019/ARRC022 - Otimização parse XML/Bean
- RRC0019-INTP008 - Ajuste no indicador de inclusao e alteração
- RRC0019-INTP    - Enviar cancelamento para registradoras que deixarem a operação
- RRC0003 - Indicador de inclusao e alteração para considerar a entrada de novas credenciadoras na operação
- Compatibilidade Atlante 5.1.76
- ARRC022 - Otimização "collator"
- [RTC41116] - Corrigido output RRC0019R1 - Incluido tags VlrComprtdOutrInst
- [RTC45183] - Correção arredondamento.

## 1.32.1

- [RTC42785] - INTP011 - Optout gravado (rrc_own.opt_out) em duplicidade.
- [RTC43374] - RRC0008R1 estava sendo enviada sempre com uma única fração.
- [RTC45257] - Tratamento correto no erro 37 na INTP011
- [RTC45261] - [BUGFIX] - [R2C3 - INTEROP /post/anuencia- v.1.32.0 Atlante v.5.1.75] - CIP ouvindo - Está trazendo arranjo como numérico.

## 1.32.0

- ARRC001 - Tratamento para nao recusar frações liquidadas com ID_OP invalido
- [EV591509] - O sistema não pode utilizar URs liquidadas em operações.
- [EV599730] - [ARRC001] - Possibilidade para realizar operações com valor pre contratado
- Compatibilidade Atlante 5.1.75
- [RTC45247] - [BUGFIX] - [R2C3 - RRC0020] - Não foram encontradas frações e a mensagem não foi enviada.
- [RTC45255] - [BUGFIX] - [R2C3 - RRC0005(Interop) - 1.31.0] - Sistema está gerando apenas Interop de Antecipação.

## 1.31.0

- Ajuste tratamento opt-in - nome metodo de busca na centralizada /api/opt/{nrCtrlCentralizada}
- Ajuste XSD para limitar em 100 registros a ARRC022 e ARRC023.
- Ajustada a versão de todos os XSDs de 8.12 para 8.13
- [RTC41486] - BUGFIX - Ajuste no xsd ARRCTIPOS (versão 8.13) p/ gerar EGEN0043 quando as tags CNPJ_CNPJBase_CPFUsuFinalRecbdr e CNPJ_CNPJBase_CPFTitlar estão vazias
- [RTC45220] - [BUGFIX] - [R2C3 - RRC0019 - v.1.29.4 Atlante v.5.1.72] - Sistema está gerando fumaça a mais no contrato de alteração de porcentagem
- [RTC44368] - [R2C3 - ARRC018 - 1.26.3] - Foram encontradas divergências no arquivo ARRC018 ao validar o EV583040 para recebivel da IF recebedora da ARRC018
- [CRONOGRAMA BACEN - INTP008] - Tratamento correto de retorno da INTP008
- Alteração na versão do xsd da ARRC018 para 8.13 devido ajuste feito no evento EV598969 (RELEASE_NOTES v. 1.30.0)

## 1.30.1

- [EV599458] - RRC0010 - Correcao de NPE em alguns cenarios de consulta
- ARRC001 - Alterado componente para obter data de referência anterior

## 1.30.0

- [EV598357] - Ajuste para não executar o recálculo no caso de gestão participante (RecalculoCessaoNegocio)
- [EV598969] - Ajuste no xsd da ARRC018 de campos do Grupo_ARRC018_Titlar que se tornaram obrigatórios
- [EV587177] - INTP004/INTP007 - Enviamos uma agenda sem o identificador de opt-in para a centralizada/Opt-in automático não estava sendo enviado para a centralizada.
- [EV590872] - RRC0013 - Opt-in sem identificador da centralizada causando NullPointer no opt-out.
- [43928] - BUGFIX - Sistema apresentando erro incorreto quando número opt-in inexistente ou em branco.
- [EV592523] - Ajuste na ARRC018 para constituir valor correto Livre total e valor livre total credenciadora
- [EV595056] - RRC0012 (Api) - Corrigido envio de urs a constituir pela URL /unidades-recebiveis-a-constituir
- [EV592523] - Ajuste na ARRC018 para constituir valor correto Livre total e valor livre total credenciadora
- ARRC001 - Inclusao de flag ATIVA_VALIDACAO_EC para preencher a tabela ESTBMNT_COMCL
- RRC0028 - Ajuste para enviar INTP011 somente para contratos de interop
- Inclusão da renegociação para operações gestão participante

## 1.29.4

- Inclusao de parametro para ativar/inativa sub-handler de envio de RRC0028 pelo RRC0019/ARRC022

## 1.29.3

- [EV586985] - Cessão Part estava gerando fração com valor zero quando a UR não tinha valor livre
- [EV594010] - Constituição de gravame, gestão registradora não respeita o valor máximo por titular
- [EV598603] - RRC0004 - Identificador de requisição apresentando duplicidade
- [45196] - BUGFIX - Sistema não está colocando 100.00 o valor previsto de liquididação  quando o  com IndrRegrDivs = P após enviar contrato de Cessão Gestão Registradora
- [EV593518] - ARRC022 - Correção para gerar opt-ins automaticos e enviar a RRC0028
- [EV598263 / EV590356] - RRC0019 - TC - Gestao Registradora - Auto-aceite = S - Corrigido para retornar erro ERRC0205 quando nao existem URs disponiveis
- [EV598085] - RRC0019 - Gestao Registradora - Inclusão de validação de unicidade para grupos de arranjo, credenciadora e usuario final recebedor
- [EV587177] - INTP004/INTP007 - Enviamos uma agenda sem o identificador de opt-in para a centralizada/Opt-in automático não estava sendo enviado para a centralizada.
- [EV590872] - RRC0013 - Opt-in sem identificador da centralizada causando NullPointer no opt-out.
- [43928] - BUGFIX - Sistema apresentando erro incorreto quando número opt-in inexistente ou em branco.

## 1.29.2

- Compatibilidade Atlante 5.1.72

## 1.29.1

- [EV592440] - Casas decimais com 44 posicoes na RRC0004.
- [EV597742] - campo IndrIA na RRC0003 deve ser 'A' em alguns casos.
- [EV584637] - Ajuste na query de busca de UR's pela operação para filtrar pelo cnpj titular do cancelamento
- RRC0019 - Gestão de participante esta gravando nr_perc com 1 root_id hint1 15083606
- RRC0019 - Otimização de método para obter URs nao encontradas (gravame - inclusao - registradora)
- RRC0005 - Antecipacao - validacao domicilio (correcao)

## 1.29.0

- Merge com versão de otimização de performance de queries em PERF

## 1.28.7

- [EV598896] - Grupo de URs faltante na ARRC018.
- [EV598255] - URs duplicadas no arquivo ARRC018.

## 1.28.6

- [44942] - PRE-EXISTENTE - [R2C3 - INTEROP /post/contrato - v.1.28.1 Atlante v.5.1.67] - CIP ouvindo - Sistema apresenta nullPointer ao receber valorCompormetido maior  valorASerMantido
- [45025] - BUGFIX - [R2C3 - RRC0019 - 1.28.3] - Sistema não está atualizando o campo nr_perc da fração livre como % igual a 100.00 e não está deixando o valor previsto de liquididação com 100 após enviar contrato de Cessão Gestão Participante
- [EV595788] - RRC0005 [duplicate key value violates unique constraint "pk_op_entreg_recalcl"]

## 1.28.5

- [45058] - BUGFIX - [R2C3 - RRC0019 - 1.28.3] - Sistema está gravando o valor 1.00 nas frações fumaça onde não houve valores constituídos para contrato Cessão Gestão ER Principal = Cred e Administrado = Não IF
- [45037] - BUGFIX - [R2C3 - INTEROP /post/contrato - v.1.28.3 Atlante v.5.1.67] - CIP ouvindo - Sistema apresenta nullPointer ao receber valorCompormetido maior 100

## 1.28.4

- [44884] - BUGFIX - [R2C3 - RRC0019 - 1.28.0] - Sistema constituiu apenas parte de uma UR ao enviar RRC0019 cessão gestao Participante com 100% informando 4 URs com saldo livre
- [44934] - BUGFIX - [R2C3 - RRC0019 - 1.28.1] - Após alteração do % na tag Vlr_PercTotOpUniddRecbvl, sistema gravou o valor 1.00 no campo nr_perc para contrato de Gravame Gestão ER
- [45025] - BUGFIX - [R2C3 - RRC0019 - 1.28.3] - Sistema não está atualizando o campo nr_perc da fração livre como % igual a 100.00 após enviar contrato de Cessão Gestão Participante

1.28.3
- [43791] - PRE-EXISTENTE - [R2C3 - RRC0005 - 1.21.15] - Sistema está criando a operação sem Urs constituidas ou fumaças ao enviar msg RRC0005 com IndrRegrDivs = P com Gestão PART

## 1.28.2

- [44953] - BUGFIX - [R2C3 - RRC0019 - 1.28.1] - Sistema está gravando o valor 1.00 nas frações fumaça onde houve valores constituídos para contrato Gravame Gestão ER
- [44934] - BUGFIX - [R2C3 - RRC0019 - 1.28.1] - Após alteração do % na tag Vlr_PercTotOpUniddRecbvl, sistema gravou o valor 1.00 no campo nr_perc para contrato de Gravame Gestão ER

## 1.28.1

- [44851] - BUGFIX - [R2C3 - RRC0019 - 1.28.0] - Sistema está gravando o valor 1.00 na fração constituída no campo nr_perc quando é uma cessão feita pela RRC0019
- [44852] - BUGFIX - [R2C3 - RRC0019 - 1.28.0] - Sistema está gravando o valor 1.00 nas frações fumaça
- [44853] - BUGFIX - [R2C3 - RRC0005 - 1.28.0] - Sistema está considerando o VlrTotLim_SldDevdr/Vlr_Gar para encontrar o valor do % inserido na tag Vlr_PercTotOpUniddRecbvl, o correto é considerar o valor total da UR

## 1.28.0

- Implementação frações percentual

## 1.27.26

- [EV587478] - Campos faltando na RRC0021.
- [EV589652] - INTP007 enviado sem URs.
- [EV596656] - RRC0003 enviado sem URs.
- [EV597490] - RRC0003 enviado sem URs.
- [EV597317] - Tipo de ônus PENHORA passa a ser aceito no grupo EfeitoContrato - alterado o swagger bilateral.
- [EV578345] - INTP013/INTP014 - Não enviamos a informação do cancelamento as credenciadoras (RRC0004) e o sistema não cancelou todas as URs do contrato.
- [EV593982] - corrigido validação ERRC0055
- [EV594977] - corrigido validação ERRC0055
- [EV590932] - [RRC0019/ARR022] - atualização de contratos não adiciona novos titulares.

## 1.27.25

- RRC0005 - Interop PostContrato para PENHORA COMENTADO(voltará depois)
- InteropAgendaSub - Ajuste para não salvar o domicílio se a operação já existir

## 1.27.24

- V_RECALC - Multiplas atualizações na mesma fração causam erros
- RRC010 - Pedidos de agenda unificados para o canal MQ
- AgendaSubHandler - Não atualiza mais a operação no retorno da INTP010
- ARRC020 - Correção do tratamento ro retorno da INTP005
- Tratamento de duplicate key na consulta de EC

## 1.27.23

- RRC0019/ARRC022 - Uma INTP010 para N INTP005

## 1.27.22

- RRC0019/ARRC022 - Gravame/Inclusão/Registradora - Ajuste de perfomance na consulta de fracoes para constituição da operação

## 1.27.21

- [EV592495] RRC0021 - Remocao do filtro 'ID_OP <> 0' da query buscaFracaoUnidadeRecebivelOperacaoComFiltrosBaseCNPJ para retorno das fracoes nao constituidas
- [EV596383] - RRC0019 - retornando erro ERRC0081 indevidamente

## 1.27.20

- [EV592091] - o participante FIDC Cielo realizou a inclusão do contrato abaixo  ROOT 182348677 {?"tpObj":"P","identdNegcRecbvl":"375199","indrTpNegc":"TC","dtVencOp":"2020-12-30","vlrTotLimOuSldDevdr":16525.53,"indrGestER":"N","indrRegrDivs":"V","indrAlcancContrtoCreddrSub":"E","indrActeIncondlOp":"N","indrActeUniddRecbvlReserv":"N","identdConjUniddRecbvl":"0000000000000001583"}? E realizou a baixa da UR através do arquivo ARRC002 ROOT 321008868, identificamos que não houve a geração da RRC0009
- [EV592091] - alteração do envio da RRC0009 para o (buscar na tabela OP NR_CPF_CNPJ_PART getNrCnpjPart() )
- Adição de TipoRecalculo para LIST_CPF_CNPJ_USU_FINAL_RECEBEDOR
- RRC0005/RRC0019/ARRC022 - Distribuição do processamento em filas dedicadas

## 1.27.17

- [EV592945] - RRC0020 - Cancelamento parcial de operação com interop. No envio da INTP007 para alteração da operação não enviamos o tipoOperacao (criação ou alteração).
- ARRC018 - Tratamento para gerar os arquivos no 2o. nivel de sub-batch caso a quantidade de registros seja menor que TAMANHO_SPLIT_VARREDURA_ARRC018
- Removida classes POC (interop)
- Refactoring no application-config.xml dos handlers das varredura (nao passar mais pelo AtivarVarreduraHandler)
- [EV593545] - INTP007 - Recusado quando enviado sem numero de conta).

## 1.27.16

- ARRC022 - Retirado select na SOLCTC_INTRDD para verificação de fim de processamento de todo o arquivo
- Inativação chamada DestinatarioLateBatch para INTP005 (inativação inclusão de destinatário opt-in)
- [EV587478] - Falta de campos na saida da RRC0021.

## 1.27.14

- Ajuste ARRC0030 -  Não inserir na tabela de Estabelecimento Comercial no cache local e quebra no envio (padrão 1000 registros).
- Varredura V_CTZESTC ajustada para usar o parâmetro de quebra no envio (padrão 1000 registros);

## 1.27.13

- [EV588963] - Recalculo
- [EV580994] - Recalculo
- [EV593568] - O cancelamento parcial deve sempre recalcular a operação.
- [EV585401] - O cancelamento parcial deve sempre recalcular a operação.
- [EV590958] - Parametrização do erro ERRC0205

## 1.27.12

- Tratamento na busca e retorno do EC da base local - Ajuste cast para integer

## 1.27.11

- Tratamento na busca e retorno do EC da base local.

## 1.27.10

- Ajuste na busca e atualização dos ECs na base centralizada e gravação do CNPJ Base na tabela de cache local ESTABELECIMENTO_COMERCIAL

## 1.27.9

- Troca de context.getCurrentReferenceDate() para context.getBatchReferenceDate()

## 1.27.8

- [EV575193] - RRC0019/RRC0003 - ajuste no envio do arquivo 3 depois de receber confirmação de sucesso da interop
- [EV591870] - [R2C3 - INTP007 - 1.27.5] - Retirar duplicidades dos recebiveis abrangidos.

## 1.27.7

- [EV575193] - RRC0019/RRC0003 - ajuste no envio do arquivo 3 depois de receber confirmação de sucesso da interop

## 1.27.6

- Ajuste no rowmapper da consulta de credenciadoras no cache da centralizada para completar com zeros à esquerda
- V_RECALCL - Retirada do envio das mensagens RRC0003 e RRC0009
- V_ENTRGOP - Nova varredura para o envio das mensagens RRC0003 e RRC0009 de recalculo
- Ajuste no rowmapper da consulta de credenciadoras no cache da centralizada para completar com zeros à esquerda

## 1.27.5

- [EV590386] - Ajuste na validação de saldo disponível para negociação para Antecipação e Penhora
- [EV587003] - RRC0010 - Mapeamento do atributo IndrDomcl na resposta da API.
- [EV593901] - RRC0010 - Remocao de fumaca (AND IC_SIT='A' AND IC_CONTR='N') na pesquisa de recebiveis para credenciadora.
- [INTP007] - Retirar duplicidades dos recebiveis abrangidos (EV591870,EV592898)
- RRC0019/ARRC022 - Inclusao de log de erro caso seja enviado codigo da interop que nao existe de-para

## 1.27.4

- [EV592091] - o participante FIDC Cielo realizou a inclusão do contrato abaixo  ROOT 182348677 {?"tpObj":"P","identdNegcRecbvl":"375199","indrTpNegc":"TC","dtVencOp":"2020-12-30","vlrTotLimOuSldDevdr":16525.53,"indrGestER":"N","indrRegrDivs":"V","indrAlcancContrtoCreddrSub":"E","indrActeIncondlOp":"N","indrActeUniddRecbvlReserv":"N","identdConjUniddRecbvl":"0000000000000001583"}? E realizou a baixa da UR através do arquivo ARRC002 ROOT 321008868, identificamos que não houve a geração da RRC0009
- [EV592541] - ARRC018: CNPJ_CPFTitular com 12 caracteres quando vier com um CNPJ.
- [EV578919] - [R2C3 - RRC0020 - 1.26.18] - Cancelamento parcial de valor de UR não está cancelando as URs como deveria.
- [EV589061] - RRC0020 - Cancelamento total enviando a RRC003 para credenciador sobre a operação que foi cancelada, porém um cancelamento total não deve enviar a RRC0003, e não enviando a RRC0003 sobre as operações recalculadas como deveria.
- V_RECALCL - Quebra de sub-jobs para processamento das operações de um mesmo recebedor

## 1.27.3

- [EV587594] - Correção do fluxo de erro para quando não há URs disponíveis e quando não há saldo.

## 1.27.2

- V_RECALCL - Correção no fluxo de constituição de URs para compor aumento do valor da operação

## 1.27.1

- [EV585401] - Ajuste no processo de recalculo por reflexo de outras operações

## 1.27.0

- [EV592482] - RRC0019 com retorno de erro está apresentando SitRetReq 001, deveria apresentar situação de recusa.
- [EV592083] - INTP007 - ajuste no campo de porcentagem para retornar a porcentagem correta
- Buscar credor na base centralizada local apenas com o status = 'ATIVO'
- V_RECALCL - Revisão de fluxo de processamento para gravames
- ARRC001 - Inclusao de validação do id_op das fraçoes para garantir que a fração esta na operação

## 1.26.38

- INTP007 - Corrigido duplicidade de frações

## 1.26.37

- Tratamento erro de constraint ao inserir ISPB_BANCO_RECEBEDOR null.

## 1.26.36

- Varredura de Credor e Credenciadora - Inserir na tabela PART_CAD novos estabelecimentos, quando são inseridos na INST_CAD.
- Tratamento nullPointer na varredura de recalculo

## 1.26.35

- [EV591870] - Ajustado para enviar a fumaça somente se não tiver para a combinação de titular, arranjo data, credenciadora
- [INTP007] - removida a validação 0050. A validação era feita duas vezes
- [RRC0019/ARRC022] - Alteração de cessão agora ajusta a constituição em caso de erros na base(duplicidades por exemplo)
- [EV587549] - RRC0008 passa a retornar 402 (sem dados) quando nao ha URs a exibir.
- [EV586585] - RRC0010 - ajuste para não validar opt-in para sub-credenciadoras
- V_RECALCL - Corrigido consulta do sub-handler em que e estava selecionado operacao nao ativas para processamento
- [EV585389] - Correção do numero de prioridade (Estava duplicando frações).
- [EV580857] - RRC0010 - Alteracao do mapeamento do campo VlrLivreUsuFinalRecbdr somente para quando UR for livre.
- [EV592045] - ARRC030 - Alteracao da validacao de quantidade de registros aceitos para tamanho de 50mb.
- [EV591311] - Configurações quantidade de registro e tamanho do arquivo para ARRC030

## 1.26.34

- INTP005 - Validar CNPJ/CPF credor somente quando contrato nao RESTRICAO
- INTP008 - REMOVIDO o a validação do erro 0050
- RRC0019/ARRC022 - Alteração de cessão. Ajustes de constituição e logs

## 1.26.33

- [EV585165] - INTP007 - ajuste no payload do contrato
- [RRC0019, ARRC001, RRC0005] Validação do domicílio SLC para as operações
- [INTP007] Removida a validação da data prevista de liquidação ter de ser maior que a data de referencia

## 1.26.32

- [EV587599] - RRC0005 correcao de regra de domilicio duplicado na alteração de operacao de antecipacao.
- Varredura de Credor e Credenciadora - Nova tabela para log de erros de duplicidade quando inserir na inst_cad a partir da base centralizada.

## 1.26.31

- Retirado validações discutidas entre as registradoras
- [EV589120] - RRC0005 - Correção na validação do tipo de conta no domicílio de pagamento entre titular e fração evitando NullPointer.

## 1.26.30

- [EV590904] - RRC0019 - Recusou operação por falta de saldo, mas devolveu lista de UR's disponíveis.
- [EV587594] - RRC0019 - Inclusão de gravame quando a agenda tem dois domicílios pode criar fração constituida com valor zero.
- [EV586585] - RRC0010 - ajuste para não validar opt-in para sub-credenciadoras
- Validação de data Fim contrato apenas para os contratos exceto os do tipo ANTECIPAÇÃO grupoNegcRecbvl.getDtVencOp()
- [EV591011] - RRC0021R1 sem informações.
- [EV590382] - Exception ao receber INTP011 de outra registradora com credenciadora não cadastrada em nossa base.
- RRC0019 (Api) - Erro ao gerar ERRC0060 com Interop

## 1.26.29

- [EV588165] - RRC0010 - Correcao na duplicidade de URs no retorno da pesquisa.
- [EV588618] - RRC0010 - Correcao na duplicidade de URs no retorno da pesquisa.
- [EV590618] - RRC0010 - Correcao na duplicidade de URs no retorno da pesquisa.
- [EV591041] - RRC0010 - Correcao na duplicidade de URs no retorno da pesquisa.

## 1.26.28

- [EV591498] - Ajuste no envio do percentual da INTP007 e RRC0019 - 319758873 - A aplicação permitiu incluir datas maiores que a data de vencimento

## 1.26.27

- [EV590386] - RRC0021 - Alteração para operação de cessão com 2 titulares
- [EV590365] - RRC0008 - Correçao para quando campo identificador vier invalido.
- [EV585380 e EV585389] - Alteração de cessão ajustada
- [EV585380 e EV585389] - Alteração de cessão ajustada
- [EV584637] - Retorno indevido do erro ERRC0100 no cancelamento com cnpj base
- [EV586824] - RRC0021 - Consulta de URs retornando frações canceladas.
- [EV587581] - Participante enviou um cancelamento de cessão e não foi enviada a RRC0004 para o credenciador.
- [EV588413] - INTP007/INTP008 - Remover a validação 9972 dos contratos da interop. Não deve ser validado o valor total das URs x valor dos contratos.
- [EV588872] - RRC0020 - Enviou a RRC003 para credenciador sobre a operação que foi cancelada, porém um cancelamento total não deve enviar a RRC0003.
- [EV589535] - ARRC023 - NullPointerException na validação da situação do titular cancelado.
- INTPO007 - Validação de data referencia para as datas do contrato não deve ocorrer na INTP007(postContrato)
- RRC0019 - Cessao - Participante - Sem URs - Com Autoaceite - Enviado por Banco (principal e administrado) deve recusar operação
- Alteracao da CentralizadoraController para simulaçao da varredura de credores
- Atualização de frações pelo CTID na operação de alteração de Cessao
- Salvar informações do cessionário autorizado
- RRC0003 - inclusão da TAG de autorização de cessão quando informado no gravame

## 1.26.26

- [EV590342] - java.util.NoSuchElementException. Colocado um controle para verificar se existem elementos na lista
- [EV583029 e EV584577] - ARRC022 - Não esta apresentando ERRC0060 em operações recusadas
- [EV581324] - RRC0010 - Mapeamento do campo vlrLivreUsuFinalRecbdr no retorno da API.
- RRC0019 - Gravame Participante Inclusao - Corrigido para atualizar as frações somente se a operação for aceita
- Ajuste na atualização da base centralizada quando tem conflito ao inserir um novo estabelecimento nas mesma data de referência.
- RRC0019 - Corrigido quebra de requisicoes de anuencia para base centralizada
- INTPO007 - Validação de data referencia para as datas do contrato não deve ocorrer na INTP007(postContrato)

## 1.26.25

- Varredura V_CTZESTC ajustada para enviar estabelecimentos independente de fração ser fumaça ou não.
- RRC0011 - Não realizar chamada para base centralizada quando não tiver estabelecimento comercial cadastrado a partir do CNPJ Base.
- RRC0010 - Ajuste na consulta de operacao por fracao.
[EV589528] - INTP007 (TC) - Corrigido o envio do CPF/CNPJ para o antigo titular
Correção da saída da RRC0008 Interop - ConsultaFracoesInteropNegocio
- RRC0019/ARRC022 - Corrigido duplicidade de envio de anuencias para base centralizada
- ARRC001 - Corrigido a copia da prioridade/titular da fração de ontem para a de hoje

## 1.26.24

[EV587628] - Erro na notificacao de anuencia quando o credor nao existe em nossa base.
[EV583169] - Corrigido nullPointer inserção sem idPartCreddr.
[EV584455] - Correção na validação quando o total das agendas disponíveis = 0;
[EV588195] - Ao recebermos o contrato, vamos precisar validar se o credor encontra-se registrado nas tabelas CREDOR
[EV587478] [EV587020] - chaves duplicadas nas consultas da RRC0021
[EV588532] - Adicionado validação de erro no RRC0019 ERRC0133 - Data prevista de liquidação deve ser menor que a data de vencimento da operação

## 1.26.23

- RRC0019/ARRC022 - Corrigido o opt-in base
[EV589215] - Favor analisar o caso relatado pelo Banco Safra.O abend no processamento ocorreu porque campos obrigatórios não vieram para algumas agendas no arquivo ARRC018:  Credenciadora GETNET.
[EV589432] - Prezado(a), o participante Banco Triangulo esta recebendo o ARRC018 com erro, nos dois arquivos:ARRC018_17351180_20210114_00168 - ROOT ID: 288234868/ARRC018_17351180_20210114_00089 - ROOT ID: 28234868

1.26.22

[EV590065] - Duas cessões na mesma UR ficam com prioridade 1
- Varredura V_CTZESTC ajustada para enviar dados para a base centralizada ao invés de trazer os dados

## 1.26.21

- RRC0019 - Number format exception ao enviar interop indevidamente (agenda)

## 1.26.20

- RRC0019 - Number format exception ao enviar interop indevidamente
- RRC0011 - Tratamento de data fim de optin para não aceitar se for antes da data de referencia - ERRC0022

## 1.26.19

[EV588985] - Erro 205 mesmo quando outros titulares possuem URs na Alteração de GRAVAME
- RRC0019 - Otimização consulta de frações por ID_OP para recalculo e alteração
[EV583140] - O participante Banco Bradesco incluiu os contratos abaixo para a credenciadora Stelo e não identigicamos a geração da mensagem RRC0003, poderiam verificar?
- Ajuste da busca de estabelecimento comercial no cache local diariamente.

## 1.26.18

[EV588189] - ARRC007 Incluindo IdentdCtrlReqSolicte para registros de OPT-IN
[EV578919] - [R2C3 - RRC0020 - 1.26.4] - Ajuste e inclusão de logs na validação validarURsInformadasPertencemContratoInformado
[EV589012] - Peço que verifiquem pois o participante Guanabara enviou RRC0025 e não gerou retorno na mensagem : Root Id: 289831868
- RRC0019 - Ajuste para so enviar a RRC0028 quando for um novo opt-in
[EV587594] - Correção frações negativas na inserção de gravame com gestão registradora / alteração de gravame com gestão registradora.
[Sem evento] - Correção na geração da RRC003 e RRC009 (Incluindo todas as frações e não apenas a diferença recalculada).
[EV589010] - Ajuste no envio de erro ERRC0205

## 1.26.17

RRC0011 - Otimização para bater o retorno da centralizada com o que foi enviado. Caso divergente o processamento falha.

## 1.26.16

[EV588423] - RRC0019/ARRC022 - Na interoperabilidade enviar a INTP010 consultando sempre pelo CNPJ completo
[EV587995] - RRC0010 - Consulta nao considerava sub credenciadora
[EV588423] - RRC0019/ARRC022 - Na interoperabilidade enviar a INTP010 consultando sempre pelo CNPJ completo
[EV588205] - RRC0019/ARRC022 - Envio de valorComprometido: "0" na INTP007
[EV584586] - RRC0019/ARRC022 - Não esta interoperando
[EV586066] - RRC0019/ARRC022 - Não esta interoperando
[EV588175] - RRC0019/ARRC022 - Não esta interoperando
[EV588403] - INTP004 - remover validação 032 (verificação de data de vencimento de contrato )
[EV588526] - Correção de NullPointer na FinanciadoraController no caso de não envio de unidades recebíveis via API
[EV587487] - RRC0020 - Participante enviou um cancelamento parcial com remoção de um CNPJ base que não tinha no contrato e aceitamos a operação cancelando o contrato como cancelamento total
[EV587594] - Correção frações negativas na inserção de gravame com gestão registradora / alteração de gravame com gestão registradora.
[Sem evento] - Correção na geração da RRC003 e RRC009 (Incluindo todas as frações e não apenas a diferença recalculada).

## 1.26.15

RRC0011 - Implementação e ajuste da regra de validação de EC x Credor quando enviado pela credenciadora.

## 1.26.14

RRC0011 - Incremento de log para avaliação de problenas.

## 1.26.13

RRC0011 - Ajuste no envio de opt-in para cada registradora de acordo com a registradora do estabelecimento e caso não tenha estabelecimento não enviar.

## 1.26.12

RRC0011 - Ajuste no envio de opt-in para cada registradora de acordo com a registradora do estabelecimento.

## 1.26.11

RRC0011 - Ajuste na otimização do processamento de envio de estabelecimento para a base centralizada.

## 1.26.10

[EV587000] - Ajuste na geração de frações fumaças e duplicate key
[EV585162] - INTP007/INTP008 - campo id_efet_contrto_intrdd nao esta sendo gravado para operacoes de penhora.
[EV586613] - Recebemos uma solicitação de alteração de contrato da CERC e rejeitamos a mesma
[EV588123] - Da 205, para a interop teremos que tirar a validação e continuar o registro da operação com as informações que foram passadas pela outra IMF

## 1.26.9

V_CTZESTC - Null pointer quando não tem estabelecimento cadastrado na base centralizada (remota).

## 1.26.8

[EV584996] - RRC0019 - Troca de Titularidade - Gestão Registradora - Sem retorno (NullPointerException) para NUOp 07679404202101045000033 e 07679404202101045000039
[EV585034] - ARRC022 - Fluxo de interop com recusa de solicitação de agenda (INTP010E) ou de registro de contrato (INTP007E) não esta gerando ARRC022RET
[EV586073] - RRC0019 - Troca de Titularidade - Gestão Registradora - Tratamento para erro ValidationException
[EV587576] - ARRC022 - Fluxo de interop com recusa de solicitação de agenda (INTP010E) ou de registro de contrato (INTP007E) não esta gerando ARRC022RET
[EV587904] - RRC0019 - Troca de Titularidade - Gestão Participante - Tratamento para erro ValidationException
[EV583083] - Ajustes no fluxo de cancelamento de cessão
[EV585023] [EV585916] [EV586072] - Ajuste na validação de unidade recebível (ERRC0108)
[EV584891] - Correção na geração de cnpj base e completo quando possui outras operações constituindo na mesma UR

## 1.26.7

[RTC44370 e EV583040] - BUGFIX -  Foram encontradas divergências no arquivo ARRC018 ao validar o EV583040 para recebivel de outra IF que não é a recebedora da ARRC018
[EV584891] - Correção na geração de cnpj base e completo.
[EV587479] - BUGFIX - Arquivo 001: Registro esta na fração stage mas não gravou os dados na fração corretamente.
[EV587010] - Exception ao tentar armazenar msg de erro na INTP002.
[EV586409] - Duplicate key na alteração.
- RRC0019 - Corrigido salvar cnpj da CIP no opt-in automatico

## 1.26.6

RECALCULO - Correção consulta de credenciadora/sub-credenciadora com CNPJ duplicado
[EV578522] - Correção na inclusão de gravame, gestão registradora. correção na insrercao nas tabelas de OP_TITLAR_DOMCL. para o recálculo.

## 1.26.5

RRC0019 - Split em 1000 registros de opt-ins para o payload enviado para a Base Centralizada

## 1.26.4

[EV578919] - [R2C3 - RRC0020 - 1.24.7] - Geração da RRC0020E não estava capturando erros da tag <Grupo_RRC0020_RegRecbvl>
- RRC0020 - Inclusão de tratamento para identd-op com espaços no endpoint /financiadora/operacoes/{identd-op}
- Ajuste query do recalculo - otimização.

## 1.26.3

[EV587026] - RRC0013 - Ajuste na validação de registradora para a financiadora.
[RTC44315] - BUGFIX -  O sistema aceitou tag VlrPreContrd com mais de 2 casas decimais
[EV577471] - Corrigido swagger
[EV575210] - Corrigido em EV585389 (adicionado teste)
- Inclusão do parâmetro SLA_POOLING_SEGUNDOS para controle de SLA em requisicoes sincronas

## 1.26.2

- RRC0011 - Ajuste na validação de anuencia duplicada. Fazer a busca apenas se não houver outros erros de validação.
EV577471 - Corrigido swagger
EV575210 - Corrigido em EV585389 (adicionado teste)

## 1.26.1

[EV583181] - Ajuste no tratamento de requisição de pagina inexistente via APU
- Ajuste tratamento de node e dpc na chamada dos batches do Atlante
- Ajuste no envio de data fim para interop INTP011 como hora 23:59:59.999
- Ajuste no tratamento de chave única da inclusão e consulta de estabelecimento comercial.

## 1.26.0

[EV579449] - O participante GETNET mencionou que recebeu contratos através da mensagem RRC0003 com o mesmo identificador de requisição
RRC0019/ARRC022 - Agrupamento da solicitação de anuencia na base centralizada

## 1.24.11

RRC0010 - Tratamento tag vlrLivreUsuFinalRecebedor.
[EV579449] - O participante GETNET mencionou que recebeu contratos através da mensagem RRC0003 com o mesmo identificador de requisição

## 1.24.10

- ARRC022/RRC0019 - TC Alteração: 254686870 org.postgresql.util.PSQLException: ERROR: duplicate key value violates unique constraint "fracao_unidd_recbv_op_20210109_8_pkey"
- Interop - Retirada a insercão na SOLICT_INTRDD para as requisicoes sem SLA

## 1.24.9

EV585418 - O sistema estava recusando operação com 0060 mesmo tendo UR e aceite incondicional = S
EV586409 - Divisão por zero quando não há livre para recalcular.
EV585156 - Fracoes exibidas na consulta RRC0008 quando operacao esta cancelada.
- atualizada a versão do swagger bilateral (0.0.32)
- ajuste na query de lock da tabela SOLCTC_INTRDD - troca de FOR UPDATE para FOR NO KEY UPDATE
- inclusão de logs na RRC0020 via API

## 1.24.8

ARRC001 - Ajuste no Nullpointer ocorrido durante o processamento.

## 1.24.7

Ajustes no xsd da 009 e 021 - Tirando obrigatoriedade do grupo titular
[RTC44320] - ARRC022 - Erro ao processar alteração com interop
- RRC0019/ARRC022 - Erro de null-constraint em operações
[EV578919] - Ajuste para preenchimento do GrupoRRC0020RegRecbvl ao processar o cancelamento via API
- PreOptIn - Erro ao buscar por subcredenciadora

## 1.24.6

[EV583380] - RRC0020 retornou com erro, mas não exibia a mensagem de erro no JSON
[EV584637] - RRC0020 - Validação ERRC0100 para cnpj base estava sendo feita de forma errada
[EV578919] - RRC0020 - Cancelamento parcial de valor de UR estava caindo no cenário de cancelamento por titular porque a aplicação estava permitindo o envio de titular e grupo de recebíveis na mesma mensagem.
[EV579214] - [R2C3 - RRC0020 - 1.23.2] - Durante reteste do evento EV557811, a REDE verificou que não foi enviado arquivo RRC0003, em cancelamento parcial.
[EV582068] - [R2C3 - RRC0020 - 1.23.2] - O participante Banco Rendimento encaminhou uma mensagem de cancelamento, no entanto, não recebeu a mensagem RRC0009 com a atualização da operação.
[EV580046] - RRC0008 - Mostrar dados de contrato quando nao ha fracoes a serem exibidas na consulta.
[EV585985]- ARRC001 - Refactoring na busca da prioridade e titular de ontem
[EV584548] - Correção nullPointer domicilio bancario na alteracao de gravame por registradora.
[EV579314] - Correção agrupamento na RRC0010.
[EV584455] - Correção na validação quando o total das agendas disponíveis = 0;

## 1.24.4

[EV573789] - BUGFIX - O particiapnte Banco Itau informou que recebeu o arquivo ARRC018 com o campo CNPJ_CPFTitular com o valor "45242914"
- RRC0019/ARRC002 - Otimização de consulta de Fracoes livres por operação
- RRC0019/ARRC002 - Quebra de consulta por frações para consultar por cada credenciadora em um loop
- ARRC007 - Otimização da consulta nas tabelas de resumo diario

## 1.24.3

- Ajuste RRC0015 e RRC0016 - erro ao processar adesão e envio para o participante.

## 1.24.2

[EV585111] - RRC0011 - Erro ao consultar estabelecimento comercial pelo CNPJ Base - Não deve enviar o arranjo neste caso para a pesquisa.
[EV584595] - RRC0010 - Erro ao consultar estabelecimento comercial pelo CNPJ Base - Não deve enviar o arranjo neste caso para a pesquisa.
- ARRC007, ARRC0017, Rolagem, RRC0008, INTP010, RRC0015, RRC0016, RRC0027 - Ajuste no tratamento de CNPJ duplicado para IF e credendiadora.
- RRC0004, ARRC007, RRC0008, RRC0011, RRC0012, RRC0013, RRC0015, RRC0016, ARRC0017, RRC0019, RRC0025, RRC0027, RRC0028, RRC0029, Rolagem, INTP010 - Ajuste no tratamento de tipo Credenciadora + SubCredenciadora e InstituicaoFinanceira e InstituicaoNaoFinanceira.

## 1.24.1

[RTC44219] - RRC0019 - Cessão Participante Sem Saldo Sem Aceite - Deveria ter retornado erro ERRC0060
[RTC44175] - Correção na query recalculo.
[EV584899] - ARRC022 - Arquivo retornao sem grupo de constituido e a constituir

## 1.24.0

[EV577343] - ARRC022 - Retornamos apenas 2 operações no arquivo RET das 4 operações. A falha ocorreu pois no arquivo haviam operações com interop e sem interop.
[EV584642] - ARRC022 - Erro java.lang.NullPointerException ao enviar Contrato para Interop de operação de Troca de Titularidade sem Valor de Garantia.
[EV585034] - RRC0019/ARRC022 - Otimização na consulta das frações para operações com CNPJ completo
[EV579463] - BUGFIX - RRC009, RRC016 e RRC029 Favor corrigir as informações do xsd conforme apontamento feito pelo participante

## 1.23.2

[EV583017] - BUGFIX - 018 O campo VlrComprtdInst está com o valor maior que o campo valorTotal
[EV583393] - RRC0008 - Consulta por CNPJ devolve apenas o ultimo contrato.
[EV584951] - nullpointer correção 009
[EV579214] - RRC0020 - Durante reteste do evento EV557811, a REDE verificou que não foi enviado arquivo RRC0003, em cancelamento parcial.
[EV582068] - RRC0020 - O participante Banco Rendimento encaminhou uma mensagem de cancelamento, no entanto, não recebeu a mensagem RRC0009 com a atualização da operação.
[EV582214] - O participante Tripag informou que não recebeu a mensagem RRC0004, no entanto, o Banco Triângulo e o BS2 encaminharam registros de cancelamento para a credenciadora.
[EV584455] - Correção na validação quando não há agenda disponível.
- Ajuste envio de data na consulta da base centralizada quando o parâmetro de data de última atualização é enviado (getAnuenciasOnLine,getCredoresOnLine, getCredenciadorasOnLine, getArranjosPagamentoOnLine, getParticipantesSLCOnLIne)
RTC-44175 - Corrigido query

## 1.23.1

[EV582211] - O participante FIDC Cielo realizou a inclusão das operações abaixo e realizou a baixa das UR através da Cielo (ARRC002_01027058_20201228_04773), porem verificamos que a mensagem RRC0009 não foi gerada para o FIDC, poderiam verificar?
[EV581314] / [EV579285] / [EV578539] - RRC0005 - correção da gravação de frações fumaça
[EV583029] - ARRC022/RRC0019 - Falta de codigo de erro na recusa das operações
- RRC0019 - Ajuste no processamento de Interop quando enviado o CNPJ Base

## 1.23.0

- RRC0004, RRC0011, RRC0012, RRC0013, RRC0019, RRC0025, RRC0028, RRC0029 - Ajuste no tratamento de CNPJ duplicado para IF e credendiadora.

## 1.22.19

- ARRC002 - Ajuste da query com erro de SQL e inclusão de log para validação.

## 1.22.18

- RRC0011 - Tratamento de duplicidade de ECs na base centralizada local - garantido por distinct na query e ignorando as data ini, criação, ultima alteração e data fim.

## 1.22.17

[EV580048] - RRC0027 / INTP012 - O sistema apresentou erros ao tentar inserir Contestação em nossa base.
[EV583052] - RRC0010 - Ajuste no envio do CNPJ Base para CNPJ Completo na INTP010
- RRC0019/ARRC022 - Otimizacao consulta a dominios de arranjo e tipo canal
- RRC0011 - Tratamento de duplicidade de ECs na base centralizada local.

## 1.22.16

[EV582449] - Nao apresentar fraçoes nas consultas RRC0008 e RRC0021 quando vlEftLiquid > 0 ou dtEftLiquid vier preenchida.

## 1.22.15

[EV573789] - BUGFIX - Itau informou que recebeu o arquivo ARRC018 com o campo CNPJ_CPFTitular com o valor "45242914".
[EV581976] - RRC0019 - Inclusão de operação RRC0019 constituiu valor maior que a garantia solicitada (operação gestão CIP, alcance geral, por percentual)
[EV581994] - RRC0019 - Não distribuiu proporcionalmente a operação entre os titulares solicitados

## 1.22.14

[EV579996] - [RRC0005] - ERRC0005E sem código de erro.
[EV579792] - [RRC0005] - ERRC0005E sem código de erro.
[EV581944] - Erro ERRC0099 estava sendo lançado indevidamente quando o cancelamento é feito pelo CNPJ base

## 1.22.13

- RRC0010 - Otimização consulta
- EV577111 - Cessao santander nao estava alocando fracoes

## 1.22.12

[EV581046] - BUGFIX - Prioridade na 019 está sendo incrementada, sem respeitar a data de referencia.
- RRC0003 - Corrigido valor da TAG <CPF_CNPJPartNegcdr> para operações com Interop
- V_ROLAGEM - Ignorar erros de constraint

## 1.22.11

- RRC0019/ARRC022 - Correção do registro de opt-in automatico para operações de interop

## 1.22.10

[RTC-43913] - [R2C3 - ARRC030 - 1.21.31] - Sistema está baixando o EC na tabela estbmnt_comcl (ic_sit = B), porém não está inativando os registros do EC na tabela estabelecimento_comercial do schema rrc_ctz

## 1.22.9

[EV582119] - BUGFIX - Registros não estão sendo enviados na 018, mesmo estando na destinatario
[EV580225] - Correção de cancelamento do titular na tabela op_titlar_domcl
[EV579930] - Campos de sitReq e identOp não estavam sendo retornados no RRC0020E api

## 1.22.8

- RRC0010 - Ajuste na exibição do grupo domicilio. Troca da regra de fração livre para domicilio proprio.
- RRC0011 - Ajuste no tratamento do retorno de codigos de erro via API.

## 1.22.7

- RRC0010 - Ajuste no agrupamento de arranjo para o grupo titular.
- Recalculo - Otimização em DELETE na tabela FRACAO_UNIDD_RECBV_OP

## 1.22.6

- Recalculo - Tratamento de NullPointerException ao gerar RRC0003

## 1.22.5

 - RRC0019 (Gravame/Registradora/Inclusao) - Correção na geração das fumaças para CNPJ base

## 1.22.4

EV580967 - RRC0011 - Erro ao processar com erro e não enviar o codigo de erro.
RRC0011 - Erro ao grava o numero de controle da base centralizada quando interopera por credor.

## 1.22.3

EV575016 - ARRC022/RRC0019 - Corrigido a geração de fumaça para CNPJ Base
- RRC0010/RRC0011/RRC0013 - Correção de NullPointerException
- [ARRC002] - ROOT_ID = 13025114 BUGFIX DE NULLPOINTER DE PARTICIPANTEVO

## 1.22.2

Ajuste RRC0010 / RRC0011 e RRC0013 para validação de credenciadora e credor
Envio de multiplas interops quando a validação é pelo credor
Revisão de validação de participante pelo papel de credor e credenciador e CNPJs repetidos para a RRC0028 e RRC0029.

## 1.22.1

[EV578515/EV579844/EV580055/EV580066] - O sistema não está retornando corretamente mensagem RRC0027R1.
[EV580617] - O sistema não está gerando RRC0025R1.

## 1.22.0

- RRC0019 - Ajuste no opt-in automatico (RRC0028)
- Compatibilidade com Atlante 5.1.64
[EV580549] - BUGFIX - 018 está considerando valores a constituir no valor Total do Titular.

## 1.21.31

- ARRC002 batch id = 12980166 nullpointer ARRC002R1
- RRC0011 - Erro ao buscar credora na centralizadadora local. Ajuste na consulta da base centralizada.

## 1.21.30

- RRC0011 / INTP0011 - Ajuste no tratamento de interop para Credor quando a credenciadora for CIP.
- ARRC001 (DestinoOptInLateBatch) - Otimização - Retirada do MAX(NR_CTRL_BASE_CENTZD) na consulta da PRE_OPT_IN

## 1.21.29

- inclusão de logs no recalculo handler e subhandler
- RRC002 - 12980166 nullpointer

## 1.21.28

- RRC0019/ARRC022 - Corrigido duplicação de registros E e R1

## 1.21.27

RTC 43789 - RRC0008 - Sistema não está retornando a tag CtPgto na msg RRC0008R1.
RTC 43790 - RRC0008 - Sistema não está retornando os dados da operação quando enviado no filtro da RRC0008 a tag CNPJ_CNPJBase_CPFTitlar.
EV579987 - Duplicidade nas mensagens RRC0008.

## 1.21.26

EV579243 - erro null pointer da RRC0005 Troca de dados da fumaça
ROOT ID - 157694644 - NullPointer na execução da RRC002

## 1.21.25

RRC0010 - Agrupamento do grupo domicilio levando em conta a data prevista de liquidação da UR.

## 1.21.24

[EV579936] - RRC0010 - Erro ao processar domicilios repetidos em diferentes URs.
[EV580477] - ARRC022 - Correção em que são enviadas duas operações e somente uma é processada (Ex. batch 155095644 - ARRC022_60701190_20201222_00002)
[EV578541] - Recebemos uma UR com uma operação cancelada na ARRC001 da Rede e enviamos na ARRC018 do Itaú.
[EV572863/EV573674] - RRC0011E/RRC0013E - No código ERRC0013 está devolvendo o status "500" quando o correto deveria ser "400", conforme o descrito no swagger.
ROOT ID - 157694644 - NullPointer na execução da RRC002
[EV576749] - RRC0010 - EGEN0037 está devolvendo o HTTP 500 ao invés do HTTP 412, conforme o descrito no swagger.

## 1.21.23

- ARRC022 - Correção no processamento de registros com interop

## 1.21.22

- RRC0011 - Está gravando o numero de controle da base centralizada no campo errado quando é uma nova inclusão e possui interop.

## 1.21.21

[EV577893] - EGEN0050 - Erro nao gerenciado na RRC0008.
[EV578623] - Estao sendo exibidos os contratos mais antigos.
[EV574598] - Consulta por operacoes na RRC0021 estava trazendo uma lista ao inves de um registro unico.

## 1.21.20

- RRC0019 - Correção de Validação de porcentagem entre 0 e 100
- Compatibilidade Atlante 5.1.62

## 1.21.19

- RRC0011 - Erro ERRC0196 ao interoperar para obter o numero de controle da base centralizada.

## 1.21.18

- ARRC022 - Correção de erros de NullPointerException

## 1.21.17

[EV573800], [EV574155] - Corrigido erro ao consultar EC na base centralizada com retorno 404 (not_found)
[EV576566] - RRC0010 - Erro de validação de adesão para participante administrado diferente do participante principal.
- RRC0011 - Ajuste no processo de interop. Falhando quando é realizado pelo CNPJ base.

## 1.21.16

[EV571577, EV579243] - Não identificamos envios da RRC009
[EV579936] - RRC0010 - Nullpointer no grupo domicilio bancário
- Adição de gatilho de recalculo na ARRC002
- RRC0011 - Ajuste na busca de EC na base remota - erro no parâmetro de busca.
- Remoção do cache na busca de estabelimento comercial na base local.

## 1.21.15

[EV579229] - Duplicidade de URs no registro da RRC0008.
[EV578581] - A conversão do objeto de api para a RRC0019 estava usando o campo de cpfCnpjTitular para preenccher o titular da conta
- A RRC0008 estava convertendo incorretamente para o objeto de pesquisa o part principal ao invés do adm para o campo de credenciadora


## 1.21.14

[EV577460] - O participante Stelo enviou um valor pre contratado no arquivo ARRC001_14625224_20201215_00001 e ao consultar a agenda RRC0010 (129888649) não foi retornado o valor pre contratado, poderiam verificar?
- Incremento dos logs na RRC0011
- Busca na base remota quando não localiza EC na base local

## 1.21.13

- Incremento dos logs na RRC0011.

## 1.21.12

[EV576910] - Ao recebermos um contrato de troca de titularidade da Interop, quando a outra registradora está informando o valor da garantia (campo inválido para este tipo de operação), o sistema está lançando código de erro 9928.
[EV578524] - Campo "cnpjCreddrSubPedDescstcNegcRecbvl" estava sendo preenchido incorretamente pela RRC0014
- Alteracoes da refatoracao de inclusao
- INTP010 - Enviar o arranjo sempre de acordo com o opt-in
- RRC0011 - Ajuste no envio de codigo de erro ERRC0196

## 1.21.11

- Inativação parâmetro de aceito do CNPJ Base na RRC0011.

## 1.21.10

[EV572972], [EV572965] - RRC0011 e RRC0010 - Tratamento de inclusão de OPT-IN e envio de interop 010 pelo CNPJ Raiz

## 1.21.9

- INTP007 - ajuste para não validar adesão na interoperabilidade no post contrato para a RRC0005

## 1.21.8

- Ajustes no post contrato para a RRC0005

## 1.21.7

[EV577431] - Ajuste no codigo de erro para facilitar o entendimento por parte do participante. De ERRC0105 para ERRC0045
[EV571176] - BUGFIX - Itau reportou que não recebeu as operações de cessão na agenda do dia 30.11. Na base de dados constam operações ativas de cessão com UR's constituídas
[EV577759] - Erro no preenchimento do campo "http://www.cip-bancos.org.br/identificador-emissor-principal-relacionado" na mensagem RRC0003 na API.
- Ajuste da validação de número de conta + dígito (erro 0014 interop)
- Ajuste NPE ARRC022 e Exemplo financiadora/operações no yaml da API

## 1.21.6

[EV578606], [EV578608], [EV578975] - RRC0010 - Agrupamento do grupo domicilio bancario quando há mais de uma operação.
[EV575702] - Erro ao validar participante inexistente no cadastro.
- Erro ao validar o CNPJ da instituição financiadora. Afeta as funcionalidades RRC0008 / RRC0010 / RRC0011 / RRC0021

## 1.21.5
===
- RRC0019 - (api) - Tratamento de NPE para URs nao encontradas na constituição da operação
- RRC0019 - (api) - Tratamento de NPE em situações de recusa com campos sem conteudo
[EV575098] - "postRetornosRegistroOperacao" id batch 115728722 ao qual foi gerado o R1 e apontado o erro - java.lang.NullPointerException

## 1.21.4

- /agenda - Ajuste na validação de DataVencimentoEfeito para comparar com context.getBatchReferenceDate() e não com LocalDate.now()
- /agenda/retry - Remoção de duplicidade dos códigos de erro
- Ajuste na RRC0021, operaçao /v1/financiadora/operacoes.
- Ajuste na INTP011 - erro ao enviar o tipo de opt-in quando não é opt-in automático e o campo não está null.

## 1.21.3

RRC0019 - Otimização - Inclusao de select IN para recebiveis de operação TC + Inclusão
ARRC001 - Corrigido tratamento para hash-fracao de ontem

## 1.21.2

[EV578018] - RRC0020 - Ajuste na mensagem ERRC0124 para esclarecer que o titular é apenas para cancelamento parcial
[EV574598] - RRC0021 nao exportava campos UIR, conforme swagger.
- Tratamento na RRC0011 para evitar null pointer quando interopera e ainda não incluiu o opt-in.

## 1.21.1

[RTC43260] - Ajuste de NullPointer e de limite de dígitos nas contas
[EV577455] - RRC0011E - Retornando HttpStatus 422-Unprocessable Entity ao invés do 400-Bad Request definido no swagger
- Inclusão dos tipos de negociação Ônus - Gravame Penhor e Ônus - Gravame Cessão Fiduciaria na rotina de recálculo
- RRC0005 - Ajuste para o tipo de negociação Ônus - Penhora desconsiderar operações do tipo de negociação Ônus - Gravame Cessão Fiduciaria
- RRC0019 - Retirada do log do objeto ProcessamentoNegociacao (interop-log)
- RRC0011 - Ativação do parâmetro para buscar registratora vinculada a credora quando a registradora da credenciadora for a CIP.
[EV576080] - Peço por gentileza verificar o não envio da RRC0009 aos participante fidc Cielo (administrado da Cielo) apos envio do arquivo ARRC002_01027058_20201212_04261.

## 1.21.0

- Compatibilidade Atlante 5.1.59
- RRC0019 - Refatoração Gravame Gestão Registradora Inclusao

## 1.20.13

[EV577763] - Tratamento na RRC0011 para buscar a registradora vinculada ao credor cada a registradora vinculada ao credenciador seja a CIP. - inativado no momento
[RTC43391] - Ajuste de gravação do CNPJ Recebedor na tabela de optout
[EV575647] - RRC0008 retorna 422 quando nao encontra registros.
[EV577097] - INTP004 - Estamos retornando erro indevido ao recebermos agendas da interop quando o tipoDocumento da informação da conta vem como cpf minúsculo.
[EV577382, EV573763] - RRC0005 - erro da rrc005 batch id 130293662
- atualizada a versão do swagger bilateral (0.0.31)
- atualizada a versão do swagger (0.0.18)

## 1.20.12

- RRC0010 - erro ao enviar a consulta com filtro pelo valor livre total.

## 1.20.11

- RRC0010 - erro ao enviar a consulta com filtro pelo valor livre total.

## 1.20.10

[EV576855] - Não gerou RRC0020R1, correção na validação da data no início do id da operação quando o mesmo menor que 8 dígitos
- Tratamento na validação de CNPJ e captura da exception
- Ajuste no filtro da RRC0010 para filtrar apenas pelas credenciadoras vinculadas ao opt-in.

## 1.20.9

[EV575673] - O participante REDE enviou a baixa das URs do CNPJ 43462720000424 com as datas 28/12 e 29/12 e o arquivo foi rejeitado com o erro ERRC0059
- Tratamento na validação de CNPJ e captura da exception
- Ajuste no filtro da RRC0010 para filtrar apenas pelas credenciadoras vinculadas ao opt-in.

## 1.20.8

- Tratamento na validação de CNPJ e captura da exception

## 1.20.7

- Ajuste na adição de grupo corretamente pela chave registradora + credenciadora
- Ajuste validação RRC0011 para permitir opt-in com cnpj base, exceto de outra registradora

## 1.20.6

- Ajuste no agrupamento de retorno da RRC0010 quando há mais de uma registradora e/ou mais de uma credenciadora para um mesmo usuário final recebedor.
- ajuste validação RRC0011 para permitir opt-in com cnpj base, exceto de outra registradora

## 1.20.5

- Ajuste no retorno de frações quando a pesquisa é por CNPJ completo e o opt-in é por base. A busca de frações deve ser pelo completo.

## 1.20.4

- Ajuste no retorno de frações quando a pesquisa é por CNPJ completo e o opt-in é por base. A busca de frações deve ser pelo completo.

## 1.20.3

[EV575555] - Inclusão de mapeamento do campo indrCancelCessConstitr em RRC0020OutputHandler para formatar a msg de erro no json
[EV572322] - RRC0019 - TC - Revisão na definição de prioridades
[EV575170] - Ajuste RRC0011 tornado a rotina de processamento da base centrlizada síncrona com o retorno a R1.

## 1.20.2

[EV575016] - Correção fumaças com cnpj base e cnpj completo.
[EV573157] / [EV574701] - correções ajustes rrc0021
[RTC43480] - [R2C3 - RRC0019 - 1.20.0] - Sistema não está considerando o valor da operação ao constituir o % da fração ao enviar uma RRC0019 Cessão Gest PART IndrRegrDivs = P, IndrActeIncondlOp = N com valor menor que o disponível livre da agenda
- RRC0011 do Itau - NULLPOINTER ROOT ID (123719644)
- unificação das rotinas de consulta rrc0021 e rrc0008
- [R2C3 - RRC0015 - 1.17.3] - Retorno do envio das datas com timezone UTC
- /agenda - Inclusão de verificação para só atualizar a operação caso os dados sejam diferentes (DtVencOp, NrLimConcdSldDevdr e NrVlrGar)

## 1.20.1

RRC0019 - Otimização do UPDATE de atualização das frações

## 1.20.0

RRC0019 - Otimização dos batch inserts com a utilização do getJdbcTemplate().batchUpdate(...new ParameterizedPreparedStatementSetter())
- Atualizada dependencias Atlante 5.1.58
- Inclusão da System.property spring.jdbc.getParameterType.ignore=true

## 1.19.2

EV575210 - RRC0019 - Ajuste em alteração de troca de titularidade com mais de uma alteração (a cada alteração é retirado uma UR)
RRC0010 - Ajuste na totalização do campo VlrLivreUsFinalRec.
[EV572804/EV572863/EV575583] - [R2C3 - RRC0013 - 1.18.11] - Enviando EGEN0050 Erro não gerenciado

## 1.19.1

RRC0010 - Ajuste na exibição do campo valor total e na totalização do campo VlrLivreUsFinalRec.

## 1.19.0

[EV572899] - BUGFIX - Participante informou receber valores divergentes no ARRC018 recebido da GetNet
Ajustes 0005 / Atualizacao de frações 
ARRC018 - Ajustes de performance com a criação da tabela destinatario_opt_in_index
RRC0010 - Ajuste na exibição do campo valor comprometido e grupo domicilio quando da mesma IF, IF diferente ou se é credenciadora.

## 1.18.20

[EV573726] - Cessão sem URs disponíveis e Gestão participante
[EV572531] - Favor verificar as mensagens 0010 enviadas pelo Santander, onde voltou somente informações do grupo titular 

## 1.18.19

[EV573803/EV557811] - RRC0020 - O ITAU enviou uma operação com 2 titulares e depois enviou um cancelamento parcial de titular. Porém o sistema cancelou todas as URs da operação.
[EV568965/EV574238/EV574592/EV575206] - ARRC023 não gerou RET, NullPointer no envio da RRC0004 via API

## 1.18.18

RTC43432 - [R2C3 - RRC0010 - 1.18.12] - Divergências encontradas nos Grupo_RRC0010R1_UniddRecbvl e Grupo_RRC0010R1_DomclBancInst quando agenda possui operação
RTC43257 - [R2C3 - RRC0010 - 1.18.14] - Divergências nos valores da UR na RRC0010R1
EV574561 - RRC0008 retorna erro 422 quando nao ha dados na consulta.

## 1.18.17

[RTC43449] - [R2C3 - RRC0010 - 1.18.14] - Sistema está retornando RRC0010R1 com SitRetReq = 004 ao enviar consulta informando CNPJs titular e do usuário final completo com OPT-IN com CNPJ Base

## 1.18.16

Ajuste no tratamento de logs para visualizar o detalhamento de logs gerados em todas as classes.
Aumento do nível de log na RRC0010 para visualizar o detalhamento do processamento.

## 1.18.15

[RTC43449] - [R2C3 - RRC0010 - 1.18.14] - Sistema está retornando RRC0010R1 com SitRetReq = 004 ao enviar consulta informando CNPJs titular e do usuário final completo com OPT-IN com CNPJ Base

## 1.18.14

RRC0019 - Ajuste no retorna das URs disponiveis para operações do tipo troca de titularidade (inclusao + participante + especifico + valor + sem auto-aceite)

## 1.18.13

- Ajuste varredura de credor - tratamento de data no formato ISO
- Ajuste varredura de credenciadora - tratamento de data no formato ISO
[EV574598] - Favor analisar o RRC0021 do Banco Banrisul, ID BATCH 11260802, esta mensagen devolveu uma lista de operações, quando deveria ter outro leiaute conforme esta no swagger.
[EV574553] - Tentei novamente realizar a consulta – RRC0021, segue o retorno do JSON, gentileza verificar pois não está compatível com o retorno da documentação do Swagger

## 1.18.12

[RTC43400] - [R2C3 - RRC0010 - 1.18.0] - Sistema está retornando erro ERRC0203 mesmo IF possuindo OPT-IN cadastrado (Validação do CNPJBase na RRC0010 e no OPT-IN) - Incluído o mesmo tratamento de like no CNPJ Base para busca de URs e Frações.
RRC0013 - Ajuste na consulta de validação de operação vigente

## 1.18.11

[RTC43402] - [R2C3 - RRC0019 - 1.18.1] - Divergências encontradas ao validar o cenárioCessão com Gestão Part + Regra divisao valor + Sem aceite incondicional + Alcance Especifico
[RTC43400] - [R2C3 - RRC0010 - 1.18.0] - Sistema está retornando erro ERRC0203 mesmo IF possuindo OPT-IN cadastrado (Validação do CNPJBase na RRC0010 e no OPT-IN)
[RTC43411] - [R2C3 - RRC0010 - 1.18.10] - Erro no conteudo da tag cnpjER.
[EV571176] - BUGFIX - Itau reportou que não recebeu as operações de cessão na agenda do dia 30.11. Na base de dados constam operações ativas de cessão com UR's constituídas
[EV572863/EV572804] - RRC0013 está enviando EGEN0050 Erro não gerenciado quando ocorre erro na validação

## 1.18.10

RTC43400 - [R2C3 - RRC0010 - 1.18.0] - Sistema está retornando erro ERRC0203 mesmo IF possuindo OPT-IN cadastrado (Validação do CNPJBase na RRC0010 e no OPT-IN)

## 1.18.9

RRC0010 - Correção no valor informado na tag VlrTot  

## 1.18.7

- ajuste na versao por duplicidade de artefato no Nexus

## 1.18.6

RRC0010 - Corrigido inclusao de fracoes nas URs

## 1.18.5

RRC0010 - Corrigido inclusao de fracoes nas URs

## 1.18.4

RRC0010 - Corrigido inclusao de fracoes nas URs

## 1.18.3

RRC0019 - Inclusao de FLAG para ativar o modelo "novo" de processamento de operações

## 1.18.2

RRC0010 - Retirada a consulta na tabela UNIDD_RECBV. A consulta foi alterada para acessar somente a FRACAO_UNIDD_RECBV_OP
RTC43400 - [R2C3 - RRC0010 - 1.18.0] - Sistema está retornando erro ERRC0203 mesmo IF possuindo OPT-IN cadastrado (Validação do CNPJBase na RRC0010 e no OPT-IN)

## 1.18.1

- Remoção da regra da Interop Agenda - 0050 - Validação de data de liquidação - Removido temporariamente até validação das registradoras

## 1.18.0

[EV569500] - BUGFIX - na base de dados o contrato foi incluído ontem com a prioridade 1 corretamente (fração pela data de referencia da inclusão = '2020-11-25'), mas no registro de hoje a prioridade está com 0 (este registro é incluído ao receber a agenda ARRC001).
[RTC43283] - CIP ouvindo não esta gravando nas tabelas fracao_unidd_recbv_op e unidd_recbv.
[EV571665] - RRC0008 esta mostrando CNPJ base em URs constituidas.
[EV573550] - Prezados, pedimos por gentileza verificar a mensagem RRC0015 gerada aos participantes por API, o envio é realizada às 13hrs, no entanto, na estrutura da mensagem consta o horário das 16hrs. Seguem algumas mensagens de exemplo (root id): 92878644, 78386664
- Adequações adicionais no tratamento de opt-in para filtar pela financiadora (RRC0010) - validação dos arranjos válidos na busca.
- RRC0019 - Otimização no processamento de operação de troca de titularidade + gestao participante + regra divisao valor + sem aceite incondicional + alcance especifico
- RTC 43283 - CIP ouvindo não esta gravando agenda nas tabelas fracao_unidd_recbv_op e unidd_recbv.

## 1.17.6

- Retirada do ajuste varredura ARRC017 e ARRC007 para enviar registros apenas com IC_TP_REALCT='P' na tabela INST_CAD. Deve enviar para todos.
- Ajuste varredura de credor para adequação do formato de datas e nome do estimulo. Mudou de V_MNTIF para V_MNTIFNC
- Ajuste na ARRC007 devido a não envio da ARRC001 (tabela nova).
- Ajuste no tratamento de opt-in para filtar pela financiadora (RRC0005, RRC0008, RRC0010, RRC0019, RRC0021)
- RRC0008/RRC0021 - Otimização na consulta para obter as URs de um ID_OP
- Ajuste no retorno da base centralizada para tratamento de retornos vazios com status HTTP404.

## 1.17.5

- Ajuste nomenclaturas e chamadas de estimulos de varredura para credor e credenciadora na base centralizada.

## 1.17.4

RRC0013 - Otimização da consulta de operação vigente
- Ajuste varredura de credores e credenciadores - CIP para base centralizada para enviar apenas com IC_TP_REALCT='P' na tabela INST_CAD
- Ajuste varredura de credores e credenciadores - base centralizada para CIP para inseir na base CIP com IC_TP_REALCT='E' na tabela INST_CAD
- Ajuste varredura ARRC017 e ARRC007 para enviar registros apenas com IC_TP_REALCT='P' na tabela INST_CAD

## 1.17.3

RRC0015 - Retorno do envio das datas com timezone UTC
Cancelamento - Tratamento para cancelamento parcial por titular para contratos com apenas o titular cancelado quando não houver interoperabilidade
EV574003 - RRC0003 enviando no campo participante negociador o CNPJ do credenciador ao invés do CNPJ do participante administrado que registrou a operação

## 1.17.2

ARRC018 - Quebra de busca por fracao (performance)
RRC0019/RRC0005 - Otimização (batch insert) no insert da tabela OP_TITLAR_DOMCL_UNIDD_RECBV
RRC0019/RRC0005 (api) - Otimização (batch insert) no insert da tabela GRUPO_REG_OP_STG
Varredura V_CTZESTC - Atualiza o cache local com dados da base centralizada

## 1.17.1

- /api - ajuste na paginação dos resultados

## 1.17.0

[EV571480] - RRC0028 enviando cnpjOuCnpjBaseOuCpfUsuFinalRecbdrOuTitlar no campo cpfOuCnpjRecbdrOptIn
[EV566862] - Favor analisar o ERRO nas 4 mensagens RRC0021 de api , 15:10 e outras 4 mensagens RRC0021 15:11 de 19.11.2020 referente a uma consulta de contratos de gravame que foi incluida em 17.11. Essas consultas estão sendo recusadas indevidamente.
[EV571156] - Ajuste no nullpointer da validação
[EV572537] - BUGFIX - O valor livre deveria ter sido informado zerado uma vez que o recebido na agenda estava com data efetiva e valor efetivo de liquidação preenchidos.
[EV573537] - RRC0015 enviando datas com timezone UTC
[RTC43279] - [R2C3 - ARRC030 - 1.16.5] - Sistema está retornando o erro ERRC0208 ao invés do ERRC0006 ao enviar CPF_CNPJCli inválido
[RTC43217] - [R2C3 - ARRC030 - 1.16.0] - Sistema está incluindo os registros de EC na tabela rrc_ctz.estabelecimento_comercial com arranjos alfanuméricos e numéricos
[RTC42038]  - [R2C3 - INTEROP /notificacao/anuencia - v.1.5.8 Atlante v.5.1.49] - CIP ouvindo - Sistema está disparando mensagem 0028 com ISPB ER CIP
- Melhoria Faturamento

## 1.16.5

/agenda/posicao - correção na inclusão/alteração de contratos com concorrência
EV572926 - ARRC023 enviando id no CNPJ do credor e tratamento para cancelamento parcial por titular para contratos com apenas o titular cancelado
EV557811 - RRC0004 enviando cancelamento parcial mesmo quando o cancelamento remove o último titular da operação
EV572082 - na consulta a URs a constituir na RRC0008, quando indrRegrDivs = P, campo VlrPercNegcd deve sair com "100".
EV572536 - null pointer na consulta RRC0008.
EV572046 - ajustes reserva.

## 1.16.4

[EV573159] - Não está gerando Opt-in automático quando ocorre a inclusão de contrato com sucesso.

## 1.16.3

/agenda/posicao - retirado o registro do payload nas tabelas de interop
Ajuste INTP010 para envio da data inicio e fim da anuencia de acordo com a base de dados. Caso não tenha data fim na base de dados será usado 31-12-9999.
EV572268 - Correção de chave duplicada.

## 1.16.2

RRC0021 - correção de retornos JSON com consulta de CNPJ e CNPJBase com retorno de lista
RRC0010 - Inclusao para tratamento de erro na interop com as demais registradoras

## 1.16.1

EV572047 - No retorno do arquivo ARRC022 para o Participante foi verificada a ausência da TAG <Grupo_ARRC022RET_NegcRecbvlActo>
EV571875 - Verificamos que o arquivo ARRC002_01425787_20201201_01299_RET foi gerado com a SitRetReq = 002 (Recusado) mas havia registro aceito dentro do arquivo
- /agenda/online - Correção evitando que seja obrigatorio o envio de idAnuencia
- /agenda/online - Melhoria na consulta da agenda posição

## 1.16.0

EV572510 - Inclusão do header com paginação nos endpoints com retorno paginado

## 1.15.6

- V_CTZOPTO - Inclusao da varredura
RRC0021 - Tratamento para erro de NullPointerException
RTC 43031 - CIP ouvindo esta retornando INTP005 grupo vazio quando a consulta INTP010 enviada com originador por CPF.
RTC 43184 - CIP não esta respondendo INTP002 quando recebido uma agenda com inconsistência.

## 1.15.5

ARRC001 - Corrigido tratamento de SitRetReq

## 1.15.4

RRC0010 - Tratamento para erro de NullPointerException ocorrido com Bradesco e Santander em HEXT

## 1.15.3

ARRC001 - Corrigido tratamento de SitRetReq

## 1.15.2

EV571574 - Correção registro nao encontrado na interop
RRC0010 - Tratamento para erro de NullPointerException ocorrido com Bradesco e Santander em HEXT

## 1.15.1

- RRC0008 - Incluido tratamento de interop sincrono e "imediato" para as requisições via API
- RRC0021 - Incluido tratamento de interop sincrono e "imediato" para as requisições via API
- RRC0010 - Correção na consulta de URs
[RTC41697] - [R2C3 - RRC0005 - 1.14.6] - Sistema não está buscando novas URs gravamadas para antecipar novo valor enviado na alteração do contrato de Antecipação

## 1.15.0

- Compatibilidade com Atlante 5.1.56

## 1.14.10

- Ajuste RRC0011 para contemplar a interface da interop + latebatch

## 1.14.9

[EV571081] - RRC0010 está retornando URs para Insituição Financeira mesmo que não tenha OPT-IN cadastrado quando não é informado o arranjo.
[EV569116] - Correção na alocação de urs na RRC0019 regra divisão percentual
[EV571581] - Participante enviou mensagem RRC0010 e recebeu retorno com campo faltando (data prevista de liquidação e valor liquidação)
- RTC42837 - [R2C3 - INTEROP /post/contrato - v.1.13.7 Atlante v.5.1.52] - CIP ouvindo - Sistema recusa contrato quando tipo de conta = CG
- RTC42736 - [R2C3 - INTEROP /post/contrato - v.1.13.0 Atlante v.5.1.52] - CIP ouvindo - Sistema exigindo agência para conta do tipo pagamento PG
- RTC43077 - CIP ouvindo INTP010 esta acatando IdAnuencia invalido.
- RTC43079 - CIP ouvindo INTP010 esta permitindo dataFim menor que a dataInicio.
- INTP004 (/agenda) - Quebra das agendas por arranjo
- RRC0019 - Ajuste relacionado a seleção das credenciadoras quando indicado alcance geral (selecionar apenas as que o estabelecimento possui relacionamento)
- ARRC022RET/RRC0019R1 - Alterar o nome da TAG <CNPJ_CPFUsuFinalRecbdr> para <CNPJ_CNPJBase_CPFUsuFinalRecbdr> - Ajuste no XSD (v8.11)
- ARRC022RET - <Grupo_ARRC022RET_NegcRecbvlActo> não está saindo no RET - Ajuste no XSD (v8.11)

## 1.14.8

[EV571090] - RRC0028 / RRC0029 foi enviada para o participante incorreto devido ao mesmo CNPJ entre credenciadora e IF. Deveria ter enviado para a credenciadora ao invés da IF.
- Ajuste configuração do Atlante para tratamento do SLA na RRC0008 quando realiza o processo de Interop.

## 1.14.7

- RRC0008 - Está ocorrendo nullpointer quando não enviado o campo UsuarioFinalRecebedor no payload da consulta.
- RRC0008 - Ao retornar 200 e sem conteúdo está enviando []. Ajustado para não enviar [] quando vazio e retornar o codigo http 204.
- RRC0019 - Ajuste na constituição Gestão PART e Percentual
- RTC42841 - [R2C3 - INTEROP /post/contrato - v.1.13.7 Atlante v.5.1.52] - CIP ouvindo - Sistema recusa contrato quando tipo de conta = CI
- RTC42837 - [R2C3 - INTEROP /post/contrato - v.1.13.7 Atlante v.5.1.52] - CIP ouvindo - Sistema recusa contrato quando tipo de conta = CG
- RTC42739 - [R2C3 - INTEROP /POST/contrato - v.1.13.0 Atlante v.5.1.42] - CIP ouvindo - Enviado o CNPJ da ER no campo CPF_CNPJPartNegcdr da mensagem RRC0003
- RTC42907 - Cip ouvindo nao esta gravando informacoes da INTP004 na tabela solctc_agenda_intrdd.
- [EV562489] - BUGFIX - Campo prioridade, no gravame recebemos 1 e na agenda está aparecendo 0.
- [EV571105] - BUGFIX - 018: Os valores total do titular, comprometido na instituição não respeita o valores registrados na agenda pelo credenciador (está considerando as fumaças registradas).

## 1.14.6

[EV570035] - RRC0019 / RRC0005 - Está incluindo OPT-IN do cnpj completo quando já tem OPT-IN do CNPJ Base cadastrado
[EV570004] - Ao retornar NO_CONTENT (HTTP 204) não deve retpomarray vazio "[]" - Ajustado RRC0008, RRC0010

## 1.14.5

- RRC0010 - Incluido tratamento de interop sincrono e "imediato" para as requisições via API
- /agenda/posição - Corrigido a validação do campo porcentagem (Erro [0051])

## 1.14.4

- Otimização das consultas de UR e Fracao

## 1.14.3

[EV568247] - Erro de null pointer ao inserir titular no grupo Titulares, quando a consulta por API
[EV570035] - RRC0019 - Está incluindo OPT-IN do cnpj completo quando já tem OPT-IN do CNPJ Base cadastrado
[EV562489] - BUGFIX - Campo prioridade, no gravame recebemos 1 e na agenda está aparecendo 0.

## 1.14.2

- atualizada a versao do swagger bilateral (0.0.30)

## 1.14.1

[RTC42918] - [R2C3 - RRC0019 - 1.13.14] - Sistema não está retornando o grupo Grupo_RRC0010R1_UsuFinalRecbdr quando agenda possui operação feita pela RRC0005 e quem está solicitando  a consulta pela RRC0010 é a Credenciadora
[RTC42919] - [R2C3 - RRC0019 - 1.13.14] - Sistema não está retornando o grupo Grupo_RRC0010R1_UsuFinalRecbdr quando agenda possui operação feita pela RRC0005 e quem está solicitando  a consulta pela RRC0010 é a Credenciadora

## 1.14.0

- Compativel Atlante 5.1.53
- ARRC001/ARRC022 - Correção do SitReq
RTC 42040 - [R2C3 - INTEROP /notificacao/anuencia - v.1.5.8 Atlante v.5.1.49] - CIP ouvindo - Sistema está disparando mensagem 0028 com cnpjOuCnpjBaseOuCpfUsuFinalRecbdrOuTitlar incorreto
[EV568636, EV570037 e EV570632]- Erro ao enviar a quantidade de registros correta na pesquisa da RRC0010
[RTC42918] - [R2C3 - RRC0019 - 1.13.14] - Sistema não está retornando o grupo Grupo_RRC0010R1_UsuFinalRecbdr quando agenda possui operação feita pela RRC0005 e quem está solicitando  a consulta pela RRC0010 é a Credenciadora
[RTC42919] - [R2C3 - RRC0019 - 1.13.14] - Sistema não está retornando o grupo Grupo_RRC0010R1_UsuFinalRecbdr quando agenda possui operação feita pela RRC0005 e quem está solicitando  a consulta pela RRC0010 é a Credenciadora

## 1.13.14

[EV570035] - RRC0019 - Está incluindo OPT-IN do cnpj completo quando já tem OPT-IN do CNPJ Base cadastrado
- Ajuste na gravação dos totalizadores das URs da Cessão

## 1.13.13

[EV569148] - RRC0010 - Remoção do grupo Grupo_RRC0010R1_NegcRecbvlInst de fora do grupo Grupo_RRC0010R1_UniddRecbvl

## 1.13.12

[EV568707] - BUGFIX - Arquivo 018 esta trazendo valores negativos no VlrTotal. Tiago Valceiro 27/11/20 14:59
[RTC42826] - Correção na chamada ao recalculo
- Ajuste na operação de cessão e ajuste na validação do total disponível para negociacao
- Ajustes na obtenção do participante administrado quando o canal é API

## 1.13.10

EV569177 - URs constituidas estao sendo informadas com valor zerado.
RTC42907 - Cip ouvindo nao esta gravando informacoes da INTP004 na tabela solctc_agenda_intrdd.

## 1.13.9

- RRC0019 (api) - Ajuste na atualização do novo titular
- RTC 42826 - Correção na query de chamada ao recalculo.

## 1.13.8

- [RTC42808] - [R2C3 - RRC0006/RRC0020 - 1.13.6] - Sistema está gravando o valor L no campo ic_sit na tabela OP quando o cancelamento é via RRC0006 ou RRC0020 com IndrLiquidOp = N
- RRC0010 enviando mais de uma R1 quando encontrada mais de uma credenciadora no filtro de busca e as credenciadores são todas vinculadas a CIP.
- [EV568714] - Corrigido output da fumaca da ARRC022
- RRC0005 (api) - ajuste na identificação do administrado (credenciadora)
- EV568603 - URs a constituir estao sendo informadas com valor zerado.
- EV569112 - Corrigido valor constituido na ARRC022.

## 1.13.7

- Aumento de logs na RRC0010 e RRC0021 via API para avaliar o tamanho de pagina.

## 1.13.6

- EV566881 - Removido validação ERRC0128. Pendente atualização na especificação.
- RTC42742 - [R2C3 - RRC0006 - 1.13.0] - Sistema está retornando erro de NullPointer ao enviar RRC0006 de cancelamento total
- EV565633 - EV566250 correção Retorno RRC0021R1 vazio
- INTP006 - ajuste para não validar adesão na interoperabilidade

## 1.13.5

- INTP005 - corrigido o valor da fracao a constituir para "0"
[RTC-42634] - [R2C3 - ARRC030 - 1.12.0] - Tratamento nas tags com somente espaços em branco
- swagger-bilateral - Campo motivoRecusado alterado de maxLenght 10 para 500

## 1.13.4

- INTP005 - está enviando o idOP ao inves do NR_CTRL_CENTRALIZADA
- INTP005 - corrigido o valor constituido
- INTP006 - ajustes no header da resposta e na gravação no recebimento da interop
- EV568603 - Duplicidade de registros "a constituir" quando ha mais de uma credenciadora com fracoes a constituir em uma operacao.

## 1.13.3

- RRC0019 - Ajuste no calculo de prioridade das fracoes

## 1.13.2

- RRC0019 - Ajuste no passo "processar" para contemplar constituições de fração que estavam implementadas em "efetivar"
- RRC0010 - Ajuste no envio da RRC0010R1 via Interop

## 1.13.1

- INTP008 - Retirada a validação de obrigatoriedade do campo IdContratoExterno
- RRC0010 - Erro ao ignorar busca de opt-in quando realizado o envio da mensagem pela credenciadora.
- RRC0019 - Ajuste controle de adesão quando chamado via API.
- RRC0019 - Ajusta na consulta do EC na base-centralizada offline para utilizar like (pelo CNPJ)
- RRC0019 - Ajuste no /contrato para enviar o campo "Porcentagem" somente quando a regra de divisão = PORCENTAGEM
- INTP005 - Está saindo sem os dados de controle quando recebe retorno de consulta vazia
[EV567384] - Tramento do tamanho da pagina e quantidade de paginas no processamento da RRC0010 e RRC0021 via consulta APU (GET)

## 1.13.0

[RTC-42635][R2C3 - ARRC030 - 1.12.0] - Sistema retorna arquivo ARRC030ERR com EGEN0043 ao informar IndrManutCad fora do dominio
[EV566677] - Erro na consulta de EC na base centralizada
[RTC 42493] - [R2C3 - RRC0020 - 1.11.5] - Campo ic_sit não foi atualizado para L na tabela op quando enviado cancelamento total informando IndrLiquidOp = S
[EV562650] - BUGFIX - O participante Redecard comunicou que recebeu o arquivo ARRC001_01425787_20201109_50001_RET com SitRetReq 001, porém houve registros recusado dentro do arquivo
- Inclusao da tabela SOLCTC_INTRDD_INST_DATA para armazenar os "blobs" relacionados a Interop
- Ajuste ARRC017 - tipo participante com 2 caracteres (01, 02, 03, 04) - Ajuste no XSD (v8.9)
- Inclusao de LOG das operações de interop (diretorio definido na PARAM_SIST com o nome DIRETORIO_INTEROP_LOG)

## 1.12.8

- Ajuste na busca de OPT-IN quando informado CNPJ completo e tem o CNPJ Base na tabela
- Ajuste para ignorar a busca de OPT-IN quando for pesquisa realizada pela credenciadora


## 1.12.7

- INTP014 - ajuste no header para enviar o idControleConfirmacao
- INTP007 - Inclusao de tratamentos de null

## 1.12.6

- Ajuste XSD para permitir espaços em branco nos campos de tipo controleNegociacaoRecebivel (EV563618, EV556444 e EV562666)
- RRC0020 - ajuste para tratar lista de frações vazia na busca de registradoras para interoperabilidade e no envio da RRC0004
- /agenda/posicao - Ajuste para enviar dados corretos das fracoes

## 1.12.5

- RRC0019 - Ajusto no /contrato para enviar o idEfeitoContrato quando se trata de uma alteração
- RRC0005 - Ajustes na antecipação e adição de mais logs para debug em HEXT

## 1.12.4

- RRC0021 - Correção no payload para envio para as outras registradoras

## 1.12.3

- INTP007 - Correção na validação de regra de divisão para alteração
- RRC0021 - Correção no payload para envio para as outras registradoras
- RRC0020 - ajuste para enviar o idEfeitoContrato da interoperabilidade no payload de cancelamento

## 1.12.2

- Ajuste na RRC0021 ao enviar dados para INTP0010 - Não está enviado o UUID do contrato, nem os dados do filtro similar ao que recebe na mensagem.
- AJuste no tratamento da INTP005 para ignorar somente os contratos que não existe quando for EfeitoContratado

## 1.12.1

- /agenda - Otimização na inclusão das frações
- /agenda/posicao - Otimização na inclusão das frações

## 1.12.0

- ARRC001 - Inclusao de validacao de unicidade de fracao
- Inclusao da PK na tabela de fracao
- /agenda - Otimização na inclusão das frações
- /agenda/posicao - Otimização na inclusão das frações
- /contrato - Tratamento para evitar NullPointerException na montagem do contrato para o POST /contrato
- Validação se o IDEFEITOCONTRATO enviado na agenda posição existe na nossa base. Caso não existe será ignorado.
- RRC0020 - ajustes na busca que verifica se há interoperabilidade

## 1.11.21

- RRC0019 - salvar o idEfeitoContrato para contratos que de interop
- RRC0005 - Ajustes no payload da notificação pós contratada
- /agenda/posicao - Retirada validação quando nao é retornado nenhum recebivel

## 1.11.20

- Alteraçao do cabeçalho da resposta do patchContrato para devolver o parametro idControleConfirmacao (solicitaçao da Natalia).
- Ajustes no payload da interop
- V_ROLAGEM - Ajustes de performance
- Inclusão das validações 0028, 0041 e 0056 no retorno da agenda posição.

## 1.11.19

Ajuste na constituição da Penhora
Ajuste na constituição da Antecipação
LOGs para o processo de interop

## 1.11.18

- Ajustes no cancelamento para aceitar IdentdNegcRecbvl opcional
- Habilitada a validação de participante no SLC

## 1.11.17

- Ajuste na Antecipação e Recalculo

## 1.11.16

[RTC-42545] - [R2C3 - ARRC030- 1.11.9] - Sistema está permitindo enviar a tag UF fora do dominio (99 ou XX)
EV566879 - RRC0020 sem R1
- Ajuste tratamento de Alteração de Contrato com indicar de Regra de Divisão igual a base - Erro 9905.
- Ajuste no tratamento do erro 045 - Interop - Patch Contrato, quando dados de renegociação não são informados.

## 1.11.15

- RRC0005 - Penhora: aceite incondicional "S" deve gerar só fumaça
- RRC0010 - Aceita de /agenda/posicao sem nenhum registro
- RRC0019 - Ajuste na validação para contratos ja cancelados

## 1.11.14

- INTP006 - Ajustes no validador da notificação pós contratada

## 1.11.13

- INTP012 - Envio do UUID de controle da interop nos campos idContestacao, idAnuencia e idEfeitoContrato + configuração do rebatedor
- ARRC001 (/agenda) - Correção no envio fo grupo de efeito de contrato
- RRC0010 - Corrigido fluxo de interop
- RRC0019 - Refatorado fluxo de interop
- /agenda/posicao - Incluido processamento em sub-batch
- Tratamento da Alteração Inclusão para o erro 9905 - Envio de Alteração com Regra de divisão igual a base
- swagger-bilateral atualizado para a versão 0.0.26 (correção do indicadorStatus)
- /agenda (falando) - Corrigido para enviar porcentagem = 0.0 quanto regra de divisao = valor
- /contrato (patch) - Corrigido o envio do digito da conta
- RRC0005/RRC0019 - Ajuste da coluna de frações para o valor previsto de liquidação
- /contrato (post) - corrigido ispb do banco recebedor

## 1.11.10

- INTP012 - Envio do UUID de controle da interop nos campos idContestacao, idAnuencia e idEfeitoContrato + configuração do rebatedor
- ARRC001 (/agenda) - Correção no envio fo grupo de efeito de contrato
- RRC0010 - Corrigido fluxo de interop
- RRC0019 - Refatorado fluxo de interop
- /agenda/posicao - Incluido processamento em sub-batch
- Tratamento da Alteração Inclusão para o erro 9905 - Envio de Alteração com Regra de divisão igual a base
- swagger-bilateral atualizado para a versão 0.0.26 (correção do indicadorStatus)
- /agenda (falando) - Corrigido para enviar porcentagem = 0.0 quanto regra de divisao = valor
- /contrato (patch) - Corrigido o envio do digito da conta
- RRC0005/RRC0019 - Ajuste da coluna de frações para o valor previsto de liquidação
- /contrato (post) - corrigido ispb do banco recebedor

## 1.11.9

- INTP012 - melhoria de inclusao de id de controle em tabela

## 1.11.8

- INTP002 - removido o cabeçalho idControleRecepcao
- Ajustes nos testes integrados da INTP011.

## 1.11.7

- /contrato - Inclusao das fracoes a criar na resposta

## 1.11.6

- /agenda - Ajuste de peformance para atualizar URs e Fracoes em lote
- INTP002 - Correçao da duplicaçao dos parametros de header
- /contrato - Inclusão do digito da conta
- /agenda - Correção de validacao para conta + digito de acordo com o tipo de conta
- /contrato - Correção para o nrCnpjRegtdr da registradora ser salvo na fracao e ur

## 1.11.5

- /agenda - Correção de validacao para conta + digito (tamanho maximo 20)

## 1.11.4

- /agenda - Inclusao de validacao para conta (tamanho maximo 13)
- Alteraçoes para resoluç~ao da INTP002 que nao estava sendo enviada.

## 1.11.3

- RRC0019 (/contrato) - Inclusao do tipo de operação (CRIACAO/ALTERACAO) e regra de repartição
 
## 1.11.2

- RRC0019 - Correção nos dados de contrato para o envio das outras registradoras (arranjo, credor e prioridade)

## 1.11.1

- RRC0019 - Inclusão da verificacao das frações a criar para o envio dos contratos para as outras registradoras

## 1.11.0

- Ajuste INTP005 - envio de URs repetidas
- Nova varredura para inclusão de OPT-INs para arranjos genericos. (V_ARRJGEN)
- RRC0003/RRC0008/RRC0021 - Otimizações de consultas SQL
- Nova funcionalidade ARRC030 - Cadastro/Alteração/Baixa - EC
- Validação RRC0020 e validacao INTP013
- Ajuste RRC0010 - consulta estabelecimento comercial não está deveolvendo RRC0010E quando ocorre erro

## 1.10.7

- RRC0019 - Ajuste do domicilio bancario
- RRC0004 - Ajustes de performance

## 1.10.6

- RRC0011/RRC0013/RRC0021 - Corrigido o envio de R1 de forma sincrona via HTTP

## 1.10.5

- /agenda/posicao - Erro ao atualizar unidade recebivel

## 1.10.4

- RRC0010 - Inclusão de tratamento no mecanismo (Thread.sleep()) para aguardar finalização da interop
- Ajustas na RRC0010 e RRC0008 para interoperabilidade - uso do getOutputHttpSyncronousHandleBuilder

## 1.10.3

[EV562672] - BUGFIX - Itau reportou que o sistema está apresentando valor negativos nos campos vlrLivreTot e VlrLivreUsuFinalRecbdr
- /agenda/posicao - Inclusão de tratamento para atualizar UR e Fracao caso já tenham sido enviadas
- RRC0019 - Inclusao de codigos de erro (801 - Erro ao processar agenda de retorno, 802 - Nao houve notificacao para as demais registradoras) para fluxos de exceção no processamento via Interop
MELHORIAS - RRC0020 - IMF -> CIP - POST /contrato/cancelamento e POST /contrato/cancelamento/resposta
          - IMF -> CIP - POST /contrato/cancelamento e POST /contrato/cancelamento/resposta - Cancelamento de negociação
[RTC-42290] - [R2C3 - RRC0020 - 1.9.1] - Sistema está retornando erro de PSQLException ao enviar o cancelamento de URs constituídas informando o Grupo_RRC0020_RegRecbvl
- INTP012 - interop /contestacao

## 1.10.2

- RRC0005 - Antecipação com interop
- RRC0005 - Penhora
- RRC0019 (/contrato) - Correção no cnpj da registradora e participante
- RRC0010 (via api) - quando ocorre interop - thead sleep por 30 segundos

## 1.10.1

- Falhou a fechar a tag. Fechamos a 1.10.0

## 1.10.0

- Suporte ao Atlante 5.1.51

## 1.9.2

- Ajuste na busca de UR utilizando o filtro data de liquidação - Erro de SQL ajustado.

## 1.9.1

[RTC-40331] - [R2C3 - RRC0020 - 1.0.57] - Divergências ao enviar o cancelamento de URs constituídas informando o Grupo_RRC0020_RegRecbvl
- /contrato - Corrigido de-para para o tipo de negociacao
- swagger atualizado para a versão 0.0.24
- Agenda onLine (INTP010) - Inclusão do filtro por numero de controle do contrato
- Agenda onLine (INTP010) - Ajuste na busca de domicilio e data liquidação - estava gerando dados duplicados.
- RRC0019 - Corrigido componente de inclusao de agenda que é compartilhado pelo /agenda e /agenda/posicao

## 1.9.0

- Nova varredura V_OPTOUT
- /contrato - retirada da obrigatoriedade na validação de TipoOnus

## 1.8.17

- Ajustes nos testes integrados da RRC0008, RRC0011 e RRC0012.

## 1.8.16

- RRC0019 - Correção na seleção do opt-in vigente para solicitação de agenda online
- /contrato - PATCH - correção no retorno das fracoes constituidades e a constituir

## 1.8.15

- RRC0019 - Inclusao de envio de anuencia para a base centralizado ao processar contrato
[RTC 41126] Correção na prioridade da fração antecipada / geração de fumaça de um gravame quando ocorre uma antecipação.
- Ajuste valor da fumaça salvo na tabela, quando regra da disivão = "P"

## 1.8.14

- /contrato - Retirado chamada a interop de requisição de cadastro via registradora

## 1.8.13

- /contrato - Ajustes na conversão dos campos IndrTpNegc, IndrAlcancContrtoCreddrSub e IndrRegrDivs
- RRC0005 - Implementação da inclusão de penhora

## 1.8.12

- RRC0005 - Implementação da inclusão de penhora
- RRC0019 - Inclusao do "tipo" no envio de opt-in
- RRC0019 - Correação no CNPJ/CPF para consulta de agenda
- /contrato - Correção do fluxo de processamento para Interop e validações de conversão para RRC0019
[EV561245] - Ajuste na RRC0010 via APIretornando conteudo incorreto
[EV562584] - Ajuste na RRC0010 via API retornando conteudo incorreto
- RRC0020 - IMF -> CIP - POST /contrato/cancelamento e POST /contrato/cancelamento/resposta
- IMF -> CIP - POST /contrato/cancelamento e POST /contrato/cancelamento/resposta - Cancelamento de negociação

## 1.8.11

- Atualizado swagger para a versão 0.0.23
- RRC0019 - Correção no tratamento de opt-ins não encontrados
- Alterado codigos de erro 9999 da Interop

## 1.8.10

- RRC0019 - Correção no tratamento de recebedor/titular ao solicitar opt-in
- ARRC001 - Correção na busca de fraçoes para o /agenda

## 1.8.9

- Falhou a fechar a tag. Fechamos a 1.8.10

## 1.8.8

- INTP005 - Não está retornando o valor previsto liquidação

## 1.8.7

- INTP005 - Ajuste na busca de frações - erro no parâmetro de busca provacando erro de SQL
- RRC0019 - Refactorings relacionados a Interop

## 1.8.6

- RRC0010 - Correção no envio de RRC0010R1 com Interop
- INTP005 - Enviando o campo de anuencia com valores incorretos e tratamento de buscas de fração utilização DTREF.
- RRC0019 - Refactorings relacionados a Interop
- INTP005 - Enviando o codigo do arranjo incorretamente para interop

## 1.8.5

- /agenda/posicao - Correção no tratamento de NULL

## 1.8.4

- /agenda/online - Inclusao de tratamento de erro
- RRC0010 - Correção no filtro por AgendaOnline

## 1.8.3

- Erro de SQL inválido ao buscar Frações de UR - INTP005
- /agenda/posicao - Tratamento de datas nulas (nao obrigatorias)

## 1.8.2

- Novo parametro para controlar a quebra de paginas de consulta pela quantidade de registros (parametro para quantidade de registros) - QUANTIDADE_REG_PAG_API_CENTRALIZADA - opcional - Valor default: 1000

## 1.8.1

- [R2C3 - ARRC017 - 1.7.6] - Sistema não está retornando registros de Participante com o mesmo CNPJ cadastrado na tabela inst_cad
- Ajuste na query de busca da agenda (INTP005) - like no CNPJCPF Titular (pode ser CNPJ Base)
- RRC0019 - Ajuste no fluxo de processamento com Interop

## 1.8.0

- Ajuste no tratamento do Erro 045 (INTEROP) - INTP010
- Alteracao do cabeçalho para agenda rejeitar, a pedido de HEXT.
- Retirada do tratamento de null da CentralizadoraNegocioImpl.java
- RRC0019 - Ajuste no fluxo de processamento com Interop

## 1.7.6

- Gravação de valor "N" no Tipo de OptIn automático quando o registro vem pela mensagem RRC0011
- Ajuste na pesquisa de Agenda (agenda posição - INTP005). Utilizar o filtro enviado na consulta da INTP010.
- Ajuste no formato de datas e inclusão de logs para analise (INTP010)
- Ajuste no envio do campo NR_VLR_PREVT_LIQUID para a INTEROP (INTP004)

## 1.7.5

- Ajuste na gravação do campo identdCtrlReqSolicte. Estava gravando o IdControle e passou a gravar o IdComunicação
- INTP004 não estava validando a data de referência com a data de referência do sistema.
- Payload INTP010 quando vem sem a data de ini passar a dtRef e sem a data de fim passar a data 9999-12-31.
- INTP004 não estava enviando o codigo de arranjo
- Ajuste no processo de OPT-OUT, inativando o registro de OPT-IN quando a data fim não é informada ou quando a data fim informada é igual a data de referencia. Caso contrário atualiza a DataFim e mantem o OPT-IN Ativo.
- RRC0019 - Inclusao de vadidação ERRC205 para operações em que não foi encontrado nenhuma UR
- /agenda - Corrigido campo ValorLiquidacao
- Ajuste na RRC0010 e RRC0021 para consultar base centralizada.

## 1.7.4

- Correção do /agenda em que estavam sendo inseridos valores NULL na UNIDD_RECBV
[RTC-42192] - [R2C3 - RRC0010 - 1.7.3] - Sistema está retornando erro de NullPointer Exception ao enviar RRC0010 consultando agenda

## 1.7.3

[EV553820] - BUGFIX - Arquivo 018 - Valor Total e valorTotalDomicilio estão com divergencia nos valores.
[EV562004] - BUGFIX - Arquivo 018 - Urs estão sendo apresentadas em duplicidade
[RTC-42023] - Corrigido para a Reserva com valor maior que o disponível para constituição
- Ajuste no processamento da RRC0019 para fazer optin somente quando nao houver optin local ja cadastrado
- Varreduras V_MNTCRED (Varredura de manutenção de credenciadoras) e V_MNTIF (Varredura de manutenção de financiadores)
- Atalização do swagger-bilateral para a versão 0.0.21
- ARRC002 - Ajuste do update da tabela de fração para alterar apenas campo de situação

## 1.7.2

Ajuste no payload de envio para interop - envio de uma lista INTP010

## 1.7.1

Ajuste no payload de envio para interop - consulta de agenda (INTP010)

## 1.7.0

Inclusão de opt-in para todos os arranjos automaticamente quando enviado arranjo nulo
Ajuste na busca de optin - apresentando erro ERRC0203 indevidamente
[RTC 41494] - [R2C3 - ARRC017 - 1.4.19] - Sistema está triplicando os registros dos Participantes na ARRC017 e não está retornando as tags NumTelPart e EmailPart mesmo com os dados cadastrados nas tabelas inst_cad_tel e inst_cad_email
Correção no /agenda enviado no processamento da ARRC001. Ajuste no campo idAnuencia
Ajuste na gravação do TIPO de Optin Automatico como S ou N. Não gravar mais o null na base de dados.

## 1.6.5

Ajuste na busca de optin na mensagem RRC0010 pelo filtro sem utilizar o parametro com LIKE

## 1.6.4

Ajuste para envio da RRC0029 ao realizar um opt-out de sucesso.
Ajuste parametro QUANTIDADE_DIAS_LIMITE_OPERACAO para restringir quantidade de dias limite para operações da 019, 022 e 005.
Ajuste no swagger. Campo conta aumentado para tamanho 20
Correção no /agenda enviado no processamento da ARRC001. Ajuste no campo idAnuencia e ValorLiquidacao

## 1.6.3

Ajuste no tratamento de OPT-OUT inexistente na INTEROP (número de controle)
[RTC-42023] - Corrigido para a Reserva com valor maior que o disponível para constituição


## 1.6.2

Inclusão do tratamento de OPT-OUT inexistente na INTEROP (número de controle)

## 1.6.1

- Não está atualizando a data fim quando ocorre cancelamento de OPT-IN pela INTEROP
- Esta enviando para a INTP013 no cancelamento de anuencia. O correto é INTP011

## 1.6.0

RRC0010 - ajuste nos dados de envio do payload da interop
RRC0010 - ajuste na busca de opt-ins ativos e dentro da vigência
EV561330 - Erro no grupo de Arranjo da ARRC018

## 1.5.20

RRC0010 não exibe erro ERCC0199 quando ultrapassa o SLA. Envia RRC0010E sem codigo de erro.
[RTC 42037] - Correção das 3 divergências apontadas.
[RTC 42034] - Corrigido junto da correção do [RTC 42037]

## 1.5.19

RRC0010 - NullPointer quando não envia da data inicio ou data fim nos parametros de pesquisa

## 1.5.18

RRC0010 não está interoperando corretamente quando opt-in está registrado na CIP e é de outra registradora.
O /agenda esta recusando digito da conta alfa. Foi alterado para atribuir "0" ao invés de retornar erro.

[RTC-41951] - [R2C3 - RRC0005- 1.5.4] - Sistema não está buscando as últimas URs livres a partir do período informado nas tags DtIniOp e DtFimOp ao incluir operação de Reserva Financeira Gestão ER
[RTC-42023] - [R2C3 - RRC0005 - 1.5.6] - Sistema não está retornando o erro ERRC0060 na msg de retorno RRC0005R1 para as operações com IndrTpNegc = OP e OR Gestão ER

## 1.5.17

EV557683 - FIDC Cielo (26286939) não recebeu o arquivo, consta na inst_cad/part_cad, mas não consta na party do atlante, não sei se tem relação?
EV557800/EV557951 - Sem identificação <TpPart> e <TpPart> fora do domínio
EV557892 - Arquivo sendo enviado p/ participantes fakes e <TpPart> fora do domínio
- Alteraçao do cabeçalho da agenda (cip ouvindo), conforme solicitaçao das analistas.
- Implementação de novo metodo de consulta na base centralizada para busca de opt-in por parametro de busca (nr_controle) - Melhoria consulta anuencia.

## 1.5.16

EV557683 - FIDC Cielo (26286939) não recebeu o arquivo, consta na inst_cad/part_cad, mas não consta na party do atlante, não sei se tem relação?
EV557800/EV557951 - Sem identificação <TpPart> e <TpPart> fora do domínio
EV557892 - Arquivo sendo enviado p/ participantes fakes e <TpPart> fora do domínio
Falta get da centralizadora (pra validar e popular cache local / falta validar duplicidade de idControle) - INTP011 (opt-in e opt-out)
[RTC-41409] - [R2C3 - INTEROP /notificacao/anuencia - v.1.3.13 Atlante v.5.1.38] - CIP ouvindo - Sistema está permitindo inclusão de optin duplicado
[RTC 42037] - Correção na constituição de valores no recalculo.
[RTC 42033] - Correção na geração de RRC0009 após recálculo de gravame.
Adequação dos headers de resposta da anuência (INTEROP), para ficarem de acordo com o manual
[EV562482] - Erro no retorno da ARRC022.

## 1.5.15

Ajuste nullpointer ao enviar RRC0029 pelo numero de controle INTEROP

## 1.5.14

Tentativa de envio indevido da RRC0028 e RRC0029 para a registradora.

## 1.5.13

[RTC 42034] - Correção geração de fumaça na alteração de gravame
[RTC-40262] - [R2C3 - RRC0019 - 1.4.25] - Sistema está retornando frações constituidas que voltaram para o saldo livre após alteração da operação para valor a menor

## 1.5.12

EV561364
- Ajuste no processo da INTEROP para processos síncronos
- Ajuste na geração dos Headers de resposta, no OptIn e OptOut
- Separação digito e conta ao enviar agenda posição interop (digito - ultimo caractere e conta sem o último caractere)

## 1.5.11

Ajuste rowmapper de participante para evitar nullpointer (somente ocorre em HEXT)

## 1.5.10

Condicional para usar a conta ou conta pagamento dependendo que qual estiver com conteúdo.
[RTC 41553] - Correção no output de fracoes constituidas RRC0003 e RRC0019R1
[RTC 41494] - Sistema está triplicando os registros dos participantes na ARRC017 e não está retornando as tags NumTelPart e EmailPart

## 1.5.9

[RTC-41478] - [R2C3 - INTEROP /contrato - v.1.4.17 Atlante v.5.1.42] - CIP ouvindo - Sistema não está incluindo contrato
- Tratamento para evitar null pointer quando a agencia não foi informada
- Separação digito e conta ao enviar agenda interop (digito - ultimo caractere e conta sem o último caractere)

## 1.5.8

[RTC-41033] - [R2C3 - RRC0019 - 1.3.5] - Após realizar cessão à constituir pela RRC0019, sistema está gravando valores negativos na tabela fracao_unidd_recbv_op e unidd_recbv do Usuário Final Recebedor
[RTC 40911] - Correção na chamada do recalculo [Executar SCRIPT 1.5.6]
[RTC-42023] - [R2C3 - RRC0005 - 1.5.6] - Sistema não está retornando o erro ERRC0060 na msg de retorno RRC0005R1 para as operações com IndrTpNegc = OP e OR Gestão ER
[RTC-42024] - [R2C3 - RRC0005 - 1.5.6] - Sistema está criando a operação e constituindo valor da fração quando enviado RRC0005 com valor maior que o disponivel na Agenda com IndrTpNegc = AN e IndrActeIncondlOp = N Gestão ER
[RTC-42025] - [R2C3 - RRC0005 - 1.5.6] - Sistema está criando a operação sem frações quando enviado RRC0005 com valor maior que o disponivel na Agenda com IndrTpNegc = AN e IndrActeIncondlOp = N e DtIniOp/DtFimOp que não possui URs disponiveis (Gestão ER)
[RTC-41126] - [R2C3 - RRC0005 - 1.3.8.1] - Sistema não deixou as frações que foram antecipadas do Gravame Gestão ER com prioridade 2 ao enviar antecipação de URS gravamadas não informando DtEftLiquidAntec e VlrEftLiquidAntec

## 1.5.7

[EV560343] - Ajuste na rotina RRC0010, conversão de objeto para lista equivocado

## 1.5.6

[RTC 41553] - Correção na geração de fumaça
[RTC-41719] - [R2C3 - RRC0019 - 1.5.0] - Sistema está retornando erro de EmptyResultDataAccessException: Incorrect result size: expected 1, actual 0
[RTC-41487] - [R2C3 - RRC0019 - 1.4.17.2] - Sistema está retornando erro de IndexOutOfBoundsException: Index: 0, Size: 0 ao enviar RRC0019 de alteração de contrato de Cessão Gestão Participante com valor a menor informando titular anterior nas tags CNPJ_CNPJBase_CPFTitlar e CNPJ_CPFTitular do Grupo_RRC0019_RegRecbvl
[EV558204] - COLOCAR TAG IndrSitOp NA MENSAGEM RRC0008R1
[EV561689] - Ajuste no tipo de mensagem devolvida caso ocorra erro 0060
[EV560672] - Correção no arredondamento.
[EV551687] - Correção de xsd
- Inclusao do parametro de cabeçalho idControleConfirmacao para a INTP002.
- Atualizado Atlante 5.1.49

## 1.5.5

[EV560898] - Prezados, o participante Safrapay encaminhou algumas mensagens RRC0008 via API nessa data (04.11) e está recebendo o erro EGEN0050. Em análise, foi identificado o erro nullpointer exception. Pedimos por gentileza verificar.
- Ajustes na validaçao da AgendaOnline.
[EV560339] - Correção cnpjBase usuFinalRecebdr
[EV560331] - Correção cnpjBase usuFinalRecebdr
[EV557344] - Correção cnpjBase usuFinalRecebdr
[EV551677] - Correção de xsd
[RTC-41676] - [R2C3 - RRC0005 - 1.4.31] - Após antecipação sobre urs gravamadas, sistema está deixando todas as Urs do gravame com IC_CONTR = S e com IC_SIT = N
[RTC-41675] - [R2C3 - RRC0005 - 1.4.31] - Sistema está criando fumaça para operação de Antecipação

## 1.5.4

[RTC-41744] - [R2C3 - INTEROP /agenda/online - v.1.5.0 Atlante v.5.1.45] - CIP ouvindo apresenta o erro 0004 ao não enviar o campo opcional Arranjo no RequestBody
[RTC-41832] - [R2C3 - INTEROP /agenda/online - v.1.5.3 Atlante v.5.1.47] - CIP ouvindo está enviando o callback /agenda/posicao para a porta errada do rebatedor(STUB)
[RTC-41400] - [R2C3 - ARRC023 - 1.4.13] - Sistema está retornando erro PSQLException: ERROR: column "cd_ispb_bco_recbdr" is of type integer but expression is of type character ao enviar arquivo ARRC023
[RTC-41096] - Correção alteração de gravame - Validação ERRC0060 GestaoParticipante.
[RTC-40911] - Correção chamada ao recalculo de alteração quando ocorrer uma alteração.
[EV557187 e EV557591] - ARRC023 NÃO GERAVA RET
- Correcoes do merge.
[RTC-41411] - correção do update opt_in após geração do opt-out
[EV558541] - Participante tentou realizar o cancelamento de um contrato através da funcionalidade 0020 (API) e ocorreu o erro: java.util.NoSuchElementException (ROOT ID: 13181984)
[EV560233] - ARRC023 somente gerou PRO

## 1.5.3

[RTC 41748] - Interop CIP recebendo agenda permitindo gravar IdBatch já incluído na base.
[RTC-38980] - [R2C3 - RRC0008/API - 1.0.38]  - Sistema está retornando Status-Code 500 ao enviar a requisição para GET /credenciadora/operacoes/identd-op/unidades-recebiveis-a-constituir
[EV558209] - 0005 está disparando 0009
[RTC-41488] - [R2C3 - RRC0019 - 1.4.17.2] - Sistema está apagando as frações constituídas na tabela fracao_unidd_recbv_op ao enviar RRC0019 de alteração de contrato de Cessão Gestão Participante com valor a menor
- Ajuste do XSD da ARRC030, a pedido do participante.
[RTC-41553] - Correção geração de fumaca
[RTC-41616] - Correção geração de fumaça
[RTC 41813] - Interop CIP ouvindo agenda retorna CodErro 0001 mais de uma vez para o mesmo campo na INTP002.
[RTC-41082] - Correção quando URs já estavam constituidas em operação anterior

## 1.5.2

- Ajustes na AgendaController para INTP004, INTP005 e INTP0010.
[RTC-41699] [R2C3 - INTEROP /notificacao/anuencia- v.1.5.0 Atlante v.5.1.45] - CIP ouvindo está gerando id do optout no formato incorreto
[RTC-41698] [R2C3 - INTEROP /notificacao/anuencia- v.1.5.0 Atlante v.5.1.45] - CIP ouvindo está permitindo a inclusão duplicada de registro OPTOUT
RTCs - 41746 - 41744 - 41743 - 41742 - 41716 - 41714 - 41634 - 41481 - 41411 - 41286

## 1.5.1

- Ajustes na AgendaController
[RTC 41639] -  Interop CIP ouvindo agenda esta aceitando valores maior que o permitido no campo valor
[RTC 41477] - Correção filtro de credenciadoras.
[RTC 41357] - Correlçao NullPointer recalculo

## 1.5.0

[RTC-41488] - [R2C3 - RRC0019 - 1.4.17.2] - Sistema está apagando as frações constituídas na tabela fracao_unidd_recbv_op ao enviar RRC0019 de alteração de contrato de Cessão Gestão Participante com valor a menor
[RTC-41411] - [R2C3 - INTEROP /notificacao/anuencia - v.1.3.13 Atlante v.5.1.38] - CIP ouvindo - Sistema apresenta EGEN0023 na recepção de OPTOUT
[RTC-41497] - Interop CIP recebendo agenda com campo idAnuenciavazio.
[RTC-41629] - Interop CIP ouvindo agenda/rejeitar INTP002 não esta processando.
[RTC-41503] - Interop CIP recebendo agenda campo documentoTitularConta gravando CPF quando tipoDocumento = CNPJ.
[RTC-41367] - Interop CIP ouvindo agenda tipoEfeito = restricao e Tipo Ônus = cessaoFiduciaria - OP não grava na base e gera INTP002 sem informação.
[RTC-41501] - Interop CIP recebendo agenda campo ISPB invalido.
[RTC-41651] - [R2C3 - RRC0021 - 1.4.31] - Sistema não está considerando o máximo de 30 frações fumaça no retorno na RRC0021R1
[RTC-41485] - [R2C3 - RRC0019 - 1.4.17.2] - Sistema está criando frações fumaça com o valor total da operação ao incluir operação de Cessão com saldo INSUFICIENTE (Gestao ER IdentdPartPrincipal IGUAL IdentdPartAdmtd)
[R2C3 - INTEROP /notificacao/anuencia- v.1.4.30 Atlante v.5.1.45] - CIP ouvindo não apresenta erro ao recepcionar mensagem OPTIN sem tag dataFim
[EV552528 e EV552880] - BUGFIX - o participante Banco Safra e Itau informaram que no arquivo ARRC018 enviado pela CIP vieram várias ocorrências de domicílio bancário de titular repetidas
[EV553920 e EV553941] - BUGFIX - arquivo 0018 está apresentando divergências nos campos de valor livre total e valor livre no domicílio
[EV556741] - Ur informada na ARRC018 não sai na RRC010R1 (Sem conteudo)
[EV557495] - RRC0008 via api com erro de conversão de data no OutputHandle
[EV555592] - RRC0010R1 faltando campo GrupoRRC0010R1CreddrSub
RRC0011 e RRC0013 não está exibindo erro no retorno da mensagem quando erro de comunicação com centralizadora.
 - Otimizações performance

## 1.4.32.9

- Novo codigo de erro provisório para limitar as operacoes dos arquivos 005, 019 e 022 em 90 dias
- Ajuste no tratamento de inserção do opt-in para inclusão apenas quando tem sucesso na consulta da centralizada.

## 1.4.32.8

- Ajuste envio OptOut para Interop - troca do campo Tipo para TipoComunicacao

## 1.4.32.7

- Ajuste envio OptOut para Interop - conteúdo da requisição com campos faltando.

## 1.4.32.6

- Otimizacao SQL de atualizacao de fracao (FRACAO_UNIDD_RECBV_OP)
- Remoção da interop na 019 temporariamente.
- Ajuste na geração dos headers das requisições síncronas.

## 1.4.32.5

Ajuste RRC0019 - null pointer ao consultar interop e base centralizada - passar paramentro batchId na busca da centralizadora.

## 1.4.32.4

Ajuste RRC0019 - null pointer ao consultar interop e base centralizada - ajuste em um outro ponto adicional do processamento.


## 1.4.32.3

Ajuste RRC0019 - null pointer ao consultar interop e base centralizada

## 1.4.32.2

- Ajuste retorno base centralizada quando volta erro 404 para resultado inexistente.
- RRC0003/RRC0009 - otimização de consulta de frações

## 1.4.32.1

Ajuste na geração do codigo de erro ERCC0196 e ERCC0081 nas mensagens RRC0011E e RRC0013E

## 1.4.32

Centralizadora - CNPJ CIP não deve se comunicar com a Centralizadora e a Interop na RRC0011 e RRC0013
Centralizadora - Ajuste fluxo centralizadora e interop RRC0011 e RRC0013 - consulta base credenciador x registradora
[EV555845/EV555567/EV555566] - ARRC023 NÃO GERAVA RET

## 1.4.31

INTEROP - Nao estava considerando varios tipos de requisicao para funcionalidades diferentes

## 1.4.30

[RTC 41534] - Interop CIP recebendo agenda campo porcentagem esta permitindo valor maior que 100% quando RegraDivisão = Porcentagem.
[EV556829] - Ajuste de regra para Cessão de Participante não criar Fumaça.
ARRC017 - NullPointerException
Ajuste no tamanho do campo da razao social e email para 50 caracteres.

## 1.4.29

INTEROP - Tratamento de erro 404 da base centralizada nao é erro (todas as funções da centralizada)
INTEROP - Correção de conversão de codigo de arranjo

## 1.4.28

INTEROP - Tratamento de erro 404 da base centralizada nao é erro

## 1.4.27

INTP011 - Tratamento para NullPointerException
- Ajuste RRC0011 e RRC0013 quando ocorre erro inesperado na base centralizadora (não simulavel pelo rebatedor).

## 1.4.26

[RTC-41286] - [R2C3 - INTEROP /contrato - v.1.4.9 Atlante v.5.1.38] - CIP ouvindo apresenta EGEN0050 quando tag arranjo fora de domínio]
[RTC-41411] - [R2C3 - INTEROP /notificacao/anuencia - v.1.3.13 Atlante v.5.1.38] - CIP ouvindo - Sistema apresenta EGEN0023 na recepção de OPTOUT]
[RTC-41481] - [R2C3 - INTEROP /notificacao/anuencia- v.1.4.17 Atlante v.5.1.42] - CIP ouvindo não apresenta erro ao receber tag arranjo inválida]
[RTC-41502] - [R2C3 - INTEROP /notificacao/anuencia- v.1.4.19 Atlante v.5.1.43] - CIP ouvindo está gerando id do optin no formato incorreto]
[RTC-41504] - [R2C3 - INTEROP /notificacao/anuencia- v.1.4.19 Atlante v.5.1.43] - CIP ouvindo está com id_ctrl_solcte e nr_ctrl_base_centzd trocados devido a nova definição]
[RTC-41500] - [R2C3 - INTEROP /notificacao/anuencia- v.1.4.19 Atlante v.5.1.43] - CIP ouvindo não está gravando hora da inclusão do registro optin]
[RTC-40331] - Ajuste de validação do erro ERRC0127
[EV557160] - ARRC017 - Enviando arquivos como XFB (e deveria ser de acordo com a adesão)
[RTC-41489] - [R2C3 - RRC0005 - 1.4.17.2] Sistema retorna R1 com grupo recusado sem informar nenhuma tag e nenhum codigo de erro no grupo quando informado CNPJ_CPFTitlarCt invalido no Grupo_RRC0005_Titlar
[RTC-41509] - RRC011 - NullPointer ao enviar CNPJ Credenciadora igual CNPJ Financiadora]

## 1.4.25

[RTC-40615] - [R2C3 - RRC0005 - 1.0.58] - Sistema não está retornando todas as frações a constituir na RRC005R1Defeito 40615 - [R2C3 - RRC0005 - 1.0.58] - Sistema não está retornando todas as frações a constituir na RRC005R1
- Novos erros para tratamento da centralizadora na mensagem RRC0011 - ERRC0081 (tag CnpjCNPJBaseCPFUsuFinalRecbdrTitular) - Dados não encontrados na base centralizada para o EC
- Novos erros para tratamento da centralizadora na mensagem RRC0011 - ERRC0196 (tag CnpjCNPJBaseCPFUsuFinalRecbdrTitular) - Base centralizada com erro na consulta ou indisponível.
- Novos erros para tratamento da centralizadora na mensagem RRC0013 - ERRC0081 (tag IdentdCtrlOptIn) - Dados não encontrados na base centralizada para o EC
- Novos erros para tratamento da centralizadora na mensagem RRC0013 - ERRC0196 (tag IdentdCtrlOptIn) - Base centralizada com erro na consulta ou indisponível.
[RTC-41398] - [R2C3 - RRC0005 - 1.4.13] - Sistema não cria as frações à constituir quando não são encontradas URs e o IndrActeIncondlOp = S para as operações de Reserva e Penhora
[RTC-41489] - [R2C3 - RRC0005 - 1.4.17.2] Sistema retorna R1 com grupo recusado sem informar nenhuma tag e nenhum codigo de erro no grupo quando informado CNPJ_CPFTitlarCt invalido no Grupo_RRC0005_Titlar

## 1.4.24

[RTC 41492] - [R2C3 - RRC0021 - 1.4.18] - Sistema está retornando frações constituídas na RRC0021R1 que não existem para a operação

## 1.4.21

[RTC 41497] - Interop CIP recebendo agenda com campo idAnuenciavazio.
[RTC 41503] - Interop CIP recebendo agenda campo documentoTitularConta gravando CPF quando tipoDocumento = CNPJ.
[RTC-41509] - [R2C3 - RRC0011 - 1.4.20] - Sistema está retornando erro de NullPointer Exception ao enviar CNPJCreddrSub = CNPJFincdr
[RTC-41483] - [R2C3 - RRC0013] O sistema aceita IdentdCtrlReqSolicte com espaço no meio da string
[EV556495] - Está voltando o erro: ERRC0110 - CNPJ informado não corresponde a uma credenciadora / subcredenciadora. CORRIGIDO, porém foi encontrado erro de NullPointer Exception em outro cenário na regressão
[RTC-40615] - [R2C3 - RRC0005 - 1.0.58] - Sistema não está retornando todas as frações a constituir na RRC005R1Defeito 40615 - [R2C3 - RRC0005 - 1.0.58] - Sistema não está retornando todas as frações a constituir na RRC005R1
[RTC 41488] - [R2C3 - RRC0019 - 1.4.17.2] - Sistema está apagando as frações constituídas na tabela fracao_unidd_recbv_op ao enviar RRC0019 de alteração de contrato de Cessão Gestão Participante com valor a menor

## 1.4.20

- RRC0011 - Buscar o CNPJ da credenciadora na base centralizada (**** ajustar a massa de teste ****)
[RTC-41493] - NullPointer na RRC005
[EV556495] - Está voltando o erro: ERRC0110 - CNPJ informado não corresponde a uma credenciadora / subcredenciadora.

 - Ajustes no swagger bilateral - v0.0.18

## 1.4.19

[RTC 41481] - INTEROP /notificacao/anuencia CIP ouvindo não apresenta erro ao receber tag arranjo inválida.
[RTC 41480] - INTEROP /notificacao/anuencia CIP ouvindo não apresenta erro ao receber tag tipoComunicacao inválida.
[RTC 41479] - INTEROP /notificacao/anuencia CIP ouvindo apresenta erro incorreto ao informar tag cpfCnpjCredor inválida.
[RTC 41286] - INTEROP /notificacao/anuencia CIP ouvindo apresenta EGEN0050 quando tag arranjo fora de domínio.
[RTC-40202] - [R2C3 - RRC0005 - 1.0.53] - Sistema não está gravando o valor da operação no campo nr_vlr_res na tabela unidd_recbv para operação de Reserva
[RTC-41100] - [R2C3 - RRC0019 - 1.3.7] - Sistema não está retornando todas as frações do contrato de Gravame na RRC0019R1 e RRC0003 após alteração do mesmo com valor a maior
[RTC-41484] - [R2C3 - RRC0019 - 1.4.17.2] - Sistema está criando frações fumaça ao incluir operação de Cessão com saldo SUFICIENTE (Gestao ER IdentdPartPrincipal DIFERENTE OU IGUAL IdentdPartAdmtd)
[EV554441] - RRC0004 com partPrincipal e Administrado errado
[EV555814] - REDE relatou que o sistema está retornando linhas em branco e quebras incorretas no retorno do arquivo ARRC002RET
[EV554441] - RRC0004 com partPrincipal e Administrado errado

## 1.4.18

[RTC-40202] - [R2C3 - RRC0005 - 1.0.53] - Sistema não está gravando o valor da operação no campo nr_vlr_res na tabela unidd_recbv para operação de Reserva
[RTC-40949] - [R2C3 - ARRC001 - 1.3.3] - Sistema está retornando valor negativo no campo nr_vlr_livre_tot na tabela unidd_recebv ao enviar agenda com registro Pré-contratado sobre o livre. Tambem está afetando o valor retornado na ARRC018
[RTC-41469] - [R2C3 - V_RECALCL - 1.4.16.1] - Sistema está retornando erro de java.lang.IllegalArgumentException: Tipo negociacao '$s' invalida ao executar a varredura
[RTC-41411] - [R2C3 - INTEROP /notificacao/anuencia - v.1.3.13 Atlante v.5.1.38] - CIP ouvindo - Sistema apresenta EGEN0023 na recepção de OPTOUT
[RTC-41413] - [R2C3 - INTEROP /notificacao/anuencia - v.1.3.13 Atlante v.5.1.38] - CIP ouvindo - Sistema está gravando 'O' em campo do tipo 'N' ou 'S'
[RTC-41406] - [R2C3 - RRC0021 - 1.4.13] - Sistema está retornando erro de NullPointer Exception ao enviar RRC0021
[RTC-40331] - Ao enviar o cancelamento parcial (IndrCancelVlrTotal = N) informando o Grupo_RRC0020_RegRecbvl, está retornando o erro ERRC0127, obrigando informar o CNPJ_CNPJBase_CPFTitlar.
[RTC-41407] - INTEROP /notificacao/anuencia - v.1.3.12 Atlante v.5.1.38] - CIP ouvindo - Id da funcionalidade inexistente na base de dados
[RTC-41410] - Interop CIP ouvindo agenda esta retornando EGEN0023 ao não preencher o campo digito da conta
[RTC-41378] -  Interop CIP ouvindo agenda TipoObrigacao = saldoLivre esta retornando INTP002 sem o motivo da rejeicao
[RTC-41414] - nterop CIP ouvindo agenda não esta gravando o digito da conta no campo NR_CT da tabela FRACAO_UNIDD_RECBV_OP.
- Ajustes de campos obrigatorios entre swagger e app
- Adaptaçao do /agenda e /agendaPosicao para o novo modelo de interoperabilidade

## 1.4.17.8

EV556435 - ARRC022 - Favor verificar o arquivo ARRC022 enviado pelo Itaú (ROOT ID:8119100), pois deveria ter sido enviado uma mensagem RRC0003 para a credenciadora Safra e não foi enviada.

## 1.4.17.2

RTC-41357 - [R2C3 - RRC0019 - 1.4.11.1] - Sistema está retornando erro de NullPointer ao enviar alteração de contrato de Cessão Gestão ER com valor a menor para recalcular contrato de Gravame que está com valores a constituir aguardando saldo  livre
RTC-41356 - [R2C3 - RRC0019 - 1.4.11.1] - Sistema está retornando erro de NullPointer ao enviar alteração de contrato de Cessão Gestão ER com valor a menor

## 1.4.17.1

EV555809 - NullPointerException ARRC022 do Itau

## 1.4.17

RTC-41090 - [R2C3 - RRC0003 - 1.3.6] - Ao alterar operação de Gravame Gestão Participante com valor a menor, sistema não está enviando a msg RRC0003
[EV554712, EV553962, EV549523] - Tratamento do erro ERRC0203 - envio do erro apenas quando não tem opt-in. Sem resultados deve retornar SITREQ = 4. Agrupamento ajustado na versão 4.1.12.
[EV554966] - Corrigido consulta por credenciadora.
[RTC 41456] - Corrigido.
EV554404 - RRC005 - Prioridade 0 quando so existem frações livres
EV554913 - Ajustado o filtro para buscar D+1
RTC 41356 - [R2C3 - RRC0019 - 1.4.11.1] - Sistema está retornando erro de NullPointer ao enviar alteração de contrato de Cessão Gestão ER com valor a menor
RTC 41357 - [R2C3 - RRC0019 - 1.4.11.1] - Sistema está retornando erro de NullPointer ao enviar alteração de contrato de Cessão Gestão ER com valor a menor para recalcular contrato de Gravame que está com valores a constituir aguardando saldo  livre
RTC 40331 - Ao enviar o cancelamento parcial (IndrCancelVlrTotal = N) informando o Grupo_RRC0020_RegRecbvl, está retornando o erro ERRC0127, obrigando informar o CNPJ_CNPJBase_CPFTitlar.

## 1.4.16

[EV552528 e EV552880] - BUGFIX - o participante Banco Safra e Itau informaram que no arquivo ARRC018 enviado pela CIP vieram várias ocorrências de domicílio bancário de titular repetidas
RTC-41128 - [R2C3 - RRC0019 - 1.3.8] - Sistema retorna o erro ERRC0060 ao enviar RRC0019 informando CNPJ_CNPJBase_CPFTitlar ou CNPJ_CNPJBase_CPFUsuFinalRecbdr = CNPJ Base

## 1.4.15

RTC-41357 - [R2C3 - RRC0019 - 1.4.11.1] - Sistema está retornando erro de NullPointer ao enviar alteração de contrato de Cessão Gestão ER com valor a menor para recalcular contrato de Gravame que está com valores a constituir aguardando saldo  livre
RTC-41356 - [R2C3 - RRC0019 - 1.4.11.1] - Sistema está retornando erro de NullPointer ao enviar alteração de contrato de Cessão Gestão ER com valor a menor
- RRC0019/RRC0005 - Ajuste nos endpoints /unidades-recebiveis-disponiveis
[EV553502] - CORREÇÃO PERSISTÊNCIA NUMERO CONTA NA TABELA OP_TITLAR_DOMCL
RTC-41128 - [R2C3 - RRC0019 - 1.3.8] - Sistema retorna o erro ERRC0060 ao enviar RRC0019 informando CNPJ_CNPJBase_CPFTitlar ou CNPJ_CNPJBase_CPFUsuFinalRecbdr = CNPJ Base
EV554472 - RRC0029 com informações incorretas no cabeçalho participante principal e administrado estão saindo com informação de quem enviou o 013
RTC41344 - Sistema está retornando frações livres no grupo Grupo_RRC0010R1_NegcRecbvOutrasInst
EV554355 - correcao nullpointer
RTC-41328 - [R2C3 - ARRC022 - 1.4.11] - Sistema está retornando erro de NullPointerException ao enviar ARRC022
RTC-41375 - [R2C3 - RRC0019 - 1.4.13] - Sistema retorna erro de IncorrectResultSizeDataAccessException ao validar EV553974

## 1.4.14

- RRC0019/RRC0005 - Implementado os endpoints /unidades-recebiveis-disponiveis

[EV553648] - Bom dia! Devido a inclusão do novo campo na tabela de frações (titular anterior), se faz necessário ajustar a funcionalidade abaixo para que o campo informado na mensagem 004 - seja o TITULAR ANTERIOR, e não o TITULAR ATUAL.
[EV554418] - Inclusao de contrato (0019) pelo Banrisul, com notifcação (003) para Banrisul Cartões no endpoint de alteração
[EV552528 e EV552880] - BUGFIX - o participante Banco Safra e Itau informaram que no arquivo ARRC018 enviado pela CIP vieram várias ocorrências de domicílio bancário de titular repetidas
[EV553397] - Não busca URs para Negociação quando informado o CNPJ Base.
RTC-41375 - [R2C3 - RRC0019 - 1.4.13] - Sistema retorna erro de IncorrectResultSizeDataAccessException ao validar EV553974
RTC-41128 - [R2C3 - RRC0019 - 1.3.8] - Sistema retorna o erro ERRC0060 ao enviar RRC0019 informando CNPJ_CNPJBase_CPFTitlar ou CNPJ_CNPJBase_CPFUsuFinalRecbdr = CNPJ Base
RTC 40126 - [R2C3 - RRC0008 - 1.0.52] - Sistema está retornando os Grupo_RRC0008R1_Titlar e Grupo_RRC0008R1_NegcRecbvl duplicados ao consultar operação com frações com valores à constituir
RTC 40331 - Ao validar o cenário de cancelamento parcial por UR foi retornado erro de NullPointer Exception
Defeito 41115: [R2C3 - v.1.3.7 Atlante v.5.1.36] - Interop CIP ouvindo agenda rejeitar não esta retornando o conteúdo esperado na INTP002R1
Defeito 41367: [R2C3 - v.1.4.12 Atlante v.5.1.38] - Interop CIP ouvindo agenda tipoEfeito = restricao e Tipo Ônus = cessaoFiduciaria - OP não grava na base e gera INTP002 sem informação
Defeito 41117: [R2C3 - INTEROP /api/opt - v.1.3.7 Atlante v.5.1.36] - CIP falando está apresentando INVALID HEADER VALUE: Authorization ao chamar Inserir Anuências

## 1.4.13

[EV553920 e EV553941] - BUGFIX - arquivo 0018 está apresentando divergências nos campos de valor livre total e valor livre no domicílio

## 1.4.12

EV553490 - Prezados, por gentileza verificar os apontamentos do Banco Santander acerca da mensagem RRC0010: Iniciamos a validação em uma RRC0010R1 (NUOP 90400888202010190005446) que chegou e encontramos alguns erros para serem corrigidos. Poderia verificar, por favor. A tag abaixo está formatando o CPF com 14 posições com zeros a esquerda. 00027007266002 O grupo Grupo_RRC0010R1_ArrajPgto está repetido 3x para o mesmo arranjo de pagamento “008” e trazendo as mesmas URs. Neste caso por ser um único arranjo de pagamento o correto era devolver apenas um grupo Grupo_RRC0010R1_ArrajPgto.
RTC 41130 - [R2C3 - RRC0021 - 1.3.9] - Sistema retorna o Grupo_RRC0021R1_Titlar repetido para cada combinação de fração a constituir retornada
RTC 41131 -  [R2C3 - RRC0021 - 1.3.9] - Sistema retorna zeros a esquerda nas tags CNPJ_CPFUsuFinalRecbdr e CNPJ_CNPJBase_CPFUsuFinalRecbdr qdo usuário final igual a CPF
EV552286 - Está retornando sitReq 001 na ARRC001 quando o arquivo tem sucesso e erro.
[Item de Trabalho 41299]  [R2C3 - ARRC002- 1.4.11] - Sistema não está retornando o erro ERRC0150 ao enviar baixa de fração já liquidada [o]
[EV553974] - RRC0019R1 com situação recusada mas sem mensagem de erro.
RTC-41128 - [R2C3 - RRC0019 - 1.3.8] - Sistema retorna o erro ERRC0060 ao enviar RRC0019 informando CNPJ_CNPJBase_CPFTitlar ou CNPJ_CNPJBase_CPFUsuFinalRecbdr = CNPJ Base
- Refactorings arquivos de mapeamento funcionalidade x endpoint por participante (.json)
RTC 41140 - /notificacao/anuencia - esta exigindo campo x-jws-sognature
RTC-41220 - [R2C3 - RRC0009 - 1.4.4] - Sistema está retornando o ISPB do Principal e Administrado preenchido na RRC0005 na msg RRC0009. Deve ser preenchido o ISPB do Participante que está recebendo a msg RRC0009

## 1.4.11.1

[EV553817] - Correção da exibição dos valores nos retornos da RRC0003, RRC0005, RRC0019, ARRC022

## 1.4.11

[EV552776/EV552892] - Ajustes na validação de operações ativas
[EV553194] - A REDE encaminhou arquivo 002 ontem e não retornamos o RET. Poderiam validar, por favor? Batch ID -> 5160103
[EV552528 e EV552880] - BUGFIX - o participante Banco Safra e Itau informaram que no arquivo ARRC018 enviado pela CIP vieram várias ocorrências de domicílio bancário de titular repetidas
[EV552925] - corrigido nullPointer
[EV552893] - Sistema mostrando o titular errado nos retornos da ARRC022.

## 1.4.10
===
[EV553817] - Correção da exibição dos valores nos retornos da RRC0003, RRC0005, RRC0019, ARRC022

## 1.4.9

[EV553485] - BUGFIX - O Banco Safra está enviando diversas mensagens RRC0011, e todas estão retornando o erro ERRC0097 Tiago Valceiro 20/10/20 15:51
[EV551841] - Correção do Titular Anterior na RRC0003
RTC-41126 - [R2C3 - RRC0005 - 1.3.8.1] - Sistema não deixou as frações que foram antecipadas do Gravame Gestão ER com prioridade 2 ao enviar antecipação de URS gravamadas não informando DtEftLiquidAntec e VlrEftLiquidAntec

## 1.4.8

[EV552140] - Ajuste para fumacas duplicadas na RRC0022.
[RCT 40859] - CIP ouvindo nao esta gravando registro na tabela AGENDA_INTRDD
[RCT 41115] - CIP ouvindo agenda rejeitar nao esta retornando o conteudi esperado na INTP002R1.

## 1.4.7

[EV553463] - RRC0019 - Corrigido sitReq quando alcance é G e não existem URs encontradas para o Filtro. (Solução temporária enquanto interop não é disponibilizada)
[Evento EV552776] - Ajustes na validação de operações ativas ao realizar o OPT_OUT.

## 1.4.6

RRC0021 - Ajuste no url /v1/financiadora/operacoes/2020101900000000101/unidades-recebiveis e /v1/financiadora/operacoes/2020101900000000101/unidades-recebiveis-a-constituir
[Evento EV551820] - Itaú - Alteração do tipo de dado da tag PriorddNegcRecbvl de String para Inteiro (numérico). Arquivos e mensagens afetados - 003, 005, 008, 009, 010, 018. 019, 021, 022
V_CTZMAPA - Corrigido chamada ao metodo de serviço

## 1.4.5

RTC-41128 - [R2C3 - RRC0019 - 1.3.8] - Sistema retorna o erro ERRC0060 ao enviar RRC0019 informando CNPJ_CNPJBase_CPFTitlar ou CNPJ_CNPJBase_CPFUsuFinalRecbdr = CNPJ Base
RTC 41115 - Agenda rejeitar nao esta retornando conteudo esperado na INTP002R1.
RTC 41134 - CIP ouvindo contrato está exigindo campo não obrigatório (valorASerMantido).
[EV551761] - BUGFIX - Realizamos um teste da funcionalidade  RRC0008, de um id operação qualquer e inválido e identificamos que o retorno do erro está sendo enviado fora do padrão definido no swagger
[EV552140] - RR0022 Corrigido limite de 30 dias.
Ajuste RRC0003 - CESSÃO - Retornar o Titular Anterior

## 1.4.4

EV552914 - Itau reportou que enviou uma consulta da mensagem 10, e não teve retorno.
[EV551761] - BUGFIX - Realizamos um teste da funcionalidade  RRC0008, de um id operação qualquer e inválido e identificamos que o retorno do erro está sendo enviado fora do padrão definido no swagger
Ajustes do merge
Ajuste RRC0019R1 - CESSÃO - Retornar o Titular Anterior

## 1.4.1

RTC 40331 - RRC0020 - NullPointerException

## 1.4.0

RCC0005 - Interop
RCC0019 - Interop
RCC0022 - Interop
RCC0010 - Interop
RCC0021 - Interop
RCC0023 - Interop
RCC0020 - Interop
RCC0008 - Interop

## 1.3.11

[EV552112] - BUGFIX - Quando é passado o mesmo arranjo no xml de entrada, o sistema esta duplicando as URs a constituir.
RRC0005 e RRC0019 - Correção no retorno do resultado da requisição de inclusão/alteração via API.

## 1.3.10

- RRC0019 - OptIn automatico corrigido (teste com Banrisul)
[RTC 41119] - Sistema retorna EGN0050 na inclusao de contrato.
[EV552140] - RR0022 Corrigido limite de 30 dias.
[EV551735] Alteração na prioridade da cessão.
[EV551576] Alteração na prioridade da cessão.
[EV551798] Alteração na prioridade da cessão.

## 1.3.9

[RCT 40859] - CIP ouvindo nao esta gravando registro na tabela AGENDA_INTRDD
[RCT 41115] - CIP ouvindo agenda rejeitar nao esta retornando conteudo esperado na INTP002
[EV547168 e RTC40019] - BUGFIX - o arquivo ARRC007 no ambiente de homologação da Registradora CIP, verificamos que quando o participante envia algum arquivo os campos NomArqMsgURLIn e NomArqMsgURLOut são preenchidos com a mesma informação
[EV552128 | RTC41038] - Corrigido valor percentual seguindo regra da divisão.
[EV552106] Feito alteração no update. É necessário reteste
[RTC 40948] - Sistema está retornando divergências nas tags VlrTotTitlar, VlrComprtdOutrInst e Grupo_ARRC018_NegcRecbvOutrasInst
[RTC 40331] - Sistema está retornando o erro ERRC0127 obrigando informar o titular do contrato ao enviar o cancelamento de URs constituídas informando o Grupo_RRC0020_RegRecbvl
[QA - sem evento] RRC0010R1 campo cpfcnpjtutilar completando com zeros a esquerda.
RTC 41119 - Sistema retorna EGEN0050 na inclusao de contrato.

## 1.3.8

[RTC 41030] - Corrigido recebimento de operações com valor de garantia zerado..3.9
[RTC 40869] - Validação do PostContrato
[RCT 40859] - CIP ouvindo nao esta gravando registro na tabela AGENDA_INTRDD
[EV552128] - Corrigido valor percentual.
[EV552137] - Correção RRC0019R1. Colocando fumaças com no máximo de 30 dias a partir da fumaca com menor data de liquidacao
[EV550636] - teste evento ARRC001 já estava corrigido commit corrigiu no dia 13/10/2020
[EV549873] - teste evento ARRC001 já estava corrigido commit corrigiu no dia 13/10/2020
[EV551917] - Correção da RRC0010 via API estava completando o campo CNPJCNPJBaseCPFUsuFinalRecbdr com zeros a esquerda não trazendo resultados.
[EV551307] - RRC0019 (Api) - Erro de mensagens Banrisul
[EV552187] - O participante Banrisul enviou RRC0019 (BATCH 4577125) e foi gerado apenas o PRO sem RET,

## 1.3.7

[EV551280] - BUGFIX - No arquivo RRC0011, quando é passado um participante e o cnpj é igual ao de outro participante. O sistema esta enviando a mensagem 028 para o participante errado.
[EV547168 e RTC40019] - BUGFIX - o arquivo ARRC007 no ambiente de homologação da Registradora CIP, verificamos que quando o participante envia algum arquivo os campos NomArqMsgURLIn e NomArqMsgURLOut são preenchidos com a mesma informação
[EV549523] - Ajuste Santander RRC0010 agrupamento.
[EV550050] - BUGFIX - Ajuste no arquivo 007 para que as tags urlin e urlout não sejam obrigatórias.
RTC-38428 - [R2C3 - RRC0021 - 1.0.33] - Sistema retorna RRC0021R1 sem dados da operação ao enviar RRC0021 informando somente CNPJ_CNPJBase_CPFTitlar e CNPJ_CNPJBase_CPFUsuFinalRecbdr no filtro

## 1.3.6

RRC0019 - Alteração Cessão
[EV551362] - Removido a validação ERRC0165 temporariamente pois depende de interop bilateral.
[EV551360] - Mesma validação do EV551362. Removido a validação ERRC0165 temporariamente pois depende de interop bilateral.
[RTC 40896] - Corrigido validação
[EV550162] - RRC0010 - Envio de ERRC0203 quando nao sao retornados registros

## 1.3.5

RTC 40906 - [R2C3 - RRC0010/MQ - 1.3.0] - Sistema não está retornando o erro de negócio ERRC0110 ao enviar CNPJCreddrSub que não corresponde a uma credenciadora
[EV551330] - Corrigido. Incluindo tag CNPJ_CNPJBase_CPFTitlar na RRC0003.
[EV551340] - Ajuste tag VlrPercNegc para percentual.
[EV550709 | RTC40915] - Correção geração de fumaça para URs nao encontradas.
[EV551329] - RRC0003 - Alterar as TAGs de IdentdAdm e IdentdPrinc

## 1.3.4

[EV549534] - RRC0010 - Erro ao consultar opt-ins com mais de um arranjo para cnpj
[EV550166] - Correção nas divergências NrPridd e Participante negociador.
[EV551253] - RRC0003 - Campo <VlrNegc> com mais de duas casas decimais

## 1.3.3

[EV550351] - Arquivo 011 da erro ERRC0110 quando é enviado um partipante que é instituição e credenciadora com ispb diferentes.
[EV550549] BUGFIX - Arquivo 018 esta apresentando o indicador de domicilio invertido Tiago Valceiro 13/10/20 22:47

## 1.3.1

RTC 40126 - [R2C3 - RRC0008 - 1.0.52] - Sistema está retornando os Grupo_RRC0008R1_Titlar e Grupo_RRC0008R1_NegcRecbvl duplicados ao consultar operação com frações com valores à constituir
RTC 40851 - [R2C3 - MQ - RRC0008/RRC0021 - 1.2.11] - Ao enviar RRC0008 ou RRC0021 com CNPJ_CNPJBase_CPFUsuFinalRecbdr = CNPJ Base OU CNPJ_CNPJBase_CPFTitlar =  CNPJ Base, o sistema não retorna os dados do contrato nas mensagens R1
EV550068 - RRC0019 - Sistemas esta recusando operações com <IndrTpNegc> = GC
EV550162 - RRC0010R1 Vazia
RTC 40870 - Corrigido validação quando saldo insuficiente e com aceite incondicional = 'N'
RTC 40914 - Corrigido validação quando saldo insuficiente e com aceite incondicional = 'N'
RTC 38080 - Sistema está permitindo criar operação informando IdentdOpOrRenegcDiv que não corresponda a uma renegociação de divida.

## 1.2.15

- RRC0010 - Ajustado busca no OPT-IN por cnpj 'like'
EV549140 - Adminstrado e principal estão saindo no mesmo arquivo, deveria sair em arquivos separados.
EV549498 - O participante Cielo comunicou que esta recepcionamos o arquivo ARRC007 sem os campos opcionais, exemplo do campo <IdentdCtrlOptIn>
RTC 38462 - [R2C3 - RRC0006 - 1.0.33] - Sistema não está alterando na tabela FRACAO_UNIDD_RECBV_OP o campo IC_SIT, ele deve ser atualizado para Cancelado
RTC 40065 - Divergencias ao aceitar a desconstituicao de garantia na RRC0019.

## 1.2.14

RTC 40811 - [R2C3 - ARRC002 - 1.2.10] - Sistema está retornando arquivo ARRC002ERR ao enviar ARRC002 informando IndrMotvBaixa = FR
RTC 40228 - [R2C3 - RRC0006/API - 1.0.54] - Sistema está retornando erro de NullPointer Exception ao informar identd-op já cancelada
RTC 39111 - [R2C3 - RRC0008 - 1.0.38] - Sistema está retornando a RRC0008R1 com dados divergentes dos inseridos no filtro de pesquisa da RRC0008
RTC 40019 - Ajustes no resumo diario

## 1.2.13

EV549720 - ARRC018 - Envio indevido do <Grupo_ARRC018_NegcRecbvlInst>
EV548551 - ARRC001 - Campo “valor efetivo liquidação” deve permitido valores zerados
SEM EVENTO - Ajuste de negocio da RRC0013 referente ao erro ERR0071

## 1.2.12

EV549678 - ARRC018 - Ajuste para tratar campos not null na geração do XML
RTC 40192 - [R2C3 - RRC0020 - 1.0.53] - Sistema não está retornando o erro ERRC0110 ao informar CNPJCreddrSub que não corresponda a uma Credenciadora no Grupo_RRC0020_RegRecbvl
RTC 40196 - [R2C3 - RRC0020 - 1.0.53] - Sistema não está retornando o erro ERRC0162 ao enviar msg RRC0020 informando Operação de Gravame informando IndrCancelCessConstitr = S
RTC 40331 - [R2C3 - RRC0020 - 1.0.57] - Sistema está retornando o erro ERRC0127 obrigando informar o titular do contrato ao enviar o cancelamento de URs constituídas informando o Grupo_RRC0020_RegRecbvl
RTC 40206 - [R2C3 - RRC0020 - 1.0.53] - Sistema não está retornando o erro ERRC0108 ao enviar Grupo_RRC0020_RegRecbvl com UR que não pertence ao contrato informado
RTC-40562 - [R2C3 - RRC0003 - 1.0.58] - Sistema não está retornando as frações Fumaça na msg RRC0003

## 1.2.11

RTC-37951 - Divergencias na msg RRC0028 enviada apos opt-in automatico.
EV548966 - ARRC018 - Ajuste para evitar duplicidade de domicilios

## 1.2.10

RTC-38080 - [R2C3 - RRC0019 - 1.0.31] - Sistema está permitindo criar operação informando IdentdOpOrRenegcDiv que não corresponda a uma renegociação de divida, deveria retornar o erro ERRC0054
RTC-40496 - [R2C3 - RRC0019 - 1.0.58] - Sistema está retornando o erro ERRC0060 em uma RRC0019E, conforme especificação deve ser retornada numa RRC0019R1
RTC-40625 - [R2C3 - RRC0005 - 1.0.58] - Sistema não retorna codErro ERRC0055 ao enviar alterar de operação sem informar a tag IdentdOp
EV547780 - Validação indevida do ISPBBancoRecebdor

## 1.2.9

EV548583 - ARRC001 - Tratamento de data invalida na tag <DtPrevtLiquid>
RTC-40262 - [R2C3 - RRC0019 - 1.0.55] - Sistema está retornando uma msg RRC0019R1 sem as frações constituídas e a constituir ao enviar alteração de operação com 2 Grupo_RRC0019_ArrajPgto
RTC-40623 - [R2C3 - RRC0019 - 1.2.4] - Sistema não está retornando o erro ERRC0060 no Grupo_RRC0019R1_NegcRecbvlRecsdo ao incluir Operação informando IndrActeIncondlOp = N (Com saldo insuficiente) (Gestão Participante)

## 1.2.7

RTC-39659 - [R2C3 - RRC0019 - 1.0.45] - Sistema não está alterando os dados do domicilio bancário na tabela op_titlar_domcl e está criando uma fração zerada ao alterar uma operação pela msg RRC0019
RTC-40612 - [R2C3 - RRC0005 - 1.0.58] - Valor das frações gravamadas constituidas que foram para o contrato de Antecipação está errado
RTC-40549 - [R2C3 - RRC0019 - 1.0.58] - Sistema está retornando erro de java.lang.ArithmeticException: / by zero ao enviar 2º contrato com agenda sem valor livre

## 1.2.6

EV547173 - RRC0011 não sai na varredura ARRC007

## 1.2.4

EV545244 - Não sai o código de erro quando o Idop é informado e recusado
EV546528 - BUGFIX - Não está sendo aceito na tag CNPJ_CNPJBase_CPFUsuFinalRecbdr o cnpjBase
EV548146 - ARRC018 - Erro de SQL
RTC-40532 - Ajuste nos HEADERS da agenda via INTEROP

## 1.1.3

RTC-37698 - [R2C3 - RRC0005 - 1.0.28] - Divergências nas tabelas fracao_unidd_recbv_op e unidd_recbv ao enviar RRC0005 de Antecipação que afete uma UR gravamada Otavio Ferreira 05/10/20 18:37

## 1.1.2

RTC 40206 - [R2C3 - RRC0020 - 1.0.53] - Sistema não está retornando o erro ERRC0108 ao enviar Grupo_RRC0020_RegRecbvl com UR que não pertence ao contrato informado
RTC 40190 - [R2C3 - RRC0020 - 1.0.53] - Sistema está retornando erro de NoSuchElementException ao enviar msg RC0020 informando IndrCancelVlrTotal = S informando IndrCancelCessConstitr = S
RTC 39111 - [R2C3 - RRC0008 - 1.0.38] - Sistema está retornando a RRC0008R1 com dados divergentes dos inseridos no filtro de pesquisa da RRC0008
RTC-37698 - [R2C3 - RRC0005 - 1.0.28] - Divergências nas tabelas fracao_unidd_recbv_op e unidd_recbv ao enviar RRC0005 de Antecipação que afete uma UR gravamada

## 1.1.0

INTP004 - Implementacao da funcionalidade
INTP005 - Implementacao da funcionalidade
RTC-40331 - [R2C3 - RRC0020 - 1.0.57] - Sistema está retornando o erro ERRC0127 obrigando informar o titular do contrato ao enviar o cancelamento de URs constituídas informando o Grupo_RRC0020_RegRecbvl
RTC-38419 - [R2C3 - RRC0021 - 1.0.33] - Sistema retorna erro de NullPointer Exception ao enviar RRC0021 informando somente IdentdOp no filtro
RTC-37105 - [R2C3 - RRC0013 - 1.0.23] - Sistema não está retornando o erro ERRC0071 ao enviar msg RRC0013 informando IdentdCtrlOptIn onde possui operações ativas em relação ao CNPJFincdr do OPT-IN
RTC 40126 - [R2C3 - RRC0008 - 1.0.52] - Sistema está retornando os Grupo_RRC0008R1_Titlar e Grupo_RRC0008R1_NegcRecbvl duplicados ao consultar operação com frações com valores à constituir
RTC 40196 - [R2C3 - RRC0020 - 1.0.53] - Sistema não está retornando o erro ERRC0162 ao enviar msg RRC0020 informando Operação de Gravame informando IndrCancelCessConstitr = S
RTC 40191 - [R2C3 - RRC0020 - 1.0.53] - Sistema não está retornando o erro ERRC0160 ao enviar msg RRC0020 informando IndrCancelVlrTotal = S informando Grupo_RRC0020_RegRecbvl
RTC 40192 - [R2C3 - RRC0020 - 1.0.53] - Sistema não está retornando o erro ERRC0110 ao informar CNPJCreddrSub que não corresponda a uma Credenciadora no Grupo_RRC0020_RegRecbvl
EV545218 - ARRC007_01027058_20200929_00002 menciona que a mensagem RRC0028 foi enviada para o participante porém a mensagem não foi gerada

## 1.0.56

RTC-40201 - [R2C3 - RRC0019 - 1.0.53] - Sistema está retornando o valor null na tag CtPgto quando agenda possui TpCt = PG
EV545751 - Retirado validação de adesão do participante principal
EV522880 - V_RRC016
EV539584 - V_RRC015

## 1.0.55

RTC 40007 - [R2C3 - RRC0013/API - 1.0.50] - Sistema não está retornando o callback /notificacoes-exclusao-anuencia
RTC-39111 - [R2C3 - RRC0008 - 1.0.38] - Sistema está retornando a RRC0008R1 com dados divergentes dos inseridos no filtro de pesquisa da RRC0008

## 1.0.54

RTC-37105 - [R2C3 - RRC0013 - 1.0.23] - Sistema não está retornando o erro ERRC0071 ao enviar msg RRC0013 informando IdentdCtrlOptIn onde possui operações ativas em relação ao CNPJFincdr do OPT-IN
RTC 38007 - [R2C3 - ARRC018 - 1.0.30] - Divergências nas tags do arquivo ARRC018 quando há OPT-IN ativo cadastrado para o Usuário Final e Recebedor e Titular
RTC 40005 - [R2C3 - RRC0013/API - 1.0.50] - Sistema está retornando StatusCode 500 - EGEN0050 ao enviar o campo identdCtrlReqSolicte inválido

## 1.0.53

RTC-39011 - [R2C3 - RRC0010 - 1.0.38] - Sistema está retornado o Grupo_RRC0010_Titlar quando a instituição recebedora do arquivo NÃO tem OPT-IN para o Titular
RTC 39810 - [R2C3 - RRC0025/MQ - 1.0.46]  - Sistema não está atualizando o campo ic_sit na tabela desctc_gar ao enviar com sucesso uma RRC0025
RTC 39007 - Ajuste nos campos da RRC0010 VlrComprtdInst e VlrComprtdOutrInst
RTC 37486 - [R2C3 - RRC0020 - 1.0.27] - Sistema não está retornando o valor da operação que foi cancelada para o nr_vlr_livre_tot na tabela unidd_recbv
RTC 38997 - [R2C3 - RRC0010 - 1.0.38] - Sistema está retornado diversas divergências no retorno da msg RRC0010
RTC 38007 - [R2C3 - ARRC018 - 1.0.30] - Divergências nas tags do arquivo ARRC018 quando há OPT-IN ativo cadastrado para o Usuário Final e Recebedor e Titular

## 1.0.52

RTC-38089 - [R2C3 - ARRC018 - 1.0.31] - Sistema não está gravando registro na tabela resum_movto_dia para o arquivo ARRC018
RTC-38007 - [R2C3 - ARRC018 - 1.0.30] - Divergências nas tags do arquivo ARRC018 quando há OPT-IN ativo cadastrado para o Usuário Final e Recebedor e Titular
RTC-39197 - [R2C3 -/ARRC018 - 1.0.38] - Sistema não está criando o arquivo ARRC018 após deploy da v.1.0.38 e trava a varredura V_ARRC018
RTC 38462 - [R2C3 - RRC0006 - 1.0.33] - Sistema não está alterando na tabela FRACAO_UNIDD_RECBV_OP o campo IC_SIT, ele deve ser atualizado para Cancelado[R2C3 - RRC0006 - 1.0.33] - Sistema não está alterando na tabela FRACAO_UNIDD_RECBV_OP o campo IC_SIT, ele deve ser atualizado para Cancelado[R2C3 - RRC0006 - 1.0.33] - Sistema não está alterando na tabela FRACAO_UNIDD_RECBV_OP o campo IC_SIT, ele deve ser atualizado para Cancelado
RTC 39936 - [R2C3 - RRC0012 - 1.0.48] - Sistema está retornando erro de NullPointer Exception ao enviar IdentdPartAdmtd inexistente

## 1.0.51

EV542622 - ARRC001 da Cielo sem RET

## 1.0.48

RTC-38997 - [R2C3 - RRC0010 - 1.0.38] - Sistema está retornado diversas divergências no retorno da msg RRC0010
- Ajuste na chamada a sequence via ARRC001

## 1.0.47

RTC-37089 - [R2C3 - RRC0003/RRC0019 - 1.0.23] - Divergências na gravação dos registros correspondentes a RRC0003 e RRC0019 na tabela resum_movto_dia
RTC-37486 - [R2C3 - RRC0020 - 1.0.27] - Sistema não está retornando o valor da operação que foi cancelada para o nr_vlr_livre_tot na tabela unidd_recbv
RTC-38889 - [R2C3 - ARRC022 - 1.0.37] - Sistema está retornando erro de Invalid destination [75334], the partyId is not registered ao enviar arquivo ARRC022
- Inclusao de coluna ID_UNIDD_RECBV na UNIDD_RECBV
- Inclusao da varredura V_ROLAGEM
RTC-39627 - [R2C3 - RRC0004/API - 1.0.44] - Sistema está retornando o callback notificacoes-cancelamento-operacao sem 2 campos obrigatórios

## 1.0.46

RTC-37951 - [R2C3 - RRC0019 - 1.0.30] - Sistema não está enviando a msg RRC0028 após envio da RRC0019 com sucesso criando um OPT-IN automático
RTC-38090 - [R2C3 - RRC0028/RRC0029 - 1.0.31] - Tag CPF_CNPJRecbdrOptIn é preenchida com 000000 + ISPB do Participante
RTC-37413 - [R2C3 - RRC0012 - 1.0.26] - Campos nomearquivoentrada e id_op divergentes na gravação da tabela  resum_movto_dia para RRC0012
RTC-39111 - [R2C3 - RRC0008 - 1.0.38] - Sistema está retornando a RRC0008R1 com dados divergentes dos inseridos no filtro de pesquisa da RRC0008
RTC-39194 - [R2C3 - RRC0005 - 1.0.42] - Sistema está retornando erro de NullPointer Exception ao enviar RRC0005 informando ISPBBcoRecbdr inexistente
RTC-38867 - [R2C3 - ARRC022 - 1.0.37] - Sistema está retornando erro de NullPointer Exception ao enviar arquivo ARRC022
- Atualizado para Atlante 5.1.16

## 1.0.45

RTC-39188 - [R2C3 - RRC0012/MQ - 1.0.40] - Sistema está retornando NullPointerException ao não enviar o campo CNPJ_CNPJBase_CPFTitlar no xml
- Ajuste de limitação de registros na consolidação da Agenda pela ARRC001
EV536552 - ARRC001 - Retirado obrigatoriedade de 4 digitos na TAG de Agencia
EV539517 - ERRO VARREDURA V_RRC0015 E V_RRC0016

## 1.0.44

RTC-39007 - [R2C3 - RRC0010 - 1.0.38] - Sistema está retornado diversas divergências no retorno da msg RRC0010 quando a UR possui apenas 1 fração livre
RTC-38997 - [R2C3 - RRC0010 - 1.0.38] - Sistema está retornado diversas divergências no retorno da msg RRC0010
RTC-33227 - [R2C3 - RRC0011 - 1.0.6] - Sistema não retorna msg RRC0011E com o CodErro ERRC0110 ao enviar a tag CNPJCreddrSub com CNPJ que não seja de uma Credenciadora
RTC-37089 - [R2C3 - RRC0003/RRC0019 - 1.0.23] - Divergências na gravação dos registros correspondentes a RRC0003 e RRC0019 na tabela resum_movto_dia
RTC-38686 - [R2C3 - ARRC023/RRC0004 - 1.0.36] - Sistema não está retornando valores nos campos id_op, id_negc_recbv_extn e id_op_cancelt na tabela resum_movto_dia quando o cancelamento é feito pela ARRC023
RTC-39194 - [R2C3 - RRC0005 - 1.0.42] - Sistema está retornando erro de NullPointer Exception ao enviar RRC0005 informando ISPBBcoRecbdr inexistente - Otimização insert em lote da ARRC001
RTC-39190 - [R2C3 - RRC0019/API - 1.0.40] - Sistema está permitindo a criação de uma operação com 0.01 acima do valor livre da agenda, na operação é informado o indrActeIncondlOp = N
RTC-39189 - [R2C3 - Callback API - 1.0.40] - Ao enviar uma requisição de inclusão da operação ou cancelamento da operação, ao dar erro, o sistema não retorna nos Callbacks /retornos o erro ocorrido
RTC-39297 - [R2C3 - RRC0005 - 1.0.42] - Divergências nas frações criadas para a operação na fracao_unidd_recbv_op
RTC-39382 - [R2C3 - RRC0005/API - 1.0.43] - Sistema está retornando situação 'ACEITO' e 'RECUSADO' quando enviado o endpoint credenciadora/operacoes (Gestao Part) com indrActeIncondlOp = N
RTC-38849 - [R2C3 - RRC0006/API - 1.0.37] - Sistema está retornando erro de NullPointer Exception ao enviar requisição PATCH//credenciadora/operacoes/{identd-op}

## 1.0.43

RTC-39191 - [R2C3 - ARRC001 - 1.0.42] - Sistema está retornando erro de NullPointer Exception ao enviar IdentdPartAdmtd inexistente
RTC-38843 - [R2C3 - RRC0011 - 1.0.37] - Sistema está retornando erro ERRC0019 na tag CNPJFincdr mesmo informando um CNPJ válido e cadastrado na base (00000000000191)
RTC-39192 - [R2C3 - RRC0019 - 1.0.42] - Sistema está retornando erro de NullPointer Exception ao enviar RRC0019 sem Ag informada
RTC-39193 - [R2C3 - RRC0019 - 1.0.42] - Sistema está retornando erro de IncorrectResultSizeDataAccessExceptionException ao enviar RRC0019
RTC-39263 - [R2C3 - RRC0005/API - 1.0.42] - Sistema está retornando StatusCode 500 ao não enviar parâmetros opcionais no endpoint /credenciadora/conjuntos-unidades-recebiveis/{identdConjUniddRecbvl}/lotes-unidades-recebiveis
RTC-39196 - [R2C3 - RRC0003/API - 1.0.42] - Sistema está retornando o endpoint POST /notificacoes-alteracao-operacao na inclusão da RRC0019, porém o correto é pelo endpoint POST /notificacoes-inclusao-operacao

## 1.0.42

RTC-38567 - [R2C3 - RRC0003 - 1.0.35] - Divergências no retorno da RRC0003

## 1.0.41

RTC-37473 - [R2C3 - RRC0019 - 1.0.27] - Sistema não está retornando RRC0019R1 com o erro ERRC0060 no Grupo_RRC0019R1_UniddRecbvlDisp ao enviar RRC0019 com IndrActeIncondlOp = N e saldo insuficiente (Gestão do contrato por ER)

## 1.0.40

RTC-38567 - [R2C3 - RRC0003 - 1.0.35] - Divergências no retorno da RRC0003
RTC-38686 - [R2C3 - ARRC023/RRC0004 - 1.0.36] - Sistema não está retornando valores nos campos id_op, id_negc_recbv_extn e id_op_cancelt na tabela resum_movto_dia quando o cancelamento é feito pela ARRC023
RTC-37683 - [R2C3 - RRC0019 - 1.0.28] - Valor da tag CNPJ_CPFTitular no Grupo_RRC0019R1_RegRecbvl da RRC0019R1 não corresponde ao valor enviado na mesma tag na msgs de envio
RTC-38566 - [R2C3 - RRC0019 - 1.0.35] - Divergências no retorno da RRC0019R1
RTC-38600 - [R2C3 - RRC0005 - 1.0.35] - Sistema não está retornando R1 ao enviar arquivo RRC0005
EV533554 - Mapeando codigo de erro do atlante para erro de negócio
RTC-39154 - [R2C3 - RRC0003/API - 1.0.39] - Sistema está retornando apenas o identdOp no retorno do /notificacoes-inclusao-operacao
RTC-39147 - [R2C3 - Callback API - 1.0.38] - Sistema não está retornando 3 parâmetros obrigatórios no jose-header para os callbacks /retornos-registro-operacao e /retornos-cancelamento-operacao
RTC-39119 - [R2C3 - RRC0019/API - 1.0.38] - Sistema está retornando erro de NullPointer Exception ao enviar a requisição /financiadora/operacoes sem os campos indrAlcancContrtoCreddrSub e indrActeUniddRecbvlReserv
RTC-39152 - [R2C3 - RRC0019/API - 1.0.39] - Sistema está retornando erro de NullPointer ao enviar requisição POST /api/financiadora/operacoes com indrActeIncondlOp = N e vlrTotLimOuSldDevdr/vlrGar MAIOR do que o disponivel livre na Agenda

## 1.0.39

RTC-37089 - [R2C3 - RRC0003/RRC0019 - 1.0.23] - Divergências na gravação dos registros correspondentes a RRC0003 e RRC0019 na tabela resum_movto_dia
RTC-39040 - [R2C3 - RRC0003/RRC0009 - 1.0.38] - Sistema está preenchendo nas tags IdentdPartPrincipal e IdentdPartAdmtd o ID_PART do Participante ao invés do ISPB do mesmo nas msgs RRC0003 e RRC0009
EV536557 - Arquivo ARRC007 não sendo enviado via connect

Novas funcionalidades API:
-RRC0004

## 1.0.38

RTC-38090 - [R2C3 - RRC0028/RRC0029 - 1.0.31] - Tag CPF_CNPJRecbdrOptIn é preenchida com 000000 + ISPB do Participante
RTC-38843 - [R2C3 - RRC0011 - 1.0.37] - Sistema está retornando erro ERRC0019 na tag CNPJFincdr mesmo informando um CNPJ válido e cadastrado na base (00000000000191)
RTC-37589 - [R2C3 - ARRC022 - 1.0.27] - Sistema não está retornando o erro ERRC0007 ao informar na tag CNPJCreddrSub o valor 12345678901234 no Grupo_ARRC022_CreddrSub ou Grupo_ARRC022_RegRecbvl
RTC-37704 - [R2C3 - ARRC007 - 1.0.28] - GEN0004 sendo gravada na tabela resum_movto_dia
RTC-37562 - [R2C3 - RRC0010 - 1.0.27] - Sistema retorna msg RRC0010E sem codErro
RTC-38075 - [R2C3 - RRC0010 - 1.0.31] - Sistema não está retornando dados da pesquisa na RRC0010R1
RTC-38453 - [R2C3 - RRC0010 - 1.0.33] - Sistema está obrigando o preenchimento da tag CNPJ_CNPJBase_CPFTitlar no filtro da RRC0010 mesmo com o CNPJ_CNPJBase_CPFUsuFinalRecbdr já informado
RTC-37473 - [R2C3 - RRC0019 - 1.0.27] - Sistema não está retornando RRC0019R1 com o erro ERRC0060 no Grupo_RRC0019R1_UniddRecbvlDisp ao enviar RRC0019 com IndrActeIncondlOp = N e saldo insuficiente (Gestão do contrato por ER)
RTC-38600 - [R2C3 - RRC0005 - 1.0.35] - Sistema não está retornando R1 ao enviar arquivo RRC0005
RTC-38195 - [R2C3 - RRC0019 - 1.0.32] - Sistema está retornando o Grupo_RRC0019R1_Constitr ao enviar uma msg RRC0019 de 500.00 com uma UR de 3000.00 de valor livre. A gestão do contrato é da CIP.
RTC-38428 - [R2C3 - RRC0021 - 1.0.33] - Sistema retorna RRC0021R1 sem dados da operação ao enviar RRC0021 informando somente CNPJ_CNPJBase_CPFTitlar e CNPJ_CNPJBase_CPFUsuFinalRecbdr no filtro
RTC-37325 - [R2C3 - RRC0021/RRC0008 - 1.0.26] - Sistema retorna msg E sem CodErro ao informar CNPJ_CNPJBase_CPFTitlar inexistente no contrato, deveria retornar o erro ERRC0100 na tag CNPJ_CNPJBase_CPFTitlar
RTC-38465 - [R2C3 - RRC0003 - 1.0.33] - Tag Ag é retornada na msg RRC0003 para operação que possui CtPgto informada
RTC-38579 - [R2C3 - RRC0029 - 1.0.35] - Sistema está retornando msgs RRC0029 após cancelamento total de 2 operações pelo ARRC023, porém o opt-in criado para essas 2 operações não é automático
RTC-38575 - [R2C3 - ARRC023 - 1.0.35] - Sistema não está cancelando as frações canceladas para Cancelado na tabela fracao_unidd_recbv_op quando é efetivado um cancelamento total das operações
RTC-38854 - [R2C3 - RRC0025/API - 1.0.37] - Sistema está retornando o erro EGEN0023 ao enviar requisição de /financiadora/operacoes/{identd-op}/recusas-desconstituicao-garantia
RTC-37698 - [R2C3 - RRC0005 - 1.0.28] - Divergências nas tabelas fracao_unidd_recbv_op e unidd_recbv ao enviar RRC0005 de Antecipação que afete uma UR gravamada
RTC-38566 - [R2C3 - RRC0019 - 1.0.35] - Divergências no retorno da RRC0019R1
RTC-38567 - [R2C3 - RRC0003 - 1.0.35] - Divergências no retorno da RRC0003

Novas funcionalidades API:
-RRC0008
-RRC0021

## 1.0.37

RTC-38419 - [R2C3 - RRC0021 - 1.0.33] - Sistema retorna erro de NullPointer Exception ao enviar RRC0021 informando somente IdentdOp no filtro
RTC-38089 - [R2C3 - ARRC018 - 1.0.31] - Sistema não está gravando registro na tabela resum_movto_dia para o arquivo ARRC018
RTC-37486 - [R2C3 - RRC0020 - 1.0.27] - Sistema não está retornando o valor da operação que foi cancelada para o nr_vlr_livre_tot na tabela unidd_recbv
RTC-38007 - [R2C3 - ARRC018 - 1.0.30] - Divergências nas tags do arquivo ARRC018 quando há OPT-IN ativo cadastrado para o Usuário Final e Recebedor e Titular
RTC-38686 - [R2C3 - ARRC023/RRC0004 - 1.0.36] - Sistema não está retornando valores nos campos id_op, id_negc_recbv_extn e id_op_cancelt na tabela resum_movto_dia quando o cancelamento é feito pela ARRC023
RTC-38573 - [R2C3 - RRC0004 - 1.0.35] - Tag IndrCancelVlrTotal é retornada com o valor S na RRC0004, porém no ARRC023  foi informando IndrCancelVlrTotal = N
RTC-38661 - [R2C3 - RRC0005 - 1.0.35] - Sistema retorna erro de NullPointer Exception ao enviar RRC0005 informando IdentdPartAdmtd diferente do registrado na operação
Novas funcionalidades API:
-RRC0006
-RRC0010
-RRC0012
-RRC0014
-RRC0020
-RRC0024
-RRC0025

## 1.0.36

RTC-37683 - [R2C3 - RRC0019 - 1.0.28] - Valor da tag CNPJ_CPFTitular no Grupo_RRC0019R1_RegRecbvl da RRC0019R1 não corresponde ao valor enviado na mesma tag na msgs de envio
RTC-38499 - [R2C3 - RRC0005 - 1.0.33] - Sistema está retornando o R1 apresentando apenas o grupo RRC0005R1
RTC-38579 - [R2C3 - RRC0029 - 1.0.35] - Sistema está retornando msgs RRC0029 após cancelamento total de 2 operações pelo ARRC023, porém o opt-in criado para essas 2 operações não é automático
RTC-37583 - [R2C3 - ARRC022 - 1.0.27] - Sistema não retorna os erros ERRC0136 e ERRC0138
RTC-37486 - [R2C3 - RRC0020 - 1.0.27] - Sistema não está retornando o valor da operação que foi cancelada para o nr_vlr_livre_tot na tabela unidd_recbv

## 1.0.35

RTC-38519 - [R2C3 - RRC0008 - 1.0.33] - Sistema está retornando mensagem no atlante java.lang.NullPointerException
RTC-38453 - [R2C3 - RRC0010 - 1.0.33] - Sistema está obrigando o preenchimento da tag CNPJ_CNPJBase_CPFTitlar no filtro da RRC0010 mesmo com o CNPJ_CNPJBase_CPFUsuFinalRecbdr já informado

## 1.0.34

RTC-37473 - [R2C3 - RRC0019 - 1.0.27] - Sistema não está retornando RRC0019R1 com o erro ERRC0060 no Grupo_RRC0019R1_UniddRecbvlDisp ao enviar RRC0019 com IndrActeIncondlOp = N e saldo insuficiente (Gestão do contrato por ER)
RTC-37901 - [R2C3 - RRC0019 - 1.0.29] - Sistema retorna apenas o Grupo_RRC0019R1_Constitr na RRC0019R1 quando há uma agenda com VlrTot = 3000.00 e incluida uma operação de 3599.00
RTC-37951 - [R2C3 - RRC0019 - 1.0.30] - Sistema não está enviando a msg RRC0028 após envio da RRC0019 com sucesso criando um OPT-IN automático
RTC-37486 - [R2C3 - RRC0020 - 1.0.27] - Sistema não está retornando o valor da operação que foi cancelada para o nr_vlr_livre_tot na tabela unidd_recbv
RTC-38314 - [R2C3 - ARRC023 - 1.0.32] - Sistema está retornando erro de NullPointer Exception ao enviar arquivo ARRC023 cancelando totalmente 2 contratos
RTC-38325 - [R2C3 - RRC0006 - 1.0.32] - Sistema está gravando os campos nomearquivoentrada e nomearquivosaida com valores divergentes na tabela resum_movto_dia
RTC-38089 - [R2C3 - ARRC018 - 1.0.31] - Sistema não está gravando registro na tabela resum_movto_dia para o arquivo ARRC018
RTC-38462 - [R2C3 - RRC0006 - 1.0.33] - Sistema não está alterando na tabela FRACAO_UNIDD_RECBV_OP o campo IC_SIT, ele deve ser atualizado para Cancelado
RTC-38198 - [R2C3 - RRC0019 - 1.0.32] - Sistema está retornando a PriorddNegcRecbvl no Grupo_RRC0019R1_RegRecbvl da RRC0019R1 com o valor 000000002, porém no banco está gravando correto o valor 1 já que é a 1ª fração com valor comprometido
RTC-37282 - [R2C3 - RRC0019 - 1.0.26] - Sistema não está considerando o valor da tag VlrPreContrd na Agenda ao constituir o valor da operação
RTC-38444 - [R2C3 - ARRC023 - 1.0.33] - Valor do campo nr_vlr_tot_comptd não é retornado para o nr_vlr_livre_tot na tabela unidd_recbv após cancelamento parcial da operação que possui apenas 1 titular
RTC-38419 - [R2C3 - RRC0021 - 1.0.33] - Sistema retorna erro de NullPointer Exception ao enviar RRC0021 informando somente IdentdOp no filtro
RTC-38007 - [R2C3 - ARRC018 - 1.0.30] - Divergências nas tags do arquivo ARRC018 quando há OPT-IN ativo cadastrado para o Usuário Final e Recebedor e Titular
RTC-38428 - [R2C3 - RRC0021 - 1.0.33] - Sistema retorna RRC0021R1 sem dados da operação ao enviar RRC0021 informando somente CNPJ_CNPJBase_CPFTitlar e CNPJ_CNPJBase_CPFUsuFinalRecbdr no filtro
RTC-38079 - [R2C3 - RRC0019 - 1.0.31] - Sistema está permitindo criar operação informando IdentdOpOrRenegcDiv inválido, deveria retornar o erro ERRC0055
Subida versão do atlante de 5.1.9 para 5.1.10

## 1.0.33

RTC-38202 - [R2C3 - RRC0019 - 1.0.32] - Sistema está retornando erro de PSQLException ao enviar RRC0019 com IndrAlcancContrtoCreddrSub = G não informando o Grupo_RRC0019_CreddrSub
RTC-37088 - [R2C3 - RRC0003 - 1.0.23] - Divergências na msg RRC0003 enviada após RRC0019 com sucesso
RTC-38075 - [R2C3 - RRC0010 - 1.0.31] - Sistema não está retornando dados da pesquisa na RRC0010R1
RTC-38075 - [R2C3 - RRC0010 - 1.0.31] - Sistema não está retornando dados da pesquisa na RRC0010R1
RTC-37325 - [R2C3 - RRC0021/RRC0008 - 1.0.26] - Sistema retorna msg E sem CodErro ao informar CNPJ_CNPJBase_CPFTitlar inexistente no contrato, deveria retornar o erro ERRC0100 na tag CNPJ_CNPJBase_CPFTitlar
RTC-37348 - [R2C3 - RRC0021 - 1.0.26] - Sistema retorna erro de NullPointer Exception ao enviar RRC0021 onde não há operações para o filtro informado
RTC-37562 - [R2C3 - RRC0010 - 1.0.27] - Sistema retorna msg RRC0010E sem codErro
RTC-38076 - [R2C3 - RRC0010 - 1.0.31] - Sistema não está gravando registro na tabela resum_movto_dia para a msg RRC0010
RTC-37437 - [R2C3 - ARRC001- 1.0.27] - Sistema está retornando erro de NullPointer Exception ao informar IdentdOp inexistente para o Usuário Final Recebedor
RTC-37282 - [R2C3 - RRC0019 - 1.0.26] - Sistema não está considerando o valor da tag VlrPreContrd na Agenda ao constituir o valor da operação
RTC-37214 - [R2C3 - RRC0019 - 1.0.24] - Sistema não está retornando RRC0019R1 com o erro ERRC0060 no Grupo_RRC0019R1_UniddRecbvlDisp ao enviar RRC0019 informando grupo de Gestão Participante com IndrActeIncondlOp = N e VlrPercNegcd > que o Saldo disponivel na UR criada na ARRC001
RTC-38077 - [R2C3 - RRC0019 - 1.0.31] - Sistema está retornando erro de NullPointerException ao informar CNPJCreddrSub inexistente no Grupo_RRC0019_CreddrSub
RTC-38079 - [R2C3 - RRC0019 - 1.0.31] - Sistema está permitindo criar operação informando IdentdOpOrRenegcDiv inválido, deveria retornar o erro ERRC0055
RTC-38195 - [R2C3 - RRC0019 - 1.0.32] - Sistema está retornando o Grupo_RRC0019R1_Constitr ao enviar uma msg RRC0019 de 500.00 com uma UR de 3000.00 de valor livre. A gestão do contrato é da CIP.
RTC-38078 - [R2C3 - RRC0019 - 1.0.31] - Sistema está permitindo criar operação informando IdentdOpOrRenegcDiv cancelado, deveria retornar o erro ERRC0120
RTC-38080 - [R2C3 - RRC0019 - 1.0.31] - Sistema está permitindo criar operação informando IdentdOpOrRenegcDiv que não corresponda a uma renegociação de divida, deveria retornar o erro ERRC0054
RTC-37023 - [R2C3 - RRC0019 - 1.0.21] - Sistema não está criando a fração constituída na tabela fracao_unidd_recbv_op, não atualiza a fração livre e não atualiza os valores na tabela
RTC-37486 - [R2C3 - RRC0020 - 1.0.27] - Sistema não está retornando o valor da operação que foi cancelada para o nr_vlr_livre_tot na tabela unidd_recbv
RTC-38314 - [R2C3 - ARRC023 - 1.0.32] - Sistema está retornando erro de NullPointer Exception ao enviar arquivo ARRC023 cancelando totalmente 2 contratos
RTC-38315 - [R2C3 - ARRC023 - 1.0.32] - Sistema está retornando erro de IllegalArgumentException ao enviar arquivo ARRC023 cancelando parcialmente 2 contratos

## 1.0.32

RTC-37573 - [R2C3 - ARRC022 - 1.0.27] - Sistema não está retornando o codErro ERRC0090 ao alterar Operação informando IndrTpNegc diferente de OG com Vlr_Gar
RTC-37917 - [R2C3 - RRC0006 - 1.0.30] - Sistema apresenta mensagem java.lang.IndexOutOfBoundsException: Index: 0, Size: 0
RTC-38011 - [R2C3 - RRC0006 - 1.0.30] - Sistema retorna erro de NullPointer Exception ao enviar RRC0006
RTC-38007 - [R2C3 - ARRC018 - 1.0.30] - Divergências nas tags do arquivo ARRC018 quando há OPT-IN ativo cadastrado para o Usuário Final e Recebedor e Titular
RTC-37508 - [R2C3 - RRC0019 - 1.0.27] - Sistema está retornando RC0019R1 ao invés de RRC0019E com o erro ERRC0148 ao informar DtPrevtLiquid < DtRef no Grupo_RRC0019_RegRecbvl (Gestão Participante)
RTC-37915 - [R2C3 - RRC0005 - 1.0.29] - Sistema não retorna erro ao inserir validar IndrGestER = S informado o Grupo_RRC0005_GestPart
RTC-38096 - [R2C3 - RRC0019 - 1.0.31] - Sistema está retornando erro de NumberFormatException ao incluir Operação informando TpCt = PG com CtPgto
RTC-38089 - [R2C3 - ARRC018 - 1.0.31] - Sistema não está gravando registro na tabela resum_movto_dia para o arquivo ARRC018
RTC-38077 - [R2C3 - RRC0019 - 1.0.31] - Sistema está retornando erro de NullPointerException ao informar CNPJCreddrSub inexistente no Grupo_RRC0019_CreddrSub
RTC-37486 - [R2C3 - RRC0020 - 1.0.27] - Sistema não está retornando o valor da operação que foi cancelada para o nr_vlr_livre_tot na tabela unidd_recbv
RTC-37698 - [R2C3 - RRC0005 - 1.0.28] - Divergências nas tabelas fracao_unidd_recbv_op e unidd_recbv ao enviar RRC0005 de Antecipação que afete uma UR gravamada
RTC-37214 - [R2C3 - RRC0019 - 1.0.24] - Sistema não está retornando RRC0019R1 com o erro ERRC0060 no Grupo_RRC0019R1_UniddRecbvlDisp ao enviar RRC0019 informando grupo de Gestão Participante com IndrActeIncondlOp = N e VlrPercNegcd > que o Saldo disponivel na UR criada na ARRC001

## 1.0.31

RTC-37702 - [R2C3 - RRC0010 - 1.0.28] - Sistema está retornando erro de NullPointer Exception ao consultar Registro de Recebível com CodInstitdrArrajPgto = BCC
RTC-37413 - [R2C3 - RRC0012 - 1.0.26] - Campos nomearquivoentrada e id_op divergentes na gravação da tabela resum_movto_dia para RRC0012
RTC-37704 - [R2C3 - ARRC007 - 1.0.28] - GEN0004 sendo gravada na tabela resum_movto_dia
RTC-37672 - [R2C3 - RRC0019 - 1.0.28] - Sistema está retornando erro de java.lang.IllegalArgumentException: The partial must not be null
RTC-37573 - [R2C3 - ARRC022 - 1.0.27] - Sistema não está retornando o codErro ERRC0090 ao alterar Operação informando IndrTpNegc diferente de OG com Vlr_Gar
RTC-37575 - [R2C3 - ARRC022 - 1.0.27] - Sistema está permitindo alterar o IndrTpNegc diferente do registrado na operação
RTC-37698 - [R2C3 - RRC0005 - 1.0.28] - Divergências nas tabelas fracao_unidd_recbv_op e unidd_recbv ao enviar RRC0005 de Antecipação que afete uma UR gravamada

## 1.0.30

RTC-37583 - [R2C3 - ARRC022 - 1.0.27] - Sistema não retorna os erros ERRC0136 e ERRC0138
RTC-37817 - [R2C3 - RRC0020 - 1.0.29] - Sistema retorna erro de NullPointer Exception ao enviar cancelamento total da operação
RTC-37747 - [R2C3 - RRC0024 - 1.0.28] - Divergências na gravação da tabela resum_movto_dia para RRC0024
RTC-37711 - [R2C3 - RRC0027 - 1.0.28] - Sistema não está gravando registro na tabela resum_movto_dia para msg RRC0027
RTC-37412 - [R2C3 - RRC0025 - 1.0.26] - Sistema não está retornando dados na tabela resum_movto_dia
RTC-37718 - [R2C3 - ARRC007 - 1.0.28] - Tag NomArqMsgURLOut possui o mesmo valor da tag NomArqMsgURLIn para o registro do arquivo ARRC001
RTC-37712 - [R2C3 - RRC0014 - 1.0.28] - Campo nomearquivoentrada deve ser gravado com valor null na tabela resum_movto_dia para varredura RRC0014
RTC-37413 - [R2C3 - RRC0012 - 1.0.26] - Campos nomearquivoentrada e id_op divergentes na gravação da tabela resum_movto_dia para RRC0012
RTC-37704 - [R2C3 - ARRC007 - 1.0.28] - GEN0004 sendo gravada na tabela resum_movto_dia
RTC-37797 - [R2C3 - ARRC007 - 1.0.29] - Sistema está retornando erro de NullPointer Exception ao disparar a varredura e criar o arquivo para a Credenciadora 10440482
RTC-37417 - [R2C3 - RRC0020 - 1.0.27] - Sistema não está retornando o erro ERRC0100 na RRC0020E informando CNPJ_CNPJBase_CPFTitlar inexistente no contrato e gera msg RRC0020R1

Novas Funcionalidades no canal API:
RRC0013
RRC0029
RRC0015
RRC0016

## 1.0.29

RTC-37747 - [R2C3 - RRC0024 - 1.0.28] - Divergências na gravação da tabela resum_movto_dia para RRC0024
RTC-37711 - [R2C3 - RRC0027 - 1.0.28] - Sistema não está gravando registro na tabela resum_movto_dia para msg RRC0027
RTC-37719 - [R2C3 - RRC0014 - 1.0.28] - Tags com valores divergentes na msg RRC0014
RTC-37712 - [R2C3 - RRC0014 - 1.0.28] - Campo nomearquivoentrada deve ser gravado com valor null na tabela resum_movto_dia para varredura RRC0014
RTC-37718 - [R2C3 - ARRC007 - 1.0.28] - Tag NomArqMsgURLOut possui o mesmo valor da tag NomArqMsgURLIn para o registro do arquivo ARRC001
RTC-37702 - [R2C3 - RRC0010 - 1.0.28] - Sistema está retornando erro de NullPointer Exception ao consultar Registro de Recebível com CodInstitdrArrajPgto = BCC
RTC-37704 - [R2C3 - ARRC007 - 1.0.28] - GEN0004 sendo gravada na tabela resum_movto_dia
RTC-37198 - [R2C3 - RRC0019 - 1.0.24] - Sistema está permitindo alterar o IndrTpNegc diferente do registrado na operação
RTC-37505 - [R2C3 - RRC0019 - 1.0.27] - Sistema está retornando RRC0019R1 ao invés de RRC0019E com o erro ERRC0055 quando enviada msg RRC0019 com IndrIA = A informando IdentdOp inexistente para o CNPJ_CNPJBase_CPFUsuFinalRecbdr
RTC-37671 - [R2C3 - RRC0020 - 1.0.28] - Sistema está retornando o erro de NullPointer Exception ao enviar RRC0020 com CNPJ_CNPJBase_CPFTitlar inexistente no contrato
RTC-37616 - [R2C3 - ARRC023 - 1.0.27] - Sistema está retornando erro de IndexOutOfBoundsException ao enviar ARRC023 informando IdentdOp inexistente para o Usuário Final Recebedor

## 1.0.28

RTC-37562 - [R2C3 - RRC0010 - 1.0.27] - Sistema retorna msg RRC0010E sem codErro
RTC-37560 - [R2C3 - RRC0010 - 1.0.27] - Sistema está retornando erro de NullPointerException ao enviar RRC0010 com todos os filtros corretos para pesquisa da agenda
RTC-37413 - [R2C3 - RRC0012 - 1.0.26] - Campos nomearquivoentrada e id_op divergentes na gravação da tabela resum_movto_dia para RRC0012
RTC-37412 - [R2C3 - RRC0025 - 1.0.26] - Sistema não está retornando dados na tabela resum_movto_dia
RTC-37410 - [R2C3 - RRC0010 - 1.0.26] - Sistema está retornando erro ERRC0099 na tag CNPJ_CNPJBase_CPFTitlar a obrigando a ser informada, porém já que informei a tag CNPJ_CNPJBase_CPFUsuFinalRecbdr não é necessário informar a do titular
RTC-37325 - [R2C3 - RRC0021/RRC0008 - 1.0.26] - Sistema retorna msg E sem CodErro ao informar CNPJ_CNPJBase_CPFTitlar inexistente no contrato, deveria retornar o erro ERRC0100 na tag CNPJ_CNPJBase_CPFTitlar
RTC-37315 - [R2C3 - RRC0012 - 1.0.26] - Gravação do campo nr_cnpj_creddr da tabela desctc_gar divergente
RTC-37311 - [R2C3 - RRC0025 - 1.0.26] - Sistema está retornando o erro ERRC0099 ao invés do ERRC0100 ao enviar msgs RRC0025 informando CNPJ_CNPJBase_CPFTitlar não cadastrado no sistema R2C3
RTC-37003 - [R2C3 - ARRC018 - 1.0.21] - Sistema não está disparando o arquivo da ARRC018
RTC-37578 - [R2C3 - ARRC022 - 1.0.27] - Sistema não retorna o erro ERRC0141 ao enviar ARRC022 com IndrTpNegc = TC e informando VlrPercNegcd > VlrTotLim_SldDevdr no Grupo_ARRC022_RegRecbvl (Gestão Participante)
RTC-37583 - [R2C3 - ARRC022 - 1.0.27] - Sistema não retorna os erros ERRC0136 e ERRC0138
RTC-37348 - [R2C3 - RRC0021 - 1.0.26] - Sistema retorna erro de NullPointer Exception ao enviar RRC0021 onde não há operações para o filtro informado
RTC-37534 - [R2C3 - RRC0019 - 1.0.27] - Sistema está permitindo criar operação informando VlrPercNegcd > VlrTotLim_SldDevdr no Grupo_RRC0019_RegRecbvl (Gestão Participante)
RTC-37473 - [R2C3 - RRC0019 - 1.0.27] - Sistema não está retornando RRC0019R1 com o erro ERRC0060 no Grupo_RRC0019R1_UniddRecbvlDisp ao enviar RRC0019 com IndrActeIncondlOp = N e saldo insuficiente (Gestão do contrato por ER)
RTC-37503 - [R2C3 - RRC0019 - 1.0.27] - Sistema está retornando o erro ERRC0146 na tag IdentdPartAdmtd , para o cenário onde IndrIA = A informando IdentdPartAdmtd diferente do registrado na operação de desconstituição de garantia, deveria retornar na tag IdentdOpDescstcNegcRecbvl
RTC-37414 - [R2C3 - RRC0020 - 1.0.27] - Sistema não está retornando o erro ERRC0123 ao enviar IdentdOp não correspondente ao IdentdNegcRecbvl informado
RTC-37417 - [R2C3 - RRC0020 - 1.0.27] - Sistema não está retornando o erro ERRC0100 na RRC0020E informando CNPJ_CNPJBase_CPFTitlar inexistente no contrato e gera msg RRC0020R1
RTC-37101 - [R2C3 - ARRC007 - 1.0.23] - Divergências no retorno do arquivo ARRC007
RTC-36935 - [R2C3 - RRC0019 - 1.0.20] - Sistema não está gravando registro na tabela opt_in como se fosse um opt-in automático quando o usuário final nao possui opt-in cadastrado
RTC-37089 - [R2C3 - RRC0003/RRC0019 - 1.0.23] - Divergências na gravação dos registros correspondentes a RRC0003 e RRC0019 na tabela resum_movto_dia
RTC-37034 - [R2C3 - RRC0019 - 1.0.21] - Gravação de campos da tabela OP_TITLAR_DOMCL_UNIDD_RECBV divergentes conforme informado na especificação ao criar operação que a Gestão é do Participante (Grupo_RRC0019_GestPart informado)
RTC-37404 - [R2C3 - RRC0005 - 1.0.26] - Sistema não está retornando dados na tabela resum_movto_dia
RTC-37437 - [R2C3 - ARRC001 - 1.0.27] - Sistema está retornando erro de NullPointer Exception ao informar IdentdOp inexistente para o Usuário Final Recebedor
RTC-37314 - [R2C3 - RRC0012/RRC0014 - 1.0.26] - Sistema não está disparando a varredura RRC0014 para a IF que criou a operação de gravame
RTC-37304 - [R2C3 - RRC0005 - 1.0.26] - Sistema retornando codErro diferente do esperado quando DtVencOp < DtRef
RTC-37211 - [R2C3 - RRC0019 - 1.0.24] - Divergências na tag PriorddNegcRecbvl na RRC0019R1 e na prioridade na tabela fracao_unidd_recbv_op
RTC-37220 - [R2C3 - RRC0020 - 1.0.25] - Sistema não está enviando a RRC0004 para Credenciadora após envio com sucesso da RRC0020
RTC-37506 - [R2C3 - RRC0019 - 1.0.27] - Sistema está retornando erro de ArithmeticException ao informar ISPBBcoRecbdr inexistente no Grupo_RRC0019_Titlar (Gestão ER)
RTC-37175 - [R2C3 - RRC0005 - 1.0.24] - Sistema está retornando erro de NullPointer Exception ao enviar RRC0005 informando IndrTpNegc = AN (Antecipação) que afete uma UR que já estava com gravame
RTC-37586 - [R2C3 - ARRC022 - 1.0.27] - Sistema está retornando erro de ArithmeticException ao enviar ARRC022 com IndrIA = A informando IdentdOp inexistente para o CNPJ_CNPJBase_CPFUsuFinalRecbdr, deveria retornar RET recusado com ERRC0055
RTC-37221 - [R2C3 - RRC0020 - 1.0.25] - Sistema não está gravando registro na tabela resum_movto_dia após envio com sucesso da RRC0020
RTC-37224 - [R2C3 - RRC0020 - 1.0.25] - Divergências na tabela op_cancelt após envio de cancelamento com sucesso da RRC0020
RTC-37486 - [R2C3 - RRC0020 - 1.0.27] - Sistema não está retornando o valor da operação que foi cancelada para o nr_vlr_livre_tot na tabela unidd_recbv
RTC-37411 - [R2C3 - RRC0025/RRC0024 - 1.0.26] - Sistema não está disparando a varredura RRC0024 para a Credenciadora que enviou a solicitação de desconstituição de garantia pela RRC0012

- Ajuste dos Layouts dos arquivos RRC0020, RRC0006, RRC0004, ARRC023
- Criação datasource CPC_DS

## 1.0.27

RTC-37175 - [R2C3 - RRC0005 - 1.0.24] - Sistema está retornando erro de NullPointer Exception ao enviar RRC0005 informando IndrTpNegc = AN (Antecipação) que afete uma UR que já estava com gravame
RTC-37214 - [R2C3 - RRC0019 - 1.0.24] - Sistema não está retornando RRC0019R1 com o erro ERRC0060 no Grupo_RRC0019R1_UniddRecbvlDisp ao enviar RRC0019 informando grupo de Gestão Participante com IndrActeIncondlOp = N e VlrPercNegcd > que o Saldo disponivel na UR criada na ARRC001
RTC-37218 - [R2C3 - RRC0019 - 1.0.24] - Sistema está retornando erro de NullPointer Exception ao enviar RRC0019 informando grupo de Gestão ER com IndrActeIncondlOp = N e VlrTotLim_SldDevdr > que o Saldo disponivel na UR criada na ARRC001
RTC-37222 - [R2C3 - RRC0020 - 1.0.25] - Na tabela fracao_unidd_recbv_op sistema está atualizando o campo IC_SIT para 2 após envio da RRC0020 com sucesso, na especificação é informado que deve ser C de Cancelado
RTC-37223 - [R2C3 - RRC0020 - 1.0.25] - Foi enviado um cancelamento parcial de uma operação que possui apenas 1 Titular, sistema deveria cancelar a operação na tabela OP, porém o campo IC_SIT continua = A
RTC-37225 - [R2C3 - RRC0020 - 1.0.25] - Sistema não está retornando o erro ERRC0120 na RRC0020E informando IdentdOp já cancelada
RTC-37226 - [R2C3 - RRC0020 - 1.0.25] - Sistema está retornando erro de NullPointer Exception ao enviar RRC0020 informando cancelamento total
RTC-37088 - [R2C3 - RRC0003 - 1.0.23] - Divergências na msg RRC0003 enviada após RRC0019 com sucesso
EV523841 - Correção de NPE ao executar comando output-gen0001

## 1.0.26

RTC-36625 - [R2C3 - ARRC001 - 1.0.17] - Sistema está gravando o valor NULL no campo nm_arq_nuop_api na tabela unidd_recbv
RTC-36624 - [R2C3 - ARRC001 - 1.0.17] - Sistema está gravando o valor NULL no campo nm_arq_nuop_api na tabela fracao_unidd_recbv_op
RTC-36611 - [R2C3 - ARRC001 - 1.0.17] - Campo nr_vlr_tot_comptd é preenchido quando enviado arquivo ARRC001 com VlrEftLiquid sem informar IdentdOp
RTC-36110 - [R2C3 - ARRC001 - 1.0.15] - Gravação de campos da tabela unidd_recbv divergentes conforme informado na especificação

## 1.0.25

RTC-36935 - [R2C3 - RRC0019 - 1.0.20] - Sistema não está gravando registro na tabela opt_in como se fosse um opt-in automático quando o usuário final nao possui opt-in cadastrado
RTC-36070 - [R2C3 - RRC0010 - 1.0.15] - Sistema está retornando erro de NullPointerException ao informar filtro que não retorne URs na RRC0010R1
RTC-37047 - [R2C3 - RRC0020 - 1.0.21] - Sistema está retornando erro de IndexOutOfBoundsException ao enviar RRC0020 informando cancelamento parcial
RTC-36936 - [R2C3 - RRC0019 - 1.0.20] - Gravação de campos da tabela OP divergentes conforme informado na especificação
RTC-37175 - [R2C3 - RRC0005 - 1.0.24] - Sistema está retornando erro de NullPointer Exception ao enviar RRC0005 informando IndrTpNegc = AN (Antecipação) que afete uma UR que já estava com gravame
RTC-36938 - [R2C3 - RRC0019 - 1.0.20] - Gravação de campos da tabela OP_TITLAR_CREDDR divergentes conforme informado na especificação
RTC-36939 - [R2C3 - RRC0019 - 1.0.20] - Gravação de campos da tabela OP_TITLAR_DOMCL_USU_FINL_RECBDR divergentes conforme informado na especificação
RTC-37033 - [R2C3 - RRC0019 - 1.0.21] - Gravação de campos da tabela OP_TITLAR_DOMCL divergentes conforme informado na especificação ao criar operação que a Gestão é do Participante (Grupo_RRC0019_GestPart informado)
RTC-36937 - [R2C3 - RRC0019 - 1.0.20] - Gravação de campos da tabela OP_TITLAR_DOMCL divergentes conforme informado na especificação
RTC-37034 - [R2C3 - RRC0019 - 1.0.21] - Gravação de campos da tabela OP_TITLAR_DOMCL_UNIDD_RECBV divergentes conforme informado na especificação ao criar operação que a Gestão é do Participante (Grupo_RRC0019_GestPart informado)
RTC-37058 - [R2C3 - ARRC001 - 1.0.23] - Sistema retornou erro de NullPointerException ao enviar ARRC001 informando IdentdOp

## 1.0.24

RTC-37021 - [R2C3 - RRC0019 - 1.0.21] - Sistema está retornando RRC0019R1 com SitRetReq = 002 e não grava registro nas tabelas de operação
RTC-36871 - [R2C3 - RRC0019 - 1.0.19] - Sistema está retornando o erro ERRC0141 ao invés do ERRC0146 ao enviar IndrIA = A informando IdentdPartAdmtd  do registrado na operação
RTC-37003 - [R2C3 - ARRC018 - 1.0.21] - Sistema não está disparando o arquivo da ARRC018
RTC-37089 - [R2C3 - RRC0003/RRC0019 - 1.0.23] - Divergências na gravação dos registros correspondentes a RRC0003 e RRC0019 na tabela resum_movto_dia : OBS : Falta o campo id_opt_in deve ser preenchido com o id_opt_in automático
RTC-37088 - [R2C3 - RRC0003 - 1.0.23] - Divergências na msg RRC0003 enviada após RRC0019 com sucesso

## 1.0.23

RTC-37021 - [R2C3 - RRC0019 - 1.0.21] - Sistema está retornando RRC0019R1 com SitRetReq = 002 e não grava registro nas tabelas de operação
RTC-36917 - [R2C3 - RRC0019 - 1.0.20] - Sistema está gerando msg RRC0019R1 ao enviar msg RRC0019 informando IndrIA = I informando IdentdOp e não retorna RRC0019E com o erro ERRC0132
RTC-36918 - [R2C3 - RRC0019 - 1.0.20] - Sistema está gerando msg RRC0019R1 ao enviar msg RRC0019 informando IndrActeUniddRecbvlReserv = S e não retorna RRC0019E com o erro ERRC0052
RTC-36025 - [R2C3 - ARRC001 - 1.0.15] - Sistema não gravou registro na tabela resum_movto_dia ao enviar arquivo ARRC001 com sucesso

## 1.0.21

RTC-36110 - [R2C3 - ARRC001 - 1.0.15] - Gravação de campos da tabela unidd_recbv divergentes conforme informado na especificação
RTC-36919 - [R2C3 - RRC0019 - 1.0.20] - Sistema está gerando msg RRC0019R1 ao enviar msg RRC0019 informando Vlr_Gar > VlrTotLim_SldDevdr e não retorna RRC0019E com o erro ERRC0063
RTC-36649 - [R2C3 - RRC0019 - 1.0.18] - Sistema está retornando erro de org.postgresql.util.PSQLException: ERROR: invalid byte sequence for encoding "UTF8": 0x00
RTC-36905 - [R2C3 - RRC0019 - 1.0.20] - Sistema está retornando erro de NullPointer Exception ao enviar msg RRC0019 informando o grupo de Gestão Participante para IndrTpNegc  = TC
RTC-36871 - [R2C3 - RRC0019 - 1.0.19] - Sistema está retornando o erro ERRC0141 ao invés do ERRC0146 ao enviar IndrIA = A informando IdentdPartAdmtd  do registrado na operação
RTC-36804 - [R2C3 - ARRC022 - 1.0.19] - Sistema não está retornando os erros ERRC0140 e ERRC0141 na tag VlrPercNegcd conforme especificação
RTC-36920 - [R2C3 - RRC0019 - 1.0.20] - Sistema está gerando msg RRC0019R1 ao enviar msg RRC0019 informando DtIniOp ou DtFimOp < DtRef no Grupo_RRC0019_Titlar e não retorna RRC0019E com o erro ERRC0101 e ERRC0103
RTC-36754 - [R2C3 - RRC0005 - 1.0.19] - Sistema está retornando uma msg RRC0005R1 com SitRetReq = 002 sem IdentdOp e não grava registro nas tabelas de operação
RTC-36311 - [R2C3 - RRC0005 - 1.0.16] - Sistema está retornando erro relation "seq_id_op" does not exist ao enviar RRC0005 em determinados cenários
Novas Funcionalidades:
RRC0008
RRC0021

## 1.0.20

RTC-36025 - [R2C3 - ARRC001 - 1.0.15] - Sistema não gravou registro na tabela resum_movto_dia ao enviar arquivo ARRC001 com sucesso
RTC-36034 - [R2C3 - RRC0015/RRC0016 - 1.0.15] - Sistema está retornando 2 erros ao enviar varredura RRC0015 ou RRC0016 (ERRC9999 - Erro inesperado e NullPointerException)
RTC-36195 - [R2C3 - RRC0010 - 1.0.16] - Sistema não retorna o erro ERRC0144 ao enviar msg RRC0010 não informando CNPJ_CNPJBase_CPFUsuFinalRecbdr e CNPJ_CNPJBase_CPFTitlar
RTC-36312 - [R2C3 - RRC0013/RRC0029 - 1.0.16] - Sistema não gravou registro na tabela resum_movto_dia ao enviar msg RRRC0013 e RRC0029 com sucesso
RTC-36611 - [R2C3 - ARRC001 - 1.0.17] - Campo nr_vlr_tot_comptd é preenchido quando enviado arquivo ARRC001 com VlrEftLiquid sem informar IdentdOp
RTC-36282 - [R2C3 - RRC0011/RRC0028 - 1.0.16] - Dados divergentes na gravação da tabela resum_movto_dia para as msgs RRC0011 e RRC0028
RTC-35181 - [R2C3 - ARRC001 - 1.0.13] - Sistema está retornando erro de NumberFormatException ao enviar CtPgto com 20 posições
RTC-36649 - [R2C3 - RRC0019 - 1.0.18] - Sistema está retornando erro de org.postgresql.util.PSQLException: ERROR: invalid byte sequence for encoding "UTF8": 0x00
RTC-36452 - [R2C3 - RRC0019 - 1.0.17] - Sistema está retornando msg RRC0019E sem cod ERRC00XX ao validar a regras ERRC0140 e ERRC0141 informando mais de um Grupo_RRC0019_RegRecbvl
RTC-36458 - [R2C3 - RRC0019 - 1.0.17] - Sistema está retornando msg GEN0004 com o erro EGEN0043 ao enviar msg RRC0019 com TpCt = PG informando Ct no Grupo_RRC0019_Titlar (Gestão ER)
RTC-36697 - [R2C3 - ARRC022 - 1.0.18] - Sistema não retorna o erro ERRC0015 ao enviar arquivo ARRC022 informando IdentdPartAdmtd sem adesão a funcionalidade
RTC-36805 - [R2C3 - RRC0027 - 1.0.19] - Sistema está retornando erro de NullPointer Exception ao enviar msg RRC0027 sem informar DescContstc
RTC-36804 - [R2C3 - ARRC022 - 1.0.19] - Sistema não está retornando os erros ERRC0140 e ERRC0141 na tag VlrPercNegcd conforme especificação

## 1.0.19

RTC-36694 - [R2C3 - ARRC001 - 1.0.18] - Sistema não está gravando registros ns tabelas fracao_unidd_recbv_op e unidd_recbv após deploy da v.1.0.18

## 1.0.18

RTC-36110 - [R2C3 - ARRC001 - 1.0.15] - Gravação de campos da tabela unidd_recbv divergentes conforme informado na especificação
RTC-36109 - [R2C3 - ARRC001 - 1.0.15] - Gravação de campos da tabela fracao_unidd_recbv_op divergentes conforme informado na especificação
RTC-36441 - [R2C3 - RRC0019 - 1.0.17] - Sistema está retornando erro de NullPointer Exception ao enviar RRC0019 em determinados cenários
RTC-36432 - [R2C3 - RRC0019 - 1.0.17] - Sistema está retornando erro de NullPointerException ao enviar msg RRC0019 informando IndrTpNegc = OG sem Vlr_Gar
RTC-36268 - [R2C3 - ARRC022 - 1.0.16] - Sistema está retornando erro de NullPointerException gerando somente arquivo ARRC02PRO ao enviar arquivo ARRC022 informando IdentdPartPrincipal inexistente
RTC-36440 - [R2C3 - RRC0019 - 1.0.17] - Sistema está retornando erro relation "seq_id_op" does not exist ao enviar RRC0019 em determinados cenários
RTC-36452 - [R2C3 - RRC0019 - 1.0.17] - Sistema está retornando msg RRC0019E sem cod ERRC00XX ao validar a regras ERRC0140 e ERRC0141 informando mais de um Grupo_RRC0019_RegRecbvl
RTC-36445 - [R2C3 - RRC0019 - 1.0.17] - Sistema está retornando msg RRC0019E sem CodErro ao validar os erros ERRC0135, ERRC0136, ERRC0137 e ERRC0138
RTC-36437 - [R2C3 - RRC0019 - 1.0.17] - Sistema não está retornando erro ERRC0034 ao enviar RRC0019 com Vlr_Gar inválido (500 sem casas decimais)
RTC-36448 - [R2C3 - RRC0019 - 1.0.17] - Sistema está retornando msg GEN0004 com o erro EGEN0043 ao enviar msg RRC0019 com TpCt = PG informando Ct no Grupo_RRC0019_Titlar (Gestão ER)
RTC-36438 - [R2C3 - RRC0019 - 1.0.17] - Sistema está retornando msg GEN0004 com o erro EGEN0043 ao enviar msg RRC0019 com IndrAlcancContrtoCreddrSub = E não informando o Grupo_RRC0019_CreddrSub
RTC-36436 - [R2C3 - RRC0019 - 1.0.17] - Sistema não está retornando erro ERRC0147 ao enviar RRC0019 com DtVencOp < DtRef

## 1.0.17

RTC-36203 - [R2C3 - RRC0010 - 1.0.16] - Sistema está retornando msg GEN0004 com o erro EGEN0043 ao informar CNPJ_CNPJBase_CPFTitlar = CNPJ Base
RTC-36201 - [R2C3 - RRC0010 - 1.0.16] - Sistema está retornando erro de NullPointerException ao informar CNPJ_CNPJBase_CPFUsuFinalRecbdr = CNPJ Base não informando CodInstitdrArrajPgto e CNPJCreddrSub
RTC-36195 - [R2C3 - RRC0010 - 1.0.16] - Sistema não retorna o erro ERRC0144 ao enviar msg RRC0010 não informando CNPJ_CNPJBase_CPFUsuFinalRecbdr e CNPJ_CNPJBase_CPFTitlar
RTC-36070 - [R2C3 - RRC0010 - 1.0.15] - Sistema está retornando erro de NullPointerException ao informar filtro que não retorne URs na RRC0010R1
RTC-36037 - [R2C3 - V_ARRC007 - 1.0.15] - Sistema não está processando varredura V_ARRC007
RTC-36036 - [R2C3 - RRC0019 - 1.0.15] - Sistema está retornando erro de NullPointerException ao enviar msg RRC0019 incluindo Operação informando IndrRegrDivs = P, IndrTpNegc = OG e IndrActeIncondlOp = S (Com saldo suficiente) (Gestão ER)
RTC-36107 - [R2C3 - RRC0019 - 1.0.15] - Sistema está retornando erro de NullPointerException ao enviar msg RRC0019 sem informar o grupo Grupo_RRC0019_GestER ou Grupo_RRC0019_GestPart
RTC-36268 - [R2C3 - ARRC022 - 1.0.16] - Sistema está retornando erro de NullPointerException gerando somente arquivo ARRC02PRO ao enviar arquivo ARRC022 informando IdentdPartPrincipal inexistente
RTC-36271 - [R2C3 - ARRC022 - 1.0.16] - Tag IdentdOpDescstcNegcRecbvl está como obrigatória no arquivo ARRC022, caso não seja enviada é retornado erro de XML Schema validation error
RTC-36023 - [R2C3 - ARRC001 - 1.0.15] - Sistema retornou RET recusado com o erro ERRC0011 ao informar a tag Ag com o valor 0235 (começando com zeros)
RTC-36054 - [R2C3 - ARRC001 - 1.0.15] - Sistema está gravando na tag SitRetReq no ARRC001RET o valor 003 que é Aceito Parcialmente, porém a ARC001 foi aceita com sucesso sem registros pendentes, onde deveria gravar 001 de Aceito
RTC-36223 - [R2C3 - ARRC001 - 1.0.16] - Sistema não retorna arquivos RET e PRO ao enviar ARRC001 informando Unidade de Recebível já existente na base de dados
RTC-36260 - [R2C3 - ARRC001- 1.0.16] - Sistema esta retornando erro de br.org.cipbancos.atlante.protocol.DataException ao enviar ARRC001, não gera RET porém grava registro na tabela de STAGE
RTC-33944 - [R2C3 - RRC0015/RRC0016 - 1.0.8] - Sistema está retornando DtHrAbert e DtHrFcht com data errada, deve retornar a data/hora do servidor

Novas funcionalidades:
RRC0011 via canal API

## 1.0.16

RTC-36036 - [R2C3 - RRC0019 - 1.0.15] - Sistema está retornando erro de NullPointerException ao enviar msg RRC0019 incluindo Operação informando IndrRegrDivs = P, IndrTpNegc = OG e IndrActeIncondlOp = S (Com saldo suficiente) (Gestão ER)
RTC-36107 - [R2C3 - RRC0019 - 1.0.15] - Sistema está retornando erro de NullPointerException ao enviar msg RRC0019 sem informar o grupo Grupo_RRC0019_GestER ou Grupo_RRC0019_GestPart
RTC-35181 - [R2C3 - ARRC001- 1.0.13] - Sistema está retornando erro de NumberFormatException ao enviar CtPgto com 20 posições
RTC-35169 - [R2C3 - ARRC001- 1.0.13] - Sistema não está gerando arquivo ARRC001RET quando informado Tag AG Inválida
RTC-36040 - [R2C3 - RRC0010 - 1.0.15] - Sistema está retornando erro de NullPointerException, não gera um retorno e causa lentidão no Atlante Viewer ao enviar msg RRC0010 informando CNPJ_CNPJBase_CPFUsuFinalRecbdr e CNPJ_CNPJBase_CPFTitlar não informados
RTC-35171 - [R2C3 - ARRC001- 1.0.13] - Sistema não está gerando arquivo ARRC001RET quando Grupo_ARRC001_UniddRecbvl não informado
RTC-36070 - [R2C3 - RRC0010 - 1.0.15] - Sistema está retornando erro de NullPointerException ao informar filtro que não retorne URs na RRC0010R1
RTC-36068 - [R2C3 - RRC0010 - 1.0.15] - Sistema está retornando msg RRC0010E sem CodErro ao informar VlrLivre inválido (1000 sem decimais)

## 1.0.15

RTC-35114 - [R2C3 - ARRC001 - 1.0.13] - Sistema retorna erro de PSQLException ao enviar arquivo ARRC001
RTC-34062 - [R2C3 - ARRC007 - 1.0.8 ] - Sistema não gera o arquivo ARRC007 após execução da varredura V_ARRC007. Tabela resum_movto_dia não está sendo populada com os arquivos do dia
RTC-35388 - [R2C3 - ARRC023 - 1.0.14] - Sistema não retorna o erro ERRC0018 ao enviar IdentdPartAdmtd não administrado pelo IdentdPartPrincipal
RTC-35386 - [R2C3 - ARRC023 - 1.0.14] - Sistema não retorna o erro ERRC0030 ao enviar IdentdPartPrincipal inexistente
RTC-35380 - [R2C3 - ARRC023 - 1.0.14] - Sistema não retorna o erro ERRC0127 ao enviar IndrCancelVlrTotal = N não informando CNPJ_CNPJBase_CPFTitlar
RTC-35387 - [R2C3 - ARRC023 - 1.0.14] - Sistema não retorna o erro ERRC0031 ao enviar IdentdPartAdmtd inexistente
RTC-35382 - [R2C3 - ARRC023 - 1.0.14] - Sistema não retorna o erro ERRC0015 ao enviar arquivo informando IdentdPartAdmtd sem adesão a funcionalidade ARRC023
Novas Funcionalidades:
RRC0010
RRC0005
RRC0019
ARRC022

## 1.0.14

RTC-33228 - [R2C3 - RRC0011 - 1.0.13] - Sistema não retorna msg RRC0011E com o CodErro ERRC0109 ao enviar a tag CNPJFincdr com CNPJ que não seja de uma IF	Ajuda
RTC-35134 - [R2C3 - ARRC001 - 1.0.13] - Sistema não retorna o CodErro ERRC0001 ao enviar a tag  VlrEftLiquid < 0
RTC-35149 - [R2C3 - ARRC001 - 1.0.13] - Sistema retorna erro de NumberFormatException ao informar CtPgto com letras para retornar o erro ERRC0012
RTC-35180 - [R2C3 - ARRC001 - 1.0.13] - Sistema está retornando erro de NullPointer Exception ao enviar arquivo ARRC001
RTC-35181 - [R2C3 - ARRC001 - 1.0.13] - Sistema está retornando erro de NumberFormatException ao enviar CtPgto com 20 posições
RTC-35128 - [R2C3 - ARRC001 - 1.0.13] - Sistema não retorna arquivo ARRC001ERR com erro EGEN0043 ao informar TpCt com espaços em branco e sim um RET recusado com o erro ERRC0010
RTC-35146 - [R2C3 - ARRC001 - 1.0.13] - Sistema não retorna arquivo ARRC001RET com o codErro ERRC0012 ao informar a tag Ct inválida
RTC-34997 - [R2C3 - ARRC023 - 1.0.13] - Sistema não está gerando arquivo ARRC023RET e retorna erro de NullPointerException no Atlante no registro do arquivo de envio

## 1.0.13

RTC-34548 - [R2C3 - RRC0027 - 1.0.10] - Sistema retornou msg RRC0027E sem CodErro ao alterar Contestação de Opt-in informando IdentdOpContstc
Novas Funcionalidades:
ARRC001
ARRC018
Consolidação da Agenda
RRC0003
RRC0009

## 1.0.11

RTC-34409 - [R2C3 - RRC0027 - 1.0.10] - Sistema está gravando no campo nr_cnpj_regr da tabela contc o valor 4391007000132
RTC-34062 - [R2C3 - ARRC007 - 1.0.8] - Sistema não gera o arquivo ARRC007 após execução da varredura V_ARRC007. Tabela resum_movto_dia não está sendo populada com os arquivos do dia

## 1.0.10

RTC-33953 - [R2C3 - RRC0027 - 1.0.8] - Sistema não retorna CodErro ao enviar msg RRC0027 não informando as tags  IdentdOpContstc, IdentdCtrlOptIn e IdentdOp
RTC-34023 - [R2C3 - RRC0020 - 1.0.8] - Sistema retorna msg GEN0004 ao enviar RRC0020 com a tag IndrCancelVlrTotal fora do domínio
RTC-34024 - [R2C3 - RRC0020 - 1.0.8] - Sistema retorna msg GEN0004 ao enviar RRC0020 com a tag IndrLiquidOp fora do domínio
RTC-34030 - [R2C3 - RRC0020 - 1.0.8] - É retornado erro de NullPointer Exception ao enviar msg RRC0020 com IndrCancelVlrTotal = N não informando CNPJ_CNPJBase_CPFTitlar
RTC-34129 - [R2C3 - RRC0006 - 1.0.9] - Sistema apresenta texto no lugar do CodErro
RTC-34258 - [R2C3 - RRC0027 - 1.0.9] - Sistema retornou erro de EGEN0061 (Invalid character) ao informar a tag DescContstc com 771 caracteres

## 1.0.9

RTC-33941 - [R2C3 - RRC0027 - 1.0.8] - Sistema retorna erro ERRC0055 ao informar a tag IdentdCtrlOptIn com valor inexistente na base, deveria retornar o erro ERRC0058.
RTC-33943 - [R2C3 - RRC0027 - 1.0.8] - Sistema retorna erro ERRC0117 ao informar a tag IdentdOp com valor inexistente na base, deveria retornar o erro ERRC0055.
RTC-33928 - [R2C3 - RRC0027 - 1.0.8] - Sistema retorna erro EGEN0043 em uma GEN0004 ao enviar a tag IndrMotvContstc fora do domínio.
RTC-34030 - [R2C3 - RRC0020 - 1.0.8] - É retornado erro de NullPointer Exception ao enviar msg RRC0020 com IndrCancelVlrTotal = N não informando CNPJ_CNPJBase_CPFTitlar
RTC-34027 - [R2C3 - RRC0020 - 1.0.8] - Não é retornado o CodErro ERRC0124 ao enviar msg RRC0020 com IndrCancelVlrTotal = S informando CNPJ_CNPJBase_CPFTitlar
RTC-34023 - [R2C3 - RRC0020 - 1.0.8] - Sistema retorna msg GEN0004 ao enviar RRC0020 com a tag IndrCancelVlrTotal fora do domínio
RTC-34024 - [R2C3 - RRC0020 - 1.0.8] - Sistema retorna msg GEN0004 ao enviar RRC0020 com a tag IndrLiquidOp fora do domínio
RTC-34062 - [R2C3 - ARRC007 - 1.0.8] - Sistema não gera o arquivo ARRC007 após execução da varredura V_ARRC007. Tabela resum_movto_dia não está sendo populada com os arquivos do dia

## 1.0.8

Novas Funcionalidades:
RRC0004
RRC0006
RRC0020
ARRC023
RRC0027
ARRC007

## 1.0.7

RTC-33277 - [R2C3 - RRC0012 - 1.0.6] - Sistema não retorna CodErro na msg RRC0012E ao enviar msg RRC0012 sem a tag IdentdOp informada
RTC-33278 - [R2C3 - RRC0012 - 1.0.6] - Sistema não retorna CodErro ERRC0030 na msg RRC0012E ao enviar msg RRC0012 com IdentdPartPrincipal inexistente
RTC-33279 - [R2C3 - RRC0012 - 1.0.6] - Sistema não retorna CodErro ERRC0031 na msg RRC0012E ao enviar msg RRC0012 com IdentdPartAdmtd inexistente
RTC-33327 - [R2C3 - RRC0012 - 1.0.6] - Ao enviar msg RRC0012 com IdentdOp com espaços em branco é retornada msg RRC0012E com o erro ERRC0055
RTC-33328 - [R2C3 - RRC0011 e 0012 - 1.0.6] - Ao enviar msg RRC0011 ou RRC0012 informando CodInstitdrArrajPgto com espaços em branco é retornada msg E com o erro ERRC0002
RTC-33322 - [R2C3 - RRC0025 - 1.0.6] - Ao enviar msg RRC0025 com SitPedDescstcNegcRecbvl fora do domínio é retornada msg GEN0004
RTC-33226 - [R2C3 - RRC0011 - 1.0.6] - Sistema retorna GEN0004 com o erro EGEN0043 ao informar IndrDomcl fora do domínio
RTC-33321 - [R2C3 - RRC0025 - 1.0.6] - Ao enviar msg RRC0025 sistema retorna erro no Atlante org.postgresql.util.PSQLException: ERROR: operator does not exist: bigint = character varying
RTC-33333 - [R2C3 - RRC0013/RRC0029 - 1.0.6] - Tag DtFimOptIn da RRC0029 não é retornada com a data que foi realizado o Opt-Out e o campo dt_fim_opt_in não é atualizado na tabela opt_in

## 1.0.6

Ajustes OPT-IN/OPT-OUT
Alteração dos layouts RRC0011R2 e RRC0013R2 para RRC0028 e RRC0029 respectivamente
Novas Funcionalidades:
RRC0012
RRC0014
RRC0024
RRC0025

## 1.0.5

RTC-30969 - [R2C3 - RRC0015 - 1.0.4] - Sistema retorna msg de erro "RejectedInputException: Erro inesperado" ao enviar varredura V_RRC0015
RTC-31035 - [R2C3 - RRC0020 - 1.0.4] - Sistema está retornando erro na estrutura do xsd ao enviar mensagem RRC0020
RTC-31122 - [R2C3 - RRC0011 - 1.0.4] - Sistema retorna R1 aceita ao enviar IdentdPartAdmtd não administrado pelo IdentdPartPrincipal
RTC-31226 - [R2C3 - ARRC023 - 1.0.4] - É apresentado msg de erro ao injetar arquivo ARRC023
RTC-31128 - [R2C3 - RRC0011R2/RRC0013R2 - 1.0.4] - É enviado os grupos Grupo_RRC0012R2_AutcEnvAgenda e Grupo_RRC0014R2_CanceltAutcEnvAgenda nas varreduras RRC0011R2 e RRC0013R2
Novas Funcionalidades:
RRC0003
RRC0005
RRC0019
ARRC022

## 1.0.4

RRC0006
RRC0020
ARRC023
Validações de Grade Horária/Adesão

## 1.0.3

Correção do instalador do R2C3

## 1.0.2

RTC-30384 - [R2C3 - RRC0011 - 1.0.1] - Sistema retorna R1 aceita ao enviar DtIniOptIn = DtFimOptIn
RTC-30269 - [R2C3 - RRC0015 - 1.0.1] - Sistema retorna msg de erro ERROR: relation "param_sist" does not exist ao enviar varredura V_RRC0015
RTC-30508 - [R2C3 - RRC0011 - 1.0.1] - Sistema retorna R1 aceita ao enviar msg RRC0011 informando a tag IdentdCtrlReqSolicte com espaços em branco
RTC-30428 - [R2C3 - RRC0013 - 1.0.1] - Sistema retorna R1 aceita e R2 ao enviar msg RRC0013 informando IdentdCtrlOptIn que já sofreu OPT-OUT
RTC-30374 - [R2C3 - RRC0016 - 1.0.1] - Sistema retorna msg RRC0016 com formato diferente do layout
RTC-30475 - [R2C3 - RRC0013 - 1.0.1] - Sistema retorna R1 ao enviar msg RRC0013 informando as tags IdentdCtrlReqSolicte ou IdentdCtrlOptIn com espaços em branco
RTC-30482 - [R2C3 - RRC0013 - 1.0.1] - Sistema retorna R1 aceita ao enviar IdentdPartPrincipal ou IdentdPartAdmtd inexistente
RTC-30394 - [R2C3 - RRC0011 - 1.0.1] - Sistema retorna R1 aceita ao enviar IdentdPartAdmtd inexistente
RTC-30324 - [R2C3 - ARRC001 - 1.0.1] - Sistema retorna erro de NullPointer ao enviar arquivo ARRC001
Alterações nos layouts OPT_IN e OPT_OUT

## 1.0.1

RTC - 30100 [R2C3 - RRC0011 - 1.0.0] - Sistema retorna RRC0011R1 recusada porém não exibe qual CodErro quando enviada msg com DtIniOptIn > DtFimOptIn
RTC - 30102 [R2C3 - RRC0011 - 1.0.0] - Sistema retorna msg GEN00004 e exibe o erro XML Schema validation error na tag IdentdCtrlReqSolicte ao enviar a mesma com 20 caracteres

## 1.0.0

ARRC001 – Inclusão de Agenda
RRC0011 – OPT_IN
RRC0013 – OPT_OUT

## 0.0.1

- Versao inicial
