#!/bin/bash -E

trap on_error ERR

function on_error() {
    local exit_status=${1:-$?}
    echo "***********"
    echo "   ERROR   "
    echo "***********"
    echo Exiting $0 with $exit_status
    exit $exit_status
}

copy_dependency(){
    dir=$1
    filename=$2

    for f in `find $dir -name $filename`
    do
        cp $f $protocolDir
    done
}

check_argument()
{
    if [[ $# != 1 ]]
    then
        echo 'Invalid number of arguments in function call!'
        exit 1
    fi
}

check_option()
{
    if [[ -z $2 || `echo $2 | grep '\--'` ]]
    then
        echo 'Invalid value for option '$1': '$2
        usage
        exit 1
    fi
}

clean_svn()
{
    check_argument "$*"
    for svn in `find "$1" -name '.svn' -type d`
    do
        rm -fr "${svn}"
    done
}

create_tar()
{
    check_argument "$*"

    archiveName=$1-${release}'.tar.gz'
    createdArchives=(${createdArchives[@]} ${archiveName})

    cd ${tmpDir}/r2c3
    tar -czf ../${archiveName} .
    cd ${baseDir}
}

usage()
{
    echo
    echo 'Usage: '$0' [options]'
    echo
    echo 'Options:'
    echo -e '--release [name]\tRelease name'
    echo -e '--run-tests\t\tRun mvn test'
    echo -e '--skip-dependencies\tDoes not call mvn to resolve tools dependencies'
    echo -e '--skip-install\t\tDoes not call mvn clean install'
    echo -e '--skip-packaging\tDoes not create distribution tar.gz'
    echo -e '--skip-site\t\tDoes not call mvn site'
    echo
}

# build options
release=''
runTests=''
skipDependencies=''
skipInstall=''
skipPackaging=''
skipSite=''
while [ $# -gt 0 ]
do
    case $1 in
    '--release')
        shift
        check_option '--release' $1
        release=$1
        ;;
    '--run-tests')
        runTests='true'
        ;;
    '--skip-install')
        skipInstall='true'
        ;;
    '--skip-packaging')
        skipPackaging='true'
        ;;
    '-h')
        usage
        exit 0
        ;;
    '--help')
        usage
        exit 0
        ;;
    *)
        echo 'Invalid option: '$1
        usage
        exit 1
        ;;
    esac
    shift
done

if [[ -z ${skipPackaging} && -z ${release} ]]
then
    version=`xmlstarlet sel -N 'x=http://maven.apache.org/POM/4.0.0' -t -m /x:project/x:properties -v x:r2c3-version pom.xml`
    today=`date +'%Y%m%d'`
    release=`echo $version | sed s/SNAPSHOT/$today/`
fi

# R2C3 paths
baseDir=`pwd`
toolsDir="${baseDir}/tools"

# build paths
tmpDir="${baseDir}/target"
distDir="${tmpDir}/r2c3"
dependencyDir="${baseDir}/r2c3-application/target/dependency/"
classpathDir="${distDir}/application/classpath"
protocolDir="${distDir}/application/protocol"

if [[ -z ${skipInstall} ]]
then
    echo '-------------------------------------------------------------------------------'
    echo "Cleaning and building R2C3 $release"
    echo
    mvn clean
    mvn -Dmaven.test.skip=true clean dependency:copy-dependencies install
fi

if [[ ${runTests} ]]
then
    echo '-------------------------------------------------------------------------------'
    echo 'Running tests'
    echo
    mvn test
fi
echo

echo '-------------------------------------------------------------------------------'
echo 'Cleaning previous distributions'
rm -fr "${distDir}"

echo '-------------------------------------------------------------------------------'
echo 'Creating directories'
mkdir -p "${distDir}"
mkdir -p "${distDir}/application/classpath"
mkdir -p "${distDir}/application/protocol"

cp -r "${baseDir}/atlante-config/application" "${distDir}"
clean_svn "${distDir}"

echo '-------------------------------------------------------------------------------'
echo 'Creating version information'
version="${distDir}/application/version.txt"
echo 'R2C3' > "$version"
echo 'Release name:' ${release} >> "$version"
#svn info | grep Revis | awk '{print $n}' >> "$version"
echo 'Build date:' `date` >> "$version"
echo 'Built by:' ${USER} >> "$version"

echo "-------------------------------------------------------------------------------"
echo "Copying dependencies"
echo
copy_dependency $dependencyDir 'elsql*.jar'
copy_dependency $dependencyDir 'xml-binder*.jar'
copy_dependency $dependencyDir 'xstream*.jar'
copy_dependency $dependencyDir 'xmlpull*.jar'
copy_dependency $dependencyDir 'classmate-*.jar'
copy_dependency $dependencyDir 'spring-plugin-core-*.jar'
copy_dependency $dependencyDir 'spring-plugin-metadata-*.jar'
copy_dependency $dependencyDir 'guava-21*.jar'
copy_dependency $dependencyDir 'api-r2c3-*.jar'
copy_dependency $dependencyDir 'api-interoperabilidade-*.jar'
copy_dependency $dependencyDir 'parallel-collectors-*.jar'

echo "-------------------------------------------------------------------------------"
echo "Copying protocol"
echo
cp -r atlante-config/protocol "${distDir}"

echo '-------------------------------------------------------------------------------'
echo 'Copying R2C3 jar'
cp "${baseDir}/r2c3-application/target"/r2c3-application-*.jar "${distDir}/application/protocol/r2c3-application-$release.jar"

echo '-------------------------------------------------------------------------------'
echo 'Copying docs'
cp CHANGELOG.md "${distDir}"

echo '-------------------------------------------------------------------------------'
echo 'Copying installer'
chmod +x utilitarios/installer/install.sh
cp utilitarios/installer/install.sh "${distDir}"

if [[ -z ${skipPackaging} ]]
then
    echo '-------------------------------------------------------------------------------'
    echo 'Creating package'
    createdArchive="r2c3-$release-installer.sh"
    (
    	cd "$tmpDir"
    	makeself r2c3 "$createdArchive" "R2C3 $release Installer" "./install.sh"
    )
fi

echo '-------------------------------------------------------------------------------'
echo 'Done!'
if [[ ${createdArchive} ]]
then
    echo 'Target directory: '${tmpDir}
    echo 'Archives created: '${createdArchive}
fi
echo
