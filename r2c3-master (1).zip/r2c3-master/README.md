
# Configurar e logar no docker registry da cip
1 - Add no arquivo /etc/systemd/system/docker.service.d/http-proxy.conf os proxies abaixo, caso ainda não tenha.Para isso, execute as instruções:
```
echo 'export HTTP_PROXY=http://proxyprd.cip.lan.com:8080' >> /etc/systemd/system/docker.service.d/http-proxy.conf
echo 'export HTTPS_PROXY=http://proxyprd.cip.lan.com:8080' >> /etc/systemd/system/docker.service.d/http-proxy.conf
```
2 - Fazer login:
Pedir senha para a equipe de segurança.
```
docker login nexus.cip.lan.com:50000
```
# Gerar Beans pelo XSD
```
java -jar schema-to-bean-4.59.0-SNAPSHOT-jar-with-dependencies.jar --package br.org.cipbancos.r2c3.bean.ar2c3001 --schema /home/cip/proj/R2C3/r2c3/atlante-config/application/xsd/ARDC3001.xsd --initial-element Grupo_ARDC3001_UsuFinalRecbdr --output-path /home/cip/proj/R2C3/r2c3/r2c3-application/src/main/java/
```
# com SPBString #
java -jar /home/cip/doc/schema-to-bean-4.59.0-SNAPSHOT-jar-with-dependencies.jar --default-spbstring SPBString --package br.org.cipbancos.rrc.bean.rrc0010 --schema /home/cip/doc/wrkspc/r2c3/atlante-config/application/xsd/rrc0010.xsd --initial-element rrc0010 --output-path /home/cip/doc/
```
ARGS:
        ("schema", "XML Schema file")
        ("initial-element", "Initial XML element to be used")
        ("package", "Java package name")
        ("type-map", "File with element to type mapping")
        ("constraint-map", "File with constraints to type mapping")
        ("to-lowercase", "File with element prefixes to be converted to lowercase")
        ("output-path", "Base output path of the generated files").withRequiredArg()
        ("default-spbstring", "Default type is SPBString");
        ("debug", "Debug mode");
        ("help").forHelp();
```
# Testes de API
```
curl -d '{"id":"1", "url":"blablabla"}' -H "Content-Type: application/json" -H "X-CIP-Logical-Id:0" -H "X-CIP-Operator-Id:0" -X POST http://localhost:8080/channel-receiver-js/api/v1/rrc0011/teste/1 -v
```

# Docker

## Instalação

Verificar se possui o docker instalado na maquina 

```
docker version
```

Se não esta instalado, seguir os passos descritos no arquivo utilitarios/docker/INSTALL_DOCKER 

## Iniciar containers (Jboss, MQ e PostgreSQL)

```
docker-compose -f utilitarios/docker/docker-compose.yml up -d
```

Caso queira iniciar somente um container

```
docker-compose -f utilitarios/docker/docker-compose.yml up -d jboss
```

Segue abaixo lista dos nomes dos serviços:
jboss -> App server
ibmmq -> Websphere MQ
dbpostgres -> PostgreSQL

## Logs

Para acompanhar todos os logs do containers

```
docker-compose -f utilitarios/docker/docker-compose.yml logs -f
```

Para acompanhar somente o log de um container

```
docker-compose -f utilitarios/docker/docker-compose.yml logs -f jboss
```

Para acompanhar os logs do Atlante

```
docker exec -ti -u atlante docker_jboss_1 tail -f /opt/atlante/log/*.log
```

## Testes

Teste de ambiente

```
docker exec -ti -u atlante docker_jboss_1 /opt/atlante/bin/test_gen0001.sh 38166
```



# Coding Conventions R2C3

## DAO

- Nomenclatura das classes (NomeDaTabela deve ser exatamente igual ao nome da tabela)
  - NomeDaTabelaDAO.java
  - NomeDaTabelaDAOImpl.java
  - NomeDaTabela.java --> DTO

- Nomenclatura dos métodos (verbos no infinitivo)
  - inserir(NomeDaTabela nomeDaTabela);
  - atualizar(NomeDaTabela nomeDaTabela);
  - NomeDaTabela buscarPorId(Integer id);
  - List<NomeDaTabela> buscarPorNome(String nome);
  - List<NomeDaTabela> buscarPorNomeIdade(String nome, Integer idade);
  - List<NomeDaTabela> buscarPorNomeOuIdade(String nome, Integer idade);
  - List<NomeDaTabela> buscarTodos();
  - String buscarNomePorId(Integer id);
  - Integer contarPorId(Integer id);
  - Integer contarTodos(Integer id);

## Testes

- Criar classe de teste com nome NomeDaTabelaDAOImplTest.java
- Deve existir pelo menos um assert em cada método de teste
- Bom senso ao utilizar mock ou chamada a outros testes
- Testes de banco de dados devem zerar a base e validar se o dado realmente foi inserido ou atualizado
- Métodos devem seguir a nomenclatura :
```
public void nomeDoMetodoQueSeraTestado_DadoDoTesto_ResultadoEsperado() {
  ...
}
```
Ex.
```
public void obterUltimoRegOp_ComRegistro_IdRetornadoComSucesso() throws Exception {
  ...
}
```

## Negocio

-  Nomenclatura da classe (pode agrupar uma ou mais tabelas)
  - FuncionalidadeNegocio.java

-  Nomenclatura dos métodos
  - Mesma nomenclatura dos métodos dos DAOs (quando forem métodos de integração)
  - Verbo no infinitivo para os demais métodos (consolidar, calcular, notificar, validar, etc.)

## Handler

- Nomenclatura da classe
  - FuncionalidadeHandler.java
  - FuncionalidadeSubHandler.java
  - FuncionalidadeSubDetalheHandler.java

- Dicas
  - Iniciar o desenvolvimento sem estender nenhuma classe. Se for verificado que MUITAS classes compartilham comportamento comuns, avaliar se é benéfico criar uma classe de abstração (Inheritance is Evil).
  - Nunca acessar DAO diretamente. Sempre passar por classes de negocio

## Controller

- Nomenclatura da classe
  - FuncionalidadeController.java

- Dicas
  - Iniciar o desenvolvimento sem estender nenhuma classe. Se for verificado que MUITAS classes compartilham comportamento comuns, avaliar se é benéfico criar uma classe de abstração (Inheritance is Evil).
  - Nunca acessar DAO diretamente. Sempre passar por classes de negocio

## ELSQL

- Nomenclatura dos arquivos (NomeDaTabela deve ser exatamente igual ao nome da tabela)
  - NomeDaTabelaDAOImpl.elsql
  - Os nomes das consultas devem ser EXATAMENTE iguais aos nomes dos métodos no respectivo DAO
- SQL Convetions (https://www.sqlstyle.guide/)
  - palavras reservas em maiúsculo e nomes de colunas, tabelas e alias em minúsculo
  - Segue abaixo exemplo de consultas demonstrando espaçamento dos operadores e alinhamento das instruções:
```    
SELECT a.title, a.release_date, a.recording_date
  FROM albums AS a
 WHERE a.title = 'Charcoal Lane'
    OR a.title = 'The New Danger';

SELECT r.last_name
  FROM riders AS r
       INNER JOIN bikes AS b
       ON r.bike_vin_num = b.vin_num
          AND b.engine_tally > 2

       INNER JOIN crew AS c
       ON r.crew_chief_last_name = c.last_name
          AND c.chief = 'Y';

(SELECT b.species_name,
        AVG(b.height) AS average_height, AVG(b.diameter) AS average_diameter
   FROM botanic_garden_flora AS b
  WHERE b.species_name = 'Banksia'
    AND b.species_name = 'Sheoak'
     OR b.species_name = 'Wattle'
  GROUP BY b.species_name, b.observation_date);
```

## Atualizando a lista de Timezone da JVM

Caso o seus testes unitários estejam com problemas, um item a se levar em consideração é o timezone da JVM e para identificar se está com o timezone atualizado, execute as seguintes instruções
    

> baixe o tzupdater.jar em: 
>> https://www.oracle.com/technetwork/java/javase/documentation/tzupdater-readme-136440.html

após o download execute o seguinte comando:

>`java -jar tzupdater.jar -V | grep version`

se a versão do JRE TZDATA estiver inferior a **tzdata2020d**

é importante executar a atualização baixando a ultima versão em:

>>https://www.iana.org/time-zones/repository/tzdata-latest.tar.gz

e executar o seguinte comando:

`java -jar tzupdater.jar -l file://<diretorio>/tzdata2020d.tar.gz --verbose`

lembrando que em file:// deve ser adicionar o diretório com /. ex.:
    `java -jar tzupdater.jar -l file:///home/cip/tzdata2020d.tar.gz --verbose`

    
    
    