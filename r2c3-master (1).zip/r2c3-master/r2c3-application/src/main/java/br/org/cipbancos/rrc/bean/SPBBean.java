package br.org.cipbancos.rrc.bean;

import java.io.Serializable;

public interface SPBBean extends Serializable {

    String getRecordId();

}
