package br.org.cipbancos.rrc.bean.arrc018;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;

@XStreamAlias("Grupo_ARRC018_UniddRecbvl")
public class GrupoARRC018UniddRecbvl2 extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("DtPrevtLiquid")
    private SPBLocalDate dtPrevtLiquid;

    @XStreamAlias("VlrTotTitlar")
    private SPBBigDecimal vlrTotTitlar;

    @XStreamAlias("VlrComprtdOutrInst")
    private SPBBigDecimal vlrComprtdOutrInst;

    @XStreamAlias("VlrComprtdInst")
    private SPBBigDecimal vlrComprtdInst;

    @XStreamAlias("VlrLivreTot")
    private SPBBigDecimal vlrLivreTot;

    @XStreamAlias("VlrLivreAntecCreddrSub")
    private SPBBigDecimal vlrLivreAntecCreddrSub;

    @XStreamAlias("VlrPreContrd")
    private SPBBigDecimal vlrPreContrd;

    @XStreamAlias("VlrOnusResTec")
    private SPBBigDecimal vlrOnusResTec;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC018_DomclBancInst")
    private List<GrupoARRC018DomclBancInst2> listagrupoARRC018DomclBancInst = new ArrayList<>();

    @XStreamImplicit(itemFieldName = "Grupo_ARRC018_NegcRecbvOutrasInst")
    private List<GrupoARRC018NegcRecbvOutrasInst2> listagrupoARRC018NegcRecbvOutrasInst = new ArrayList<>();

    public SPBLocalDate getDtPrevtLiquid() {
        return dtPrevtLiquid;
    }

    public void setDtPrevtLiquid(SPBLocalDate dtPrevtLiquid) {
        this.dtPrevtLiquid = dtPrevtLiquid;
    }

    public SPBBigDecimal getVlrTotTitlar() {
        return vlrTotTitlar;
    }

    public void setVlrTotTitlar(SPBBigDecimal vlrTotTitlar) {
        this.vlrTotTitlar = vlrTotTitlar;
    }

    public SPBBigDecimal getVlrComprtdOutrInst() {
        return vlrComprtdOutrInst;
    }

    public void setVlrComprtdOutrInst(SPBBigDecimal vlrComprtdOutrInst) {
        this.vlrComprtdOutrInst = vlrComprtdOutrInst;
    }

    public SPBBigDecimal getVlrComprtdInst() {
        return vlrComprtdInst;
    }

    public void setVlrComprtdInst(SPBBigDecimal vlrComprtdInst) {
        this.vlrComprtdInst = vlrComprtdInst;
    }

    public SPBBigDecimal getVlrLivreTot() {
        return vlrLivreTot;
    }

    public void setVlrLivreTot(SPBBigDecimal vlrLivreTot) {
        this.vlrLivreTot = vlrLivreTot;
    }

    public SPBBigDecimal getVlrLivreAntecCreddrSub() {
        return vlrLivreAntecCreddrSub;
    }

    public void setVlrLivreAntecCreddrSub(SPBBigDecimal vlrLivreAntecCreddrSub) {
        this.vlrLivreAntecCreddrSub = vlrLivreAntecCreddrSub;
    }

    public SPBBigDecimal getVlrPreContrd() {
        return vlrPreContrd;
    }

    public void setVlrPreContrd(SPBBigDecimal vlrPreContrd) {
        this.vlrPreContrd = vlrPreContrd;
    }

    public SPBBigDecimal getVlrOnusResTec() {
        return vlrOnusResTec;
    }

    public void setVlrOnusResTec(SPBBigDecimal vlrOnusResTec) {
        this.vlrOnusResTec = vlrOnusResTec;
    }

    public List<GrupoARRC018DomclBancInst2> getListagrupoARRC018DomclBancInst() {
        return listagrupoARRC018DomclBancInst;
    }

    public void setListagrupoARRC018DomclBancInst(List<GrupoARRC018DomclBancInst2> listagrupoARRC018DomclBancInst) {
        this.listagrupoARRC018DomclBancInst = listagrupoARRC018DomclBancInst;
    }

    public List<GrupoARRC018NegcRecbvOutrasInst2> getListagrupoARRC018NegcRecbvOutrasInst() {
        return listagrupoARRC018NegcRecbvOutrasInst;
    }

    public void setListagrupoARRC018NegcRecbvOutrasInst(List<GrupoARRC018NegcRecbvOutrasInst2> listagrupoARRC018NegcRecbvOutrasInst) {
        this.listagrupoARRC018NegcRecbvOutrasInst = listagrupoARRC018NegcRecbvOutrasInst;
    }
}
