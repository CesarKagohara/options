package br.org.cipbancos.rrc.bean.rrc0010;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("RRC0010R1")
public class RRC0010R1 extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CodMsg")
    private SPBString codMsg;

    @XStreamAlias("SitRetReq")
    private SPBString sitRetReq;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0010R1_CreddrSub")
    private List<GrupoRRC0010R1CreddrSub> listagrupoRRC0010R1CreddrSub = new ArrayList<GrupoRRC0010R1CreddrSub>();

    public SPBString getCodMsg() {
        return codMsg;
    }

    public void setCodMsg(SPBString codMsg) {
        this.codMsg = codMsg;
    }

    public SPBString getSitRetReq() {
        return sitRetReq;
    }

    public void setSitRetReq(SPBString sitRetReq) {
        this.sitRetReq = sitRetReq;
    }

    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public List<GrupoRRC0010R1CreddrSub> getListagrupoRRC0010R1CreddrSub() {
        return listagrupoRRC0010R1CreddrSub;
    }

    public void setListagrupoRRC0010R1CreddrSub(List<GrupoRRC0010R1CreddrSub> listagrupoRRC0010R1CreddrSub) {
        this.listagrupoRRC0010R1CreddrSub = listagrupoRRC0010R1CreddrSub;
    }

}
