package br.org.cipbancos.rrc.dao;

import java.util.Date;

import br.org.cipbancos.atlante.api.handler.Context;
import br.org.cipbancos.rrc.bean.rrc0027.RRC0027;
import br.org.cipbancos.rrc.vo.Contestacao;

import br.org.cip.api.r2c3.model.ContestacaoInterop;

public interface ContestacaoDAO {

    /**
     * Grava uma nova Contestação no BD.
     *  @param contestacao a ser salva no BD.
     * @param refDate     Data de hoje.
     * @param context Contexto Atlante.
     * @param contestacaoInterop
     */
    String inserirContestacao(RRC0027 contestacao, Date refDate, Context context, ContestacaoInterop contestacaoInterop);

    /**
     * Atualiza uma Contestação no BD.
     *
     * @param contestacao a ser atualizada no BD.
     */
    void atualizarContestacao(RRC0027 contestacao, Date refDate);

    /**
     * Busca uma Contestação no BD.
     *
     * @param contestacao a ser buscada no BD.
     */
    Contestacao buscarContestacao(RRC0027 contestacao);

    /**
     * Busca uma Contestação no BD.
     *
     * @param idOptIn da contestação a ser buscada no BD.
     * ^ ou exclusivo
     * @param idOp da contestação a ser buscada no BD.
     */
    Contestacao buscarContestacaoPorIdentOptInOuIdentOp(String idOptIn, String idOp);

    /**
     * Busca o proximo sequencial no Banco
     *
     * @return o proximo valor disponivel.
     */
    Long obterSeqIdContestacao();

    Contestacao buscarInfoResumoDiario(Long idAtlRoot);
}
