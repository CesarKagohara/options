package br.org.cipbancos.rrc.bean.arrc022;

import java.io.Serializable;

import br.org.cipbancos.atlante.xmlbinder.spb.*;
import com.thoughtworks.xstream.annotations.XStreamAlias;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@XStreamAlias("Grupo_ARRC022RET_RegRecbvl")
public class GrupoARRC022RETRegRecbvl extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("PriorddNegcRecbvl")
    private SPBInteger priorddNegcRecbvl;

    @XStreamAlias("CNPJ_CPFUsuFinalRecbdr")
    private SPBString cNPJCPFUsuFinalRecbdr;

    @XStreamAlias("CNPJ_CPFTitular")
    private SPBString cNPJCPFTitular;

    @XStreamAlias("CNPJCreddrSub")
    private SPBString cNPJCreddrSub;

    @XStreamAlias("CodInstitdrArrajPgto")
    private SPBString codInstitdrArrajPgto;

    @XStreamAlias("DtPrevtLiquid")
    private SPBLocalDate dtPrevtLiquid;

    @XStreamAlias("VlrNegcd")
    private SPBBigDecimal vlrNegcd;

    public SPBInteger getPriorddNegcRecbvl() {
        return priorddNegcRecbvl;
    }

    public void setPriorddNegcRecbvl(SPBInteger priorddNegcRecbvl) {
        this.priorddNegcRecbvl = priorddNegcRecbvl;
    }

    public SPBString getcNPJCPFUsuFinalRecbdr() {
        return cNPJCPFUsuFinalRecbdr;
    }

    public void setcNPJCPFUsuFinalRecbdr(SPBString cNPJCPFUsuFinalRecbdr) {
        this.cNPJCPFUsuFinalRecbdr = cNPJCPFUsuFinalRecbdr;
    }

    public SPBString getcNPJCPFTitular() {
        return cNPJCPFTitular;
    }

    public void setcNPJCPFTitular(SPBString cNPJCPFTitular) {
        this.cNPJCPFTitular = cNPJCPFTitular;
    }

    public SPBString getcNPJCreddrSub() {
        return cNPJCreddrSub;
    }

    public void setcNPJCreddrSub(SPBString cNPJCreddrSub) {
        this.cNPJCreddrSub = cNPJCreddrSub;
    }

    public SPBString getCodInstitdrArrajPgto() {
        return codInstitdrArrajPgto;
    }

    public void setCodInstitdrArrajPgto(SPBString codInstitdrArrajPgto) {
        this.codInstitdrArrajPgto = codInstitdrArrajPgto;
    }

    public SPBLocalDate getDtPrevtLiquid() {
        return dtPrevtLiquid;
    }

    public void setDtPrevtLiquid(SPBLocalDate dtPrevtLiquid) {
        this.dtPrevtLiquid = dtPrevtLiquid;
    }

    public SPBBigDecimal getVlrNegcd() {
        return vlrNegcd;
    }

    public void setVlrNegcd(SPBBigDecimal vlrNegcd) {
        this.vlrNegcd = vlrNegcd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GrupoARRC022RETRegRecbvl that = (GrupoARRC022RETRegRecbvl) o;
        return new EqualsBuilder()
                .append(getPriorddNegcRecbvl(), that.getPriorddNegcRecbvl())
                .append(getcNPJCPFUsuFinalRecbdr(), that.getcNPJCPFUsuFinalRecbdr())
                .append(getcNPJCPFTitular(), that.getcNPJCPFTitular())
                .append(getcNPJCreddrSub(), that.getcNPJCreddrSub())
                .append(getCodInstitdrArrajPgto(), that.getCodInstitdrArrajPgto())
                .append(getDtPrevtLiquid(), that.getDtPrevtLiquid())
                .append(getVlrNegcd(), that.getVlrNegcd())
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(getPriorddNegcRecbvl())
                .append(getcNPJCPFUsuFinalRecbdr())
                .append(getcNPJCPFTitular())
                .append(getcNPJCreddrSub())
                .append(getCodInstitdrArrajPgto())
                .append(getDtPrevtLiquid())
                .append(getVlrNegcd())
                .toHashCode();
    }
}
