package br.org.cipbancos.rrc.bean.arrc007;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_ARRC007_Ctrl")
public class GrupoARRC007Ctrl extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("NomArqMsgURLIn")
    private SPBString nomArqMsgURLIn;

    @XStreamAlias("NomArqMsgURLOut")
    private SPBString nomArqMsgURLOut;

    @XStreamAlias("DtHrReq")
    private SPBString dtHrReq;

    @XStreamAlias("IdentdOp")
    private SPBString identdOp;

    @XStreamAlias("IdentdNegcRecbvl")
    private SPBString identdNegcRecbvl;

    @XStreamAlias("IdentdOpCancel")
    private SPBString identdOpCancel;

    @XStreamAlias("IdentdCtrlReqSolicte")
    private SPBString identdCtrlReqSolicte;

    @XStreamAlias("IdentdOpDescstcNegcRecbvl")
    private SPBString identdOpDescstcNegcRecbvl;

    @XStreamAlias("IdentdOpOrRenegcDiv")
    private SPBString identdOpOrRenegcDiv;

    @XStreamAlias("IdentdCtrlOptIn")
    private SPBString identdCtrlOptIn;

    @XStreamAlias("IdentdCtrlOptOut")
    private SPBString identdCtrlOptOut;

    @XStreamAlias("IdentdOpContstc")
    private SPBString identdOpContstc;

    public SPBString getNomArqMsgURLIn() {
        return nomArqMsgURLIn;
    }

    public void setNomArqMsgURLIn(SPBString nomArqMsgURLIn) {
        this.nomArqMsgURLIn = nomArqMsgURLIn;
    }

    public SPBString getNomArqMsgURLOut() {
        return nomArqMsgURLOut;
    }

    public void setNomArqMsgURLOut(SPBString nomArqMsgURLOut) {
        this.nomArqMsgURLOut = nomArqMsgURLOut;
    }

    public SPBString getDtHrReq() {
        return dtHrReq;
    }

    public void setDtHrReq(SPBString dtHrReq) {
        this.dtHrReq = dtHrReq;
    }

    public SPBString getIdentdOp() {
        return identdOp;
    }

    public void setIdentdOp(SPBString identdOp) {
        this.identdOp = identdOp;
    }

    public SPBString getIdentdNegcRecbvl() {
        return identdNegcRecbvl;
    }

    public void setIdentdNegcRecbvl(SPBString identdNegcRecbvl) {
        this.identdNegcRecbvl = identdNegcRecbvl;
    }

    public SPBString getIdentdOpCancel() {
        return identdOpCancel;
    }

    public void setIdentdOpCancel(SPBString identdOpCancel) {
        this.identdOpCancel = identdOpCancel;
    }

    public SPBString getIdentdCtrlReqSolicte() {
        return identdCtrlReqSolicte;
    }

    public void setIdentdCtrlReqSolicte(SPBString identdCtrlReqSolicte) {
        this.identdCtrlReqSolicte = identdCtrlReqSolicte;
    }

    public SPBString getIdentdOpDescstcNegcRecbvl() {
        return identdOpDescstcNegcRecbvl;
    }

    public void setIdentdOpDescstcNegcRecbvl(SPBString identdOpDescstcNegcRecbvl) {
        this.identdOpDescstcNegcRecbvl = identdOpDescstcNegcRecbvl;
    }

    public SPBString getIdentdOpOrRenegcDiv() {
        return identdOpOrRenegcDiv;
    }

    public void setIdentdOpOrRenegcDiv(SPBString identdOpOrRenegcDiv) {
        this.identdOpOrRenegcDiv = identdOpOrRenegcDiv;
    }

    public SPBString getIdentdCtrlOptIn() {
        return identdCtrlOptIn;
    }

    public void setIdentdCtrlOptIn(SPBString identdCtrlOptIn) {
        this.identdCtrlOptIn = identdCtrlOptIn;
    }

    public SPBString getIdentdCtrlOptOut() {
        return identdCtrlOptOut;
    }

    public void setIdentdCtrlOptOut(SPBString identdCtrlOptOut) {
        this.identdCtrlOptOut = identdCtrlOptOut;
    }

    public SPBString getIdentdOpContstc() {
        return identdOpContstc;
    }

    public void setIdentdOpContstc(SPBString identdOpContstc) {
        this.identdOpContstc = identdOpContstc;
    }

}
