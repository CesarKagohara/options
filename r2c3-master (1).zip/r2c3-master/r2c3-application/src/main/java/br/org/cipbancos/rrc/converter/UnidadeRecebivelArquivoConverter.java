package br.org.cipbancos.rrc.converter;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001ArrajPgto;
import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001DomclBanc;
import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001DomclBancRecsdo;
import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001RETArrajPgto;
import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001RETUsuFinalRecbdr;
import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001UniddRecbvl;
import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001UniddRecbvlActo;
import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001UniddRecbvlRecsdo;
import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001UsuFinalRecbdr;
import br.org.cipbancos.rrc.funcional.Converter;
import br.org.cipbancos.rrc.vo.UnidadeRecebivelStage;

/**
 * Classe utilitária para converter informações de Unidades Recebíveis STG de entrada para realizar,
 * inserções no BD e conversões de Entrada para Retorno.
 *
 * @author otavio.ferreira
 * @since 1.0
 */
public class UnidadeRecebivelArquivoConverter {

    private UnidadeRecebivelArquivoConverter() {}

    /**
     * Popula uma Unidade Recebível, caso ela esteja recusada.
     */
    public static Converter<GrupoARRC001UniddRecbvl, GrupoARRC001UniddRecbvlRecsdo> emUnidadeRecebivelRecusada() {
        return origem -> {
            GrupoARRC001UniddRecbvlRecsdo destino = new GrupoARRC001UniddRecbvlRecsdo();
            destino.setDtPrevtLiquid(origem.getDtPrevtLiquid());
            destino.setVlrPreContrd(origem.getVlrPreContrd());
            destino.setVlrTot(origem.getVlrTot());
            return destino;
        };
    }

    /**
     * Popula uma Unidade Recebível, caso ela esteja aceita.
     */
    public static Converter<GrupoARRC001UniddRecbvl, GrupoARRC001UniddRecbvlActo> emUnidadeRecebivelAceita() {
        return origem -> {
            GrupoARRC001UniddRecbvlActo destino = new GrupoARRC001UniddRecbvlActo();
            destino.setDtPrevtLiquid(origem.getDtPrevtLiquid());
            return destino;
        };
    }

    /**
     * Converte o Usuário Final Recebedor em Recusado caso existam problemas gerais de validação.
     *
     * @return Um usuarioRecebedor para o RET.
     */
    public static Converter<GrupoARRC001UsuFinalRecbdr, GrupoARRC001RETUsuFinalRecbdr> emUsuarioRecebedorRETRecusado() {
        return origem -> {
            GrupoARRC001RETUsuFinalRecbdr destino = new GrupoARRC001RETUsuFinalRecbdr();

            destino.setCNPJCPFUsuFinalRecbdr(origem.getCNPJCPFUsuFinalRecbdr());

            for (GrupoARRC001ArrajPgto arranjo : origem.getListagrupoARRC001ArrajPgto()) {
                GrupoARRC001RETArrajPgto arranjoRET = new GrupoARRC001RETArrajPgto();

                arranjoRET.setCodInstitdrArrajPgto(arranjo.getCodInstitdrArrajPgto());

                for (GrupoARRC001UniddRecbvl unidade : arranjo.getListagrupoARRC001UniddRecbvl()) {
                    GrupoARRC001UniddRecbvlRecsdo unidadeRET = UnidadeRecebivelArquivoConverter
                            .emUnidadeRecebivelRecusada()
                            .convert(unidade);

                    for (GrupoARRC001DomclBanc domicilio : unidade.getListagrupoARRC001DomclBanc()) {
                        GrupoARRC001DomclBancRecsdo domicilioRET = DomicilioBancarioConverter
                                .emDomicilioBancarioRecusado()
                                .convert(domicilio);

                        unidadeRET.getListagrupoARRC001DomclBancRecsdo().add(domicilioRET);
                    }

                    arranjoRET.getListagrupoARRC001UniddRecbvlRecsdo().add(unidadeRET);
                }

                destino.getListagrupoARRC001ArrajPgto().add(arranjoRET);
            }

            return destino;
        };
    }

    /**
     * Popula uma Unidade Recebível, caso ela esteja recusada.
     */
    public static Converter<GrupoARRC001UniddRecbvl, UnidadeRecebivelStage> emUnidadeRecebivelStage(String usuarioFinal, String arranjo) {
        return origem -> {
            UnidadeRecebivelStage destino = new UnidadeRecebivelStage();

            destino.setNrCpfCnpjUsurioFinlRecbdr(usuarioFinal);
            destino.setCdArrjPgto(arranjo);
            destino.setDtPrevtLiqui(origem.getDtPrevtLiquid().getValue().toDate());
            destino.setUrArquivo(origem);

            return destino;
        };
    }

    /**
     * Popula uma Unidade Recebível, caso ela esteja recusada.
     */
    public static Converter<UnidadeRecebivelStage, MapSqlParameterSource> emUnidadeRecebivelStageParaInsercao() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();

            populaURStage(origem, parametros);

            return parametros;
        };
    }

    /**
     * Popula a chave primária para a Fracao de Unidade Recebível no BD.
     *
     * @param unidade    Unidade Recebível com os dados da chave primária.
     * @param parametros Cadeia de parametros a serem utilizados no SQL.
     */
    public static void populaURStage(UnidadeRecebivelStage unidade, MapSqlParameterSource parametros) {
        parametros.addValue("nrCpfCnpjUsurioFinlRecbdr", unidade.getNrCpfCnpjUsurioFinlRecbdr());
        parametros.addValue("cdArrjPgto", unidade.getCdArrjPgto());
        parametros.addValue("dtPrevtLiqui", new java.sql.Date(unidade.getDtPrevtLiqui().getTime()));
    }

}
