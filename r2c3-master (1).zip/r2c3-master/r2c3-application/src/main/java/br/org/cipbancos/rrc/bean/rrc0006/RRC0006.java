package br.org.cipbancos.rrc.bean.rrc0006;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.CancelamentoGrupoNegcRecbvl;
import br.org.cipbancos.rrc.bean.PartPrincXPartAdm;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

import java.util.ArrayList;
import java.util.List;

/**
 * @author anderson.martins
 * @since 1.0.0
 */
@XStreamAlias("RRC0006")
public class RRC0006 extends ErrorCodeBean implements CancelamentoGrupoNegcRecbvl, PartPrincXPartAdm {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CodMsg")
    private SPBString codMsg;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamAlias("IdentdNegcRecbvl")
    private SPBString identdNegcRecbvl;

    @XStreamAlias("IdentdOp")
    private SPBString identdOp;

    @XStreamAlias("CNPJ_CNPJBase_CPFTitlar")
    private SPBString cnpjCnpjBaseCpfTitlar;

    @XStreamAlias("IndrCancelVlrTotal")
    private SPBString indrCancelVlrTotal;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0006_RegRecbvl")
    private List<GrupoRRC0006RegRecbvl> listagrupoRRC0006RegRecbvl = new ArrayList<GrupoRRC0006RegRecbvl>();

    @XStreamOmitField
    private String recordId;

    @XStreamOmitField
    private Long atlRootId;

    public SPBString getCodMsg() {
        return codMsg;
    }

    public void setCodMsg(SPBString codMsg) {
        this.codMsg = codMsg;
    }

    @Override
    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    @Override
    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public SPBString getIdentdNegcRecbvl() {
        return identdNegcRecbvl;
    }

    public void setIdentdNegcRecbvl(SPBString identdNegcRecbvl) {
        this.identdNegcRecbvl = identdNegcRecbvl;
    }

    public SPBString getIdentdOp() {
        return identdOp;
    }

    public void setIdentdOp(SPBString identdOp) {
        this.identdOp = identdOp;
    }

    public SPBString getCnpjCnpjBaseCpfTitlar() {
        return cnpjCnpjBaseCpfTitlar;
    }

    public void setCnpjCnpjBaseCpfTitlar(SPBString cnpjCnpjBaseCpfTitlar) {
        this.cnpjCnpjBaseCpfTitlar = cnpjCnpjBaseCpfTitlar;
    }

    public SPBString getIndrCancelVlrTotal() {
        return indrCancelVlrTotal;
    }

    public void setIndrCancelVlrTotal(SPBString indrCancelVlrTotal) {
        this.indrCancelVlrTotal = indrCancelVlrTotal;
    }

    public List<GrupoRRC0006RegRecbvl> getListagrupoRRC0006RegRecbvl() {
        return listagrupoRRC0006RegRecbvl;
    }

    public void setListagrupoRRC0006RegRecbvl(List<GrupoRRC0006RegRecbvl> listagrupoRRC0006RegRecbvl) {
        this.listagrupoRRC0006RegRecbvl = listagrupoRRC0006RegRecbvl;
    }

    @Override
    public SPBString getIndrLiquidOp() {
        return null;
    }

    @Override
    public SPBString getIndrCancelCessConstitr() {
        return null;
    }

    @Override
    public List getListaGrupoRegRecbvl() {
        return listagrupoRRC0006RegRecbvl;
    }

    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }

    @Override
    public Long getAtlRootId() {
        return atlRootId;
    }

    @Override
    public void setAtlRootId(Long atlRootId) {
        this.atlRootId = atlRootId;
    }
}
