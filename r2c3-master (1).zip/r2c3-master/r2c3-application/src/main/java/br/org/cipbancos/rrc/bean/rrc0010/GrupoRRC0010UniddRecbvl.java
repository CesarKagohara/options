package br.org.cipbancos.rrc.bean.rrc0010;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.annotation.HttpFieldName;

@XStreamAlias("Grupo_RRC0010_UniddRecbvl")
@HttpFieldName("cnpjOuCnpjBaseOuCpfTitlar")
public class GrupoRRC0010UniddRecbvl extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CNPJBase_CPFUsuFinalRecbdr")
    private SPBString cNPJCNPJBaseCPFUsuFinalRecbdr;

    @XStreamAlias("CodInstitdrArrajPgto")
    private SPBString codInstitdrArrajPgto;

    @XStreamAlias("CNPJCreddrSub")
    private SPBString cNPJCreddrSub;

    @XStreamAlias("DtPrevtLiquid")
    private SPBLocalDate dtPrevtLiquid;

    @XStreamAlias("VlrLivre")
    private SPBBigDecimal vlrLivre;

    @XStreamAlias("DtIniPrevtLiquid")
    private SPBLocalDate dtIniPrevtLiquid;

    @XStreamAlias("DtFimPrevtLiquid")
    private SPBLocalDate dtFimPrevtLiquid;

    @XStreamAlias("IndrTpNegc")
    private SPBString indrTpNegc;

    @HttpFieldName("cnpjOuCnpjBaseOuCpfTitlar")
    @XStreamAlias("CNPJ_CNPJBase_CPFTitlar")
    private SPBString cNPJCNPJBaseCPFTitlar;

    public SPBString getCNPJCNPJBaseCPFUsuFinalRecbdr() {
        return cNPJCNPJBaseCPFUsuFinalRecbdr;
    }

    public void setCNPJCNPJBaseCPFUsuFinalRecbdr(SPBString cNPJCNPJBaseCPFUsuFinalRecbdr) {
        this.cNPJCNPJBaseCPFUsuFinalRecbdr = cNPJCNPJBaseCPFUsuFinalRecbdr;
    }

    public SPBString getCodInstitdrArrajPgto() {
        return codInstitdrArrajPgto;
    }

    public void setCodInstitdrArrajPgto(SPBString codInstitdrArrajPgto) {
        this.codInstitdrArrajPgto = codInstitdrArrajPgto;
    }

    public SPBString getCNPJCreddrSub() {
        return cNPJCreddrSub;
    }

    public void setCNPJCreddrSub(SPBString cNPJCreddrSub) {
        this.cNPJCreddrSub = cNPJCreddrSub;
    }

    public SPBLocalDate getDtPrevtLiquid() {
        return dtPrevtLiquid;
    }

    public void setDtPrevtLiquid(SPBLocalDate dtPrevtLiquid) {
        this.dtPrevtLiquid = dtPrevtLiquid;
    }

    public SPBBigDecimal getVlrLivre() {
        return vlrLivre;
    }

    public void setVlrLivre(SPBBigDecimal vlrLivre) {
        this.vlrLivre = vlrLivre;
    }

    public SPBLocalDate getDtIniPrevtLiquid() {
        return dtIniPrevtLiquid;
    }

    public void setDtIniPrevtLiquid(SPBLocalDate dtIniPrevtLiquid) {
        this.dtIniPrevtLiquid = dtIniPrevtLiquid;
    }

    public SPBLocalDate getDtFimPrevtLiquid() {
        return dtFimPrevtLiquid;
    }

    public void setDtFimPrevtLiquid(SPBLocalDate dtFimPrevtLiquid) {
        this.dtFimPrevtLiquid = dtFimPrevtLiquid;
    }

    public SPBString getIndrTpNegc() {
        return indrTpNegc;
    }

    public void setIndrTpNegc(SPBString indrTpNegc) {
        this.indrTpNegc = indrTpNegc;
    }

    public SPBString getCNPJCNPJBaseCPFTitlar() {
        return cNPJCNPJBaseCPFTitlar;
    }

    public void setCNPJCNPJBaseCPFTitlar(SPBString cNPJCNPJBaseCPFTitlar) {
        this.cNPJCNPJBaseCPFTitlar = cNPJCNPJBaseCPFTitlar;
    }

    @Override
    public String toString() {
        return "GrupoRRC0010UniddRecbvl{" +
                "cNPJCNPJBaseCPFUsuFinalRecbdr=" + cNPJCNPJBaseCPFUsuFinalRecbdr +
                ", codInstitdrArrajPgto=" + codInstitdrArrajPgto +
                ", cNPJCreddrSub=" + cNPJCreddrSub +
                ", dtPrevtLiquid=" + dtPrevtLiquid +
                ", vlrLivre=" + vlrLivre +
                ", dtIniPrevtLiquid=" + dtIniPrevtLiquid +
                ", dtFimPrevtLiquid=" + dtFimPrevtLiquid +
                ", indrTpNegc=" + indrTpNegc +
                ", cNPJCNPJBaseCPFTitlar=" + cNPJCNPJBaseCPFTitlar +
                '}';
    }
}
