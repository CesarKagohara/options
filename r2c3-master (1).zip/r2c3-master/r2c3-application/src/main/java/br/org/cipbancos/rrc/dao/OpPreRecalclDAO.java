package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.rrc.enums.IndicadorSimNao;
import br.org.cipbancos.rrc.enums.TipoNegociacao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface OpPreRecalclDAO {

    void inserir(Long idOp, String cpfCnpjBaseRecedor, TipoNegociacao tipoNegociacao, IndicadorSimNao icInterop,
                        IndicadorSimNao icGestEntRegtdr, BigDecimal nrVlrGar, BigDecimal nrLimConcdSldDevdr, BigDecimal somaNrVlrPrevtLiquid,
                        Date dtRefSistIncl, Date dtRefSistUltAlt, Long idAtlRoot);

    BigDecimal calcularSomaValorPrevistoLiquidacaoPorRecebedor(Date dtRef, Long idOp, String sufixo);

    List<Long> buscaIdsOpSemInterop(Date dtRef);

    List<Long> buscaIdsOpInterop(Date dtRef, TipoNegociacao... tiposNegociacoes);

    List<Long> buscaIdsOp(Date dtRef, Boolean comInterop, Boolean paraDesalocacao, TipoNegociacao... icTpNegcs);

    Map<Integer, List<Long>> buscaCpfCnpjBaseRecbdrIdsOp(Date dtRef, Boolean comInterop, Boolean paraDesalocacao, TipoNegociacao... icTpNegcs);

    List<Long> buscaIdsOp(Set<Long> idOps, Date dtRef, Boolean comInterop, Boolean paraDesalocacao, TipoNegociacao... icTpNegcs);

    List<Long> buscaIdsOpPorUR(String sufixo, Set<Long> urs, Integer idPartCred, Date dtRef, TipoNegociacao... icTpNegcs);

    void atualizar(Long idOp, Date dtRef, Long idAtlRootReclc);

    void atualizar(List<Long> idOp, Date dtRef, Long idAtlRootReclc);
}