package br.org.cipbancos.rrc.builder;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.arrc018.GrupoARRC018UniddRecbvl;
import br.org.cipbancos.rrc.util.DateUtil;

import java.math.BigDecimal;
import java.util.Date;

public class GrupoARRC018UniddRecbvlBuilder {

    private GrupoARRC018UniddRecbvl grupoARRC018UniddRecbvl;

    private GrupoARRC018UniddRecbvlBuilder(){
        this.grupoARRC018UniddRecbvl = new GrupoARRC018UniddRecbvl();
    }

    public static GrupoARRC018UniddRecbvlBuilder builder(){
        return new GrupoARRC018UniddRecbvlBuilder();
    }

    public GrupoARRC018UniddRecbvlBuilder comDataPrevistaLiquidacao(Date dataPrevistatLiquidacao){
        if (dataPrevistatLiquidacao != null) {
            this.grupoARRC018UniddRecbvl.setDtPrevtLiquid(new SPBLocalDate(DateUtil.toLocalDate(dataPrevistatLiquidacao)));
        }
        return this;
    }

    public GrupoARRC018UniddRecbvlBuilder comValorTotal(BigDecimal valorTotal){
        if (valorTotal != null) {
            this.grupoARRC018UniddRecbvl.setVlrTot(new SPBBigDecimal(valorTotal));
        }
        return this;
    }

    public GrupoARRC018UniddRecbvlBuilder comIndicadorDomicilio(String indicadorDomicilio){
        if (indicadorDomicilio != null) {
            this.grupoARRC018UniddRecbvl.setIndrDomcl(new SPBString(indicadorDomicilio));
        }
        return this;
    }

    public GrupoARRC018UniddRecbvl build(){
        return this.grupoARRC018UniddRecbvl;
    }
}