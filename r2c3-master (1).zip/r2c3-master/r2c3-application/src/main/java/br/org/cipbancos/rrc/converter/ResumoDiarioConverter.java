package br.org.cipbancos.rrc.converter;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import br.org.cipbancos.rrc.funcional.Converter;
import br.org.cipbancos.rrc.vo.ResumoDiario;

public class ResumoDiarioConverter {

    private ResumoDiarioConverter() {
    }

    public static Converter<ResumoDiario, MapSqlParameterSource> emResumoDiarioParaInsercao() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();

            parametros.addValue("identificadorR2C3", origem.getIdentificadorR2C3());
            parametros.addValue("idPart", origem.getIdPart());
            parametros.addValue("nmArqEntr", origem.getNmArqEntr());
            parametros.addValue("nmArqSaid", origem.getNmArqSaid());
            parametros.addValue("dhArq", origem.getDhArq());
            parametros.addValue("idOp", origem.getIdOp());
            parametros.addValue("idNegcRecbvExtn", origem.getIdNegcRecbvExtn());
            parametros.addValue("idOpCancelt", origem.getIdOpCancelt());
            parametros.addValue("idCtrlSolcte", origem.getIdCtrlSolcte());
            parametros.addValue("idDesctcGar", origem.getIdDesctcGar());
            parametros.addValue("idOpOr", origem.getIdOpOr());
            parametros.addValue("idOptIn", origem.getIdOptIn());
            parametros.addValue("idOptOut", origem.getIdOptOut());
            parametros.addValue("idContc", origem.getIdContc());
            parametros.addValue("idPartPrinc", origem.getIdPart());
            parametros.addValue("idPartAdm", origem.getIdPartAdmtd());
            parametros.addValue("idPartOrig", origem.getIdPartAdmtd());

            parametros.addValue("dtRefSistIncl", origem.getDtRefMovto());
            parametros.addValue("dtRefSistUltAlt", origem.getDtRefMovto());
            parametros.addValue("idAtlRoot", origem.getIdAtlRoot());
            parametros.addValue("nmArqNuopApi", origem.getNmArqEntr());
            parametros.addValue("idFunc", origem.getIdFuncdd());

            parametros.addValue("dtRefMovto", origem.getDtRefMovto());
            parametros.addValue("dhUltAlt", origem.getDhUltAlt());
            parametros.addValue("dhIncl", origem.getDhIncl());

            return parametros;
        };
    }
}
