package br.org.cipbancos.rrc.bean.arrc032;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@XStreamAlias("Grupo_ARRC032_Arq")
public class GrupoARRC032Arq extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamImplicit(itemFieldName = "NomArq")
    private List<SPBString> listaNomeArq = new ArrayList<SPBString>();

    public List<SPBString> getListaNomeArq() {
        return listaNomeArq;
    }

    public void setListaNomeArq(List<SPBString> listaNomeArq) {
        this.listaNomeArq = listaNomeArq;
    }

}
