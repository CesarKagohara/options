package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.rrc.vo.OptinVO;
import br.org.cipbancos.rrc.vo.PreOptInVO;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface PreOptInDAO {

    void buscarDestinatarioCNPJCompleto(Set<String> solicitante, String codArranjo, Integer credenciadora, List<Integer> registradora, Map<String, Set<PreOptInVO>> cnpjsDestinatarios, Date dtRef, Map<Integer, Set<Integer>> credoresMultiplasRegistradoras);

    void buscarDestinatarioCNPJBase(Set<String> solicitante, String codArranjo, Integer credenciadora, List<Integer> registradora, Map<String, Set<PreOptInVO>> cnpjsDestinatarios, Date dtRef, Map<Integer, Set<Integer>> credoresMultiplasRegistradoras);

    void incluirPreOptIn(Date dataReferencia, List<OptinVO> optIns);
}
