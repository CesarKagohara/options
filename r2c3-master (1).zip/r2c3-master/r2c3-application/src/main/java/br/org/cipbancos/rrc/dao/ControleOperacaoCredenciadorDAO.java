package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.rrc.vo.ControleOperacaoCredenciadorVO;

import java.util.List;

public interface ControleOperacaoCredenciadorDAO {

    void insereEmLote(List<ControleOperacaoCredenciadorVO> controleOperacaoCredenciadorVOS);

    List<ControleOperacaoCredenciadorVO> buscar(ControleOperacaoCredenciadorVO vo);

    List<Long> buscarPorNrGrdProc(Integer nrGrdProc);

}
