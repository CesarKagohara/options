package br.org.cipbancos.rrc.dao;

import java.util.Date;

public interface AtlanteDAO {

   Integer buscarQtdInputRecordsPorAtlRootId(Long atlRootId, Date dtRef);

}