package br.org.cipbancos.rrc.bean.rrc0019;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoArrajPgto;

@XStreamAlias("Grupo_RRC0019_ArrajPgto")
public class GrupoRRC0019ArrajPgto extends ErrorCodeBean implements GrupoArrajPgto {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CodInstitdrArrajPgto")
    private SPBString codInstitdrArrajPgto;

    public SPBString getCodInstitdrArrajPgto() {
        return codInstitdrArrajPgto;
    }

    public void setCodInstitdrArrajPgto(SPBString codInstitdrArrajPgto) {
        this.codInstitdrArrajPgto = codInstitdrArrajPgto;
    }

    @Override
    public String toString() {
        return "GrupoRRC0019ArrajPgto{" +
                "codInstitdrArrajPgto=" + codInstitdrArrajPgto +
                '}';
    }
}
