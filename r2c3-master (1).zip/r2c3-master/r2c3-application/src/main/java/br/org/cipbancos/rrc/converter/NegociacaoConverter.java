package br.org.cipbancos.rrc.converter;

import br.org.cipbancos.atlante.api.ContextPropertyKeys;
import br.org.cipbancos.atlante.api.CustomTransportType;
import br.org.cipbancos.atlante.api.handler.Context;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.*;
import br.org.cipbancos.rrc.bean.rrc0005.*;
import br.org.cipbancos.rrc.bean.rrc0019.RRC0019;
import br.org.cipbancos.rrc.dominio.SituacaoAtivoInativo;
import br.org.cipbancos.rrc.enums.AlcanceContrato;
import br.org.cipbancos.rrc.enums.IcSit;
import br.org.cipbancos.rrc.funcional.Converter;
import br.org.cipbancos.rrc.vo.*;

/**
 * Classe utilitária para converter informações de Negociações.
 *
 * @author otavio.ferreira
 * @since 1.0
 */
public class NegociacaoConverter {

    private NegociacaoConverter() {
    }

    public static Converter<RRC0005, Negociacao> rrc0005EmNegociacao() {
        return origem -> {
            Negociacao destino = new Negociacao();

            destino.setCodMsg(origem.getCodMsg());
            destino.setIdentdPartPrincipal(origem.getIdentdPartPrincipal());
            destino.setIdentdPartAdmtd(origem.getIdentdPartAdmtd());
            destino.setIdentdNegcRecbvl(origem.getIdentdNegcRecbvl());
            destino.setIdentdOp(origem.getIdentdOp());
            destino.setIndrTpNegc(origem.getIndrTpNegc());
            destino.setDtVencOp(origem.getDtVencOp());
            destino.setVlrTotLimSldDevdr(origem.getVlrTotLimSldDevdr());
            destino.setIndrGestER(origem.getIndrGestER());
            destino.setIndrRegrDivs(origem.getIndrRegrDivs());
            destino.setIndrActeIncondlOp(origem.getIndrActeIncondlOp());
            destino.setIndrIA(origem.getIndrIA());

            if (origem.getGrupoGestER() != null) {
                NegociacaoGestaoRegistradora registradora = new NegociacaoGestaoRegistradora();

                origem.getGrupoGestER().getListagrupoRRC0005Titlar().forEach(titularRegistradora -> {
                    TitularGestaoRegistradora titular = new TitularGestaoRegistradora();
                    titular.setCnpjCnpjBaseCpfTitlar(titularRegistradora.getcNPJCNPJBaseCPFTitlar());
                    titular.setVlrPercTotOpUniddRecbvl(titularRegistradora.getVlrPercTotOpUniddRecbvl());
                    titular.setDtIniOp(titularRegistradora.getDtIniOp());
                    titular.setDtFimOp(titularRegistradora.getDtFimOp());
                    titular.setCnpjCpfTitlarCt(titularRegistradora.getCNPJCPFTitlarCt());
                    titular.setIspbBcoRecbdr(titularRegistradora.getISPBBcoRecbdr());
                    titular.setTpCt(titularRegistradora.getTpCt());
                    titular.setAg(titularRegistradora.getAg());
                    titular.setCt(titularRegistradora.getCt());
                    titular.setCtPgto(titularRegistradora.getCtPgto());

                    titularRegistradora.getListagrupoRRC0005ArrajPgto().forEach(arrPagto -> {
                        ArranjoTitularGestaoRegistradora arranjo = new ArranjoTitularGestaoRegistradora();
                        arranjo.setCodInstitdrArrjPgto(arrPagto.getCodInstitdrArrajPgto());

                        titular.getListaGrupoArrajPgto().add(arranjo);
                    });

                    registradora.getTitulares().add(titular);
                });

                destino.setGestER(registradora);
            }

            if (origem.getGrupoGestPart() != null) {
                NegociacaoGestaoParticipante participante = new NegociacaoGestaoParticipante();

                origem.getGrupoGestPart().getListagrupoRRC0005Titlar().forEach(titularParticipante -> {
                    TitularGestaoParticipante titular = new TitularGestaoParticipante();
                    titular.setCnpjCnpjBaseCpfTitlar(titularParticipante.getCNPJCNPJBaseCPFTitlar());

                    titularParticipante.getListagrupoRRC0005DomclBanc().forEach(domicilioParticipante -> {
                        DomicilioTitularGestaoParticipante domicilio = new DomicilioTitularGestaoParticipante();
                        domicilio.setCnpjCpfTitlarCt(domicilioParticipante.getCNPJCPFTitlarCt());
                        domicilio.setIspbBcoRecbdr(domicilioParticipante.getISPBBcoRecbdr());
                        domicilio.setTpCt(domicilioParticipante.getTpCt());
                        domicilio.setAg(domicilioParticipante.getAg());
                        domicilio.setCt(domicilioParticipante.getCt());
                        domicilio.setCtPgto(domicilioParticipante.getCtPgto());

                        domicilioParticipante.getListagrupoRRC0005RegRecbvl().forEach(registroDomicilio -> {
                            RegistroRecebivelDomicilioTitularGestaoParticipante registro = new RegistroRecebivelDomicilioTitularGestaoParticipante();

                            registro.setCnpjCpfUsuFinalRecbdr(registroDomicilio.getCNPJCPFUsuFinalRecbdr());
                            registro.setCnpjCpfTitular(registroDomicilio.getCNPJCPFTitular());
                            registro.setCodInstitdrArrjPgto(registroDomicilio.getCodInstitdrArrajPgto());
                            registro.setDtPrevtLiquid(registroDomicilio.getDtPrevtLiquid());
                            registro.setVlrPercNegcd(registroDomicilio.getVlrPercNegcd());
                            registro.setDtAntec(registroDomicilio.getDtAntec());
                            registro.setDtEftLiquidAntec(registroDomicilio.getDtEftLiquidAntec());
                            registro.setVlrEftLiquidAntec(registroDomicilio.getVlrEftLiquidAntec());
                            registro.setVlrAntecNRegtd(registroDomicilio.getVlrAntecNRegtd());

                            domicilio.getRegistrosRecebiveis().add(registro);
                        });

                        titular.getDomicilios().add(domicilio);
                    });

                    participante.getTitulares().add(titular);
                });

                destino.setGestPart(participante);
            }

            return destino;
        };
    }

//    public static Converter<Negociacao, RRC0005> negociacaoEmRRC0005() {
//        return origem -> {
//            RRC0005 destino = new RRC0005();
//
//            destino.setCodMsg(origem.getCodMsg());
//            destino.setIdentdPartPrincipal(origem.getIdentdPartPrincipal());
//            destino.setIdentdPartAdmtd(origem.getIdentdPartAdmtd());
//            destino.setIdentdNegcRecbvl(origem.getIdentdNegcRecbvl());
//            destino.setIdentdOp(origem.getIdentdOp());
//            destino.setIndrTpNegc(origem.getIndrTpNegc());
//            destino.setDtVencOp(origem.getDtVencOp());
//            destino.setVlrTotLimSldDevdr(origem.getVlrTotLimSldDevdr());
//            destino.setIndrGestER(origem.getIndrGestER());
//            destino.setIndrRegrDivs(origem.getIndrRegrDivs());
//            destino.setIndrActeIncondlOp(origem.getIndrActeIncondlOp());
//            destino.setIndrIA(origem.getIndrIA());
//
//            if (origem.getGestER() != null) {
//                GrupoRRC0005GestER registradora = new GrupoRRC0005GestER();
//
//                if (origem.getGestER().hasErrorCode())
//                    registradora.setErrorCode(origem.getGestER().getErrorCode());
//
//                origem.getGestER().getTitulares().forEach(titularRegistradora -> {
//                    GrupoRRC0005Titlar titular = new GrupoRRC0005Titlar();
//                    titular.setcNPJCNPJBaseCPFTitlar(titularRegistradora.getCnpjCnpjBaseCpfTitlar());
//                    titular.setVlrPercTotOpUniddRecbvl(titularRegistradora.getVlrPercTotOpUniddRecbvl());
//                    titular.setDtIniOp(titularRegistradora.getDtIniOp());
//                    titular.setDtFimOp(titularRegistradora.getDtFimOp());
//                    titular.setcNPJCPFTitlarCt(titularRegistradora.getCnpjCpfTitlarCt());
//                    titular.setiSPBBcoRecbdr(titularRegistradora.getIspbBcoRecbdr());
//                    titular.setTpCt(titularRegistradora.getTpCt());
//                    titular.setAg(titularRegistradora.getAg());
//                    titular.setCt(titularRegistradora.getCt());
//                    titular.setCtPgto(titularRegistradora.getCtPgto());
//
//                    titularRegistradora.getArranjos().forEach(arrPagto -> {
//                        GrupoRRC0005ArrajPgto arranjo = new GrupoRRC0005ArrajPgto();
//                        arranjo.setCodInstitdrArrajPgto(arrPagto.getCodInstitdrArrjPgto());
//
//                        titular.getListagrupoRRC0005ArrajPgto().add(arranjo);
//                    });
//
//                    registradora.getListagrupoRRC0005Titlar().add(titular);
//                });
//
//                destino.setGrupoRRC0005GestER(registradora);
//            }
//
//            if (origem.getGestPart() != null) {
//                GrupoRRC0005GestPart participante = new GrupoRRC0005GestPart();
//
//                if (origem.getGestPart().hasErrorCode())
//                    participante.setErrorCode(origem.getGestPart().getErrorCode());
//
//                origem.getGestPart().getTitulares().forEach(titularParticipante -> {
//                    GrupoRRC0005TitlarGestPart titular = new GrupoRRC0005TitlarGestPart();
//                    titular.setCNPJCNPJBaseCPFTitlar(titularParticipante.getCnpjCnpjBaseCpfTitlar());
//
//                    titularParticipante.getDomicilios().forEach(domicilioParticipante -> {
//                        GrupoRRC0005DomclBanc domicilio = new GrupoRRC0005DomclBanc();
//                        domicilio.setcNPJCPFTitlarCt(domicilioParticipante.getCnpjCpfTitlarCt());
//                        domicilio.setiSPBBcoRecbdr(domicilioParticipante.getIspbBcoRecbdr());
//                        domicilio.setTpCt(domicilioParticipante.getTpCt());
//                        domicilio.setAg(domicilioParticipante.getAg());
//                        domicilio.setCt(domicilioParticipante.getCt());
//                        domicilio.setCtPgto(domicilioParticipante.getCtPgto());
//
//                        domicilioParticipante.getRegistrosRecebiveis().forEach(registroDomicilio -> {
//                            GrupoRRC0005GrupoRegRecbvl registro = new GrupoRRC0005GrupoRegRecbvl();
//
//                            registro.setcNPJCPFUsuFinalRecbdr(registroDomicilio.getCnpjCpfUsuFinalRecbdr());
//                            registro.setcNPJCPFTitular(registroDomicilio.getCnpjCpfTitular());
//                            registro.setCodInstitdrArrajPgto(registroDomicilio.getCodInstitdrArrjPgto());
//                            registro.setDtPrevtLiquid(registroDomicilio.getDtPrevtLiquid());
//                            registro.setVlrPercNegcd(registroDomicilio.getVlrPercNegcd());
//                            registro.setDtAntec(registroDomicilio.getDtAntec());
//                            registro.setDtEftLiquidAntec(registroDomicilio.getDtEftLiquidAntec());
//                            registro.setVlrEftLiquidAntec(registroDomicilio.getVlrEftLiquidAntec());
//                            registro.setVlrAntecNRegtd(registroDomicilio.getVlrAntecNRegtd());
//
//                            domicilio.getListagrupoRRC0005RegRecbvl().add(registro);
//                        });
//
//                        titular.getListagrupoRRC0005DomclBanc().add(domicilio);
//                    });
//
//                    participante.getListagrupoRRC0005Titlar().add(titular);
//                });
//
//                destino.setGrupoRRC0005GestPart(participante);
//            }
//
//            return destino;
//        };
//    }

    public static Converter<GrupoNegcRecbvl, Operacao> emOperacao(Context context, ParticipanteVO participanteVO, Integer idFuncdd) {
        return origem -> {
            Operacao destino = new Operacao();

            destino.setIdOp(origem.getIdentdOp() != null ? Long.parseLong(origem.getIdentdOp().getValue()) : null);
            //            destino.setNrCnpjRegtdr(Constantes.CNPJ_R2C3);
            destino.setIdNegcRecbvExtn(
                    origem.getIdentdNegcRecbvl() != null ? origem.getIdentdNegcRecbvl().getValue() : null);
            destino.setIcTpNegc(origem.getIndrTpNegc().getValue());
            destino.setDtVencOp(SPBConverter.spbLocalDateToSqlDate(origem.getDtVencOp()));
            destino.setNrLimConcdSldDevdr(origem.getVlrTotLimSldDevdr().getValue());
            destino.setIcGesteNtRegtdr(origem.getIndrGestER().getValue());
            destino.setIcRegrDivs(origem.getIndrRegrDivs().getValue());

            if (origem instanceof GrupoNegcRecbvl0019) {
                destino.setIcAlcccontrto((null == ((GrupoNegcRecbvl0019)origem).getIndrAlcancContrtoCreddrSub() ?
                        AlcanceContrato.ESPECIFICO.getValue() : ((GrupoNegcRecbvl0019)origem).getIndrAlcancContrtoCreddrSub().getValue()));
                if(((GrupoNegcRecbvl0019)origem).getIndrAutcCess() != null) {
                    destino.setIcAutcCess(((GrupoNegcRecbvl0019)origem).getIndrAutcCess().getValue());
                }
            } else {
                destino.setIcAlcccontrto(AlcanceContrato.ESPECIFICO.getValue());
            }

            destino.setIcActeOp(origem.getIndrActeIncondlOp().getValue());

            destino.setIcTpOp(origem.getIndrIA().getValue());
            destino.setIdIntrdd(0L);
            destino.setIcSit(IcSit.ACEITO.getValue());
            destino.setIdPartPrincipal(participanteVO.getIdPartPrinc().longValue());
            destino.setIdPartAdmtd(participanteVO.getIdPartAdm().longValue());
            destino.setIdPartOrigdr(participanteVO.getIdPartAdm().longValue());
            destino.setIdAtlRoot(context.getRootId());

            if (origem instanceof RRC0019) {
                RRC0019 rrc0019 = (RRC0019)origem;
                if (rrc0019.getContrato() != null) {
                    destino.setIdEfeitoContrato(rrc0019.getContrato().getDadosControle().getIdEfeitoContrato());
                }
            } else if (origem instanceof RRC0005) {
                RRC0005 rrc0005 = (RRC0005)origem;
                if (rrc0005.getNotificacaoPosContratada() != null) {
                    destino.setIdEfeitoContrato(rrc0005.getNotificacaoPosContratada().getIdComunicacao());
                }
            }

            String nmNuopApi = (String) context.getProperties().get(ContextPropertyKeys.LOGICAL_IDENTIFIER);
            if (null == nmNuopApi || nmNuopApi.isEmpty()) {
                nmNuopApi = (String) context.getProperties().get(ContextPropertyKeys.PHYSICAL_IDENTIFIER);
            }
            destino.setNmArqNuOpApi(nmNuopApi);

            destino.setDtRefSistIncl(new java.sql.Date(context.getBatchReferenceDate().getTime()));
            destino.setDtRefSistUltAlt(new java.sql.Date(context.getBatchReferenceDate().getTime()));

            destino.setIdFuncdd(idFuncdd.longValue());

            return destino;
        };
    }

    public static Converter<GrupoTitlar, OperacaoTitularDomicilio>
    titularGestaoRegistradoraEmOperacaoTitularDomicilio(Context context, Operacao operacao, String codArranjo) {
        return origem -> {
            OperacaoTitularDomicilio destino = new OperacaoTitularDomicilio();
            CustomTransportType canal = (CustomTransportType) context.getProperties().get(ContextPropertyKeys.TRANSPORT_TYPE);

            final String nmNuopApi = null == context.getProperties().get(ContextPropertyKeys.LOGICAL_IDENTIFIER)
                    || ((String) context.getProperties().get(ContextPropertyKeys.LOGICAL_IDENTIFIER)).isEmpty() ?
                    (String) context.getProperties().get(ContextPropertyKeys.PHYSICAL_IDENTIFIER) :
                    (String) context.getProperties().get(ContextPropertyKeys.LOGICAL_IDENTIFIER);

            destino.setIdOperacao(operacao.getIdOp());
            destino.setNrCpfCnpjTitular(origem.getcNPJCNPJBaseCPFTitlar().getValue());
            destino.setNrCpfCnpjTitularConta(origem.getCNPJCPFTitlarCt().getValue());
            destino.setIspbBancoRecebedor(origem.getISPBBcoRecbdr().getValue());
            destino.setTipoConta(origem.getTpCt().getValue());
            destino.setAgencia((null == origem.getAg() ? null : Integer.parseInt(origem.getAg().getValue())));
            destino.setConta((null == origem.getCt() ? null : Long.parseLong(origem.getCt().getValue())));
            destino.setContaPagamento((null == origem.getCtPgto() ? null : origem.getCtPgto().getValue()));
            destino.setDtIniOp((null == origem.getDtIniOp() ? null : origem.getDtIniOp().getValue().toDate()));
            destino.setDtFimOp((null == origem.getDtFimOp() ? null : origem.getDtFimOp().getValue().toDate()));
            destino.setIdPartPrincipal(operacao.getIdPartPrincipal());
            destino.setIdPartAdmtd(operacao.getIdPartAdmtd());
            destino.setIdPartOrigdr(operacao.getIdPartAdmtd());
            destino.setIdAtlRoot(context.getRootId());
            destino.setNmArqNuopApi(nmNuopApi);
            destino.setCanal(canal.getValue());
            destino.setIdFuncdd(operacao.getIdFuncdd());
            destino.setDtRefSistIncl(context.getBatchReferenceDate());
            destino.setDtRefSistUltAlt(context.getBatchReferenceDate());
            destino.setNrVlrTotOpUniddRecbv(origem.getVlrPercTotOpUniddRecbvl().getValue());
            destino.setIcSit(SituacaoAtivoInativo.ATIVO.getValue());

            return destino;
        };
    }

    public static Converter<NegociacaoR1, RRC0005R1> emRRC0005R1() {
        return origem -> {
            RRC0005R1 destino = new RRC0005R1();

            destino.setCodMsg(new SPBString("RRC0005R1"));
            destino.setSitRetReq(origem.getSitRetReq());
            destino.setIdentdPartPrincipal(origem.getIdentPartPrincipal());
            destino.setIdentdPartAdmtd(origem.getIdentPartAdmtd());
            destino.setIdentdNegcRecbvl(origem.getIdentdNegcRecbvl());
            destino.setIdentdOp(origem.getIdentdOp());

            if (origem.possuiNegociacaoAceita()) {
                GrupoRRC0005R1NegcRecbvlActo negAceita = new GrupoRRC0005R1NegcRecbvlActo();

                if (!origem.getNegociacaoAceita().getListaRegRecbvl().isEmpty()) {
                    origem.getNegociacaoAceita().getListaRegRecbvl().forEach(unidade -> {
                        GrupoRRC0005R1RegRecbvl urConstituida =
                                UnidadeRecebivelConverter.emURConstituida005R1().convert(unidade);
                        negAceita.getListaGrupoRRC0005R1RegRecbvl().add(urConstituida);
                    });
                }

                if (!origem.getNegociacaoAceita().getListaConstitr().isEmpty()) {
                    origem.getNegociacaoAceita().getListaConstitr().forEach(unidade -> {
                        GrupoRRC0005R1Constitr urAConstituir =
                                UnidadeRecebivelConverter.emURAConstituir005R1().convert(unidade);
                        negAceita.getListaGrupoRRC0005R1Constitr().add(urAConstituir);
                    });
                }

                destino.setGrupoRRC0005R1NegcRecbvlActo(negAceita);
            }

            if (origem.possuiNegociacaoRecusada() || origem.getNegociacaoRecusada().hasErrorCode()) {
                GrupoRRC0005R1NegcRecbvlRecsdo negRecusada = new GrupoRRC0005R1NegcRecbvlRecsdo();

                if (origem.getNegociacaoRecusada().hasErrorCode())
                    negRecusada.setErrorCode(origem.getNegociacaoRecusada().getErrorCode());

                origem.getNegociacaoRecusada().getListaUniddRecbvlDisp().forEach(unidade -> {
                    GrupoRRC0005R1UniddRecbvlDisp urDisponivel =
                            UnidadeRecebivelConverter.emURDisponivel005R1().convert(unidade);
                    negRecusada.getListagrupoRRC0005R1UniddRecbvlDisp().add(urDisponivel);
                });

                destino.setGrupoRRC0005R1NegcRecbvlRecsdo(negRecusada);
            }

            return destino;
        };
    }

    public static Converter<GrupoTitlarGestPart,TitularGestaoParticipante> emTitularGestaoParticipante () {
        return origem -> {
            TitularGestaoParticipante destino = new TitularGestaoParticipante();
            destino.setCnpjCnpjBaseCpfTitlar(origem.getCNPJCNPJBaseCPFTitlar());
            origem.getListaGrupoDomclBanc().forEach(grupoDomicilio -> {
                DomicilioTitularGestaoParticipante domicl = new DomicilioTitularGestaoParticipante();
                domicl.setAg(grupoDomicilio.getAg());
                domicl.setCnpjCpfTitlarCt(grupoDomicilio.getCNPJCPFTitlarCt());
                domicl.setCt(grupoDomicilio.getCt());
                domicl.setCtPgto(grupoDomicilio.getCtPgto());
                domicl.setIspbBcoRecbdr(grupoDomicilio.getISPBBcoRecbdr());
                domicl.setTpCt(grupoDomicilio.getTpCt());

                grupoDomicilio.getListaGrupoRegRecbvl().forEach(grupoRegRecbvl -> {
                    RegistroRecebivelDomicilioTitularGestaoParticipante recb = new RegistroRecebivelDomicilioTitularGestaoParticipante();
                    recb.setCnpjCpfTitular(grupoRegRecbvl.getCNPJCPFTitular());
                    recb.setCnpjCpfUsuFinalRecbdr(grupoRegRecbvl.getCNPJCPFUsuFinalRecbdr());
                    if (grupoRegRecbvl instanceof GrupoRegRecbvl0019) {
                        recb.setCnpjCreddSub(((GrupoRegRecbvl0019)grupoRegRecbvl).getCNPJCreddrSub());
                    }
                    recb.setCodInstitdrArrjPgto(grupoRegRecbvl.getCodInstitdrArrajPgto());
                    recb.setDtPrevtLiquid(grupoRegRecbvl.getDtPrevtLiquid());
                    recb.setVlrPercNegcd(grupoRegRecbvl.getVlrPercNegcd());

                    domicl.getRegistrosRecebiveis().add(recb);
                });

                destino.getDomicilios().add(domicl);
            });

            return destino;
        };
    }

    public static Converter<GrupoTitlar,TitularGestaoRegistradora> emTitularGestaoRegistradora () {
        return origem -> {
            TitularGestaoRegistradora destino = new TitularGestaoRegistradora();
            destino.setAg(origem.getAg());
            destino.setCnpjCnpjBaseCpfTitlar(origem.getcNPJCNPJBaseCPFTitlar());
                destino.setCnpjCpfTitlarCt(origem.getCNPJCPFTitlarCt());
            destino.setCt(origem.getCt());
            destino.setCtPgto(origem.getCtPgto());
            destino.setDtIniOp(origem.getDtIniOp());
            destino.setDtFimOp(origem.getDtFimOp());
            destino.setIspbBcoRecbdr(origem.getISPBBcoRecbdr());
            destino.setTpCt(origem.getTpCt());
            destino.setVlrPercTotOpUniddRecbvl(origem.getVlrPercTotOpUniddRecbvl());

            origem.getListaGrupoArrajPgto().forEach(grupoArrajPgto -> {
                ArranjoTitularGestaoRegistradora arrj = new ArranjoTitularGestaoRegistradora();
                arrj.setCodInstitdrArrjPgto(grupoArrajPgto.getCodInstitdrArrajPgto());

                destino.getListaGrupoArrajPgto().add(arrj);
            });

            if (origem instanceof GrupoTitlar0019) {
                ((GrupoTitlar0019)origem).getListaGrupoCreddrSub().forEach(grupoCreddrSub -> {
                    CredenciadoraTitularGestaoRegistradora creddrSub = new CredenciadoraTitularGestaoRegistradora();
                    creddrSub.setCnpjCreddSub(grupoCreddrSub.getCNPJCreddrSub());

                    destino.getCredenciadoras().add(creddrSub);
                });

                ((GrupoTitlar0019)origem).getListaGrupoUsuFinalRecbdr().forEach(grupoUsuFinalRecbdr -> {
                    UsuarioFinalTitularGestaoRegistradora usu = new UsuarioFinalTitularGestaoRegistradora();
                    usu.setCnpjCnpjBaseCpfUsuFinalRecbdr(grupoUsuFinalRecbdr.getCNPJCNPJBaseCPFUsuFinalRecbdr());

                    destino.getUsuariosFinais().add(usu);
                });
            }

            return destino;
        };
    }
}
