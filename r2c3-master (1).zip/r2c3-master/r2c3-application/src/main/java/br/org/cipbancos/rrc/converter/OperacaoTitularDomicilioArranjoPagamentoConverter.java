package br.org.cipbancos.rrc.converter;

import br.org.cipbancos.rrc.funcional.Converter;
import br.org.cipbancos.rrc.util.DateUtil;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilioArranjoPagamento;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

public class OperacaoTitularDomicilioArranjoPagamentoConverter {

    public static Converter<OperacaoTitularDomicilioArranjoPagamento, MapSqlParameterSource>
    emOperacaoTitularDomicilioArranjoParaInsercao() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();
            parametros.addValue("ID_OP", origem.getIdOp());
            parametros.addValue("ID_OP_TITLAR_DOMCL", origem.getIdOpTitlarDomcl());
            parametros.addValue("CD_ARRJ_PGTO", origem.getCdArrjoPgto());
            parametros.addValue("DT_REF_SIST_INCL", origem.getDtRefSistIncl() == null ? null : origem.getDtRefSistIncl().toDate());
            parametros.addValue("DT_REF_SIST_ULT_ALT", origem.getDtRefSistUltAlt() == null ? null :origem.getDtRefSistUltAlt().toDate());
            parametros.addValue("ID_ATL_ROOT", origem.getIdAtlRoot());
            parametros.addValue("NM_ARQ_NUOP_API", origem.getNmArqNuOpApi());
            parametros.addValue("ID_FUNCDD", origem.getIdFuncdd());
            return parametros;
        };
    }
}
