package br.org.cipbancos.rrc.dao;

public enum QueryResource {
	
	R2C3,CTZ,CPC,ATL,R2C3_2,R2C3_3;

}
