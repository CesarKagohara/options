package br.org.cipbancos.rrc.bean.arrc023;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.PartPrincXPartAdm;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author anderson.martins
 * @since 1.0.0
 */
@XStreamAlias("Grupo_ARRC023_CanceltNegcRecbvl")
public class GrupoARRC023CanceltNegcRecbvl extends ErrorCodeBean implements Serializable, PartPrincXPartAdm {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC023_NegcRecbvl")
    private List<GrupoARRC023NegcRecbvl> listaGrupoARRC023NegcRecbvl = new ArrayList<GrupoARRC023NegcRecbvl>();

    @XStreamOmitField
    private String recordId;

    @Override
    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    @Override
    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public List<GrupoARRC023NegcRecbvl> getListaGrupoARRC023NegcRecbvl() {
        return listaGrupoARRC023NegcRecbvl;
    }

    public void setListaGrupoARRC023NegcRecbvl(List<GrupoARRC023NegcRecbvl> listaGrupoARRC023NegcRecbvl) {
        this.listaGrupoARRC023NegcRecbvl = listaGrupoARRC023NegcRecbvl;
    }

    @Override
    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }
}
