package br.org.cipbancos.rrc.bean.rrc0010;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_RRC0010R1_UniddRecbvl")
public class GrupoRRC0010R1UniddRecbvl extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("DtPrevtLiquid")
    private SPBLocalDate dtPrevtLiquid;

    @XStreamAlias("VlrTot")
    private SPBBigDecimal vlrTot;

    @XStreamAlias("IndrDomcl")
    private SPBString indrDomcl;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0010_Titlar")
    private List<GrupoRRC0010Titlar> listagrupoRRC0010Titlar = new ArrayList<GrupoRRC0010Titlar>();

    public SPBLocalDate getDtPrevtLiquid() {
        return dtPrevtLiquid;
    }

    public void setDtPrevtLiquid(SPBLocalDate dtPrevtLiquid) {
        this.dtPrevtLiquid = dtPrevtLiquid;
    }

    public SPBBigDecimal getVlrTot() {
        return vlrTot;
    }

    public void setVlrTot(SPBBigDecimal vlrTot) {
        this.vlrTot = vlrTot;
    }

    public SPBString getIndrDomcl() {
        return indrDomcl;
    }

    public void setIndrDomcl(SPBString indrDomcl) {
        this.indrDomcl = indrDomcl;
    }

    public List<GrupoRRC0010Titlar> getListagrupoRRC0010Titlar() {
        return listagrupoRRC0010Titlar;
    }

    public void setListagrupoRRC0010Titlar(List<GrupoRRC0010Titlar> listagrupoRRC0010Titlar) {
        this.listagrupoRRC0010Titlar = listagrupoRRC0010Titlar;
    }

}
