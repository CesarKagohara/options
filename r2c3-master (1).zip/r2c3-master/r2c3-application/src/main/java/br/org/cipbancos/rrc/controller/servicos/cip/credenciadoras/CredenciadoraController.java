package br.org.cipbancos.rrc.controller.servicos.cip.credenciadoras;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import br.org.cipbancos.atlante.api.ApplicationErrorAPIException;
import br.org.cipbancos.atlante.api.handler.BatchContext;
import br.org.cipbancos.atlante.api.handler.Context;
import br.org.cipbancos.atlante.api.handler.ContextLocator;
import br.org.cipbancos.atlante.config.HttpTransportConfig;
import br.org.cipbancos.atlante.session.AtlanteSession;
import br.org.cipbancos.atlante.util.PartyUtility;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLong;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.rrc0005.RRC0005;
import br.org.cipbancos.rrc.bean.rrc0006.RRC0006;
import br.org.cipbancos.rrc.bean.rrc0008.GrupoRRC0008NegcRecbvl;
import br.org.cipbancos.rrc.bean.rrc0008.RRC0008;
import br.org.cipbancos.rrc.bean.rrc0012.GrupoRRC0012RegRecbvl;
import br.org.cipbancos.rrc.bean.rrc0012.RRC0012;
import br.org.cipbancos.rrc.dominio.ErroValidacao;
import br.org.cipbancos.rrc.enums.Constantes;
import br.org.cipbancos.rrc.enums.DateTimeUtils;
import br.org.cipbancos.rrc.enums.IndicadorSimNao;
import br.org.cipbancos.rrc.enums.ParametroConfiguracao;
import br.org.cipbancos.rrc.enums.TipoFuncionalidade;
import br.org.cipbancos.rrc.handler.PaginacaoHandler;
import br.org.cipbancos.rrc.handler.rrc0008.RRC0008Handler;
import br.org.cipbancos.rrc.handler.rrc0012.RRC0012Handler;
import br.org.cipbancos.rrc.negocio.ConjuntoUnidadeRecebivelDisponivelNegocio;
import br.org.cipbancos.rrc.negocio.ParametroConfiguracaoSistemaNegocio;
import br.org.cipbancos.rrc.negocio.RegistroOperacaoStageNegocio;
import br.org.cipbancos.rrc.util.ListUtil;
import br.org.cipbancos.rrc.util.PaginacaoUtil;
import br.org.cipbancos.rrc.vo.GrupoRegOpStg;
import br.org.cipbancos.rrc.vo.ParticipanteVO;
import br.org.cipbancos.rrc.vo.ResultadoPaginado;

import br.org.cip.api.r2c3.CredenciadoraApi;
import br.org.cip.api.r2c3.model.ConjuntoUnidadesRecebiveisChave;
import br.org.cip.api.r2c3.model.Erro;
import br.org.cip.api.r2c3.model.GarantiaCredenciadora;
import br.org.cip.api.r2c3.model.MessageListArrayOutput;
import br.org.cip.api.r2c3.model.OperacaoCancelamentoCredenciadora;
import br.org.cip.api.r2c3.model.OperacaoCredenciadora;
import br.org.cip.api.r2c3.model.OperacaoCredenciadoraBase;
import br.org.cip.api.r2c3.model.OperacaoERCredenciadora;
import br.org.cip.api.r2c3.model.OperacaoPartCredenciadora;
import br.org.cip.api.r2c3.model.ResultadoGarantiaCredenciadora;
import br.org.cip.api.r2c3.model.UnidadeRecebivelAConstituirOperacaoCredenciadora;
import br.org.cip.api.r2c3.model.UnidadeRecebivelDisponivelCredenciadora;
import br.org.cip.api.r2c3.model.UnidadeRecebivelOperacaoCredenciadora;
import br.org.cip.api.r2c3.model.UnidadeRecebivelPreviaOperacaoCredenciadora;
import br.org.cip.arche.commons.library.exceptions.ArcConditionalException;

@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS)
@Controller
public class CredenciadoraController implements CredenciadoraApi {

    private static final Logger LOG = LoggerFactory.getLogger(CredenciadoraController.class);
    private static final String RRC008_TYPE = "RRC0008";
    @Autowired
    private RRC0008Handler rrc0008Handler;

    @Autowired
    private RRC0012Handler rrc0012Handler;

    @Autowired
    private PaginacaoHandler paginacaoHandler;

    @Autowired
    private PaginacaoUtil paginacaoUtil;

    @Autowired
    private RegistroOperacaoStageNegocio registroOperacaoStageNegocio;

    @Autowired
    private ConjuntoUnidadeRecebivelDisponivelNegocio conjuntoUnidadeRecebivelDisponivelNegocio;

    @Autowired
    private ParametroConfiguracaoSistemaNegocio parametroSistemaNegocio;

    private Context getContext() {
        return ContextLocator.getContext();
    }

    @Override
    public ResponseEntity<Void> deleteCredenciadoraOperacoesIdentdOp(String xJwsSignature, String identdOp, OperacaoCancelamentoCredenciadora operacaoCancelamentoCredenciadora, String acceptEncoding, String contentEncoding) {
        Context ctx = getContext();
        RRC0006 rrc0006 = criarRRC0006(ctx, identdOp, operacaoCancelamentoCredenciadora);
        BatchContext batchContext = ctx.createBatch(TipoFuncionalidade.RRC0006.getValue());
        batchContext.addJob().addRecord(rrc0006);
        return new ResponseEntity<>(HttpStatus.ACCEPTED);
    }

    private RRC0006 criarRRC0006(Context ctx, String identdOp, OperacaoCancelamentoCredenciadora operacaoCancelamentoCredenciadora) {
        RRC0006 rrc0006 = new RRC0006();
        rrc0006.setCodMsg(new SPBString(TipoFuncionalidade.RRC0006.getValue()));
        rrc0006.setIdentdOp(new SPBString(identdOp));
        rrc0006.setIdentdPartPrincipal(new SPBString(PartyUtility.partyIdToIspb(ctx.getPartyId())));
        String partyAdmin = PartyUtility.partyIdToIspb(
                Integer.valueOf(ctx.getProperties().get(HttpTransportConfig.HEADER_PARTY_ADMIN_ID).toString()));
        rrc0006.setIdentdPartAdmtd(new SPBString(partyAdmin));
        rrc0006.setIdentdNegcRecbvl(new SPBString(operacaoCancelamentoCredenciadora.getIdentdNegcRecbvl()));
        rrc0006.setIdentdOp(new SPBString(identdOp));
        String identdTitular = operacaoCancelamentoCredenciadora.getCnpjOuCnpjBaseOuCpfTitlar();
        if (identdTitular != null) {
            rrc0006.setCnpjCnpjBaseCpfTitlar(new SPBString(identdTitular));
            rrc0006.setIndrCancelVlrTotal(new SPBString(IndicadorSimNao.NAO.getValue()));
        }
        else {
            rrc0006.setIndrCancelVlrTotal(new SPBString(IndicadorSimNao.SIM.getValue()));
        }
        return rrc0006;
    }

    @Override
    public ResponseEntity<ResultadoGarantiaCredenciadora> postCredenciadoraOperacoesIdentdOpSolicitacoesDesconstituicaoGarantia(String xJwsSignature, String identdOp, GarantiaCredenciadora garantiaCredenciadora, String acceptEncoding, String contentEncoding) {
        LOG.info(
                "Iniciando processamento de Desconstituição de Garantia RRC0012 via HTTP. GarantiaCredenciadora {} e identdOp {}.",
                garantiaCredenciadora, identdOp);
        Context ctx = getContext();

        RRC0012 rrc0012 = new RRC0012();
        rrc0012.setCodMsg(new SPBString(TipoFuncionalidade.RRC0012.getValue()));
        rrc0012.setIdentdOp(new SPBString(identdOp));
        rrc0012.setIdentdPartPrincipal(new SPBString(PartyUtility.partyIdToIspb(ctx.getPartyId())));
        String partyAdmin = PartyUtility.partyIdToIspb(
                Integer.valueOf(ctx.getProperties().get(HttpTransportConfig.HEADER_PARTY_ADMIN_ID).toString()));
        rrc0012.setIdentdPartAdmtd(new SPBString(partyAdmin));
        rrc0012.setIdentdCtrlReqSolicte(new SPBString(garantiaCredenciadora.getIdentdCtrlReqSolicte()));
        rrc0012.setcNPJCNPJBaseCPFTitlar(new SPBString(garantiaCredenciadora.getCnpjOuCnpjBaseOuCpfTitlar()));

        //Preenchimento do grupo
        List<GrupoRRC0012RegRecbvl> grupoRRC0012RegRecbvls = new ArrayList<>();
        garantiaCredenciadora.getListaUnidadesRecebiveis().forEach(unidadeRecebivelGarantia -> {
            GrupoRRC0012RegRecbvl grupoRRC0012RegRecbvl = new GrupoRRC0012RegRecbvl();
            grupoRRC0012RegRecbvl.setcNPJCreddrSub(new SPBString(unidadeRecebivelGarantia.getCnpjCreddrSub()));
            grupoRRC0012RegRecbvl.setcNPJCPFUsuFinalRecbdr(
                    new SPBString(unidadeRecebivelGarantia.getCnpjOuCpfUsuFinalRecbdr()));
            grupoRRC0012RegRecbvl.setcNPJCPFTitular(new SPBString(unidadeRecebivelGarantia.getCnpjOuCpfTitlar()));
            grupoRRC0012RegRecbvl.setCodInstitdrArrajPgto(
                    new SPBString(unidadeRecebivelGarantia.getCodInstitdrArrajPgto()));
            grupoRRC0012RegRecbvl.setDtPrevtLiquid(
                    new SPBLocalDate(DateTimeUtils.toLocalDate(unidadeRecebivelGarantia.getDtPrevtLiquid())));
            grupoRRC0012RegRecbvl.setVlrDescst(
                    new SPBBigDecimal(new BigDecimal(unidadeRecebivelGarantia.getVlrDescst(), MathContext.DECIMAL64)));
            grupoRRC0012RegRecbvls.add(grupoRRC0012RegRecbvl);
        });
        rrc0012.setListagrupoRRC0012RegRecbvl(grupoRRC0012RegRecbvls);

        rrc0012Handler.process(rrc0012, ctx);

        Object o = AtlanteSession.getSession().getHttpRecords().get(0);

        if (o instanceof ResultadoGarantiaCredenciadora) {
            return new ResponseEntity<>((ResultadoGarantiaCredenciadora)o, HttpStatus.OK);
        }

        throw new ApplicationErrorAPIException(o, new ArcConditionalException());
    }

    @Override
    public ResponseEntity<List<OperacaoCredenciadora>> getCredenciadoraOperacoes(String xJwsSignature, String acceptEncoding, String contentEncoding, String cnpjOuCnpjBaseOuCpfUsuFinalRecbdr, String cnpjOuCnpjBaseOuCpfTitlar, Integer numeroPagina, Integer tamanhoPagina, Long identificadorTransacao) {
        Context ctx = getContext();

        RRC0008 rrc0008 = new RRC0008();
        rrc0008.setCodMsg(new SPBString(RRC008_TYPE ));
        rrc0008.setIdentdPartPrincipal(new SPBString(PartyUtility.partyIdToIspb(ctx.getPartyId())));
        String partyAdmin = PartyUtility.partyIdToIspb(
                Integer.valueOf(ctx.getProperties().get(HttpTransportConfig.HEADER_PARTY_ADMIN_ID).toString()));
        rrc0008.setIdentdPartAdmtd(new SPBString(partyAdmin));
        rrc0008.setPaginacao(numeroPagina, tamanhoPagina);
        GrupoRRC0008NegcRecbvl negcRecbvl = new GrupoRRC0008NegcRecbvl();
        if (cnpjOuCnpjBaseOuCpfUsuFinalRecbdr != null) {
            negcRecbvl.setcNPJCNPJBaseCPFUsuFinalRecbdr(new SPBString(cnpjOuCnpjBaseOuCpfUsuFinalRecbdr));
        }
        if (cnpjOuCnpjBaseOuCpfTitlar != null) {
            negcRecbvl.setcNPJCNPJBaseCPFTitlar(new SPBString(cnpjOuCnpjBaseOuCpfTitlar));
        }
        rrc0008.setGrupoRRC0008NegcRecbvl(negcRecbvl);

        List<OperacaoCredenciadora> resultado = null;
        String uri = "";

        if(!Optional.ofNullable(identificadorTransacao).isPresent()) {
            rrc0008Handler.process(rrc0008, ctx);
            Object o = AtlanteSession.getSession().getHttpRecords().get(0);
            if (o instanceof List) {
                resultado = (List<OperacaoCredenciadora>)o;
                paginacaoHandler.insereDadosAPaginar(o, ctx.getRootId());
                if (resultado.isEmpty()) {
                    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
                }
                boolean paramIncluido = false;
                uri = "/v1/credenciadora/operacoes";
                if (cnpjOuCnpjBaseOuCpfUsuFinalRecbdr != null) {
                    uri += "?cnpjOuCnpjBaseOuCpfUsuFinalRecbdr=" + cnpjOuCnpjBaseOuCpfUsuFinalRecbdr;
                    paramIncluido = true;
                }
                if (cnpjOuCnpjBaseOuCpfTitlar != null) {
                    uri += (paramIncluido ? "&" : "?") + "cnpjOuCnpjBaseOuCpfTitlar=" + cnpjOuCnpjBaseOuCpfTitlar;
                }
                uri += "&identificadorTransacao=" + ((identificadorTransacao == null)?ctx.getRootId().toString():identificadorTransacao.toString());
            } else if (o instanceof Erro) {
                return new ResponseEntity(o, HttpStatus.PRECONDITION_FAILED);
            } else {
                LOG.info("RRC0008 ERRO getCredenciadoraOperacoes - Objeto o: {}.", o);
                throw new ApplicationErrorAPIException(o, new ArcConditionalException());
            }
        } else {
            resultado = paginacaoHandler.paginadosOperacaoCredenciadora(identificadorTransacao, tamanhoPagina, numeroPagina);
        }
        ResultadoPaginado resultadoPaginado = paginacaoUtil.paginar(resultado, numeroPagina, tamanhoPagina, uri, ((identificadorTransacao == null)?ctx.getRootId():identificadorTransacao));
        return new ResponseEntity<>(resultadoPaginado.getLista(), resultadoPaginado.getLinkHeader(), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<OperacaoCredenciadora> getCredenciadoraOperacoesIdentdOp(String xJwsSignature, String identdOp, String acceptEncoding, String contentEncoding) {
        Context ctx = getContext();

        RRC0008 rrc0008 = new RRC0008();
        rrc0008.setCodMsg(new SPBString(RRC008_TYPE ));
        rrc0008.setIdentdPartPrincipal(new SPBString(PartyUtility.partyIdToIspb(ctx.getPartyId())));
        String partyAdmin = PartyUtility.partyIdToIspb(
                Integer.valueOf(ctx.getProperties().get(HttpTransportConfig.HEADER_PARTY_ADMIN_ID).toString()));
        rrc0008.setIdentdPartAdmtd(new SPBString(partyAdmin));
        GrupoRRC0008NegcRecbvl negcRecbvl = new GrupoRRC0008NegcRecbvl();
        if (identdOp != null) {
            try {
                negcRecbvl.setIdentdOp(new SPBLong(Long.parseLong(identdOp)));
            } catch (NumberFormatException ne) {
                Erro erro = getIdentdOpErro (identdOp);
                return new ResponseEntity(erro, HttpStatus.PRECONDITION_FAILED);
            }
        }
        rrc0008.setGrupoRRC0008NegcRecbvl(negcRecbvl);
        rrc0008.setCompletavel(true);

        rrc0008Handler.process(rrc0008, ctx);

        if(AtlanteSession.getSession().getHttpRecords() == null || AtlanteSession.getSession().getHttpRecords().size() == 0){
            LOG.info("Sem retorno após esperar o tempo para timeout.");
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        Object o = AtlanteSession.getSession().getHttpRecords().get(0);
        if (o instanceof OperacaoCredenciadora) {
            return new ResponseEntity<>((OperacaoCredenciadora)o, HttpStatus.OK);
        } else if (o instanceof Erro) {
            return new ResponseEntity(o, HttpStatus.PRECONDITION_FAILED);
        }
        LOG.info("RRC0008 ERRO getCredenciadoraOperacoesIdentdOp - Objeto o: {}.", o);
        throw new ApplicationErrorAPIException(o, new ArcConditionalException());
    }

    @Override
    public ResponseEntity<List<UnidadeRecebivelOperacaoCredenciadora>> getCredenciadoraOperacoesIdentdOpUnidadesRecebiveis(String xJwsSignature, String identdOp, String acceptEncoding, String contentEncoding, Integer numeroPagina, Integer tamanhoPagina, Long identificadorTransacao) {
        Context ctx = getContext();
        RRC0008 rrc0008 = new RRC0008();
        rrc0008.setCodMsg(new SPBString(RRC008_TYPE ));
        rrc0008.setIdentdPartPrincipal(new SPBString(PartyUtility.partyIdToIspb(ctx.getPartyId())));
        String partyAdmin = PartyUtility.partyIdToIspb(Integer.valueOf(ctx.getProperties().get(HttpTransportConfig.HEADER_PARTY_ADMIN_ID).toString()));
        rrc0008.setIdentdPartAdmtd(new SPBString(partyAdmin));
        GrupoRRC0008NegcRecbvl negcRecbvl = new GrupoRRC0008NegcRecbvl();
        negcRecbvl.setFiltroConstituido(true);
        if (identdOp != null) {
            try {
                negcRecbvl.setIdentdOp(new SPBLong(Long.parseLong(identdOp)));
            } catch (NumberFormatException ne) {
                Erro erro = getIdentdOpErro (identdOp);
                return new ResponseEntity(erro, HttpStatus.PRECONDITION_FAILED);
            }
        }
        rrc0008.setGrupoRRC0008NegcRecbvl(negcRecbvl);
        rrc0008.setRetornarApenasUrs(true);
        rrc0008.setCompletavel(false);
        rrc0008.setPaginacao(numeroPagina, tamanhoPagina);

        List<UnidadeRecebivelOperacaoCredenciadora> resultado = null;
        String uri = "/credenciadora/operacoes/" + identdOp + "/unidades-recebiveis?identificadorTransacao="
                + ((identificadorTransacao == null)?ctx.getRootId().toString():identificadorTransacao.toString());

        Object o = null;
        if(!Optional.ofNullable(identificadorTransacao).isPresent()) {
            rrc0008Handler.process(rrc0008, ctx);
            o = AtlanteSession.getSession().getHttpRecords().get(0);
            if (o instanceof List) {
                resultado = (List<UnidadeRecebivelOperacaoCredenciadora>)o;
                paginacaoHandler.insereDadosAPaginar(o, ctx.getRootId());
                if (resultado.isEmpty()) {
                    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
                }
            }
        } else {
            resultado = paginacaoHandler.paginadosUnidadeRecebivelOperacaoCredenciadora(((identificadorTransacao == null)?ctx.getRootId():identificadorTransacao), tamanhoPagina, numeroPagina);
        }

        if (resultado instanceof List) {
            ResultadoPaginado resultadoPaginado = paginacaoUtil.paginar(resultado, numeroPagina, tamanhoPagina, uri, ((identificadorTransacao == null)?ctx.getRootId():identificadorTransacao));
            return new ResponseEntity<>(resultadoPaginado.getLista(), resultadoPaginado.getLinkHeader(), HttpStatus.OK);
        } else if (o instanceof Erro) {
            LOG.info("RRC0008 ERRO getCredenciadoraOperacoesIdentdOpUnidadesRecebiveis - Objeto o: {}.", o);
            return new ResponseEntity(o, HttpStatus.PRECONDITION_FAILED);
        } else{
            LOG.info("RRC0008 ERRO getCredenciadoraOperacoesIdentdOpUnidadesRecebiveis - Objeto o: {}.", o);
            throw new ApplicationErrorAPIException(o, new ArcConditionalException());
        }
    }

    @Override
    public ResponseEntity<List<UnidadeRecebivelAConstituirOperacaoCredenciadora>> getCredenciadoraOperacoesIdentdOpUnidadesRecebiveisAConstituir(String xJwsSignature, String identdOp, String acceptEncoding, String contentEncoding, Integer numeroPagina, Integer tamanhoPagina, Long identificadorTransacao) {
        Context ctx = getContext();

        RRC0008 rrc0008 = new RRC0008();
        rrc0008.setCodMsg(new SPBString(RRC008_TYPE ));
        rrc0008.setIdentdPartPrincipal(new SPBString(PartyUtility.partyIdToIspb(ctx.getPartyId())));
        String partyAdmin = PartyUtility.partyIdToIspb(
                Integer.valueOf(ctx.getProperties().get(HttpTransportConfig.HEADER_PARTY_ADMIN_ID).toString()));
        rrc0008.setIdentdPartAdmtd(new SPBString(partyAdmin));
        GrupoRRC0008NegcRecbvl negcRecbvl = new GrupoRRC0008NegcRecbvl();
        if (identdOp != null) {
            try {
                negcRecbvl.setIdentdOp(new SPBLong(Long.parseLong(identdOp)));
            } catch (NumberFormatException ne) {
                Erro erro = getIdentdOpErro (identdOp);
                return new ResponseEntity(erro, HttpStatus.PRECONDITION_FAILED);
            }
        }
        negcRecbvl.setFiltroConstituido(false);
        rrc0008.setGrupoRRC0008NegcRecbvl(negcRecbvl);
        rrc0008.setRetornarApenasUrs(true);
        rrc0008.setCompletavel(false);

        rrc0008.setPaginacao(numeroPagina, tamanhoPagina);

        List<UnidadeRecebivelAConstituirOperacaoCredenciadora> resultado = null;
        String uri = "/credenciadora/operacoes/" + identdOp + "/unidades-recebiveis-a-constituir"
                + "?identificadorTransacao=" + ((identificadorTransacao == null)?ctx.getRootId().toString():identificadorTransacao.toString());

        Object o = null;
        if(!Optional.ofNullable(identificadorTransacao).isPresent()) {
            rrc0008Handler.process(rrc0008, ctx);
            o = AtlanteSession.getSession().getHttpRecords().get(0);
            if (o instanceof List) {
                resultado = (List<UnidadeRecebivelAConstituirOperacaoCredenciadora>)o;
                paginacaoHandler.insereDadosAPaginar(o, ctx.getRootId());
                if (resultado.isEmpty()) {
                    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
                }
            }
        } else {
            resultado = paginacaoHandler.paginadosUnidadeRecebivelAConstituirOperacaoCredenciadora(((identificadorTransacao == null)?ctx.getRootId():identificadorTransacao), tamanhoPagina, numeroPagina);
        }

        if(resultado instanceof List) {
            ResultadoPaginado resultadoPaginado = paginacaoUtil.paginar(resultado, numeroPagina, tamanhoPagina, uri, ((identificadorTransacao == null)?ctx.getRootId():identificadorTransacao));
            return new ResponseEntity<>(resultadoPaginado.getLista(), resultadoPaginado.getLinkHeader(), HttpStatus.OK);
        }else if (o instanceof Erro) {
            LOG.info("RRC0008 ERRO getCredenciadoraOperacoesIdentdOpUnidadesRecebiveisAConstituir - Objeto o: {}.", o);
            return new ResponseEntity(o, HttpStatus.PRECONDITION_FAILED);
        } else{
            LOG.info("RRC0008 ERRO getCredenciadoraOperacoesIdentdOpUnidadesRecebiveisAConstituir - Objeto o: {}.", o);
            throw new ApplicationErrorAPIException(o, new ArcConditionalException());
        }
    }

    @Override
    public ResponseEntity<ConjuntoUnidadesRecebiveisChave> postCredenciadoraConjuntosUnidadesRecebiveis(String xJwsSignature, String acceptEncoding, String contentEncoding) {
        Long id = registroOperacaoStageNegocio.inserirRegOp(PartyUtility.partyIdToIspb(getContext().getPartyId()));
        ConjuntoUnidadesRecebiveisChave conjunto = new ConjuntoUnidadesRecebiveisChave();
        conjunto.setIdentdConjUniddRecbvl(String.format("%019d", id));
        return new ResponseEntity<>(conjunto, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> postCredenciadoraConjuntosUnidadesRecebiveisIdentdConjUniddRecbvlLotesUnidadesRecebiveis(String xJwsSignature, String identdConjUniddRecbvl, List<UnidadeRecebivelPreviaOperacaoCredenciadora> listaUnidadeRecebivelPreviaOperacaoCredenciadora, String acceptEncoding, String contentEncoding) {
        try {
            Long id = registroOperacaoStageNegocio.validarIdOp(getContext().getPartyId(), identdConjUniddRecbvl);
            ParticipanteVO credenciadora = registroOperacaoStageNegocio.validarParticipante(getContext().getPartyId());
            if (listaUnidadeRecebivelPreviaOperacaoCredenciadora != null) {
                List<GrupoRegOpStg> grupos = new ArrayList<>();
                for (UnidadeRecebivelPreviaOperacaoCredenciadora ur : listaUnidadeRecebivelPreviaOperacaoCredenciadora) {
                    GrupoRegOpStg grupo = new GrupoRegOpStg();
                    grupo.setIdRegOpStg(id);
                    grupo.setNrCnpjRegrDest(Constantes.CNPJ_R2C3);
                    grupo.setNrCpfCnpjTitular(ur.getCnpjOuCpfTitlar());
                    grupo.setNrCpfCnpjBaseTitular(ur.getCnpjOuCnpjBaseOuCpfTitlar());
                    grupo.setNrCpfCnpjTitularCt(ur.getCnpjOuCpfTitlarCt());
                    grupo.setCdIspbBcoRecbdr(ur.getIspbBcoRecbdr());
                    grupo.setCdTpCt(ur.getTpCt());
                    if (ur.getAg() != null) {
                        grupo.setNrAg(ur.getAg().intValue());
                    }
                    if (ur.getCt() != null) {
                        grupo.setNrCt(ur.getCt().longValue());
                    }
                    if (ur.getCtPgto() != null) {
                        grupo.setNrCtPgto(ur.getCtPgto().setScale(0, RoundingMode.FLOOR).toString());
                    }
                    grupo.setNrCnpjCreddr(credenciadora.getCnpj());
                    grupo.setNrCpfCnpjUsurioFinlRecbdr(ur.getCnpjOuCpfUsuFinalRecbdr());
                    grupo.setCdArrjPgto(ur.getCodInstitdrArrajPgto());
                    grupo.setDtPrevtLiquid(
                            Date.from(ur.getDtPrevtLiquid().atStartOfDay(ZoneId.systemDefault()).toInstant()));
                    grupo.setNrVlPcNegcd(new BigDecimal(ur.getVlrPercNegcd()));
                    if (ur.getDtAntec() != null) {
                        grupo.setDtAntec(Date.from(ur.getDtAntec().atStartOfDay(ZoneId.systemDefault()).toInstant()));
                    }
                    if (ur.getDtEftLiquidAntec() != null) {
                        grupo.setDtEftLiquidc(
                                Date.from(ur.getDtEftLiquidAntec().atStartOfDay(ZoneId.systemDefault()).toInstant()));
                    }
                    if (ur.getVlrEftLiquidAntec() != null) {
                        grupo.setNrTotEftLiquidc(new BigDecimal(ur.getVlrEftLiquidAntec()));
                    }
                    if (ur.getVlrAntecNRegtd() != null) {
                        grupo.setNrVlAntecNRegtd(new BigDecimal(ur.getVlrAntecNRegtd()));
                    }
                    grupos.add(grupo);
                }
                if (!grupos.isEmpty()) {
                    Integer tamanhoQuebra = parametroSistemaNegocio.getIntParam(ParametroConfiguracao.TAMANHO_QUEBRA_INSERT_GRUPO_REG_OP_STG);
                    List<List<GrupoRegOpStg>> gruposRanges = ListUtil.split(grupos, tamanhoQuebra);
                    for (List<GrupoRegOpStg> gruposRange : gruposRanges) {
                        registroOperacaoStageNegocio.inserirGrupoRegOp(gruposRange, getContext().getBatchReferenceDate());
                    }
                }
            }
            return new ResponseEntity<>(HttpStatus.OK);
        }
        catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.PRECONDITION_FAILED);
        }
    }

    @Override
    public ResponseEntity<Void> postCredenciadoraOperacoes(String xJwsSignature, OperacaoCredenciadoraBase operacaoCredenciadoraBase, String acceptEncoding, String contentEncoding) {
        return processCredenciadoraOperacoes(operacaoCredenciadoraBase, 'I', null);
    }

    @Override
    public ResponseEntity<Void> putCredenciadoraOperacoesIdentdOp(String xJwsSignature, String identdOp, OperacaoCredenciadoraBase operacaoCredenciadoraBase, String acceptEncoding, String contentEncoding) {
        return processCredenciadoraOperacoes(operacaoCredenciadoraBase, 'A', identdOp);
    }

    private ResponseEntity<Void> processCredenciadoraOperacoes(OperacaoCredenciadoraBase operacaoCredenciadoraBase, char indrIA, String identdOp) {
        try {
            Integer partyId = getContext().getPartyId();
            ParticipanteVO credenciadora = registroOperacaoStageNegocio.validarParticipante(partyId);
            Long idOp = null;
            RRC0005 rrc0005;
            if (operacaoCredenciadoraBase instanceof OperacaoERCredenciadora) {
                OperacaoERCredenciadora operacao = (OperacaoERCredenciadora)operacaoCredenciadoraBase;
                rrc0005 = registroOperacaoStageNegocio.converterOperacaoCredenciadoraBaseParaRRC0005(partyId,
                        credenciadora, operacao, indrIA, null, identdOp, getContext().getBatchReferenceDate());
            }
            else {
                OperacaoPartCredenciadora operacao = (OperacaoPartCredenciadora)operacaoCredenciadoraBase;
                idOp = registroOperacaoStageNegocio.validarIdOp(getContext().getPartyId(),
                        operacao.getIdentdConjUniddRecbvl());
                rrc0005 = registroOperacaoStageNegocio.converterOperacaoCredenciadoraBaseParaRRC0005(partyId,
                        credenciadora, operacao, indrIA, idOp, identdOp, getContext().getBatchReferenceDate());
            }

            // Enviar bean para processamento assincrono
            BatchContext batchContext = getContext().createLateBatch(TipoFuncionalidade.RRC0005.getValue());
            batchContext.addJob().addRecord(rrc0005);

            return new ResponseEntity<>(HttpStatus.ACCEPTED);
        }
        catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.PRECONDITION_FAILED);
        }
    }

    @Override
    public ResponseEntity<List<UnidadeRecebivelDisponivelCredenciadora>> getCredenciadoraUnidadesRecebiveisDisponiveis(String xJwsSignature, String identdConjUniddRecbvlDisp, String acceptEncoding, String contentEncoding, Integer numeroPagina, Integer tamanhoPagina) {
        Long id;
        try {
            id = Long.parseLong(identdConjUniddRecbvlDisp);
        } catch (NumberFormatException e){
            return new ResponseEntity<>(HttpStatus.PRECONDITION_FAILED);
        }

        List<UnidadeRecebivelDisponivelCredenciadora> resultado = conjuntoUnidadeRecebivelDisponivelNegocio.buscarUnidadeRecebivelDisponivelCredenciadoraPorId(PartyUtility.partyIdToIspb(getContext().getPartyId()), id);
        if (resultado.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        String uri = "/v1/credenciadora/unidades-recebiveis-disponiveis?identdConjUniddRecbvlDisp=" + identdConjUniddRecbvlDisp;
        ResultadoPaginado resultadoPaginado = ListUtil.paginar(resultado, numeroPagina, tamanhoPagina, uri);
        return new ResponseEntity<>(resultadoPaginado.getLista(), resultadoPaginado.getLinkHeader(), HttpStatus.OK);
    }

    private Erro getIdentdOpErro (String identdOp) {
        Erro erro = new Erro();
        erro.setDataHora(OffsetDateTime.now());
        MessageListArrayOutput mensagem = new MessageListArrayOutput();
        mensagem.campo("identdOp");
        mensagem.mensagem(ErroValidacao.fromValue(ErroValidacao.ERRC0055.getFormattedValue()).getDescricao());
        mensagem.codigo(ErroValidacao.ERRC0055.getFormattedValue());
        mensagem.conteudo(identdOp);
        erro.addMensagensItem(mensagem);

        return erro;
    }
}