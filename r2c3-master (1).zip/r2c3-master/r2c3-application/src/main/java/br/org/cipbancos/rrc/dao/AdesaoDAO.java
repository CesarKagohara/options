package br.org.cipbancos.rrc.dao;

import java.util.List;

import br.org.cipbancos.rrc.dominio.TipoCanal;
import br.org.cipbancos.rrc.enums.TipoFuncionalidade;
import br.org.cipbancos.rrc.vo.AdesaoVO;
import br.org.cipbancos.rrc.vo.ParticipanteVO;

public interface AdesaoDAO {

    AdesaoVO obtemAdesaoAtiva(Integer idPartAdm, TipoFuncionalidade tipoFuncionalidade, TipoCanal tipoCanal);

    List<AdesaoVO> obtemAdesoesAtivas(ParticipanteVO participanteVO, TipoFuncionalidade tipoFuncionalidade, TipoCanal... tipoCanal);

    List<AdesaoVO> obtemAdesoesAtivasPorTipoFuncionalidade(TipoFuncionalidade tipoFuncionalidade);

    AdesaoVO obtemAdesaoAtivaPorTipoFuncionalidade(Integer idPartAdm, TipoFuncionalidade tipoFuncionalidade);
}
