package br.org.cipbancos.rrc.bean.rrc0005;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoArrajPgto;
import br.org.cipbancos.rrc.bean.GrupoTitlar;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@XStreamAlias("Grupo_RRC0005_Titlar")
public class GrupoRRC0005Titlar extends ErrorCodeBean implements GrupoTitlar {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CNPJBase_CPFTitlar")
    private SPBString cNPJCNPJBaseCPFTitlar;

    @XStreamAlias("Vlr_PercTotOpUniddRecbvl")
    private SPBBigDecimal vlrPercTotOpUniddRecbvl;

    @XStreamAlias("DtIniOp")
    private SPBLocalDate dtIniOp;

    @XStreamAlias("DtFimOp")
    private SPBLocalDate dtFimOp;

    @XStreamAlias("CNPJ_CPFTitlarCt")
    private SPBString cNPJCPFTitlarCt;

    @XStreamAlias("ISPBBcoRecbdr")
    private SPBString iSPBBcoRecbdr;

    @XStreamAlias("TpCt")
    private SPBString tpCt;

    @XStreamAlias("Ag")
    private SPBString ag;

    @XStreamAlias("Ct")
    private SPBString ct;

    @XStreamAlias("CtPgto")
    private SPBString ctPgto;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0005_ArrajPgto")
    private List<GrupoRRC0005ArrajPgto> listagrupoRRC0005ArrajPgto = new ArrayList<>();

    public SPBString getcNPJCNPJBaseCPFTitlar() {
        return cNPJCNPJBaseCPFTitlar;
    }

    public void setcNPJCNPJBaseCPFTitlar(SPBString cNPJCNPJBaseCPFTitlar) {
        this.cNPJCNPJBaseCPFTitlar = cNPJCNPJBaseCPFTitlar;
    }

    public SPBBigDecimal getVlrPercTotOpUniddRecbvl() {
        return vlrPercTotOpUniddRecbvl;
    }

    public void setVlrPercTotOpUniddRecbvl(SPBBigDecimal vlrPercTotOpUniddRecbvl) {
        this.vlrPercTotOpUniddRecbvl = vlrPercTotOpUniddRecbvl;
    }

    public SPBLocalDate getDtIniOp() {
        return dtIniOp;
    }

    public void setDtIniOp(SPBLocalDate dtIniOp) {
        this.dtIniOp = dtIniOp;
    }

    public SPBLocalDate getDtFimOp() {
        return dtFimOp;
    }

    public void setDtFimOp(SPBLocalDate dtFimOp) {
        this.dtFimOp = dtFimOp;
    }

    public SPBString getCNPJCPFTitlarCt() {
        return cNPJCPFTitlarCt;
    }

    public void setcNPJCPFTitlarCt(SPBString cNPJCPFTitlarCt) {
        this.cNPJCPFTitlarCt = cNPJCPFTitlarCt;
    }

    public SPBString getISPBBcoRecbdr() {
        return iSPBBcoRecbdr;
    }

    public void setiSPBBcoRecbdr(SPBString iSPBBcoRecbdr) {
        this.iSPBBcoRecbdr = iSPBBcoRecbdr;
    }

    public SPBString getTpCt() {
        return tpCt;
    }

    public void setTpCt(SPBString tpCt) {
        this.tpCt = tpCt;
    }

    public SPBString getAg() {
        return ag;
    }

    public void setAg(SPBString ag) {
        this.ag = ag;
    }

    public SPBString getCt() {
        return ct;
    }

    public void setCt(SPBString ct) {
        this.ct = ct;
    }

    public SPBString getCtPgto() {
        return ctPgto;
    }

    public void setCtPgto(SPBString ctPgto) {
        this.ctPgto = ctPgto;
    }

    public List<GrupoRRC0005ArrajPgto> getListagrupoRRC0005ArrajPgto() {
        return listagrupoRRC0005ArrajPgto;
    }

    public void setListagrupoRRC0005ArrajPgto(List<GrupoRRC0005ArrajPgto> listagrupoRRC0005ArrajPgto) {
        this.listagrupoRRC0005ArrajPgto = listagrupoRRC0005ArrajPgto;
    }

    @Override
    public List getListaGrupoArrajPgto() {
        return getListagrupoRRC0005ArrajPgto();
    }

    @Override
    public String toString() {
        return "GrupoRRC0005Titlar{" + "cNPJCNPJBaseCPFTitlar=" + cNPJCNPJBaseCPFTitlar + ", vlrPercTotOpUniddRecbvl="
                + vlrPercTotOpUniddRecbvl + ", dtIniOp=" + dtIniOp + ", dtFimOp=" + dtFimOp + ", cNPJCPFTitlarCt="
                + cNPJCPFTitlarCt + ", iSPBBcoRecbdr=" + iSPBBcoRecbdr + ", tpCt=" + tpCt + ", ag=" + ag + ", ct=" + ct
                + ", ctPgto=" + ctPgto + ", listagrupoRRC0005ArrajPgto=" + listagrupoRRC0005ArrajPgto + '}';
    }
}
