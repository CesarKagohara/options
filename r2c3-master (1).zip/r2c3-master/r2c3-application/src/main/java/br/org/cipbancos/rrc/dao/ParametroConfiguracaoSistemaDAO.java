package br.org.cipbancos.rrc.dao;

public interface ParametroConfiguracaoSistemaDAO {

    String obterValorPelaChave(String nomeParametro);

}
