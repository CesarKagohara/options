package br.org.cipbancos.rrc.bean.arrc023;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.CancelamentoGrupoNegcRecbvl;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

import java.util.ArrayList;
import java.util.List;

/**
 * @author anderson.martins
 * @since 1.0.0
 */            
@XStreamAlias("Grupo_ARRC023_NegcRecbvl")
public class GrupoARRC023NegcRecbvl extends ErrorCodeBean implements CancelamentoGrupoNegcRecbvl {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdentdNegcRecbvl")
    private SPBString identdNegcRecbvl;

    @XStreamAlias("IdentdOp")
    private SPBString identdOp;

    @XStreamAlias("CNPJ_CNPJBase_CPFTitlar")
    private SPBString cnpjCnpjBaseCpfTitlar;

    @XStreamAlias("IndrCancelVlrTotal")
    private SPBString indrCancelVlrTotal;

    @XStreamAlias("IndrLiquidOp")
    private SPBString indrLiquidOp;

    @XStreamAlias("IndrCancelCessConstitr")
    private SPBString indrCancelCessConstitr;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC023_RegRecbvl")
    private List<GrupoARRC023RegRecbvl> listaGrupoARRC023RegRecbvl = new ArrayList<GrupoARRC023RegRecbvl>();

    @XStreamOmitField
    private String recordId;

    @XStreamOmitField
    private Long atlRootId;

    public SPBString getIdentdNegcRecbvl() {
        return identdNegcRecbvl;
    }

    public void setIdentdNegcRecbvl(SPBString identdNegcRecbvl) {
        this.identdNegcRecbvl = identdNegcRecbvl;
    }

    public SPBString getIdentdOp() {
        return identdOp;
    }

    public void setIdentdOp(SPBString identdOp) {
        this.identdOp = identdOp;
    }

    public SPBString getIndrCancelVlrTotal() {
        return indrCancelVlrTotal;
    }

    public void setIndrCancelVlrTotal(SPBString indrCancelVlrTotal) {
        this.indrCancelVlrTotal = indrCancelVlrTotal;
    }

    public SPBString getIndrLiquidOp() {
        return indrLiquidOp;
    }

    public void setIndrLiquidOp(SPBString indrLiquidOp) {
        this.indrLiquidOp = indrLiquidOp;
    }

    public SPBString getCnpjCnpjBaseCpfTitlar() {
        return cnpjCnpjBaseCpfTitlar;
    }

    public void setCnpjCnpjBaseCpfTitlar(SPBString cnpjCnpjBaseCpfTitlar) {
        this.cnpjCnpjBaseCpfTitlar = cnpjCnpjBaseCpfTitlar;
    }

    public SPBString getIndrCancelCessConstitr() {
        return indrCancelCessConstitr;
    }

    public void setIndrCancelCessConstitr(SPBString indrCancelCessConstitr) {
        this.indrCancelCessConstitr = indrCancelCessConstitr;
    }

    public List<GrupoARRC023RegRecbvl> getListaGrupoARRC023RegRecbvl() {
        return listaGrupoARRC023RegRecbvl;
    }

    public void setListaGrupoARRC023RegRecbvl(List<GrupoARRC023RegRecbvl> listaGrupoARRC023RegRecbvl) {
        this.listaGrupoARRC023RegRecbvl = listaGrupoARRC023RegRecbvl;
    }

    @Override
    public List getListaGrupoRegRecbvl() {
        return listaGrupoARRC023RegRecbvl;
    }

    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }

    public Long getAtlRootId() {
        return atlRootId;
    }

    public void setAtlRootId(Long atlRootId) {
        this.atlRootId = atlRootId;
    }
}
