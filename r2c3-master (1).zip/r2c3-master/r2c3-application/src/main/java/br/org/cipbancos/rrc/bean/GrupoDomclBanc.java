package br.org.cipbancos.rrc.bean;

import java.io.Serializable;
import java.util.List;

public interface GrupoDomclBanc extends DomicilioBancario {

    List<GrupoRegRecbvl> getListaGrupoRegRecbvl();
}
