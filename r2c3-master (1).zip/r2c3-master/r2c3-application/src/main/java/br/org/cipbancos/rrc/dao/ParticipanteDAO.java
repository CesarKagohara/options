package br.org.cipbancos.rrc.dao;

import java.util.List;

import br.org.cipbancos.rrc.enums.TipoParticipante;
import br.org.cipbancos.rrc.vo.PartAdmPrincVO;
import br.org.cipbancos.rrc.vo.ParticipanteVO;


public interface ParticipanteDAO {

    ParticipanteVO obterPorIspb(Integer numIspb);

    @Deprecated
    Integer obterIspbPorNrCnpj(String nrCnpj);

    /*@Deprecated
    Integer obterIdPartPorNrCnpj(String nrCnpj, TipoParticipante... tipos);*/

    @Deprecated
    Integer obterIdPartAdmCreddrAtiva(Long cnpj);

    List<ParticipanteVO> obterParticipantesPorNrCnpj(String nrCnpj, TipoParticipante... tipos);

    List<ParticipanteVO> obterParticipantesAtivos(TipoParticipante... tipos);

    List<ParticipanteVO> obterDadosCadastraisParticipantesVOAtivos();

    PartAdmPrincVO obterAdmXPrincPorIspbAdm(Integer numIspbAdm);

    PartAdmPrincVO obterPorPartAdmId(Integer partAdmId);

    ParticipanteVO obterParticipanteVOPorPartAdmId(Integer partAdmId);

    void inserirParticipante(Integer idPart, String icSitPart, TipoParticipante tipoParticipante);

}
