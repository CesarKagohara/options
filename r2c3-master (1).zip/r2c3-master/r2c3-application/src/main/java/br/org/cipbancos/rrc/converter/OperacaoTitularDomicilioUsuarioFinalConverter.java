package br.org.cipbancos.rrc.converter;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import br.org.cipbancos.rrc.funcional.Converter;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilioUsuarioFinal;

public class OperacaoTitularDomicilioUsuarioFinalConverter {

    private OperacaoTitularDomicilioUsuarioFinalConverter() {
    }

    public static Converter<OperacaoTitularDomicilioUsuarioFinal, MapSqlParameterSource>
    emOperacaoTitularDomicilioCredenciadoraParaInsercao() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();
            parametros.addValue("idOp", origem.getIdOperacao());
            parametros.addValue("idOpTitlarDomcl", origem.getIdOperacaoTitDomcl());
            parametros.addValue("usuarioFinal", origem.getCnpjCpfUsuarioFinalRecbdr());
            parametros.addValue("idPartPrincipal", origem.getIdPartPrincipal());
            parametros.addValue("idPartAdmtd", origem.getIdPartAdmtd());
            parametros.addValue("idPartOrigdr", origem.getIdPartOrigdr());
            parametros.addValue("dtRefSistIncl", origem.getDtRefSistIncl());
            parametros.addValue("dtRefSistUltAlt", origem.getDtRefSistUltAlt());
            parametros.addValue("idAtlRoot", origem.getIdAtlRoot());
            parametros.addValue("nmArqNuopApi", origem.getNmArqNuopApi());
            parametros.addValue("canal", origem.getCanal());
            parametros.addValue("idFuncdd", origem.getIdFuncdd());
            parametros.addValue("icSit", origem.getIcSit());
            return parametros;
        };
    }
}
