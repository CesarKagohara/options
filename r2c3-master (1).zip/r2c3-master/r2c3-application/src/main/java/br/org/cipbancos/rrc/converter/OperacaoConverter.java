package br.org.cipbancos.rrc.converter;

import java.util.Date;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import br.org.cipbancos.rrc.funcional.Converter;
import br.org.cipbancos.rrc.vo.Operacao;

/**
 * Classe utilitária para converter informações de fracao_unidd_recbv_op de entrada para realizar,
 * inserções no BD e conversões de Entrada para Retorno.
 *
 * @author anderson.martins
 * @since 1.0
 */
public class OperacaoConverter {

    private OperacaoConverter() {}

    /**
     * Popula os parametros utilizados para buscar um op no BD.
     * @return Um conjunto de parametros para setar as informações no ElSql.
     */
    public static Converter<Operacao, MapSqlParameterSource> emIdOperacaoParaBuscarOperacao() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();

            parametros.addValue("idOp", origem.getIdOp());

            return parametros;
        };
    }

    /**
     * Popula os parametros utilizados para buscar um op no BD.
     * @return Um conjunto de parametros para setar as informações no ElSql.
     */
    public static Converter<Operacao, MapSqlParameterSource> emIdOperacaoParaAtualizarSituacao() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();

            parametros.addValue("idOp", origem.getIdOp());
            parametros.addValue("icSit", origem.getIcSit());
            parametros.addValue("dhultalt", new java.sql.Timestamp(new Date().getTime()));

            return parametros;
        };
    }


    /**
     * Popula os parametros utilizados para inserir um op no BD.
     * @return Um conjunto de parametros para setar as informações no ElSql.
     */
    public static Converter<Operacao, MapSqlParameterSource> emOperacaoParaInsercaoOP() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();

            parametros.addValue("idop", origem.getIdOp());
            parametros.addValue("idatlroot", origem.getIdAtlRoot());
            parametros.addValue("nrcnpjregtdr", origem.getNrCnpjRegtdr());
            parametros.addValue("nrcnpjpart", origem.getNrCnpjPart());
            parametros.addValue("idnegcrecbvextn", origem.getIdNegcRecbvExtn());

            parametros.addValue("ictpnegc", origem.getIcTpNegc());
            parametros.addValue("dtvencop", origem.getDtVencOp());
            parametros.addValue("nrlimconcdslddevdr", origem.getNrLimConcdSldDevdr());
            parametros.addValue("nrvlrgar", origem.getNrVlrGar());
            parametros.addValue("icgestentregtdr", origem.getIcGesteNtRegtdr());

            parametros.addValue("icregrdivs", origem.getIcRegrDivs());
            parametros.addValue("icalcccontrto", origem.getIcAlcccontrto());
            parametros.addValue("icacteop", origem.getIcActeOp());
            parametros.addValue("idopor", origem.getIdOpor());
            parametros.addValue("idintrdd", origem.getIdIntrdd());

            parametros.addValue("idDesctcGar", origem.getIdDesctcGar());
            parametros.addValue("icTpOp", origem.getIcTpOp());
            parametros.addValue("icSit", origem.getIcSit());
            parametros.addValue("idPartPrincipal", origem.getIdPartPrincipal());

            parametros.addValue("idPartAdmtd", origem.getIdPartAdmtd());
            parametros.addValue("idPartOrigdr", origem.getIdPartOrigdr());
            parametros.addValue("dtRefSistIncl", origem.getDtRefSistIncl());
            parametros.addValue("dtRefSistUltAlt", origem.getDtRefSistUltAlt());
            parametros.addValue("nmArqNuopApi", origem.getNmArqNuOpApi());
            parametros.addValue("canal", origem.getCanal());
            parametros.addValue("idFuncdd", origem.getIdFuncdd());
            parametros.addValue("dhincl", new java.sql.Timestamp(new Date().getTime()));
            parametros.addValue("dhultalt", new java.sql.Timestamp(new Date().getTime()));

          return parametros;
        };
    }


    /**
     * Popula os parametros utilizados para inserir um op no BD.
     * @return Um conjunto de parametros para setar as informações no ElSql.
     */
    public static Converter<Operacao, MapSqlParameterSource> emOperacaoParaAtualizacao() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();

            parametros.addValue("idOp", origem.getIdOp());
            parametros.addValue("icTpNegc", origem.getIcTpNegc());
            parametros.addValue("dtvencop", origem.getDtVencOp());
            parametros.addValue("nrlimconcdslddevdr", origem.getNrLimConcdSldDevdr());
            parametros.addValue("nrvlrgar", origem.getNrVlrGar());
            parametros.addValue("icgestentregtdr", origem.getIcGesteNtRegtdr());

            parametros.addValue("icregrdivs", origem.getIcRegrDivs());
            parametros.addValue("icalcccontrto", origem.getIcAlcccontrto());
            parametros.addValue("icacteop", origem.getIcActeOp());
            parametros.addValue("idopor", origem.getIdOpor());

            parametros.addValue("idDesctcGar", origem.getIdDesctcGar());
            parametros.addValue("icTpOp", origem.getIcTpOp());
            parametros.addValue("icSit", origem.getIcSit());

            return parametros;
        };
    }

}
