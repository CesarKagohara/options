package br.org.cipbancos.rrc.dao;

import java.util.List;

import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001UniddRecbvl;
import br.org.cipbancos.rrc.vo.DomicilioStageVO;
import br.org.cipbancos.rrc.vo.ParticipanteVO;

public interface DomicilioStageDAO {

    /**
     * Grava no BD todos os Domicílios informados no parametro <b>domicilios</b>
     *
     * @param domiciliosParaInsercao MLista de Domicilios para inserção.
     * @param participanteVO Participante que enviou o arquivo
     */
    void inserirDomicilios(List<DomicilioStageVO> domiciliosParaInsercao, ParticipanteVO participanteVO);

    /**
     * Verifica se a Unidade Recebível já se encontra cadastrada no BD.
     *
     * @param unidade Unidade recebível a ser verificada.
     * @return <p><b>TRUE</b> - Se já existe essa UR no Banco </p><p><b>FALSE</b> - Se não existe essa UR no Banco </p>
     */
    boolean unidadeRecebivelNova(String numeroCnpjCredenciadora,
                                 String numeroCpfCnpjUsuarioRecebedor,
                                 String codigoArranjoPagamento,
                                 GrupoARRC001UniddRecbvl unidade);

    List<DomicilioStageVO> buscarDomiciliosStage();

}
