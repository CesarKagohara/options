package br.org.cipbancos.rrc.bean.arrc001;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;

public class GrupoARRC001UniddRecbvlActo extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("DtPrevtLiquid")
    private SPBLocalDate dtPrevtLiquid;

    public SPBLocalDate getDtPrevtLiquid() {
        return dtPrevtLiquid;
    }

    public void setDtPrevtLiquid(SPBLocalDate dtPrevtLiquid) {
        this.dtPrevtLiquid = dtPrevtLiquid;
    }

}
