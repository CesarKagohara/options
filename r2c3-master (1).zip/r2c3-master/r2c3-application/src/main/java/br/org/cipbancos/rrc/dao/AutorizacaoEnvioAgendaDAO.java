package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.atlante.api.handler.Context;
import br.org.cipbancos.rrc.vo.AutorizacaoEnvioAgenda;
import br.org.cipbancos.rrc.vo.OptinVO;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface AutorizacaoEnvioAgendaDAO {

    int inserirAutorizacao(AutorizacaoEnvioAgenda autorizacaoEnvioAgenda);

    void inserirAutorizacoes(List<AutorizacaoEnvioAgenda> autorizacoes);

    AutorizacaoEnvioAgenda buscarAutorizacoesPrevias(AutorizacaoEnvioAgenda autorizacaoEnvioAgenda);

    Long obterSeqNumeroControleOptIn();

    boolean existeIdCtrl(Long identdOptIn);

    AutorizacaoEnvioAgenda buscarDadosAutorizacao(Long identdOptIn);

    AutorizacaoEnvioAgenda buscarDadosAutorizacaoPorNumCtrlCentralizada(String numCtrlCentralizada);

    List<String> buscarArranjosAutorizados(Integer idPartRegr, Integer idPartCreddr, String cdArrjPgtoOptIn, String nrCpfCnpjSolcte, String icTpCnpjCompt, List<String> idAnuencia);

    String buscarIcSitOptInPorNrCpfCnpjUsurioFinlRecbdrNrCnpjFincrd(String nrCpfCnpjUsurioFinlRecbdr, Integer idPartFincrd, String cdArrjPgto, Context ctx);

    AutorizacaoEnvioAgenda buscarAutorizacao(Integer idPartCreddr, String cpfCnpjUsuFinalRecbdr, String codArrjPgto, Integer idPartFinanciadora, Date dtInicio, Date dtFim);

    Map<String, Set<String>> buscarOptIn(Set<String> cnpjCpfUsuarioFinalRecebedores, Set<Integer> idPartCredds, String cnpjCpfTitular, Set<String> codArranjos, Date dtInicio, Date dtFim, Integer idPartFinanciadora);

    Map<String, Set<String>> buscarRegistradorasIdAnuenciaAgendaOnlineInterop(String cnpjCpfUsuarioFinalRecebedor, Integer idPartCredenciadora, String CnpjCpfTitular, String codArranjo, Integer idPartFinanciadora, Context ctx);

    Map<String,Set<String>> buscarCredenciadorasIdAnuenciaAgendaOnlineInterop(String cnpjCpfUsuarioFinalRecebedor, Integer idPartCredenciadora, String CnpjCpfTitular, String codArranjo, Integer idPartFinanciadora, Context ctx, List<OptinVO> optinVOList);

    String existeIdentificadorBaseCentralizada(String codigoControleOptInCentralizadora);

    int atualizarCnpjFinanciadoraBaseCentralizada(String cnpjFinanciadora, Integer idPartFinanciadora, String codigoControleOptInCentralizadora);

    AutorizacaoEnvioAgenda buscarInfoResumoDiario(Long idAtlRoot);
}
