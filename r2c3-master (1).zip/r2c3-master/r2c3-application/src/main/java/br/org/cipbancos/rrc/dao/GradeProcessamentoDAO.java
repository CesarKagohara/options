package br.org.cipbancos.rrc.dao;

import java.util.Date;

import br.org.cipbancos.rrc.dominio.TipoCanal;
import br.org.cipbancos.rrc.dominio.TipoGradeHoraria;
import br.org.cipbancos.rrc.enums.TipoFuncionalidade;
import br.org.cipbancos.rrc.vo.GradeProcessamentoVO;

public interface GradeProcessamentoDAO {

    GradeProcessamentoVO obterGradeVigente(Date dtRef, boolean isFeriado, boolean isFds, TipoFuncionalidade tipoFuncionalidade, TipoCanal tipoCanal, TipoGradeHoraria tipoGradeHoraria);
}
