package br.org.cipbancos.rrc.bean.arrc018;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_ARRC018_UniddRecbvl")
public class GrupoARRC018UniddRecbvl extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("DtPrevtLiquid")
    private SPBLocalDate dtPrevtLiquid;

    @XStreamAlias("VlrTot")
    private SPBBigDecimal vlrTot;

    @XStreamAlias("IndrDomcl")
    private SPBString indrDomcl;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC018_Titlar")
    private List<GrupoARRC018Titlar> listagrupoARRC018Titlar = new ArrayList<>();

    public SPBLocalDate getDtPrevtLiquid() {
        return dtPrevtLiquid;
    }

    public void setDtPrevtLiquid(SPBLocalDate dtPrevtLiquid) {
        this.dtPrevtLiquid = dtPrevtLiquid;
    }

    public SPBBigDecimal getVlrTot() {
        return vlrTot;
    }

    public void setVlrTot(SPBBigDecimal vlrTot) {
        this.vlrTot = vlrTot;
    }

    public SPBString getIndrDomcl() {
        return indrDomcl;
    }

    public void setIndrDomcl(SPBString indrDomcl) {
        this.indrDomcl = indrDomcl;
    }

    public List<GrupoARRC018Titlar> getListagrupoARRC018Titlar() {
        return listagrupoARRC018Titlar;
    }

    public void setListagrupoARRC018Titlar(List<GrupoARRC018Titlar> listagrupoARRC018Titlar) {
        this.listagrupoARRC018Titlar = listagrupoARRC018Titlar;
    }
}
