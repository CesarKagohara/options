package br.org.cipbancos.rrc.bean.rrc0019;

import br.org.cip.api.r2c3.model.Contrato;
import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoGestER;
import br.org.cipbancos.rrc.bean.GrupoGestPart;
import br.org.cipbancos.rrc.bean.GrupoNegcRecbvl0019;
import br.org.cipbancos.rrc.handler.recalculo.bean.RecalculoObjetoParametro;
import br.org.cipbancos.rrc.interop.helper.HeaderReception;
import br.org.cipbancos.rrc.vo.Operacao;
import br.org.cipbancos.rrc.vo.ProcessamentoNegociacao;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@XStreamAlias("RRC0019")
public class RRC0019 extends ErrorCodeBean implements GrupoNegcRecbvl0019 {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CodMsg")
    private SPBString codMsg;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamAlias("IdentdNegcRecbvl")
    private SPBString identdNegcRecbvl;

    @XStreamAlias("IdentdOp")
    private SPBString identdOp;

    @XStreamAlias("IndrTpNegc")
    private SPBString indrTpNegc;

    @XStreamAlias("DtVencOp")
    private SPBLocalDate dtVencOp;

    @XStreamAlias("VlrTotLim_SldDevdr")
    private SPBBigDecimal vlrTotLimSldDevdr;

    @XStreamAlias("Vlr_Gar")
    private SPBBigDecimal vlrGar;

    @XStreamAlias("IndrGestER")
    private SPBString indrGestER;

    @XStreamAlias("IndrRegrDivs")
    private SPBString indrRegrDivs;

    @XStreamAlias("IndrAlcancContrtoCreddrSub")
    private SPBString indrAlcancContrtoCreddrSub;

    @XStreamAlias("IndrActeIncondlOp")
    private SPBString indrActeIncondlOp;

    @XStreamAlias("IdentdOpOrRenegcDiv")
    private SPBString identdOpOrRenegcDiv;

    @XStreamAlias("IndrActeUniddRecbvlReserv")
    private SPBString indrActeUniddRecbvlReserv;

    @XStreamAlias("IndrIA")
    private SPBString indrIA;

    @XStreamAlias("IdentdOpDescstcNegcRecbvl")
    private SPBString identdOpDescstcNegcRecbvl;

    @XStreamAlias("IndrAutcCess")
    private SPBString indrAutcCess;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0019_CesAutd")
    private List<GrupoRRC0019CesAutd> listagrupoRRC0019CesAutd = new ArrayList<>();

    @XStreamImplicit(itemFieldName = "Grupo_RRC0019_RenegcDiv")
    private List<GrupoRRC0019RenegcDiv> listagrupoRRC0019RenegcDiv = new ArrayList<>();

    @XStreamAlias("Grupo_RRC0019_GestER")
    private GrupoRRC0019GestER grupoRRC0019GestER;

    @XStreamAlias("Grupo_RRC0019_GestPart")
    private GrupoRRC0019GestPart grupoRRC0019GestPart;

    @XStreamOmitField
    private Contrato contrato;

    @XStreamOmitField
    private HeaderReception headerReception;

    @XStreamOmitField
    private Operacao operacaoAtual;

    @XStreamOmitField
    private ProcessamentoNegociacao processamentoNegociacao;

    @XStreamOmitField
    private String proximoStep;

    @XStreamOmitField
    private String recordId;

    @XStreamOmitField
    private Long atlRootId;

    @XStreamOmitField
    private List<String> cnpjsRegistradoras;

    @XStreamOmitField
    private Set<String> estabelecimentosBloqueados;

    @XStreamOmitField
    private Set<String> credenciadorasAlcanceGeral;

    @XStreamOmitField
    private RecalculoObjetoParametro<Long> recalculoObjetoParametro;

    @XStreamOmitField
    private Long[] idsOpsRecalculo;

    @XStreamOmitField
    private Map<String, Set<String>> credenciadorasArranjosOutrasIMFs = new HashMap<>();

    public SPBString getCodMsg() {
        return codMsg;
    }

    public void setCodMsg(SPBString codMsg) {
        this.codMsg = codMsg;
    }

    @Override
    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    @Override
    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    @Override
    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    @Override
    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public SPBString getIdentdNegcRecbvl() {
        return identdNegcRecbvl;
    }

    public void setIdentdNegcRecbvl(SPBString identdNegcRecbvl) {
        this.identdNegcRecbvl = identdNegcRecbvl;
    }

    public SPBString getIdentdOp() {
        return identdOp;
    }

    public void setIdentdOp(SPBString identdOp) {
        this.identdOp = identdOp;
    }

    public SPBString getIndrTpNegc() {
        return indrTpNegc;
    }

    public void setIndrTpNegc(SPBString indrTpNegc) {
        this.indrTpNegc = indrTpNegc;
    }

    public SPBLocalDate getDtVencOp() {
        return dtVencOp;
    }

    public void setDtVencOp(SPBLocalDate dtVencOp) {
        this.dtVencOp = dtVencOp;
    }

    public SPBBigDecimal getVlrTotLimSldDevdr() {
        return vlrTotLimSldDevdr;
    }

    public void setVlrTotLimSldDevdr(SPBBigDecimal vlrTotLimSldDevdr) {
        this.vlrTotLimSldDevdr = vlrTotLimSldDevdr;
    }

    public SPBBigDecimal getVlrGar() {
        return vlrGar;
    }

    public void setVlrGar(SPBBigDecimal vlrGar) {
        this.vlrGar = vlrGar;
    }

    public SPBString getIndrGestER() {
        return indrGestER;
    }

    public void setIndrGestER(SPBString indrGestER) {
        this.indrGestER = indrGestER;
    }

    public SPBString getIndrRegrDivs() {
        return indrRegrDivs;
    }

    public void setIndrRegrDivs(SPBString indrRegrDivs) {
        this.indrRegrDivs = indrRegrDivs;
    }

    public SPBString getIndrAlcancContrtoCreddrSub() {
        return indrAlcancContrtoCreddrSub;
    }

    public void setIndrAlcancContrtoCreddrSub(SPBString indrAlcancContrtoCreddrSub) {
        this.indrAlcancContrtoCreddrSub = indrAlcancContrtoCreddrSub;
    }

    public SPBString getIndrActeIncondlOp() {
        return indrActeIncondlOp;
    }

    public void setIndrActeIncondlOp(SPBString indrActeIncondlOp) {
        this.indrActeIncondlOp = indrActeIncondlOp;
    }

    public SPBString getIdentdOpOrRenegcDiv() {
        return identdOpOrRenegcDiv;
    }

    public void setIdentdOpOrRenegcDiv(SPBString identdOpOrRenegcDiv) {
        this.identdOpOrRenegcDiv = identdOpOrRenegcDiv;
    }

    public SPBString getIndrActeUniddRecbvlReserv() {
        return indrActeUniddRecbvlReserv;
    }

    public void setIndrActeUniddRecbvlReserv(SPBString indrActeUniddRecbvlReserv) {
        this.indrActeUniddRecbvlReserv = indrActeUniddRecbvlReserv;
    }

    public SPBString getIndrIA() {
        return indrIA;
    }

    public void setIndrIA(SPBString indrIA) {
        this.indrIA = indrIA;
    }

    public SPBString getIdentdOpDescstcNegcRecbvl() {
        return identdOpDescstcNegcRecbvl;
    }

    public void setIdentdOpDescstcNegcRecbvl(SPBString identdOpDescstcNegcRecbvl) {
        this.identdOpDescstcNegcRecbvl = identdOpDescstcNegcRecbvl;
    }

    public SPBString getIndrAutcCess() {
        return indrAutcCess;
    }

    public void setIndrAutcCess(SPBString indrAutcCess) {
        this.indrAutcCess = indrAutcCess;
    }

    public List<GrupoRRC0019CesAutd> getListagrupoRRC0019CesAutd() {
        return listagrupoRRC0019CesAutd;
    }

    public void setListagrupoRRC0019CesAutd(List<GrupoRRC0019CesAutd> listagrupoRRC0019CesAutd) {
        this.listagrupoRRC0019CesAutd = listagrupoRRC0019CesAutd;
    }

    public List<GrupoRRC0019RenegcDiv> getListagrupoRRC0019RenegcDiv() {
        return listagrupoRRC0019RenegcDiv;
    }

    public void setListagrupoRRC0019RenegcDiv(List<GrupoRRC0019RenegcDiv> listagrupoRRC0019RenegcDiv) {
        this.listagrupoRRC0019RenegcDiv = listagrupoRRC0019RenegcDiv;
    }

    public GrupoRRC0019GestER getGrupoRRC0019GestER() {
        return grupoRRC0019GestER;
    }

    public void setGrupoRRC0019GestER(GrupoRRC0019GestER grupoRRC0019GestER) {
        this.grupoRRC0019GestER = grupoRRC0019GestER;
    }

    public GrupoRRC0019GestPart getGrupoRRC0019GestPart() {
        return grupoRRC0019GestPart;
    }

    public void setGrupoRRC0019GestPart(GrupoRRC0019GestPart grupoRRC0019GestPart) {
        this.grupoRRC0019GestPart = grupoRRC0019GestPart;
    }

    @Override
    public Contrato getContrato() {
        return contrato;
    }

    @Override
    public void setContrato(Contrato contrato) {
        this.contrato = contrato;
    }

    @Override
    public HeaderReception getHeaderReception() {
        return headerReception;
    }

    @Override
    public void setHeaderReception(HeaderReception headerReception) {
        this.headerReception = headerReception;
    }

    public Operacao getOperacaoAtual() {
        return operacaoAtual;
    }

    public void setOperacaoAtual(Operacao operacaoAtual) {
        this.operacaoAtual = operacaoAtual;
    }

    public ProcessamentoNegociacao getProcessamentoNegociacao() {
        return processamentoNegociacao;
    }

    public void setProcessamentoNegociacao(ProcessamentoNegociacao processamentoNegociacao) {
        this.processamentoNegociacao = processamentoNegociacao;
    }

    public String getProximoStep() {
        return proximoStep;
    }

    public void setProximoStep(String proximoStep) {
        this.proximoStep = proximoStep;
    }

    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }

    @Override
    public Long getAtlRootId() {
        return atlRootId;
    }

    public void setAtlRootId(Long atlRootId) {
        this.atlRootId = atlRootId;
    }

    public List<String> getCnpjsRegistradoras() {
        return cnpjsRegistradoras;
    }

    public void setCnpjsRegistradoras(List<String> cnpjsRegistradoras) {
        this.cnpjsRegistradoras = cnpjsRegistradoras;
    }

    @Override
    public int hashCode() {
        return recordId.hashCode();
    }

    @Override
    public List getListaGrupoCesAutd() {
        return getListagrupoRRC0019CesAutd();
    }

    @Override
    public List getListaGrupoRenegcDiv() {
        return getListagrupoRRC0019RenegcDiv();
    }

    @Override
    public GrupoGestER getGrupoGestER() {
        return getGrupoRRC0019GestER();
    }

    @Override
    public GrupoGestPart getGrupoGestPart() {
        return getGrupoRRC0019GestPart();
    }

    @Override
    public boolean isInterop() {
        return contrato != null;
    }

    @Override
    public Set<String> getEstabelecimentosBloqueados() {
        return estabelecimentosBloqueados;
    }

    @Override
    public void setEstabelecimentosBloqueados(Set<String> estabelecimentosBloqueados) {
        this.estabelecimentosBloqueados = estabelecimentosBloqueados;
    }

    @Override
    public String toString() {
        return "RRC0019{" +
                "codMsg=" + codMsg +
                ", identdPartPrincipal=" + identdPartPrincipal +
                ", identdPartAdmtd=" + identdPartAdmtd +
                ", identdNegcRecbvl=" + identdNegcRecbvl +
                ", identdOp=" + identdOp +
                ", indrTpNegc=" + indrTpNegc +
                ", dtVencOp=" + dtVencOp +
                ", vlrTotLimSldDevdr=" + vlrTotLimSldDevdr +
                ", vlrGar=" + vlrGar +
                ", indrGestER=" + indrGestER +
                ", indrRegrDivs=" + indrRegrDivs +
                ", indrAlcancContrtoCreddrSub=" + indrAlcancContrtoCreddrSub +
                ", indrActeIncondlOp=" + indrActeIncondlOp +
                ", identdOpOrRenegcDiv=" + identdOpOrRenegcDiv +
                ", indrActeUniddRecbvlReserv=" + indrActeUniddRecbvlReserv +
                ", indrIA=" + indrIA +
                ", identdOpDescstcNegcRecbvl=" + identdOpDescstcNegcRecbvl +
                ", indrAutcCess=" + indrAutcCess +
                ", listagrupoRRC0019CesAutd=" + listagrupoRRC0019CesAutd +
                ", listagrupoRRC0019RenegcDiv=" + listagrupoRRC0019RenegcDiv +
                ", grupoRRC0019GestER=" + grupoRRC0019GestER +
                ", grupoRRC0019GestPart=" + grupoRRC0019GestPart +
                ", contrato=" + contrato +
                ", headerReception=" + headerReception +
                ", operacaoAtual=" + operacaoAtual +
                ", proximoStep='" + proximoStep + '\'' +
                ", recordId='" + recordId + '\'' +
                ", cnpjsRegistradoras='" + cnpjsRegistradoras + '\'' +
                '}';
    }

    @Override
    public void setCredenciadorasAlcanceGeral(Set<String> creds) {
        this.credenciadorasAlcanceGeral = creds;
    }

    @Override
    public Set<String> getCredenciadorasAlcanceGeral() {
        return credenciadorasAlcanceGeral;
    }

    public RecalculoObjetoParametro<Long> getRecalculoObjetoParametro() {
        return recalculoObjetoParametro;
    }

    public void setRecalculoObjetoParametro(RecalculoObjetoParametro<Long> recalculoObjetoParametro) {
        this.recalculoObjetoParametro = recalculoObjetoParametro;
    }

    @Override
    public void setCredenciadorasArranjosOutrasIMFs(Map<String, Set<String>> credenciadorasArranjosOutrasIMFs) {
        this.credenciadorasArranjosOutrasIMFs = credenciadorasArranjosOutrasIMFs;
    }

    @Override
    public Map<String, Set<String>> getCredenciadorasArranjosOutrasIMFs() {
        return this.credenciadorasArranjosOutrasIMFs;
    }

    @Override
    public Long[] getIdsOpsRecalculo() {
        return idsOpsRecalculo;
    }

    @Override
    public void setIdsOpsRecalculo(Long[] idsOpsRecalculo) {
        this.idsOpsRecalculo = idsOpsRecalculo;
    }
}
