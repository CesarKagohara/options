package br.org.cipbancos.rrc.bean.rrc0009;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDateTime;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("RRC0009")
public class RRC0009 implements Serializable {

    @XStreamAlias("CodMsg")
    private SPBString codMsg;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamAlias("CNPJER")
    private SPBString cnpjER;

    @XStreamAlias("IdentdNegcRecbvl")
    private SPBString identdNegcRecbvl;

    @XStreamAlias("IdentdOp")
    private SPBString identdOp;

    @XStreamAlias("IndrTpNegc")
    private SPBString indrTpNegc;

    @XStreamAlias("DtVencOp")
    private SPBLocalDate dtVencOp;

    @XStreamAlias("VlrTotLim_SldDevdr")
    private SPBBigDecimal vlrTotLimSldDevdr;

    @XStreamAlias("Vlr_Gar")
    private SPBBigDecimal vlrGar;

    @XStreamAlias("IndrGestER")
    private SPBString indrGestER;

    @XStreamAlias("IndrRegrDivs")
    private SPBString indrRegrDivs;

    @XStreamAlias("IndrAlcancContrtoCreddrSub")
    private SPBString indrAlcancContrtoCreddrSub;

    @XStreamAlias("IndrActeIncondlOp")
    private SPBString indrActeIncondlOp;

    @XStreamAlias("IdentdCIPOpOrRenegcDiv")
    private SPBString identdCIPOpOrRenegcDiv;

    @XStreamAlias("IndrActeUniddRecbvlReserv")
    private SPBString indrActeUniddRecbvlReserv;

    @XStreamAlias("DtHrIncl")
    private SPBLocalDateTime dtHrIncl;

    @XStreamAlias("IndrAutcCess")
    private SPBString indrAutcCess;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0009_CreddrSub")
    private List<GrupoRRC0009CreddrSub> grupoRRC0009CreddrSub = new ArrayList<>();

    @XStreamImplicit(itemFieldName = "Grupo_RRC0009_CesAutd")
    private List<GrupoRRC0009CesAutd> grupoRRC0009CesAutd = new ArrayList<>();

    @XStreamImplicit(itemFieldName = "Grupo_RRC0009_RenegcDiv")
    private List<GrupoRRC0009RenegcDiv> grupoRRC0009RenegcDiv = new ArrayList<>();

    @XStreamImplicit(itemFieldName = "Grupo_RRC0009_Titlar")
    private List<GrupoRRC0009Titlar> grupoRRC0009Titlar = new ArrayList<>();

    public SPBString getCodMsg() {
        return codMsg;
    }

    public void setCodMsg(SPBString codMsg) {
        this.codMsg = codMsg;
    }

    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public SPBString getCnpjER() {
        return cnpjER;
    }

    public void setCnpjER(SPBString cnpjER) {
        this.cnpjER = cnpjER;
    }

    public SPBString getIdentdNegcRecbvl() {
        return identdNegcRecbvl;
    }

    public void setIdentdNegcRecbvl(SPBString identdNegcRecbvl) {
        this.identdNegcRecbvl = identdNegcRecbvl;
    }

    public SPBString getIdentdOp() {
        return identdOp;
    }

    public void setIdentdOp(SPBString identdOp) {
        this.identdOp = identdOp;
    }

    public SPBString getIndrTpNegc() {
        return indrTpNegc;
    }

    public void setIndrTpNegc(SPBString indrTpNegc) {
        this.indrTpNegc = indrTpNegc;
    }

    public SPBLocalDate getDtVencOp() {
        return dtVencOp;
    }

    public void setDtVencOp(SPBLocalDate dtVencOp) {
        this.dtVencOp = dtVencOp;
    }

    public SPBBigDecimal getVlrTotLimSldDevdr() {
        return vlrTotLimSldDevdr;
    }

    public void setVlrTotLimSldDevdr(SPBBigDecimal vlrTotLimSldDevdr) {
        this.vlrTotLimSldDevdr = vlrTotLimSldDevdr;
    }

    public SPBBigDecimal getVlrGar() {
        return vlrGar;
    }

    public void setVlrGar(SPBBigDecimal vlrGar) {
        this.vlrGar = vlrGar;
    }

    public SPBString getIndrGestER() {
        return indrGestER;
    }

    public void setIndrGestER(SPBString indrGestER) {
        this.indrGestER = indrGestER;
    }

    public SPBString getIndrRegrDivs() {
        return indrRegrDivs;
    }

    public void setIndrRegrDivs(SPBString indrRegrDivs) {
        this.indrRegrDivs = indrRegrDivs;
    }

    public SPBString getIndrAlcancContrtoCreddrSub() {
        return indrAlcancContrtoCreddrSub;
    }

    public void setIndrAlcancContrtoCreddrSub(SPBString indrAlcancContrtoCreddrSub) {
        this.indrAlcancContrtoCreddrSub = indrAlcancContrtoCreddrSub;
    }

    public SPBString getIndrActeIncondlOp() {
        return indrActeIncondlOp;
    }

    public void setIndrActeIncondlOp(SPBString indrActeIncondlOp) {
        this.indrActeIncondlOp = indrActeIncondlOp;
    }

    public SPBString getIdentdCIPOpOrRenegcDiv() {
        return identdCIPOpOrRenegcDiv;
    }

    public void setIdentdCIPOpOrRenegcDiv(SPBString identdCIPOpOrRenegcDiv) {
        this.identdCIPOpOrRenegcDiv = identdCIPOpOrRenegcDiv;
    }

    public SPBString getIndrActeUniddRecbvlReserv() {
        return indrActeUniddRecbvlReserv;
    }

    public void setIndrActeUniddRecbvlReserv(SPBString indrActeUniddRecbvlReserv) {
        this.indrActeUniddRecbvlReserv = indrActeUniddRecbvlReserv;
    }

    public SPBLocalDateTime getDtHrIncl() {
        return dtHrIncl;
    }

    public void setDtHrIncl(SPBLocalDateTime dtHrIncl) {
        this.dtHrIncl = dtHrIncl;
    }

    public SPBString getIndrAutcCess() {
        return indrAutcCess;
    }

    public void setIndrAutcCess(SPBString indrAutcCess) {
        this.indrAutcCess = indrAutcCess;
    }

    public List<GrupoRRC0009CreddrSub> getGrupoRRC0009CreddrSub() {
        return grupoRRC0009CreddrSub;
    }

    public void setGrupoRRC0009CreddrSub(List<GrupoRRC0009CreddrSub> grupoRRC0009CreddrSub) {
        this.grupoRRC0009CreddrSub = grupoRRC0009CreddrSub;
    }

    public List<GrupoRRC0009CesAutd> getGrupoRRC0009CesAutd() {
        return grupoRRC0009CesAutd;
    }

    public void setGrupoRRC0009CesAutd(List<GrupoRRC0009CesAutd> grupoRRC0009CesAutd) {
        this.grupoRRC0009CesAutd = grupoRRC0009CesAutd;
    }

    public List<GrupoRRC0009RenegcDiv> getGrupoRRC0009RenegcDiv() {
        return grupoRRC0009RenegcDiv;
    }

    public void setGrupoRRC0009RenegcDiv(List<GrupoRRC0009RenegcDiv> grupoRRC0009RenegcDiv) {
        this.grupoRRC0009RenegcDiv = grupoRRC0009RenegcDiv;
    }

    public List<GrupoRRC0009Titlar> getGrupoRRC0009Titlar() {
        return grupoRRC0009Titlar;
    }

    public void setGrupoRRC0009Titlar(List<GrupoRRC0009Titlar> grupoRRC0009Titlar) {
        this.grupoRRC0009Titlar = grupoRRC0009Titlar;
    }
}
