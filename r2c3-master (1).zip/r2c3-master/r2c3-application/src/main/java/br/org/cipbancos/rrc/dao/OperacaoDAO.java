package br.org.cipbancos.rrc.dao;

import br.org.cip.api.r2c3.model.EfeitoContrato;
import br.org.cipbancos.atlante.api.handler.Context;
import br.org.cipbancos.rrc.enums.IcSitOperacao;
import br.org.cipbancos.rrc.enums.TipoNegociacao;
import br.org.cipbancos.rrc.vo.ContratoPostVO;
import br.org.cipbancos.rrc.vo.Operacao;
import br.org.cipbancos.rrc.vo.OperacaoFoto;
import br.org.cipbancos.rrc.vo.RecalculoOperacao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface OperacaoDAO {

    boolean operacaoNova(Operacao operacao);

    void inserir(Operacao operacao);

    void inserirFotos(List<OperacaoFoto> fotos);

    List<String> buscarJsonFotoFracoesConstituidas(Long idOp, int idxInicio, int idxFim);

    void atualizar(Operacao operacao);

    void atualizarSituacao(Operacao operacao);

    void atualizarOperacaoDesctcGar(Long idOp, Long idDesctcGar);

    void atualizarDadosInterop(Long idOp, Date dtVencto, BigDecimal nrLimConcdSldDevdr, BigDecimal nrVlrGar);

    void excluir(Operacao operacao);

    Operacao buscar(Operacao operacao);

    Operacao buscarInfoResumoDiario(Long idAtlRoot);

    Operacao buscarPorId(Long idOperacao);

    List<Operacao> buscarOperacoesPorIds(List<Long> idsOps);

    List<Operacao> buscarPorIds(List<Long> idsOps);

    List<Long> buscarPorIdsBlacklist(List<Long> idsOps);

    List<Operacao> buscarPorIdsIcTpNegc(List<Long> idsOps, TipoNegociacao... icTpNegcs);

    Long obterProximaSeqOp();

    List<RecalculoOperacao> buscarOperacoesParaRecalculoGestaoCIP(IcSitOperacao sitOperacao, Long idOp);

    List<RecalculoOperacao> buscarOperacaoByIdParaRecalculo(List<Long> idOp);

    List<String> buscarCpfsCnpjsUsuFinalRecebedorParaRecalculo(IcSitOperacao situacao);

    Set<Long> buscarIdsOpsPorCpfCnpjRecebedorParaRecalculo(List<String> listCpfCnpjUsuFinalRecebedor, IcSitOperacao situacao);

    Set<Long> buscarOperacoesPorCpcCnpjRecbedorParaRecalculoGestaoParticipante(List<String> listCpfCnpjUsuFinalRecebedor, IcSitOperacao situacao);

    Map<Long, Map<String, List<ContratoPostVO>>> obterMapaContratoPostGestPart(Operacao operacao);

    Map<Long, Map<String, List<ContratoPostVO>>> obterMapaContratoPostGestER(Operacao operacao);

    BigDecimal buscarValorPrevistoLiquidacao(ContratoPostVO contratoPostVO, Date dtRef, Long idOp, String nrCpfCnpjUsurioFinlRecbdr);

    EfeitoContrato buscarEfeitoContratoPorIdOp(Long idOp);

    String buscarIdEfeitoContratoPorIdOp(Long idOp);

    Operacao buscarPorIdEfeitoContrato(String idEfeitoContrato);

    List<Long> buscarOutrosIdsOpsDentroDoPeriodo(Operacao operacao);


    Long validaContratoInterop(String idOpInterop);

    boolean inserirEstabelecimentoEmProcessamento(Context context, Set<String> usuFinalRecbdr);

    void deletarEstabelecimentosProcessados(Set<String> usuFinalRecbdr);

    List<Operacao> buscaOperacoesPorCNPJ(Date referenceDate, String nrCpfCnpjTitular, String nrCpfCnpjRecbdr);

    void atualizarOpRecalc(List<Long> idOps, Integer idFunc, Date dtRef);

    List<Operacao> buscaOperacoesRegistradasPorUR(Date referenceDate, String nrCpfCnpjRecebedorOuTitular, Date dtIniOptIn, Date dtFimOptIn, String codArrjPgto);

    List<Operacao> buscaOperacoesRegistradasPorFiltros(String nrCpfCnpjCreddr, String codArrjPgto, String nrCpfCnpjRecbdr);

    List<Long> buscarIdsOpsCancelados(Date datahoraUltimaVarredura, IcSitOperacao... situacao);
}
