package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.rrc.vo.DestinatarioOptInTipoDestino;
import br.org.cipbancos.rrc.vo.DestinatarioRecalculoVO;

import java.util.List;

public interface DestinatarioRecalculoDAO {

    List<DestinatarioRecalculoVO> obterDestinatarioRecalculo(List<Integer> ids);

    List<DestinatarioOptInTipoDestino> obterIdsURsPorDestinatarioRecalculo(DestinatarioRecalculoVO destinatarioOptInVO);

}
