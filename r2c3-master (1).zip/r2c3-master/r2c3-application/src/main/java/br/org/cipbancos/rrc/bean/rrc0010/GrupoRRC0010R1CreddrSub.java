package br.org.cipbancos.rrc.bean.rrc0010;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_RRC0010R1_CreddrSub")
public class GrupoRRC0010R1CreddrSub extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJER")
    private SPBString cNPJER;

    @XStreamAlias("CNPJCreddrSub")
    private SPBString cNPJCreddrSub;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0010R1_ArrajPgto")
    private List<GrupoRRC0010R1ArrajPgto> listagrupoRRC0010R1ArrajPgto = new ArrayList<GrupoRRC0010R1ArrajPgto>();

    public SPBString getCNPJER() {
        return cNPJER;
    }

    public void setCNPJER(SPBString cNPJER) {
        this.cNPJER = cNPJER;
    }

    public SPBString getCNPJCreddrSub() {
        return cNPJCreddrSub;
    }

    public void setCNPJCreddrSub(SPBString cNPJCreddrSub) {
        this.cNPJCreddrSub = cNPJCreddrSub;
    }

    public List<GrupoRRC0010R1ArrajPgto> getListagrupoRRC0010R1ArrajPgto() {
        return listagrupoRRC0010R1ArrajPgto;
    }

    public void setListagrupoRRC0010R1ArrajPgto(List<GrupoRRC0010R1ArrajPgto> listagrupoRRC0010R1ArrajPgto) {
        this.listagrupoRRC0010R1ArrajPgto = listagrupoRRC0010R1ArrajPgto;
    }

}
