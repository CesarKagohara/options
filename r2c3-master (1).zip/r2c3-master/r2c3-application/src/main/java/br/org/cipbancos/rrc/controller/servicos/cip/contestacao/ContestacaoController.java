package br.org.cipbancos.rrc.controller.servicos.cip.contestacao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;

import br.org.cipbancos.atlante.api.ApplicationErrorAPIException;
import br.org.cipbancos.atlante.api.handler.Context;
import br.org.cipbancos.atlante.api.handler.ContextLocator;
import br.org.cipbancos.atlante.config.HttpTransportConfig;
import br.org.cipbancos.atlante.session.AtlanteSession;
import br.org.cipbancos.atlante.util.PartyUtility;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.rrc0027.GrupoRRC0027Contstc;
import br.org.cipbancos.rrc.bean.rrc0027.RRC0027;
import br.org.cipbancos.rrc.enums.TipoFuncionalidade;
import br.org.cipbancos.rrc.handler.rrc0027.RRC0027Handler;

import br.org.cip.api.r2c3.ContestacoesApi;
import br.org.cip.api.r2c3.model.Contestacao;
import br.org.cip.api.r2c3.model.ContestacaoChave;
import br.org.cip.api.r2c3.model.Erro;
import br.org.cip.arche.commons.library.exceptions.ArcConditionalException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS)
@Controller
public class ContestacaoController implements ContestacoesApi {

    private static final Logger LOG = LoggerFactory.getLogger(ContestacaoController.class);

    @Autowired
    private RRC0027Handler rrc0027Handler;

    private Context getContext() {
        return ContextLocator.getContext();
    }

    @Override
    public ResponseEntity<ContestacaoChave> postContestacoes(String xJwsSignature, Contestacao contestacao, String acceptEncoding, String contentEncoding) {
        LOG.info("Iniciando processamento de Inclusão de  Contestação RRC0027 via HTTP. Contestacao {}", contestacao);
        Context ctx = getContext();

        RRC0027 rrc0027 = criarRRC0027(ctx, contestacao, null);
        rrc0027Handler.process(rrc0027, ctx);

        Object o = AtlanteSession.getSession().getHttpRecords().get(0);

        if (o instanceof ContestacaoChave) {
            return new ResponseEntity<>((ContestacaoChave) o, HttpStatus.OK);
        } else if (o instanceof Erro) {
            return new ResponseEntity(o, HttpStatus.BAD_REQUEST);
        }

        throw new ApplicationErrorAPIException(o, new ArcConditionalException());
    }

    @Override
    public ResponseEntity<Void> putContestacoesIdentdOpContstc(String xJwsSignature, String identdOpContstc, Contestacao contestacao, String acceptEncoding, String contentEncoding) {
        LOG.info("Iniciando processamento de Atualização de Contestação RRC0027 via HTTP. Contestacao {}, identdOpContstc{}", contestacao, identdOpContstc);
        Context ctx = getContext();

        RRC0027 rrc0027 = criarRRC0027(ctx, contestacao, identdOpContstc);
        rrc0027Handler.process(rrc0027, ctx);

        Object o = AtlanteSession.getSession().getHttpRecords().get(0);

        if (o instanceof Erro) {
            return new ResponseEntity(o, HttpStatus.BAD_REQUEST);
        }

        return new ResponseEntity<>(HttpStatus.OK);
    }

    private RRC0027 criarRRC0027(Context ctx, Contestacao contestacao, String identdOpContstc) {
        RRC0027 rrc0027 = new RRC0027();
        rrc0027.setCodMsg(new SPBString(TipoFuncionalidade.RRC0027.getValue()));
        rrc0027.setIdentdPartPrincipal(new SPBString(PartyUtility.partyIdToIspb(ctx.getPartyId())));
        String partyAdmin = PartyUtility.partyIdToIspb(Integer.valueOf(ctx.getProperties().get(HttpTransportConfig.HEADER_PARTY_ADMIN_ID).toString()));
        rrc0027.setIdentdPartAdmtd(new SPBString(partyAdmin));
        GrupoRRC0027Contstc grupoRRC0027Contstc = new GrupoRRC0027Contstc();
        grupoRRC0027Contstc.setIdendPartOrigdrContstc(new SPBString(contestacao.getIdendPartOrigdrContstc()));
        grupoRRC0027Contstc.setIdendPartContstd(new SPBString(contestacao.getIdendPartContstd()));
        grupoRRC0027Contstc.setIdentdCtrlReqSolicte(new SPBString(contestacao.getIdentdCtrlReqSolicte()));
        if (identdOpContstc != null) {
            grupoRRC0027Contstc.setIdentdOpContstc(new SPBString(identdOpContstc));
        }
        grupoRRC0027Contstc.setIndrMotvContstc(new SPBString(contestacao.getIndrMotvContstc()));
        grupoRRC0027Contstc.setDescContstc(new SPBString(contestacao.getDescContstc()));

        if(contestacao.getIdentdOp() != null){
            grupoRRC0027Contstc.setIdentdOp(new SPBString(contestacao.getIdentdOp()));
        }

        if (contestacao.getIdentdCtrlOptIn() != null) {
            grupoRRC0027Contstc.setIdentdCtrlOptIn(new SPBString(contestacao.getIdentdCtrlOptIn()));
        }

        rrc0027.setGrupoRRC0027Contstc(grupoRRC0027Contstc);
        return rrc0027;
    }
}