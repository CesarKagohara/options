package br.org.cipbancos.rrc.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Set;

import org.postgresql.util.PSQLException;

import br.org.cipbancos.atlante.api.handler.Context;

public interface OperacaoNotificacaoDAO {

    boolean isInclusaoOperacao0003(Long idOp, String cnpjCredr, Context context) throws SQLException;

    boolean inserirOperacaoINTP007(String idEfeitoContrato, String cnpjRegtr, Context context);

    boolean isInclusaoOperacaoINTP007(String idEfeitoContrato, String cnpjRegtr, Context context);

    /**
     * Exclui registradora da lista para não mandar novo cancelamento quando
     * for o caso
     *
     * @param idEfeitoContrato
     * @param cnpjRegtr
     * @return true quando excluído com sucesso
     */
    boolean excluirNotificacaoINTP007(String idEfeitoContrato, String cnpjRegtr);

    /**
     * Retorna a lista de registradoras que devem ser notificadas do cancelamento
     * @param idEfeitoContrato
     * @param registradorasNotificadas
     * @return Lista de Registradoras
     */
    List<String> obterRegistradorasCancelamento(String idEfeitoContrato, Set<String> registradorasNotificadas);

    /**
     * Inclui Notificacao de Penhora para para controle de flag de inclusao/alteracao
     * @param idEfeitoContrato
     * @param cnpjRegtr
     * @param context
     * @return
     */
    boolean isInclusaoOperacaoINTP001(String idEfeitoContrato, String cnpjRegtr, Context context) throws SQLException;

}
