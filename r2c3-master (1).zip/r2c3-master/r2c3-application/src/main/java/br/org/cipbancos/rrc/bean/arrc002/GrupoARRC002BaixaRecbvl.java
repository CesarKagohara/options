package br.org.cipbancos.rrc.bean.arrc002;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_ARRC002_BaixaRecbvl")
public class GrupoARRC002BaixaRecbvl extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC002_RegRecbvlBaixa")
    private List<GrupoARRC002RegRecbvlBaixa> listagrupoARRC002RegRecbvlBaixa = new ArrayList<>();

    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public List<GrupoARRC002RegRecbvlBaixa> getListagrupoARRC002RegRecbvlBaixa() {
        return listagrupoARRC002RegRecbvlBaixa;
    }

    public void setListagrupoARRC002RegRecbvlBaixa(List<GrupoARRC002RegRecbvlBaixa> listagrupoARRC002RegRecbvlBaixa) {
        this.listagrupoARRC002RegRecbvlBaixa = listagrupoARRC002RegRecbvlBaixa;
    }
}
