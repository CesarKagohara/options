package br.org.cipbancos.rrc.bean.rrc0010;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_RRC0010R1_DomclBancInst")
public class GrupoRRC0010R1DomclBancInst extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CPFTitlarCt")
    private SPBString cNPJCPFTitlarCt;

    @XStreamAlias("TpCt")
    private SPBString tpCt;

    @XStreamAlias("Ag")
    private SPBString ag;

    @XStreamAlias("Ct")
    private SPBString ct;

    @XStreamAlias("CtPgto")
    private SPBString ctPgto;

    @XStreamAlias("DtEftLiquid")
    private SPBLocalDate dtEftLiquid;

    @XStreamAlias("VlrEftLiquid")
    private SPBBigDecimal vlrEftLiquid;

    @XStreamAlias("VlrLivre")
    private SPBBigDecimal vlrLivre;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0010R1_NegcRecbvlInst")
    private List<GrupoRRC0010R1NegcRecbvlInst> listagrupoRRC0010R1NegcRecbvlInst = new ArrayList<GrupoRRC0010R1NegcRecbvlInst>();

    public SPBString getCNPJCPFTitlarCt() {
        return cNPJCPFTitlarCt;
    }

    public void setCNPJCPFTitlarCt(SPBString cNPJCPFTitlarCt) {
        this.cNPJCPFTitlarCt = cNPJCPFTitlarCt;
    }

    public SPBString getTpCt() {
        return tpCt;
    }

    public void setTpCt(SPBString tpCt) {
        this.tpCt = tpCt;
    }

    public SPBString getAg() {
        return ag;
    }

    public void setAg(SPBString ag) {
        this.ag = ag;
    }

    public SPBString getCt() {
        return ct;
    }

    public void setCt(SPBString ct) {
        this.ct = ct;
    }

    public SPBString getCtPgto() {
        return ctPgto;
    }

    public void setCtPgto(SPBString ctPgto) {
        this.ctPgto = ctPgto;
    }

    public SPBLocalDate getDtEftLiquid() {
        return dtEftLiquid;
    }

    public void setDtEftLiquid(SPBLocalDate dtEftLiquid) {
        this.dtEftLiquid = dtEftLiquid;
    }

    public SPBBigDecimal getVlrEftLiquid() {
        return vlrEftLiquid;
    }

    public void setVlrEftLiquid(SPBBigDecimal vlrEftLiquid) {
        this.vlrEftLiquid = vlrEftLiquid;
    }

    public SPBBigDecimal getVlrLivre() {
        return vlrLivre;
    }

    public void setVlrLivre(SPBBigDecimal vlrLivre) {
        this.vlrLivre = vlrLivre;
    }

    public List<GrupoRRC0010R1NegcRecbvlInst> getListagrupoRRC0010R1NegcRecbvlInst() {
        return listagrupoRRC0010R1NegcRecbvlInst;
    }

    public void setListagrupoRRC0010R1NegcRecbvlInst(List<GrupoRRC0010R1NegcRecbvlInst> listagrupoRRC0010R1NegcRecbvlInst) {
        this.listagrupoRRC0010R1NegcRecbvlInst = listagrupoRRC0010R1NegcRecbvlInst;
    }

}
