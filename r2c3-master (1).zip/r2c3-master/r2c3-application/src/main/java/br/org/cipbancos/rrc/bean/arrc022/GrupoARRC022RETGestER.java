package br.org.cipbancos.rrc.bean.arrc022;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;

@XStreamAlias("Grupo_ARRC022RET_GestER")
public class GrupoARRC022RETGestER extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC022RET_Titlar")
    private List<GrupoARRC022RETTitlar> listagrupoARRC022Titlar = new ArrayList<>();

    public List<GrupoARRC022RETTitlar> getListagrupoARRC022Titlar() {
        return listagrupoARRC022Titlar;
    }

    public void setListagrupoARRC022Titlar(List<GrupoARRC022RETTitlar> listagrupoARRC022Titlar) {
        this.listagrupoARRC022Titlar = listagrupoARRC022Titlar;
    }

}
