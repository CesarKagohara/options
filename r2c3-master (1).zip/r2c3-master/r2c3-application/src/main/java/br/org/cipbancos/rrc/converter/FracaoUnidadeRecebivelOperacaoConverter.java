package br.org.cipbancos.rrc.converter;

import static br.org.cipbancos.rrc.util.NumberUtil.round;

import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBInteger;
import br.org.cipbancos.rrc.enums.RegraDivisao;
import br.org.cipbancos.rrc.funcional.Converter;
import br.org.cipbancos.rrc.util.HashUtil;
import br.org.cipbancos.rrc.vo.ConsultaNegociacaoRecebivel;
import br.org.cipbancos.rrc.vo.FracaoAConstituirNegociacao;
import br.org.cipbancos.rrc.vo.FracaoConstituidaNegociacao;
import br.org.cipbancos.rrc.vo.FracaoUnidadeRecebivelOperacao;
import br.org.cipbancos.rrc.vo.Operacao;
import br.org.cipbancos.rrc.vo.UnidadeRecebivel;

/**
 * Classe utilitária para converter informações de fracao_unidd_recbv_op de entrada para realizar,
 * inserções no BD e conversões de Entrada para Retorno.
 *
 * @author anderson.martins
 * @since 1.0
 */
public class FracaoUnidadeRecebivelOperacaoConverter {

    private static final String NR_CNPJ_CREDDR = "nrCnpjCreddr";
    private static final String NR_CPF_CNPJ_USURIO_RECBDR = "nrCpfCnpjUsurioFinlRecbdr";
    private static final String CD_ARRJ_PGTO = "cdArrjPgto";
    private static final String DT_PREVT_LIQUID = "dtPrevtLiquid";
    private static final String ISPB_BCO_RECBDR = "cdIspbBcoRecbdr";
    private static final String CPF_CNPJ_TITLAR = "nrCpfCnpjTitlar";



    private FracaoUnidadeRecebivelOperacaoConverter() {
    }
    public static Converter<Operacao, FracaoUnidadeRecebivelOperacao> operacaoEmFracaoUnidadeRecebivelOperacao(){

        return origem -> {
            FracaoUnidadeRecebivelOperacao destino = new FracaoUnidadeRecebivelOperacao();
            if(origem.getNrCnpjRegtdr() != null){
            destino.setNrCnpjRegtdr(origem.getNrCnpjRegtdr());}
            if(origem.getIdPartPrincipal() != null){
            destino.setIdPartCreddr(origem.getIdPartPrincipal().intValue());}
            if(origem.getIdOp() != null){
            destino.setIdOp(origem.getIdOp());}
            if(origem.getIcTpNegc() != null){
            destino.setIcTpCt(origem.getIcTpNegc());}
            if(origem.getDtVencOp() != null){
            destino.setDtEftLiquidc(origem.getDtVencOp());}
            if(origem.getIcSit() != null){
            destino.setIcSit(origem.getIcSit());}
            if(origem.getIdPartPrincipal() != null){
            destino.setIdPartPrincipal(origem.getIdPartPrincipal());}
            if(origem.getIdPartAdmtd() != null){
            destino.setIdPartAdmtd(origem.getIdPartAdmtd());}
            if(origem.getIdIntrdd() != null){
            destino.setIdIntrdd(origem.getIdIntrdd());}
            if(origem.getIdPartOrigdr() != null){
            destino.setIdPartOrigdr(origem.getIdPartOrigdr());}
            if(origem.getDtRefSistIncl() != null){
            destino.setDtRefSistIncl(origem.getDtRefSistIncl());}
            if(origem.getDtRefSistUltAlt() != null){
            destino.setDtRefSistUltAlt(origem.getDtRefSistUltAlt());}
            if(origem.getIdAtlRoot() != null){
            destino.setIdAtlRoot(origem.getIdAtlRoot());}
            if(origem.getNmArqNuOpApi() != null){
            destino.setNmArqNuopApi(origem.getNmArqNuOpApi());}
            if(origem.getIdFuncdd() != null){
            destino.setIdFuncdd(origem.getIdFuncdd());}
            if(origem.getDhIncl() != null){
            destino.setDhIncl(origem.getDhIncl());}
            if(origem.getDhUltAlt() != null){
            destino.setDhUltAlt(origem.getDhUltAlt());}

            if(Objects.nonNull(origem.getTitularDomicilio())){
                if (StringUtils.isNotBlank(
                        origem.getTitularDomicilio().getNrCpfCnpjTitular())) {
                    destino.setNrCpfCnpjUsurioFinlRecbdr(origem.getTitularDomicilio().getNrCpfCnpjTitular());
                }
                if (Objects.nonNull(origem.getTitularDomicilio().getDtFimOp())){
                destino.setDtPrevtLiquid(origem.getTitularDomicilio().getDtFimOp());}
                if(origem.getTitularDomicilio().getIspbBancoRecebedor() != null ){
                destino.setCdIspbBcoRecbdr(Long.parseLong(origem.getTitularDomicilio().getIspbBancoRecebedor()));}
                if(origem.getTitularDomicilio().getNrCpfCnpjTitular() != null){
                destino.setNrCpfCnpjTitlar(origem.getTitularDomicilio().getNrCpfCnpjTitular());}
                if(origem.getTitularDomicilio().getNrCpfCnpjTitularConta() != null){
                destino.setNrCpfCnpjTitlarCt(origem.getTitularDomicilio().getNrCpfCnpjTitularConta());}
                if(origem.getTitularDomicilio().getAgencia() != null){
                destino.setNrAg(origem.getTitularDomicilio().getAgencia());}
                if(origem.getTitularDomicilio().getConta() != null){
                destino.setNrCt(origem.getTitularDomicilio().getConta());}
                if(origem.getTitularDomicilio().getContaPagamento() != null){
                destino.setNrCtPgto(origem.getTitularDomicilio().getContaPagamento());}
                if(origem.getTitularDomicilio().getNrVlrTotOpUniddRecbv()!= null) {
                    destino.setNrVlrPrevtPreconttd(origem.getTitularDomicilio().getNrVlrTotOpUniddRecbv());
                    destino.setNrVlrEftLiquid(origem.getTitularDomicilio().getNrVlrTotOpUniddRecbv());
                    destino.setNrVlrPrevtLiquid(origem.getTitularDomicilio().getNrVlrTotOpUniddRecbv());
                }
            }

            return destino;
        };
    }
    /**
     * Popula os parametros utilizados para inserir uma Fracao de Unidade Recebivel no BD.
     *
     * @return Um conjunto de parametros para setar as informações no ElSql.
     */
    public static Converter<FracaoUnidadeRecebivelOperacao, MapSqlParameterSource> emFracaoUnidadeRecebivelParaInsercao() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();

            populaChavePrimaria(origem, parametros);

            populaFracaoUnidadeRecebivel(origem, parametros);

            parametros.addValue("dhIncl", new java.sql.Timestamp(new Date().getTime()));
            parametros.addValue("dhUltAlt", new java.sql.Timestamp(new Date().getTime()));

            return parametros;
        };
    }

    /**
     * Popula os parametros utilizados para atualizar uma Fracao de Unidade Recebivel no BD.
     *
     * @return Um conjunto de parametros para setar as informações no ElSql.
     */
    public static Converter<FracaoUnidadeRecebivelOperacao, MapSqlParameterSource> emFracaoUnidadeRecebivelParaAtualizacao() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();

            populaChavePrimaria(origem, parametros);

            populaFracaoUnidadeRecebivel(origem, parametros);

            parametros.addValue("dhUltAlt", new java.sql.Timestamp(new Date().getTime()));
            parametros.addValue("novoHash", HashUtil.generateHashCode(origem));

            return parametros;
        };
    }

    /**
     * Popula a chave primária para a Fracao de Unidade Recebível no BD.
     *
     * @param fracao     Fração com os dados da chave primária.
     * @param parametros Cadeia de parametros a serem utilizados no SQL.
     */
    public static void populaChavePrimaria(FracaoUnidadeRecebivelOperacao fracao, MapSqlParameterSource parametros) {
        parametros.addValue(NR_CNPJ_CREDDR, fracao.getNrCnpjCreddr());
        parametros.addValue(NR_CPF_CNPJ_USURIO_RECBDR, fracao.getNrCpfCnpjUsurioFinlRecbdr());
        parametros.addValue(CD_ARRJ_PGTO, fracao.getCdArrjPgto());
        parametros.addValue(DT_PREVT_LIQUID, fracao.getDtPrevtLiquid());
        parametros.addValue("idOp", fracao.getIdOp());
        parametros.addValue(ISPB_BCO_RECBDR, fracao.getCdIspbBcoRecbdr());
        parametros.addValue("nrPridd", fracao.getNrPridd());
        parametros.addValue("icContr", fracao.getIcContr());
        assert fracao.getIdUniddRecbv() != null;
        assert fracao.getIdPartCreddr() != null;
        assert fracao.getNrCpfCnpjTitlar() != null;
        parametros.addValue("idUniddRecbvl", fracao.getIdUniddRecbv());
        parametros.addValue("idPartCreddr", fracao.getIdPartCreddr());
        parametros.addValue("cnpjTitular", fracao.getNrCpfCnpjTitlar());

        if(!fracao.getIdOp().equals(0L)) {
            parametros.addValue("idOp", fracao.getIdOp());
            parametros.addValue("nrHash",fracao.getNrHashFracaoUniddRecbvOp());
        }
    }

    /**
     * Popula a chave primária para a Fracao de Unidade Recebível no BD.
     *
     * @param fracao     Fração com os dados da chave primária.
     * @param parametros Cadeia de parametros a serem utilizados no SQL.
     */
    public static void populaChavePrimariaNova(FracaoUnidadeRecebivelOperacao fracao, MapSqlParameterSource parametros) {
        parametros.addValue(NR_CNPJ_CREDDR, fracao.getNrCnpjCreddr());
        parametros.addValue(NR_CPF_CNPJ_USURIO_RECBDR, fracao.getNrCpfCnpjUsurioFinlRecbdr());
        parametros.addValue(CD_ARRJ_PGTO, fracao.getCdArrjPgto());
        parametros.addValue(DT_PREVT_LIQUID, fracao.getDtPrevtLiquid());
        parametros.addValue("idOp", fracao.getIdOp());
    }

    /**
     * Popula a chave primária para a Fracao de Unidade Recebível no BD.
     *
     * @param idOp       id operacao.
     * @param parametros Cadeia de parametros a serem utilizados no SQL.
     */
    public static void populaChavePrimariaPorIdOperacao(Long idOp, MapSqlParameterSource parametros) {
        parametros.addValue("idOp", idOp);
    }

    /**
     * Popula o periodo para a Fracao de Unidade Recebível no BD.
     *
     * @param dataInicio periodo inicial
     * @param dataFim    periodo final
     * @param parametros Cadeia de parametros a serem utilizados no SQL.
     */
    public static void populaParaPesquisaDataInclusao(DateTime dataInicio, DateTime dataFim, MapSqlParameterSource parametros) {

        Date dtIni = dataInicio.toLocalDate().toDateTimeAtStartOfDay().toDate();
        Date dtFim = dataFim.toLocalDate().toDateTimeAtStartOfDay().withTime(23, 59, 59, 999).toDate();

        parametros.addValue("dataIncio", dtIni);
        parametros.addValue("dataFim", dtFim);
    }

    /**
     * Popula o periodo para a Fracao de Unidade Recebível no BD.
     *
     * @param unidadeRecebivel UnidadeRecebivel
     * @param parametros       Cadeia de parametros a serem utilizados no SQL.
     */
    public static void populaParaPesquisaUnidadeRecebivel(UnidadeRecebivel unidadeRecebivel, MapSqlParameterSource parametros) {

        parametros.addValue(NR_CNPJ_CREDDR, unidadeRecebivel.getNrCnpjCreddr());
        parametros.addValue(NR_CPF_CNPJ_USURIO_RECBDR, unidadeRecebivel.getNrCpfCnpjUsurioFinlRecbdr());
        parametros.addValue(CD_ARRJ_PGTO, unidadeRecebivel.getCdArrjPgto());
        parametros.addValue(DT_PREVT_LIQUID, unidadeRecebivel.getDtPrevtLiqui());
        parametros.addValue(CPF_CNPJ_TITLAR, unidadeRecebivel.getNrCpfCnpjTitlar());
    }


    private static void populaFracaoUnidadeRecebivel(FracaoUnidadeRecebivelOperacao fracao, MapSqlParameterSource parametros) {

        parametros.addValue(NR_CNPJ_CREDDR, fracao.getNrCnpjCreddr());
        parametros.addValue(NR_CPF_CNPJ_USURIO_RECBDR, fracao.getNrCpfCnpjUsurioFinlRecbdr());
        parametros.addValue(CD_ARRJ_PGTO, fracao.getCdArrjPgto());
        parametros.addValue(CPF_CNPJ_TITLAR, fracao.getNrCpfCnpjTitlar());
        parametros.addValue("nrCpfCnpjTitlarCt", fracao.getNrCpfCnpjTitlarCt());
        parametros.addValue("nrCpfCnpjTitlarAnt", fracao.getNrCpfCnpjTitlarAnterior());
        parametros.addValue("nrVlrTot", round(fracao.getNrVlrTot()));
        parametros.addValue("nrVlrPrevtPreconttd", round(fracao.getNrVlrPrevtPreconttd()));
        parametros.addValue("icTpCt", fracao.getIcTpCt());
        parametros.addValue("nrAg", fracao.getNrAg());
        parametros.addValue("nrCt", fracao.getNrCt());
        parametros.addValue("nrCtPgto", fracao.getNrCtPgto());
        parametros.addValue("nrVlrPrevtLiquid", round(fracao.getNrVlrPrevtLiquid()));
        parametros.addValue("dtEftLiquidc", fracao.getDtEftLiquidc());
        parametros.addValue("nrVlrEftLiquid", fracao.getNrVlrEftLiquid());
        parametros.addValue("nrPridd", fracao.getNrPridd() != null ? fracao.getNrPridd() : 0);
        parametros.addValue("idOp", fracao.getIdOp());
        parametros.addValue("icContr", fracao.getIcContr());
        parametros.addValue("dtAntec", fracao.getDtAntec());
        parametros.addValue(DT_PREVT_LIQUID, fracao.getDtPrevtLiquid());
        parametros.addValue(ISPB_BCO_RECBDR, fracao.getCdIspbBcoRecbdr());
        parametros.addValue("nrCnpjRegtdr", fracao.getNrCnpjRegtdr());
        parametros.addValue("idPartPrincipal", fracao.getIdPartPrincipal());
        parametros.addValue("idPartAdmtd", fracao.getIdPartAdmtd());
        parametros.addValue("icSit", fracao.getIcSit());
        parametros.addValue(CPF_CNPJ_TITLAR, fracao.getNrCpfCnpjTitlar());
        parametros.addValue("idIntrdd", fracao.getIdIntrdd());
        parametros.addValue("idPartOrigdr", fracao.getIdPartAdmtd());
        parametros.addValue("dtRefSistIncl", fracao.getDtRefSistIncl());
        parametros.addValue("dtRefSistUltAlt", fracao.getDtRefSistUltAlt());
        parametros.addValue("idAtlRoot", fracao.getIdAtlRoot());
        parametros.addValue("nmArqNuopApi", fracao.getNmArqNuopApi());
        parametros.addValue("nrVlAntecNRegtd", round(fracao.getNrVlAntecNRegtd()));
        parametros.addValue("idFuncdd", fracao.getIdFuncdd());
        parametros.addValue("canal", fracao.getCanal());
        parametros.addValue("idOpSusps", fracao.getIdOpSusps());
    }


    /**
     * Popula a chave primária para a Fracao de Unidade Recebível no BD.
     *
     * @param fracao     Fração com os dados da chave primária.
     * @param parametros Cadeia de parametros a serem utilizados no SQL.
     */
    public static void populaChavePrimariaStage(FracaoUnidadeRecebivelOperacao fracao,
                                                MapSqlParameterSource parametros) {
        parametros.addValue(NR_CNPJ_CREDDR, fracao.getNrCnpjCreddr());
        parametros.addValue(NR_CPF_CNPJ_USURIO_RECBDR, fracao.getNrCpfCnpjUsurioFinlRecbdr());
        parametros.addValue(CD_ARRJ_PGTO, fracao.getCdArrjPgto());
        parametros.addValue(DT_PREVT_LIQUID, fracao.getDtPrevtLiquid());
        parametros.addValue("idOp", fracao.getIdOp());
        parametros.addValue(ISPB_BCO_RECBDR, fracao.getCdIspbBcoRecbdr());
        parametros.addValue(CPF_CNPJ_TITLAR, fracao.getNrCpfCnpjUsurioFinlRecbdr());
        parametros.addValue("nrCpfCnpjTitlarCT", fracao.getNrCpfCnpjTitlarCt());
        parametros.addValue("icTpCt", fracao.getIcTpCt());
        parametros.addValue("nrAg", fracao.getNrAg());
        parametros.addValue("nrCt", fracao.getNrCt());
    }

    public static void populaParaPesquisaGenerica(
            ConsultaNegociacaoRecebivel consultaNegociacaoRecebivel,
            MapSqlParameterSource parametros) {
        parametros.addValue("dtRef", consultaNegociacaoRecebivel.getBatchReferenceDate());
        parametros.addValue("idOp", consultaNegociacaoRecebivel.getIdentdOp());
        parametros.addValue("nrCpfCnpjTitlar", consultaNegociacaoRecebivel.getCnpjCnpjBaseCpfTitlar());
        parametros.addValue(NR_CPF_CNPJ_USURIO_RECBDR, consultaNegociacaoRecebivel.getCnpjCnpjBaseCpfUsuFinalRecbdr());
    }

    /**
     * Transforma a Fração em um Fração Constituida da Negociação.
     *
     * @return Um converter para realizar a tarefa.
     */
    public static Converter<FracaoUnidadeRecebivelOperacao, FracaoConstituidaNegociacao> emFracaoConstituidaNegociacao() {
        return origem -> {
            FracaoConstituidaNegociacao destino = new FracaoConstituidaNegociacao();

            destino.setcNPJCPFTitular(SPBConverter.stringToSPBString(origem.getNrCpfCnpjTitlar()));
            destino.setcNPJCPFUsuFinalRecbdr(SPBConverter.stringToSPBString(origem.getNrCpfCnpjUsurioFinlRecbdr()));
            destino.setcNPJCreddrSub(SPBConverter.stringToSPBString(origem.getNrCnpjCreddr()));
            destino.setCodInstitdrArrajPgto(SPBConverter.stringToSPBString(origem.getCdArrjPgto()));
            destino.setDtPrevtLiquid(SPBConverter.dateToSPBLocalDate(origem.getDtPrevtLiquid()));
            destino.setPriorddNegcRecbvl(new SPBInteger(origem.getNrPridd()));
            destino.setVlrPercNegcd(new SPBBigDecimal(origem.getNrVlrTot()));

            return destino;
        };
    }

    /**
     * Transforma a Fração em um Fração À Constituir da Negociação.
     *
     * @return Um converter para realizar a tarefa.
     */
    public static Converter<FracaoUnidadeRecebivelOperacao, FracaoAConstituirNegociacao> emFracaoAConstituirNegociacao(RegraDivisao regraDivisao) {
        return origem -> {
            FracaoAConstituirNegociacao destino = new FracaoAConstituirNegociacao();

            destino.setcNPJCNPJBaseCPFTitlar(SPBConverter.stringToSPBString(origem.getNrCpfCnpjTitlar()));
            destino.setcNPJCPFUsuFinalRecbdr(SPBConverter.stringToSPBString(origem.getNrCpfCnpjUsurioFinlRecbdr()));
            destino.setcNPJCreddrSub(SPBConverter.stringToSPBString(origem.getNrCnpjCreddr()));
            destino.setCodInstitdrArrajPgto(SPBConverter.stringToSPBString(origem.getCdArrjPgto()));
            destino.setDtPrevtLiquid(SPBConverter.dateToSPBLocalDate(origem.getDtPrevtLiquid()));
            destino.setPriorddNegcRecbvl(new SPBInteger(origem.getNrPridd()));
            destino.setVlrPercNegcd(new SPBBigDecimal(origem.getNrVlrTot()));
            destino.setIndrRegrDivs(SPBConverter.stringToSPBString(regraDivisao.getRegra()));

            return destino;
        };
    }



    public static void populaParaPesquisaGenericaBaseCNPJ(
            ConsultaNegociacaoRecebivel consultaNegociacaoRecebivel,
            MapSqlParameterSource parametros) {
        parametros.addValue("dtRef", consultaNegociacaoRecebivel.getBatchReferenceDate());
        parametros.addValue("idOp", consultaNegociacaoRecebivel.getIdentdOp());
        parametros.addValue("nrCpfCnpjTitlarCT", consultaNegociacaoRecebivel.getCnpjCnpjBaseCpfTitlar()+"%");
        parametros.addValue(NR_CPF_CNPJ_USURIO_RECBDR, consultaNegociacaoRecebivel.getCnpjCnpjBaseCpfUsuFinalRecbdr()+"%");
    }
}
