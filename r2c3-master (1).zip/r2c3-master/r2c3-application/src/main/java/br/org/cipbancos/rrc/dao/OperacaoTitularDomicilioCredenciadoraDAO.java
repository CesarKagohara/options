package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.rrc.dominio.SituacaoAtivoInativo;
import br.org.cipbancos.rrc.enums.IndicadorSimNao;
import br.org.cipbancos.rrc.vo.Operacao;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilio;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilioCredenciadora;

import java.util.List;

public interface OperacaoTitularDomicilioCredenciadoraDAO {

    void inserir(OperacaoTitularDomicilioCredenciadora operacaoTitularDomicilio);

    List<OperacaoTitularDomicilioCredenciadora> buscarByIdOpTitlarDomicilio(List<Long> idsOpTitlarDomicilio);

    List<String> buscarNrCnpjCreddrPorIdOp(Long idOp);

    void atualizarSitPorIdOp(Long idOp, SituacaoAtivoInativo icSit);

    List<OperacaoTitularDomicilioCredenciadora> buscar(OperacaoTitularDomicilio operacaoTitularDomicilio);

    void remover(OperacaoTitularDomicilio operacaoTitularDomicilio, Operacao operacao, String credenciadora);

    void inativarCredenciadorasPorIdOp(Long idOp);

}
