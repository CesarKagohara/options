package br.org.cipbancos.rrc.dao;

import java.util.Date;

import br.org.cipbancos.rrc.enums.TipoVarredura;

public interface ExecucaoVarreduraDAO {

    void iniciarVarredura(TipoVarredura tipoVarredura, Long atlRootId, Date dtRef, Date dataHoraCorrente);

    void finalizarVarredura(Long atlRootId);

    boolean hasVarreduraPendente(TipoVarredura tipoVarredura);

    void addRegistrosProcessados(Long atlRootId, Integer qtdeProcessado);

    void addRegistrosEnviados(Long atlRootId, Integer qtdeEnviado);

    void updateRangeDatas(Long atlRootId, Date dataRangeInicio, Date dataRangeFim);

    Date obtemUtimaDhFimRangeVarreduraFinalizadaPorTipo(TipoVarredura tipoVarredura);

    Date obtemUtimaDhInicioRangeVarreduraFinalizadaPorTipo(TipoVarredura tipoVarredura);

    Integer obterIdVarreduraPorAtlRootId(Long atlRootId);

    TipoVarredura obterTipoVarreduraPorAtlRootId(Long atlRootId);

    Date obtemUtimaDataReferenciaVarreduraFinalizadaPorTipoVarredura(TipoVarredura tipoVarredura);

    Date obtemUtimaDataHoraInicioExecucaoPorTipoVarredura(TipoVarredura tipoVarredura);

    boolean existeVarredParaDataReferenciaETipo(Date dtRef, TipoVarredura tipoVarredura);

    Date getRangeDataInicio(Long atlRootId);

    Date getRangeDataFim(Long atlRootId);

    Date obterDataUltimaExecucao(TipoVarredura tipoVarredura);
}
