package br.org.cipbancos.rrc.bean.arrc023;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;

/**
 * @author anderson.martins
 * @since 1.0.0
 */
@XStreamAlias("ARRC023")
public class ARRC023 extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("Grupo_ARRC023_CanceltNegcRecbvl")
    private GrupoARRC023CanceltNegcRecbvl grupoARRC023CanceltNegcRecbvl;

    public GrupoARRC023CanceltNegcRecbvl getGrupoARRC023CanceltNegcRecbvl() {
        return grupoARRC023CanceltNegcRecbvl;
    }

    public void setGrupoARRC023CanceltNegcRecbvl(GrupoARRC023CanceltNegcRecbvl grupoARRC023CanceltNegcRecbvl) {
        this.grupoARRC023CanceltNegcRecbvl = grupoARRC023CanceltNegcRecbvl;
    }

}
