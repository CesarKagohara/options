package br.org.cipbancos.rrc.bean.rrc0019;

import br.org.cip.api.r2c3.model.OperacaoPartFinanciadora;
import br.org.cipbancos.rrc.bean.SPBBean;
import br.org.cipbancos.rrc.vo.ParticipanteVO;

import java.util.Date;

public class RRC0019ApiGestaoParticipante implements SPBBean {

    private Integer partyId;
    private ParticipanteVO participanteVO;
    private OperacaoPartFinanciadora operacao;
    private char indrIA;
    private Long idOp;
    private String identdOp;
    private Date dtRef;
    private String recordId;

    public RRC0019ApiGestaoParticipante(Integer partyId, ParticipanteVO participanteVO, OperacaoPartFinanciadora operacao, char indrIA, Long idOp, String identdOp, Date dtRef) {
        this.partyId = partyId;
        this.participanteVO = participanteVO;
        this.operacao = operacao;
        this.indrIA = indrIA;
        this.idOp = idOp;
        this.identdOp = identdOp;
        this.dtRef = dtRef;
    }

    public Integer getPartyId() {
        return partyId;
    }

    public void setPartyId(Integer partyId) {
        this.partyId = partyId;
    }

    public ParticipanteVO getParticipanteVO() {
        return participanteVO;
    }

    public void setParticipanteVO(ParticipanteVO participanteVO) {
        this.participanteVO = participanteVO;
    }

    public OperacaoPartFinanciadora getOperacao() {
        return operacao;
    }

    public void setOperacao(OperacaoPartFinanciadora operacao) {
        this.operacao = operacao;
    }

    public char getIndrIA() {
        return indrIA;
    }

    public void setIndrIA(char indrIA) {
        this.indrIA = indrIA;
    }

    public Long getIdOp() {
        return idOp;
    }

    public void setIdOp(Long idOp) {
        this.idOp = idOp;
    }

    public String getIdentdOp() {
        return identdOp;
    }

    public void setIdentdOp(String identdOp) {
        this.identdOp = identdOp;
    }

    public Date getDtRef() {
        return dtRef;
    }

    public void setDtRef(Date dtRef) {
        this.dtRef = dtRef;
    }

    @Override
    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }
}
