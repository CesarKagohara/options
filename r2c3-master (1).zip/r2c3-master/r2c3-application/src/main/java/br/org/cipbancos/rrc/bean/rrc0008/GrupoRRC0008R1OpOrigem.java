package br.org.cipbancos.rrc.bean.rrc0008;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_RRC0008R1_OpOrigem")
public class GrupoRRC0008R1OpOrigem extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1234566788897645437l;

    @XStreamAlias("IdentdOpOrigem")
    private SPBString identdOpOrigem;

    public SPBString getIdentdOpOrigem() {
        return identdOpOrigem;
    }

    public void setIdentdOpOrigem(SPBString identdOpOrigem) {
        this.identdOpOrigem = identdOpOrigem;
    }
}
