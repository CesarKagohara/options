package br.org.cipbancos.rrc.bean.rrc0019;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoRenegcDiv;
import org.apache.commons.lang3.builder.ToStringBuilder;

@XStreamAlias("Grupo_RRC0019_RenegcDiv")
public class GrupoRRC0019RenegcDiv extends ErrorCodeBean implements GrupoRenegcDiv {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdentdOpOrRenegcDiv")
    private SPBString identdOpOrRenegcDiv;

    public SPBString getIdentdOpOrRenegcDiv() {
        return identdOpOrRenegcDiv;
    }

    public void setIdentdOpOrRenegcDiv(SPBString identdOpOrRenegcDiv) {
        this.identdOpOrRenegcDiv = identdOpOrRenegcDiv;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("identdOpOrRenegcDiv", identdOpOrRenegcDiv)
                .toString();
    }
}
