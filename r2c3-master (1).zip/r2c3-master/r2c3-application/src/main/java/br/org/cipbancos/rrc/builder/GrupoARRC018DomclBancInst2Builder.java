package br.org.cipbancos.rrc.builder;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.arrc018.GrupoARRC018DomclBancInst2;
import br.org.cipbancos.rrc.util.DateUtil;

import java.math.BigDecimal;
import java.util.Date;

public class GrupoARRC018DomclBancInst2Builder {

    private GrupoARRC018DomclBancInst2 grupoARRC018DomclBancInst2;

    private GrupoARRC018DomclBancInst2Builder(){
        this.grupoARRC018DomclBancInst2 = new GrupoARRC018DomclBancInst2();
    }

    public static GrupoARRC018DomclBancInst2Builder builder(){
        return new GrupoARRC018DomclBancInst2Builder();
    }

    public GrupoARRC018DomclBancInst2Builder comCnpjCpfTitularConta(String cnpjCpfTitularConta){
        this.grupoARRC018DomclBancInst2.setcNPJCPFTitlarCt(new SPBString(cnpjCpfTitularConta));
        return this;
    }

    public GrupoARRC018DomclBancInst2Builder comTipoConta(String tipoConta){
        this.grupoARRC018DomclBancInst2.setTpCt(new SPBString(tipoConta));
        return this;
    }

    public GrupoARRC018DomclBancInst2Builder comDataEfetivacaoLiquidacao(Date dataEfetivacaoLiquidacao){
        if (dataEfetivacaoLiquidacao != null) {
            this.grupoARRC018DomclBancInst2.setDtEftLiquid(new SPBLocalDate(DateUtil.toLocalDate(dataEfetivacaoLiquidacao)));
        }
        return this;
    }

    public GrupoARRC018DomclBancInst2Builder comValorEfetivacaoLiquidacao(BigDecimal valorEfetivacaoLiquidacao){
        if (valorEfetivacaoLiquidacao != null) {
            this.grupoARRC018DomclBancInst2.setVlrEftLiquid(new SPBBigDecimal(valorEfetivacaoLiquidacao));
        }
        return this;
    }

    public GrupoARRC018DomclBancInst2Builder comValorLivre(BigDecimal valorLivre){
        this.grupoARRC018DomclBancInst2.setVlrLivre(new SPBBigDecimal(valorLivre));
        return this;
    }

    public GrupoARRC018DomclBancInst2Builder comAgencia(Integer agencia){
        if (agencia != null) {
            this.grupoARRC018DomclBancInst2.setAg(new SPBString(String.format("%04d", agencia)));
        }
        return this;
    }

    public GrupoARRC018DomclBancInst2Builder comNumeroConta(Long numeroConta){
        if (numeroConta != null) {
            this.grupoARRC018DomclBancInst2.setCt(new SPBString(String.format("%013d", numeroConta)));
        }
        return this;
    }

    public GrupoARRC018DomclBancInst2Builder comNumeroContaPagamento(String numeroContaPagamento){
        if (numeroContaPagamento != null) {
            this.grupoARRC018DomclBancInst2.setCtPgto(new SPBString(numeroContaPagamento));
        }
        return this;
    }

    public GrupoARRC018DomclBancInst2 build(){
        return this.grupoARRC018DomclBancInst2;
    }
}