package br.org.cipbancos.rrc.dao;

import java.util.List;

import br.org.cipbancos.rrc.vo.CancelamentoNegociacao;

public interface CancelamentoNegociacaoDAO {

    List<CancelamentoNegociacao> obterCancelamentoNegociacoes(Long identificadorOperacao);

}
