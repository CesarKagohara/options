package br.org.cipbancos.rrc.bean.ardc500;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;

@XStreamAlias("Grupo_ARDC500_ArrajPgto")
public class GrupoARDC500ArrajPgto extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CodInstitdrArrajPgto")
    private String codInstitdrArrajPgto;

    @XStreamImplicit(itemFieldName = "Grupo_ARDC500_UniddRecbvl")
    private List<GrupoARDC500UniddRecbvl> listaGrupoARDC500UniddRecbvl = new ArrayList<>();

    public String getCodInstitdrArrajPgto() {
        return codInstitdrArrajPgto;
    }

    public void setCodInstitdrArrajPgto(String codInstitdrArrajPgto) {
        this.codInstitdrArrajPgto = codInstitdrArrajPgto;
    }

    public List<GrupoARDC500UniddRecbvl> getListaGrupoARDC500UniddRecbvl() {
        return listaGrupoARDC500UniddRecbvl;
    }

    public void setListaGrupoARDC500UniddRecbvl(List<GrupoARDC500UniddRecbvl> listaGrupoARDC500UniddRecbvl) {
        this.listaGrupoARDC500UniddRecbvl = listaGrupoARDC500UniddRecbvl;
    }

}
