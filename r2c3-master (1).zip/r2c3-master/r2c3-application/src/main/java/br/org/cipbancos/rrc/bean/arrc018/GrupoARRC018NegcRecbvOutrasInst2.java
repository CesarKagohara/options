package br.org.cipbancos.rrc.bean.arrc018;

import java.io.Serializable;

import br.org.cipbancos.atlante.xmlbinder.spb.*;
import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("Grupo_ARRC018_NegcRecbvOutrasInst")
public class GrupoARRC018NegcRecbvOutrasInst2 extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IndrRegrDivs")
    private SPBString indrRegrDivs;

    @XStreamAlias("VlrNegcd")
    private SPBBigDecimal vlrNegcd;

    @XStreamAlias("VlrPercNegcdConstitr")
    private SPBBigDecimal vlrPercNegcdConstitr;

    @XStreamAlias("DtFimOp")
    private SPBLocalDate dtFimOp;

    @XStreamAlias("PriorddNegcRecbvl")
    private SPBInteger priorddNegcRecbvl;

    public SPBString getIndrRegrDivs() {
        return indrRegrDivs;
    }

    public void setIndrRegrDivs(SPBString indrRegrDivs) {
        this.indrRegrDivs = indrRegrDivs;
    }

    public SPBBigDecimal getVlrNegcd() {
        return vlrNegcd;
    }

    public void setVlrNegcd(SPBBigDecimal vlrNegcd) {
        this.vlrNegcd = vlrNegcd;
    }

    public SPBBigDecimal getVlrPercNegcdConstitr() {
        return vlrPercNegcdConstitr;
    }

    public void setVlrPercNegcdConstitr(SPBBigDecimal vlrPercNegcdConstitr) {
        this.vlrPercNegcdConstitr = vlrPercNegcdConstitr;
    }

    public SPBLocalDate getDtFimOp() {
        return dtFimOp;
    }

    public void setDtFimOp(SPBLocalDate dtFimOp) {
        this.dtFimOp = dtFimOp;
    }

    public SPBInteger getPriorddNegcRecbvl() {
        return priorddNegcRecbvl;
    }

    public void setPriorddNegcRecbvl(SPBInteger priorddNegcRecbvl) {
        this.priorddNegcRecbvl = priorddNegcRecbvl;
    }
}
