package br.org.cipbancos.rrc.bean;

public class PaginacaoApi {

    private Long idroot;
    private String idregistro;
    private byte[] binario;

    public Long getIdroot() {
        return idroot;
    }

    public String getIdregistro() {
        return idregistro;
    }

    public byte[] getBinario() {
        return binario;
    }

    public void setIdroot(Long idroot) {
        this.idroot = idroot;
    }

    public void setIdregistro(String idregistro) {
        this.idregistro = idregistro;
    }

    public void setBinario(byte[] binario) {
        this.binario = binario;
    }
}
