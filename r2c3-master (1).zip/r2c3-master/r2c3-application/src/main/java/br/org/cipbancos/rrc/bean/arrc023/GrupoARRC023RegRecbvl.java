package br.org.cipbancos.rrc.bean.arrc023;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.CancelamentoGrupoRegRecbvl;
import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("Grupo_ARRC023_RegRecbvl")
public class GrupoARRC023RegRecbvl extends ErrorCodeBean implements CancelamentoGrupoRegRecbvl {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJCreddrSub")
    private SPBString cnpjCreddrSub;

    @XStreamAlias("CNPJ_CPFUsuFinalRecbdr")
    private SPBString cnpjCpfUsuFinalRecbdr;

    @XStreamAlias("CodInstitdrArrajPgto")
    private SPBString codInstitdrArrajPgto;

    @XStreamAlias("DtPrevtLiquid")
    private SPBLocalDate dtPrevtLiquid;

    @XStreamAlias("CNPJ_CPFTitularVendd_NegcdrRecbvl")
    private SPBString cnpjCpfTitularVenddNegcdrRecbvl;

    @XStreamAlias("VlrNegcdCancel")
    private SPBBigDecimal vlrNegcdCancel;

    @XStreamAlias("VlrPercNegcdConstitrCancel")
    private SPBBigDecimal vlrPercNegcdConstitrCancel;

    public SPBString getCnpjCreddrSub() {
        return cnpjCreddrSub;
    }

    public void setCnpjCreddrSub(SPBString cnpjCreddrSub) {
        this.cnpjCreddrSub = cnpjCreddrSub;
    }

    public SPBString getCnpjCpfUsuFinalRecbdr() {
        return cnpjCpfUsuFinalRecbdr;
    }

    public void setCnpjCpfUsuFinalRecbdr(SPBString cnpjCpfUsuFinalRecbdr) {
        this.cnpjCpfUsuFinalRecbdr = cnpjCpfUsuFinalRecbdr;
    }

    public SPBString getCodInstitdrArrajPgto() {
        return codInstitdrArrajPgto;
    }

    public void setCodInstitdrArrajPgto(SPBString codInstitdrArrajPgto) {
        this.codInstitdrArrajPgto = codInstitdrArrajPgto;
    }

    public SPBLocalDate getDtPrevtLiquid() {
        return dtPrevtLiquid;
    }

    public void setDtPrevtLiquid(SPBLocalDate dtPrevtLiquid) {
        this.dtPrevtLiquid = dtPrevtLiquid;
    }

    public SPBString getCnpjCpfTitularVenddNegcdrRecbvl() {
        return cnpjCpfTitularVenddNegcdrRecbvl;
    }

    public void setCnpjCpfTitularVenddNegcdrRecbvl(SPBString cnpjCpfTitularVenddNegcdrRecbvl) {
        this.cnpjCpfTitularVenddNegcdrRecbvl = cnpjCpfTitularVenddNegcdrRecbvl;
    }

    public SPBBigDecimal getVlrNegcdCancel() {
        return vlrNegcdCancel;
    }

    public void setVlrNegcdCancel(SPBBigDecimal vlrNegcdCancel) {
        this.vlrNegcdCancel = vlrNegcdCancel;
    }

    public SPBBigDecimal getVlrPercNegcdConstitrCancel() {
        return vlrPercNegcdConstitrCancel;
    }

    public void setVlrPercNegcdConstitrCancel(SPBBigDecimal vlrPercNegcdConstitrCancel) {
        this.vlrPercNegcdConstitrCancel = vlrPercNegcdConstitrCancel;
    }
}
