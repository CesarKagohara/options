package br.org.cipbancos.rrc.bean.rrc0005;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoRegRecbvl0005;
import com.thoughtworks.xstream.annotations.XStreamAlias;


@XStreamAlias("Grupo_RRC0005_RegRecbvl")
public class GrupoRRC0005GrupoRegRecbvl extends ErrorCodeBean implements GrupoRegRecbvl0005 {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CPFUsuFinalRecbdr")
    private SPBString cNPJCPFUsuFinalRecbdr;

    @XStreamAlias("CNPJ_CPFTitular")
    private SPBString cNPJCPFTitular;

    @XStreamAlias("CodInstitdrArrajPgto")
    private SPBString codInstitdrArrajPgto;

    @XStreamAlias("DtPrevtLiquid")
    private SPBLocalDate dtPrevtLiquid;

    @XStreamAlias("VlrPercNegcd")
    private SPBBigDecimal vlrPercNegcd;

    @XStreamAlias("DtAntec")
    private SPBLocalDate dtAntec;

    @XStreamAlias("DtEftLiquidAntec")
    private SPBLocalDate dtEftLiquidAntec;

    @XStreamAlias("VlrEftLiquidAntec")
    private SPBBigDecimal vlrEftLiquidAntec;

    @XStreamAlias("VlrAntecNRegtd")
    private SPBBigDecimal vlrAntecNRegtd;

    public SPBString getCNPJCPFUsuFinalRecbdr() {
        return cNPJCPFUsuFinalRecbdr;
    }

    public void setcNPJCPFUsuFinalRecbdr(SPBString cNPJCPFUsuFinalRecbdr) {
        this.cNPJCPFUsuFinalRecbdr = cNPJCPFUsuFinalRecbdr;
    }

    public SPBString getCNPJCPFTitular() {
        return cNPJCPFTitular;
    }

    public void setcNPJCPFTitular(SPBString cNPJCPFTitular) {
        this.cNPJCPFTitular = cNPJCPFTitular;
    }

    public SPBString getCodInstitdrArrajPgto() {
        return codInstitdrArrajPgto;
    }

    public void setCodInstitdrArrajPgto(SPBString codInstitdrArrajPgto) {
        this.codInstitdrArrajPgto = codInstitdrArrajPgto;
    }

    public SPBLocalDate getDtPrevtLiquid() {
        return dtPrevtLiquid;
    }

    public void setDtPrevtLiquid(SPBLocalDate dtPrevtLiquid) {
        this.dtPrevtLiquid = dtPrevtLiquid;
    }

    public SPBBigDecimal getVlrPercNegcd() {
        return vlrPercNegcd;
    }

    public void setVlrPercNegcd(SPBBigDecimal vlrPercNegcd) {
        this.vlrPercNegcd = vlrPercNegcd;
    }

    public SPBLocalDate getDtAntec() {
        return dtAntec;
    }

    public void setDtAntec(SPBLocalDate dtAntec) {
        this.dtAntec = dtAntec;
    }

    public SPBLocalDate getDtEftLiquidAntec() {
        return dtEftLiquidAntec;
    }

    public void setDtEftLiquidAntec(SPBLocalDate dtEftLiquidAntec) {
        this.dtEftLiquidAntec = dtEftLiquidAntec;
    }

    public SPBBigDecimal getVlrEftLiquidAntec() {
        return vlrEftLiquidAntec;
    }

    public void setVlrEftLiquidAntec(SPBBigDecimal vlrEftLiquidAntec) {
        this.vlrEftLiquidAntec = vlrEftLiquidAntec;
    }

    public SPBBigDecimal getVlrAntecNRegtd() {
        return vlrAntecNRegtd;
    }

    public void setVlrAntecNRegtd(SPBBigDecimal vlrAntecNRegtd) {
        this.vlrAntecNRegtd = vlrAntecNRegtd;
    }
}
