package br.org.cipbancos.rrc.bean.rrc0021;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDateTime;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_RRC0021R1_NegcRecbvl")
public class GrupoRRC0021R1NegcRecbvl extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJER")
    private SPBString cNPJER;

    @XStreamAlias("IdentdNegcRecbvl")
    private SPBString identdNegcRecbvl;

    @XStreamAlias("IdentdOp")
    private SPBString identdOp;

    @XStreamAlias("IndrTpNegc")
    private SPBString indrTpNegc;

    @XStreamAlias("DtVencOp")
    private SPBLocalDate dtVencOp;

    @XStreamAlias("VlrTotLim_SldDevdr")
    private SPBBigDecimal vlrTotLimSldDevdr;

    @XStreamAlias("Vlr_Gar")
    private SPBBigDecimal vlrGar;

    @XStreamAlias("IndrGestER")
    private SPBString indrGestER;

    @XStreamAlias("IndrRegrDivs")
    private SPBString indrRegrDivs;

    @XStreamAlias("IndrAlcancContrtoCreddrSub")
    private SPBString indrAlcancContrtoCreddrSub;

    @XStreamAlias("IndrActeIncondlOp")
    private SPBString indrActeIncondlOp;

    @XStreamAlias("IndrActeUniddRecbvlReserv")
    private SPBString indrActeUniddRecbvlReserv;

    @XStreamAlias("DtHrIncl")
    private SPBLocalDateTime dtHrIncl;

    @XStreamAlias("IndrSitOp")
    private SPBString indrSitOp;

    @XStreamAlias("IndrAutcCess")
    private SPBString indrAutcCess;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0021R1_CesAutd")
    private List<GrupoRRC0021R1CesAutd> listagrupoRRC0021R1CesAutd = new ArrayList<GrupoRRC0021R1CesAutd>();

    @XStreamImplicit(itemFieldName = "Grupo_RRC0021R1_RenegcDiv")
    private List<GrupoRRC0021R1RenegcDiv> listagrupoRRC0021R1RenegcDiv = new ArrayList<GrupoRRC0021R1RenegcDiv>();

    @XStreamImplicit(itemFieldName = "Grupo_RRC0021R1_Titlar")
    private List<GrupoRRC0021R1Titlar> listagrupoRRC0021R1Titlar = new ArrayList<GrupoRRC0021R1Titlar>();

    @XStreamOmitField
    private boolean completo;

    public boolean isCompleto() {
        return completo;
    }

    public void setCompleto(boolean completo) {
        this.completo = completo;
    }

    public SPBString getCNPJER() {
        return cNPJER;
    }

    public void setCNPJER(SPBString cNPJER) {
        this.cNPJER = cNPJER;
    }

    public SPBString getIdentdNegcRecbvl() {
        return identdNegcRecbvl;
    }

    public void setIdentdNegcRecbvl(SPBString identdNegcRecbvl) {
        this.identdNegcRecbvl = identdNegcRecbvl;
    }

    public SPBString getIdentdOp() {
        return identdOp;
    }

    public void setIdentdOp(SPBString identdOp) {
        this.identdOp = identdOp;
    }

    public SPBString getIndrTpNegc() {
        return indrTpNegc;
    }

    public void setIndrTpNegc(SPBString indrTpNegc) {
        this.indrTpNegc = indrTpNegc;
    }

    public SPBLocalDate getDtVencOp() {
        return dtVencOp;
    }

    public void setDtVencOp(SPBLocalDate dtVencOp) {
        this.dtVencOp = dtVencOp;
    }

    public SPBBigDecimal getVlrTotLimSldDevdr() {
        return vlrTotLimSldDevdr;
    }

    public void setVlrTotLimSldDevdr(SPBBigDecimal vlrTotLimSldDevdr) {
        this.vlrTotLimSldDevdr = vlrTotLimSldDevdr;
    }

    public SPBBigDecimal getVlrGar() {
        return vlrGar;
    }

    public void setVlrGar(SPBBigDecimal vlrGar) {
        this.vlrGar = vlrGar;
    }

    public SPBString getIndrGestER() {
        return indrGestER;
    }

    public void setIndrGestER(SPBString indrGestER) {
        this.indrGestER = indrGestER;
    }

    public SPBString getIndrRegrDivs() {
        return indrRegrDivs;
    }

    public void setIndrRegrDivs(SPBString indrRegrDivs) {
        this.indrRegrDivs = indrRegrDivs;
    }

    public SPBString getIndrAlcancContrtoCreddrSub() {
        return indrAlcancContrtoCreddrSub;
    }

    public void setIndrAlcancContrtoCreddrSub(SPBString indrAlcancContrtoCreddrSub) {
        this.indrAlcancContrtoCreddrSub = indrAlcancContrtoCreddrSub;
    }

    public SPBString getIndrActeIncondlOp() {
        return indrActeIncondlOp;
    }

    public void setIndrActeIncondlOp(SPBString indrActeIncondlOp) {
        this.indrActeIncondlOp = indrActeIncondlOp;
    }

    public SPBString getIndrActeUniddRecbvlReserv() {
        return indrActeUniddRecbvlReserv;
    }

    public void setIndrActeUniddRecbvlReserv(SPBString indrActeUniddRecbvlReserv) {
        this.indrActeUniddRecbvlReserv = indrActeUniddRecbvlReserv;
    }

    public SPBLocalDateTime getDtHrIncl() {
        return dtHrIncl;
    }

    public void setDtHrIncl(SPBLocalDateTime dtHrIncl) {
        this.dtHrIncl = dtHrIncl;
    }

    public SPBString getIndrSitOp() {
        return indrSitOp;
    }

    public void setIndrSitOp(SPBString indrSitOp) {
        this.indrSitOp = indrSitOp;
    }

    public SPBString getIndrAutcCess() {
        return indrAutcCess;
    }

    public void setIndrAutcCess(SPBString indrAutcCess) {
        this.indrAutcCess = indrAutcCess;
    }

    public List<GrupoRRC0021R1CesAutd> getListagrupoRRC0021R1CesAutd() {
        return listagrupoRRC0021R1CesAutd;
    }

    public void setListagrupoRRC0021R1CesAutd(List<GrupoRRC0021R1CesAutd> listagrupoRRC0021R1CesAutd) {
        this.listagrupoRRC0021R1CesAutd = listagrupoRRC0021R1CesAutd;
    }

    public List<GrupoRRC0021R1RenegcDiv> getListagrupoRRC0021R1RenegcDiv() {
        return listagrupoRRC0021R1RenegcDiv;
    }

    public void setListagrupoRRC0021R1RenegcDiv(List<GrupoRRC0021R1RenegcDiv> listagrupoRRC0021R1RenegcDiv) {
        this.listagrupoRRC0021R1RenegcDiv = listagrupoRRC0021R1RenegcDiv;
    }

    public List<GrupoRRC0021R1Titlar> getListagrupoRRC0021R1Titlar() {
        return listagrupoRRC0021R1Titlar;
    }

    public void setListagrupoRRC0021R1Titlar(List<GrupoRRC0021R1Titlar> listagrupoRRC0021R1Titlar) {
        this.listagrupoRRC0021R1Titlar = listagrupoRRC0021R1Titlar;
    }

}
