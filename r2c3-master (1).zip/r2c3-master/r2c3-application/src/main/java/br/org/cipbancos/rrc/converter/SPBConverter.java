package br.org.cipbancos.rrc.converter;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import br.org.cipbancos.rrc.bean.arrc017.GrupoARRC017;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBInteger;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDateTime;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLong;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.util.DateUtil;

/**
 * Classa responsavel por converter tipos primitivos para objetos do tipo SPB.
 *
 * @author otavio.ferreira
 * @since 1.0
 */
public class SPBConverter {




    private static final Logger LOG = LoggerFactory.getLogger(SPBConverter.class);

    private static final String MSG_PATTERN_INVALIDO = "O pattern informado está incorreto.";
    private static final String MSG_DATA_NULA = "Data nula.";

    private SPBConverter() {
    }

    /**
     * Converte uma String para uma SPBString
     *
     * @param value Valor a ser convertido.
     * @return Um SPBString com o valor informado.
     */
    public static SPBString stringToSPBString(String value) {
        if (value == null)
            return null;
        return new SPBString(value);
    }

    /**
     * Converte um Date representando uma data para um SPBLocalDate.
     *
     * @param value Date a ser convertida.
     * @return Um SPBLocalDate com a data informada convertida para LocalDate.
     */
    public static SPBLocalDate dateToSPBLocalDate(Date value) {
        if (value == null)
            return null;
        try {
            return new SPBLocalDate(LocalDate.fromDateFields(value));
        } catch (IllegalArgumentException e) {
            LOG.error(MSG_PATTERN_INVALIDO, e);
        }

        return new SPBLocalDate();
    }

    /**
     * Converte uma String representando uma data utilizando um pattern informado.
     *
     * @param value   String no formato de data.
     * @param pattern Pattern a ser utilizado na conversão.
     * @return Um SPBLocalDate com a data informada convertida para LocalDate.
     */
    public static SPBLocalDate dateStringToSPBLocalDate(String value, String pattern) {
        if (value == null)
            return null;
        try {
            return new SPBLocalDate(LocalDate.parse(value, DateTimeFormat.forPattern(pattern)));
        } catch (IllegalArgumentException e) {
            LOG.error(MSG_PATTERN_INVALIDO, e);
        }

        return new SPBLocalDate();
    }

    /**
     * Converte um java.sql.Date para um SPBLocalDate.
     *
     * @param value java.sql.Date para converter.
     * @return Um SPBLocalDate com a data informada convertida para LocalDate.
     */
    public static SPBLocalDate sqlDateToSPBLocalDate(java.sql.Date value) {
        try {
            if (null == value) {
                if (Objects.isNull(value)) {
                    throw new IllegalArgumentException();
                }
            }
            Date data = new Date(value.getTime());
            return new SPBLocalDate(DateUtil.toLocalDate(data));
        } catch (IllegalArgumentException e) {
            LOG.error(MSG_DATA_NULA, e);
        }

        return new SPBLocalDate();
    }

    /**
     * Converte um SPBLocalDate para um java.sql.Date.
     *
     * @param value SPBLocalDate para converter.
     * @return Um java.sql.Date com a data informada.
     */
    public static java.sql.Date spbLocalDateToSqlDate(SPBLocalDate value) {
        try {
            if (null == value) {
                throw new IllegalArgumentException();
            }
            return new java.sql.Date(value.getValue().toDate().getTime());
        } catch (IllegalArgumentException e) {
            LOG.error(MSG_DATA_NULA, e);
        }

        return null;
    }

    /**
     * Converte uma String representando uma datahora utilizando um pattern informado.
     *
     * @param value   String no formato de datahora.
     * @param pattern Pattern a ser utilizado na conversão.
     * @return Um SPBLocalDateTime com a datahora informada convertida para LocalDateTime.
     */
    public static SPBLocalDateTime dateTimeToSPBLocalDateTime(DateTime value, String pattern) {
        try {
            if (null == value) {
                throw new IllegalArgumentException(MSG_DATA_NULA);
            }

            return new SPBLocalDateTime(
                    LocalDateTime.parse((new SimpleDateFormat(pattern).format(value.toDate())),
                            DateTimeFormat.forPattern(pattern)));
        } catch (IllegalArgumentException e) {
            LOG.error(MSG_PATTERN_INVALIDO, e);
        }

        return new SPBLocalDateTime();
    }

    /**
     * Converte uma String para um SPBBigDecimal
     *
     * @param value Valor a ser convertido.
     * @return Um SPBBigDecimal com o valor informado.
     * @throws NumberFormatException Caso o valor informado não possa ser convertido para BigDecimal.
     */
    public static SPBBigDecimal stringToSPBBigDecimal(String value) {
        if (value == null)
            return null;
        try {
            return new SPBBigDecimal(new BigDecimal(value));
        } catch (NumberFormatException e) {
            LOG.error("Não foi possível converter o valor informmado para BigDecimal.", e);
        }

        return new SPBBigDecimal();
    }

    /**
     * Converte uma String para um SPBInteger
     *
     * @param value Valor a ser convertido.
     * @return Um SPBInteger com o valor informado.
     * @throws NumberFormatException Caso o valor informado não possa ser convertido para Integer.
     */
    public static SPBInteger stringToSPBInteger(String value) {
        if (value == null)
            return null;
        try {
            return new SPBInteger(Integer.parseInt(value));
        } catch (NumberFormatException e) {
            LOG.error("Não foi possível converter o valor informmado para SPBInteger.", e);
        }

        return new SPBInteger();
    }

    /**
     * Converte um Integer para um SPBInteger
     *
     * @param value Valor a ser convertido.
     * @return Um SPBInteger com o valor informado.
     * @throws NumberFormatException Caso o valor informado não possa ser convertido para Integer.
     */
    public static SPBInteger integerToSPBInteger(Integer value) {
        if (value == null)
            return null;
        return new SPBInteger(value);
    }

    /**
     * Converte uma String para um SPBLong
     *
     * @param value Valor a ser convertido.
     * @return Um SPBLong com o valor informado.
     * @throws NumberFormatException Caso o valor informado não possa ser convertido para Long.
     */
    public static SPBLong stringToSPBLong(String value) {
        if (value == null)
            return null;
        try {
            return new SPBLong(Long.parseLong(value));
        } catch (NumberFormatException e) {
            LOG.error("Não foi possível converter o valor informmado para SPBLong.", e);
        }

        return new SPBLong();
    }

    /**
     * Converte um Long para um SPBLong
     *
     * @param value Valor a ser convertido.
     * @return Um SPBLong com o valor informado.
     * @throws NumberFormatException Caso o valor informado não possa ser convertido para Long.
     */
    public static SPBLong longToSPBLong(Long value) {
        if (value == null)
            return null;
        return new SPBLong(value);
    }

    /**
     * Converte uma String para um SPBBigDecimal
     *
     * @param value Valor a ser convertido.
     * @return Um SPBBigDecimal com o valor informado.
     * @throws NumberFormatException Caso o valor informado não possa ser convertido para BigDecimal.
     */
    public static SPBBigDecimal bigDecimalToSPBBigDecimal(BigDecimal value) {
        if (value == null)
            return null;
        try {
            return new SPBBigDecimal(value);
        } catch (NumberFormatException e) {
            LOG.error("Não foi possível converter o valor informmado para BigDecimal.", e);
        }

        return new SPBBigDecimal();
    }
}
