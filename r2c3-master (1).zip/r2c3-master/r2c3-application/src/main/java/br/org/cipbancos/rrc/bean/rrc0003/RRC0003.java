package br.org.cipbancos.rrc.bean.rrc0003;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDateTime;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("RRC0003")
public class RRC0003 extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CodMsg")
    private SPBString codMsg;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamAlias("CNPJER")
    private SPBString cNPJER;

    @XStreamAlias("CPF_CNPJPartNegcdr")
    private SPBString cPFCNPJPartNegcdr;

    @XStreamAlias("IdentdOp")
    private SPBString identdOp;

    @XStreamAlias("IdentdNegcRecbvl")
    private SPBString identdNegcRecbvl;

    @XStreamAlias("IndrTpNegc")
    private SPBString indrTpNegc;

    @XStreamAlias("IndrIA")
    private SPBString indrIA;

    @XStreamAlias("IndrActeUniddRecbvlReserv")
    private SPBString indrActeUniddRecbvlReserv;

    @XStreamAlias("DtHrIncl")
    private SPBLocalDateTime dtHrIncl;

    @XStreamAlias("IndrRegrDivs")
    private SPBString indrRegrDivs;

    @XStreamAlias("IndrAutcCess")
    private SPBString indrAutcCess;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0003_Titlar")
    private List<GrupoRRC0003Titlar> listagrupoRRC0003Titlar = new ArrayList<>();

    public SPBString getCodMsg() {
        return codMsg;
    }

    public void setCodMsg(SPBString codMsg) {
        this.codMsg = codMsg;
    }

    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public SPBString getcNPJER() {
        return cNPJER;
    }

    public void setcNPJER(SPBString cNPJER) {
        this.cNPJER = cNPJER;
    }

    public SPBString getcPFCNPJPartNegcdr() {
        return cPFCNPJPartNegcdr;
    }

    public void setcPFCNPJPartNegcdr(SPBString cPFCNPJPartNegcdr) {
        this.cPFCNPJPartNegcdr = cPFCNPJPartNegcdr;
    }

    public SPBString getIdentdOp() {
        return identdOp;
    }

    public void setIdentdOp(SPBString identdOp) {
        this.identdOp = identdOp;
    }

    public SPBString getIdentdNegcRecbvl() {
        return identdNegcRecbvl;
    }

    public void setIdentdNegcRecbvl(SPBString identdNegcRecbvl) {
        this.identdNegcRecbvl = identdNegcRecbvl;
    }

    public SPBString getIndrTpNegc() {
        return indrTpNegc;
    }

    public void setIndrTpNegc(SPBString indrTpNegc) {
        this.indrTpNegc = indrTpNegc;
    }

    public SPBString getIndrIA() {
        return indrIA;
    }

    public void setIndrIA(SPBString indrIA) {
        this.indrIA = indrIA;
    }

    public SPBString getIndrActeUniddRecbvlReserv() {
        return indrActeUniddRecbvlReserv;
    }

    public void setIndrActeUniddRecbvlReserv(SPBString indrActeUniddRecbvlReserv) {
        this.indrActeUniddRecbvlReserv = indrActeUniddRecbvlReserv;
    }

    public SPBLocalDateTime getDtHrIncl() {
        return dtHrIncl;
    }

    public void setDtHrIncl(SPBLocalDateTime dtHrIncl) {
        this.dtHrIncl = dtHrIncl;
    }

    public SPBString getIndrRegrDivs() {
        return indrRegrDivs;
    }

    public void setIndrRegrDivs(SPBString indrRegrDivs) {
        this.indrRegrDivs = indrRegrDivs;
    }

    public List<GrupoRRC0003Titlar> getListagrupoRRC0003Titlar() {
        return listagrupoRRC0003Titlar;
    }

    public void setListagrupoRRC0003Titlar(List<GrupoRRC0003Titlar> listagrupoRRC0003Titlar) {
        this.listagrupoRRC0003Titlar = listagrupoRRC0003Titlar;
    }

    public SPBString getIndrAutcCess() {
        return indrAutcCess;
    }

    public void setIndrAutcCess(SPBString indrAutcCess) {
        this.indrAutcCess = indrAutcCess;
    }
}
