package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.rrc.vo.CancelamentoUnidadeRecebivel;

public interface CancelamentoUnidadeRecebivelDAO {

    /**
     * Grava no BD as Cancelamento unidades recebiveis
     *
     * @param cancelamentoUnidadeRecebivel Cancelamento Unideda Recabível para ser inserid
     *
     */
    void inserir(CancelamentoUnidadeRecebivel cancelamentoUnidadeRecebivel);

    /**
     * Atualiza no BD as Cancelamento unidades recebiveis
     *
     * @param cancelamentoUnidadeRecebivel Cancelamento Unideda Recabível para ser atualizada.
     *
     */
    void atualizar(CancelamentoUnidadeRecebivel cancelamentoUnidadeRecebivel);

    /**
     * Exclui no BD as Cancelamento unidades recebiveis
     *
     * @param cancelamentoUnidadeRecebivel Cancelamento Unideda Recabível para ser excluída.
     */
    void excluir(CancelamentoUnidadeRecebivel cancelamentoUnidadeRecebivel);

    /**
     * Busca no BD as Cancelamento unidades recebiveis
     *
     * @param cancelamentoUnidadeRecebivel Cancelamento Unideda Recabível para ser buscada.
     */
    CancelamentoUnidadeRecebivel buscar(CancelamentoUnidadeRecebivel cancelamentoUnidadeRecebivel);

}
