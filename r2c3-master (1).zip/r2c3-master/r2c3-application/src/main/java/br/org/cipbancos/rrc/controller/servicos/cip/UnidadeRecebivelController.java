package br.org.cipbancos.rrc.controller.servicos.cip;

import br.org.cip.api.r2c3.UnidadesRecebiveisApi;
import br.org.cip.api.r2c3.model.Erro;
import br.org.cip.api.r2c3.model.UnidadeRecebivelBase;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import br.org.cipbancos.atlante.api.handler.Context;
import br.org.cipbancos.atlante.api.handler.ContextLocator;
import br.org.cipbancos.atlante.config.HttpTransportConfig;
import br.org.cipbancos.atlante.session.AtlanteSession;
import br.org.cipbancos.atlante.util.PartyUtility;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.rrc0010.GrupoRRC0010UniddRecbvl;
import br.org.cipbancos.rrc.bean.rrc0010.RRC0010;
import br.org.cipbancos.rrc.handler.PaginacaoHandler;
import br.org.cipbancos.rrc.handler.rrc0010.RRC0010Handler;
import br.org.cipbancos.rrc.util.DateUtil;
import br.org.cipbancos.rrc.util.PaginacaoUtil;
import br.org.cipbancos.rrc.vo.ResultadoPaginado;

import java.util.Optional;

@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS)
@Controller
public class UnidadeRecebivelController implements UnidadesRecebiveisApi {

    @Autowired
    private RRC0010Handler rrc0010Handler;

    @Autowired
    private PaginacaoHandler paginacaoHandler;

    @Autowired
    private PaginacaoUtil paginacaoUtil;

    private static final Logger LOG = LoggerFactory.getLogger(UnidadeRecebivelController.class);

    private Context getContext() {
        return ContextLocator.getContext();
    }

    @Override
    public ResponseEntity<List<UnidadeRecebivelBase>> getUnidadesRecebiveis(String xJwsSignature, String acceptEncoding, String contentEncoding, String cnpjOuCnpjBaseOuCpfUsuFinalRecbdr, String codInstitdrArrajPgto,
                                                                            String cnpjCreddrSub, LocalDate dtPrevtLiquid, Double vlrLivre, LocalDate dtIniPrevtLiquid, LocalDate dtFimPrevtLiquid, String indrTpNegc,
                                                                            String cnpjOuCnpjBaseOuCpfTitlar, Integer numeroPagina, Integer tamanhoPagina, Long identificadorTransacao) {
        Context ctx = getContext();
        Long idTransacao = Optional.ofNullable(identificadorTransacao).orElse(ctx.getRootId());

        List<UnidadeRecebivelBase> resultado = null;
        ResultadoPaginado resultadoPaginado = null;

        if(!Optional.ofNullable(identificadorTransacao).isPresent()) {

            RRC0010 rrc0010 = getRrc0010(cnpjOuCnpjBaseOuCpfUsuFinalRecbdr,
                    codInstitdrArrajPgto,
                    cnpjCreddrSub,
                    dtPrevtLiquid,
                    vlrLivre,
                    dtIniPrevtLiquid,
                    dtFimPrevtLiquid,
                    indrTpNegc,
                    cnpjOuCnpjBaseOuCpfTitlar);
            rrc0010.setaPaginacao(numeroPagina, tamanhoPagina);

            rrc0010Handler.processSPB(rrc0010, getContext());
            Object o = AtlanteSession.getSession().getHttpRecords().get(0);
            if(AtlanteSession.getSession().getHttpRecords() == null || AtlanteSession.getSession().getHttpRecords().isEmpty()){
                LOG.info("Sem retorno após esperar 60 segundos.");
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            if (o instanceof List) {
                resultado = (List<UnidadeRecebivelBase>) o;
                paginacaoHandler.insereDadosAPaginar(o, ctx.getRootId());
                if (resultado.isEmpty()) {
                    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
                }
            } else if(o instanceof Erro) {
                return new ResponseEntity(o, HttpStatus.PRECONDITION_FAILED);
            }
        } else {
            resultado = paginacaoHandler.paginadosUnidadeRecebivel(((identificadorTransacao == null)?ctx.getRootId():identificadorTransacao), tamanhoPagina, numeroPagina);
        }

        // TODO - Refatorar para utilizar os valores direto do Request
        boolean paramIncluido = false;
        String uri = "/v1/unidades-recebiveis" + "?identificadorTransacao=" + idTransacao;
        if (cnpjOuCnpjBaseOuCpfUsuFinalRecbdr != null) {
            uri += "&cnpjOuCnpjBaseOuCpfUsuFinalRecbdr=" + cnpjOuCnpjBaseOuCpfUsuFinalRecbdr;
            paramIncluido = true;
        }
        if (codInstitdrArrajPgto != null) {
            uri += (paramIncluido ? "&" : "?") + "codInstitdrArrajPgto=" + codInstitdrArrajPgto;
            paramIncluido = true;
        }
        if (cnpjCreddrSub != null) {
            uri += (paramIncluido ? "&" : "?") + "cnpjCreddrSub=" + cnpjCreddrSub;
            paramIncluido = true;
        }
        if (dtPrevtLiquid != null) {
            uri += (paramIncluido ? "&" : "?") + "dtPrevtLiquid=" + dtPrevtLiquid.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            paramIncluido = true;
        }
        if (vlrLivre != null) {
            uri += (paramIncluido ? "&" : "?") + "vlrLivre=" + vlrLivre;
            paramIncluido = true;
        }
        if (dtIniPrevtLiquid != null) {
            uri += (paramIncluido ? "&" : "?") + "dtIniPrevtLiquid=" + dtIniPrevtLiquid.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            paramIncluido = true;
        }
        if (dtFimPrevtLiquid != null) {
            uri += (paramIncluido ? "&" : "?") + "dtFimPrevtLiquid=" + dtFimPrevtLiquid.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            paramIncluido = true;
        }
        if (indrTpNegc != null) {
            uri += (paramIncluido ? "&" : "?") + "indrTpNegc=" + indrTpNegc;
            paramIncluido = true;
        }
        if (cnpjOuCnpjBaseOuCpfTitlar != null) {
            uri += (paramIncluido ? "&" : "?") + "cnpjOuCnpjBaseOuCpfTitlar=" + cnpjOuCnpjBaseOuCpfTitlar;
        }

        resultadoPaginado = paginacaoUtil.paginar(resultado, numeroPagina, tamanhoPagina, uri, idTransacao);
        return new ResponseEntity<>(resultadoPaginado.getLista(), resultadoPaginado.getLinkHeader(), HttpStatus.OK);
    }

    private RRC0010 getRrc0010(String cnpjOuCnpjBaseOuCpfUsuFinalRecbdr, String codInstitdrArrajPgto, String cnpjCreddrSub,
            LocalDate dtPrevtLiquid, Double vlrLivre, LocalDate dtIniPrevtLiquid, LocalDate dtFimPrevtLiquid,
            String indrTpNegc, String cnpjOuCnpjBaseOuCpfTitlar) {
        RRC0010 rrc0010 = new RRC0010();
        rrc0010.setCodMsg(new SPBString("RRC0010"));
        String partyAdmin = PartyUtility.partyIdToIspb(
                Integer.valueOf(getContext().getProperties().get(HttpTransportConfig.HEADER_PARTY_ADMIN_ID).toString()));
        rrc0010.setIdentdPartAdmtd(new SPBString(partyAdmin));
        rrc0010.setIdentdPartPrincipal(new SPBString(PartyUtility.partyIdToIspb(getContext().getPartyId())));

        GrupoRRC0010UniddRecbvl ur = new GrupoRRC0010UniddRecbvl();
        if (cnpjOuCnpjBaseOuCpfUsuFinalRecbdr != null) {
            ur.setCNPJCNPJBaseCPFUsuFinalRecbdr(new SPBString(cnpjOuCnpjBaseOuCpfUsuFinalRecbdr));
        }
        if (codInstitdrArrajPgto != null) {
            ur.setCodInstitdrArrajPgto(new SPBString(codInstitdrArrajPgto));
        }
        if (cnpjCreddrSub != null) {
            ur.setCNPJCreddrSub(new SPBString(String.format("%014d", Long.parseLong(cnpjCreddrSub))));
        }
        if (dtPrevtLiquid != null) {
            ur.setDtPrevtLiquid(new SPBLocalDate(DateUtil.toLocalDate(Date.from(dtPrevtLiquid.atStartOfDay(ZoneId.systemDefault()).toInstant()))));
        }
        if (vlrLivre != null) {
            ur.setVlrLivre(new SPBBigDecimal(BigDecimal.valueOf(vlrLivre)));
        }
        if (dtIniPrevtLiquid != null) {
            ur.setDtIniPrevtLiquid(new SPBLocalDate(DateUtil.toLocalDate(Date.from(dtIniPrevtLiquid.atStartOfDay(ZoneId.systemDefault()).toInstant()))));
        }
        if (dtFimPrevtLiquid != null) {
            ur.setDtFimPrevtLiquid(new SPBLocalDate(DateUtil.toLocalDate(Date.from(dtFimPrevtLiquid.atStartOfDay(ZoneId.systemDefault()).toInstant()))));
        }
        if (indrTpNegc != null) {
            ur.setIndrTpNegc(new SPBString(indrTpNegc));
        }
        if (cnpjOuCnpjBaseOuCpfTitlar != null) {
            ur.setCNPJCNPJBaseCPFTitlar(new SPBString(cnpjOuCnpjBaseOuCpfTitlar));
        }
        rrc0010.setGrupoRRC0010UniddRecbvl(ur);
        return rrc0010;
    }
}
