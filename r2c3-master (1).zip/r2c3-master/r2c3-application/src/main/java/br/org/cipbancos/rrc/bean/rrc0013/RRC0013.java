package br.org.cipbancos.rrc.bean.rrc0013;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.PartPrincXPartAdm;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

import java.io.Serializable;

@XStreamAlias("RRC0013")
public class RRC0013 extends ErrorCodeBean implements Serializable, PartPrincXPartAdm {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CodMsg")
    private SPBString codMsg;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamAlias("Grupo_RRC0013_CanceltAutcEnvAgenda")
    private GrupoRRC0013CanceltAutcEnvAgenda grupoRRC0013CanceltAutcEnvAgenda;

    @XStreamOmitField
    private String recordId;

    public SPBString getCodMsg() {
        return codMsg;
    }

    public void setCodMsg(SPBString codMsg) {
        this.codMsg = codMsg;
    }

    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public GrupoRRC0013CanceltAutcEnvAgenda getGrupoRRC0013CanceltAutcEnvAgenda() {
        return grupoRRC0013CanceltAutcEnvAgenda;
    }

    public void setGrupoRRC0013CanceltAutcEnvAgenda(GrupoRRC0013CanceltAutcEnvAgenda grupoRRC0013CanceltAutcEnvAgenda) {
        this.grupoRRC0013CanceltAutcEnvAgenda = grupoRRC0013CanceltAutcEnvAgenda;
    }

    @Override
    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }
}
