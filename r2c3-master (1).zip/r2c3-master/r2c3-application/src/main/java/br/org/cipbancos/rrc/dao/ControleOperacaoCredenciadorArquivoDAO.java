package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.rrc.vo.ControleOperacaoCredenciadorArquivoVO;

import java.util.List;

public interface ControleOperacaoCredenciadorArquivoDAO {

    void inserir(ControleOperacaoCredenciadorArquivoVO controleOperacaoCredenciadorArquivoVO);

    List<ControleOperacaoCredenciadorArquivoVO> buscar(Integer grade);

}
