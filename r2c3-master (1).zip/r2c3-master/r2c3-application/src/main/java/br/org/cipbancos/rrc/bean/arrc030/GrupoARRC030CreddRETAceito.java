package br.org.cipbancos.rrc.bean.arrc030;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@XStreamAlias("Grupo_ARRC030RET_CreddActo")
public class GrupoARRC030CreddRETAceito extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1;

    @XStreamAlias("IndrManutCad")
    private SPBString indicadorManutencaoCadastro;

    @XStreamAlias("TpPessoa")
    private SPBString tipoPessoa;

    @XStreamAlias("CPF_CNPJCli")
    private SPBString cpfCNPJCliente;

    @XStreamAlias("Nom_RzSocCli")
    private SPBString nomeRazaoSocialCliente;

    @XStreamAlias("NomFants")
    private SPBString nomeFantasia;

    @XStreamAlias("End")
    private SPBString endereco;

    @XStreamAlias("CEP")
    private SPBString cep;

    @XStreamAlias("Munic")
    private SPBString municipio;

    @XStreamAlias("UF")
    private SPBString uf;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC030RET_ArrajPgto")
    private List<GrupoARRC030ArrajPgto> listagrupoARRC030ArrajPgto = new ArrayList<>();

    public SPBString getIndicadorManutencaoCadastro() {
        return indicadorManutencaoCadastro;
    }

    public void setIndicadorManutencaoCadastro(SPBString indicadorManutencaoCadastro) {
        this.indicadorManutencaoCadastro = indicadorManutencaoCadastro;
    }

    public SPBString getTipoPessoa() {
        return tipoPessoa;
    }

    public void setTipoPessoa(SPBString tipoPessoa) {
        this.tipoPessoa = tipoPessoa;
    }

    public SPBString getCpfCNPJCliente() {
        return cpfCNPJCliente;
    }

    public void setCpfCNPJCliente(SPBString cpfCNPJCliente) {
        this.cpfCNPJCliente = cpfCNPJCliente;
    }

    public SPBString getNomeRazaoSocialCliente() {
        return nomeRazaoSocialCliente;
    }

    public void setNomeRazaoSocialCliente(SPBString nomeRazaoSocialCliente) {
        this.nomeRazaoSocialCliente = nomeRazaoSocialCliente;
    }

    public SPBString getNomeFantasia() {
        return nomeFantasia;
    }

    public void setNomeFantasia(SPBString nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }

    public SPBString getEndereco() {
        return endereco;
    }

    public void setEndereco(SPBString endereco) {
        this.endereco = endereco;
    }

    public SPBString getCep() {
        return cep;
    }

    public void setCep(SPBString cep) {
        this.cep = cep;
    }

    public SPBString getMunicipio() {
        return municipio;
    }

    public void setMunicipio(SPBString municipio) {
        this.municipio = municipio;
    }

    public SPBString getUf() {
        return uf;
    }

    public void setUf(SPBString uf) {
        this.uf = uf;
    }

    public List<GrupoARRC030ArrajPgto> getListagrupoARRC030ArrajPgto() {
        return listagrupoARRC030ArrajPgto;
    }

    public void setListagrupoARRC030ArrajPgto(List<GrupoARRC030ArrajPgto> listagrupoARRC030ArrajPgto) {
        this.listagrupoARRC030ArrajPgto = listagrupoARRC030ArrajPgto;
    }
}
