package br.org.cipbancos.rrc.bean.ardc500;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;

@XStreamAlias("Grupo_ARDC500_DomclBanc")
public class GrupoARDC500DomclBanc extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CPFTitlarCt")
    private String cNPJCPFTitlarCt;

    @XStreamAlias("ISPBBcoRecbdr")
    private String iSPBBcoRecbdr;

    @XStreamAlias("TpCt")
    private String tpCt;

    @XStreamAlias("Ag")
    private String ag;

    @XStreamAlias("Ct")
    private String ct;

    @XStreamAlias("CtPgto")
    private String ctPgto;

    @XStreamAlias("VlrPrevtLiquid")
    private BigDecimal vlrPrevtLiquid;

    @XStreamAlias("DtEftLiquid")
    private LocalDate dtEftLiquid;

    @XStreamAlias("VlrEftLiquid")
    private BigDecimal vlrEftLiquid;

    @XStreamAlias("IndrVlrLivre")
    private String indrVlrLivre;

    @XStreamAlias("IdentdCIPOp")
    private Long identdCIPOp;

    public String getCNPJCPFTitlarCt() {
        return cNPJCPFTitlarCt;
    }

    public void setCNPJCPFTitlarCt(String cNPJCPFTitlarCt) {
        this.cNPJCPFTitlarCt = cNPJCPFTitlarCt;
    }

    public String getISPBBcoRecbdr() {
        return iSPBBcoRecbdr;
    }

    public void setISPBBcoRecbdr(String iSPBBcoRecbdr) {
        this.iSPBBcoRecbdr = iSPBBcoRecbdr;
    }

    public String getTpCt() {
        return tpCt;
    }

    public void setTpCt(String tpCt) {
        this.tpCt = tpCt;
    }

    public String getAg() {
        return ag;
    }

    public void setAg(String ag) {
        this.ag = ag;
    }

    public String getCt() {
        return ct;
    }

    public void setCt(String ct) {
        this.ct = ct;
    }

    public String getCtPgto() {
        return ctPgto;
    }

    public void setCtPgto(String ctPgto) {
        this.ctPgto = ctPgto;
    }

    public BigDecimal getVlrPrevtLiquid() {
        return vlrPrevtLiquid;
    }

    public void setVlrPrevtLiquid(BigDecimal vlrPrevtLiquid) {
        this.vlrPrevtLiquid = vlrPrevtLiquid;
    }

    public LocalDate getDtEftLiquid() {
        return dtEftLiquid;
    }

    public void setDtEftLiquid(LocalDate dtEftLiquid) {
        this.dtEftLiquid = dtEftLiquid;
    }

    public BigDecimal getVlrEftLiquid() {
        return vlrEftLiquid;
    }

    public void setVlrEftLiquid(BigDecimal vlrEftLiquid) {
        this.vlrEftLiquid = vlrEftLiquid;
    }

    public String getIndrVlrLivre() {
        return indrVlrLivre;
    }

    public void setIndrVlrLivre(String indrVlrLivre) {
        this.indrVlrLivre = indrVlrLivre;
    }

    public Long getIdentdCIPOp() {
        return identdCIPOp;
    }

    public void setIdentdCIPOp(Long identdCIPOp) {
        this.identdCIPOp = identdCIPOp;
    }

}
