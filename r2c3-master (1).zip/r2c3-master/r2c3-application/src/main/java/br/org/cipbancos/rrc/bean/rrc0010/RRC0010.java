package br.org.cipbancos.rrc.bean.rrc0010;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.PartPrincXPartAdm;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

import java.io.Serializable;
import java.util.List;

@XStreamAlias("RRC0010")
public class RRC0010 extends ErrorCodeBean implements PartPrincXPartAdm, Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CodMsg")
    private SPBString codMsg;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamAlias("Grupo_RRC0010_UniddRecbvl")
    private GrupoRRC0010UniddRecbvl grupoRRC0010UniddRecbvl;

    @XStreamOmitField
    private List<String> cnpjsCompletosUsuFinalRecbdr;

    @XStreamOmitField
    private String recordId;

    @XStreamOmitField
    private Integer numeroPagina;

    @XStreamOmitField
    private Integer tamanhoPagina;

    public SPBString getCodMsg() {
        return codMsg;
    }

    public void setCodMsg(SPBString codMsg) {
        this.codMsg = codMsg;
    }

    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public GrupoRRC0010UniddRecbvl getGrupoRRC0010UniddRecbvl() {
        return grupoRRC0010UniddRecbvl;
    }

    public void setGrupoRRC0010UniddRecbvl(GrupoRRC0010UniddRecbvl grupoRRC0010UniddRecbvl) {
        this.grupoRRC0010UniddRecbvl = grupoRRC0010UniddRecbvl;
    }

    public boolean isConsultaPorTitular(){
        return grupoRRC0010UniddRecbvl != null && grupoRRC0010UniddRecbvl.getCNPJCNPJBaseCPFTitlar() != null && grupoRRC0010UniddRecbvl.getCNPJCNPJBaseCPFTitlar().getValue() != null && !grupoRRC0010UniddRecbvl.getCNPJCNPJBaseCPFTitlar().getValue().trim().equals("");
    }

    public List<String> getCnpjsCompletosUsuFinalRecbdr() {
        return cnpjsCompletosUsuFinalRecbdr;
    }

    public void setCnpjsCompletosUsuFinalRecbdr(List<String> cnpjsCompletosUsuFinalRecbdr) {
        this.cnpjsCompletosUsuFinalRecbdr = cnpjsCompletosUsuFinalRecbdr;
    }

    @Override
    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }

    public Integer getNumeroPagina() {
        return numeroPagina;
    }

    public void setNumeroPagina(Integer numeroPagina) {
        this.numeroPagina = numeroPagina;
    }

    public Integer getTamanhoPagina() {
        return tamanhoPagina;
    }

    public void setTamanhoPagina(Integer tamanhoPagina) {
        this.tamanhoPagina = tamanhoPagina;
    }

    public void setaPaginacao(Integer numeroPagina, Integer tamanhoPagina) {
        this.numeroPagina = numeroPagina;
        this.tamanhoPagina = tamanhoPagina;
    }
}
