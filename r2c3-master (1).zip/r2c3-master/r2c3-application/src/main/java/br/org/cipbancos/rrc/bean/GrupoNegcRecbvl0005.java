package br.org.cipbancos.rrc.bean;

import java.util.Set;

import br.org.cipbancos.rrc.enums.TipoNegociacao;

public interface GrupoNegcRecbvl0005 extends GrupoNegcRecbvl {

    default boolean isAntecipacao() {
        return this.getIndrTpNegc().getValue().equals(TipoNegociacao.AN.getValue());
    }

    default boolean isPenhora() {
        return this.getIndrTpNegc().getValue().equals(TipoNegociacao.OP.getValue());
    }

    boolean isInterop();

    Set<String> getEstabelecimentosBloqueados();

    void setEstabelecimentosBloqueados(Set<String> estabelecimentosBloqueados);

}
