package br.org.cipbancos.rrc.builder;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBInteger;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.arrc018.GrupoARRC018NegcRecbvOutrasInst;
import br.org.cipbancos.rrc.util.DateUtil;

import java.math.BigDecimal;
import java.util.Date;

public class GrupoARRC018NegcRecbvOutrasInstBuilder {

    private GrupoARRC018NegcRecbvOutrasInst grupoARRC018NegcRecbvOutrasInst;

    private GrupoARRC018NegcRecbvOutrasInstBuilder(){
        this.grupoARRC018NegcRecbvOutrasInst = new GrupoARRC018NegcRecbvOutrasInst();
    }

    public static GrupoARRC018NegcRecbvOutrasInstBuilder builder(){
        return new GrupoARRC018NegcRecbvOutrasInstBuilder();
    }

    public GrupoARRC018NegcRecbvOutrasInstBuilder comIndrRegraDivisao(String indrRegraDivisao){
        if (indrRegraDivisao != null) {
            grupoARRC018NegcRecbvOutrasInst.setIndrRegrDivs(new SPBString(indrRegraDivisao));
        }
        return this;
    }

    public GrupoARRC018NegcRecbvOutrasInstBuilder comValorNegociado(BigDecimal valorNegociado){
        if (valorNegociado != null) {
            grupoARRC018NegcRecbvOutrasInst.setVlrNegcd(new SPBBigDecimal(valorNegociado));
        }
        return this;
    }

    public GrupoARRC018NegcRecbvOutrasInstBuilder comValorPercentualNegociadoConstituir(BigDecimal valorPercentualNegociadoConstituir){
        if (valorPercentualNegociadoConstituir != null) {
            grupoARRC018NegcRecbvOutrasInst.setVlrPercNegcdConstitr(new SPBBigDecimal(valorPercentualNegociadoConstituir));
        }
        return this;
    }

    public GrupoARRC018NegcRecbvOutrasInstBuilder comDataFimOperacao(Date dataFimOperacao){
        if (dataFimOperacao != null) {
            grupoARRC018NegcRecbvOutrasInst.setDtFimOp(new SPBLocalDate(DateUtil.toLocalDate(dataFimOperacao)));
        }
        return this;
    }

    public GrupoARRC018NegcRecbvOutrasInstBuilder comPriorddNegcRecbvl(Integer priorddNegcRecbvl){
        if (priorddNegcRecbvl != null) {
            grupoARRC018NegcRecbvOutrasInst.setPriorddNegcRecbvl(new SPBInteger(priorddNegcRecbvl));
        }
        return this;
    }

    public GrupoARRC018NegcRecbvOutrasInst build(){
        return this.grupoARRC018NegcRecbvOutrasInst;
    }
}
