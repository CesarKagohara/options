package br.org.cipbancos.rrc.bean.rrc0009;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

public class GrupoRRC0009RenegcDiv implements Serializable {

    @XStreamAlias("IdentdOpOrRenegcDiv")
    private SPBString identdOpOrRenegcDiv;

    public SPBString getIdentdOpOrRenegcDiv() {
        return identdOpOrRenegcDiv;
    }

    public void setIdentdOpOrRenegcDiv(SPBString identdOpOrRenegcDiv) {
        this.identdOpOrRenegcDiv = identdOpOrRenegcDiv;
    }
}
