package br.org.cipbancos.rrc.bean;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

public class AtivarVarreduraParametro {

    @XStreamAlias("Nome")
    private SPBString nome;

    @XStreamAlias("Valor")
    private SPBString valor;

    public SPBString getNome() {
        return nome;
    }

    public void setNome(SPBString nome) {
        this.nome = nome;
    }

    public SPBString getValor() {
        return valor;
    }

    public void setValor(SPBString valor) {
        this.valor = valor;
    }
}
