package br.org.cipbancos.rrc.bean;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.vo.FracaoUnidadeRecebivelOperacao;

import java.util.List;

public interface GrupoRegRecbvl0019 extends GrupoRegRecbvl {

    SPBString getCNPJCreddrSub();

    List<FracaoUnidadeRecebivelOperacao> getFracoes();

    void setFracoes(List<FracaoUnidadeRecebivelOperacao> fracoes);

}
