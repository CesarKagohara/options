package br.org.cipbancos.rrc.bean.arrc001;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

public class GrupoARRC001ArrajPgto extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CodInstitdrArrajPgto")
    private SPBString codInstitdrArrajPgto;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC001_UniddRecbvl")
    private List<GrupoARRC001UniddRecbvl> listagrupoARRC001UniddRecbvl = new ArrayList<>();

    public SPBString getCodInstitdrArrajPgto() {
        return codInstitdrArrajPgto;
    }

    public void setCodInstitdrArrajPgto(SPBString codInstitdrArrajPgto) {
        this.codInstitdrArrajPgto = codInstitdrArrajPgto;
    }

    public List<GrupoARRC001UniddRecbvl> getListagrupoARRC001UniddRecbvl() {
        return listagrupoARRC001UniddRecbvl;
    }

    public void setListagrupoARRC001UniddRecbvl(List<GrupoARRC001UniddRecbvl> listagrupoARRC001UniddRecbvl) {
        this.listagrupoARRC001UniddRecbvl = listagrupoARRC001UniddRecbvl;
    }

}
