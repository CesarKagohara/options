package br.org.cipbancos.rrc.bean.rrc0009;

import java.io.Serializable;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBInteger;
import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

public class GrupoRRC0009Constitr implements Serializable {

    @XStreamAlias("PriorddNegcRecbvl")
    private SPBInteger priorddNegcRecbvl;

    @XStreamAlias("CNPJCreddrSub")
    private SPBString cnpjCreddrSub;

    @XStreamAlias("CNPJ_CNPJBase_CPFUsuFinalRecbdr")
    private SPBString cnpjCnpjBaseCpfUsuFinalRecbdr;

    @XStreamAlias("CNPJ_CNPJBase_CPFTitlar")
    private SPBString cnpjCnpjBaseCPFTitlar;

    @XStreamAlias("CodInstitdrArrajPgto")
    private SPBString codInstitdrArrajPgto;

    @XStreamAlias("DtPrevtLiquid")
    private SPBLocalDate dtPrevtLiquid;

    @XStreamAlias("VlrPercNegcdConstitr")
    private SPBBigDecimal vlrPercNegcdConstitr;

    public SPBInteger getPriorddNegcRecbvl() {
        return priorddNegcRecbvl;
    }

    public void setPriorddNegcRecbvl(SPBInteger priorddNegcRecbvl) {
        this.priorddNegcRecbvl = priorddNegcRecbvl;
    }

    public SPBString getCnpjCreddrSub() {
        return cnpjCreddrSub;
    }

    public void setCnpjCreddrSub(SPBString cnpjCreddrSub) {
        this.cnpjCreddrSub = cnpjCreddrSub;
    }

    public SPBString getCnpjCnpjBaseCpfUsuFinalRecbdr() {
        return cnpjCnpjBaseCpfUsuFinalRecbdr;
    }

    public void setCnpjCnpjBaseCpfUsuFinalRecbdr(SPBString cnpjCnpjBaseCpfUsuFinalRecbdr) {
        this.cnpjCnpjBaseCpfUsuFinalRecbdr = cnpjCnpjBaseCpfUsuFinalRecbdr;
    }

    public SPBString getCnpjCnpjBaseCPFTitlar() {
        return cnpjCnpjBaseCPFTitlar;
    }

    public void setCnpjCnpjBaseCPFTitlar(SPBString cnpjCnpjBaseCPFTitlar) {
        this.cnpjCnpjBaseCPFTitlar = cnpjCnpjBaseCPFTitlar;
    }

    public SPBString getCodInstitdrArrajPgto() {
        return codInstitdrArrajPgto;
    }

    public void setCodInstitdrArrajPgto(SPBString codInstitdrArrajPgto) {
        this.codInstitdrArrajPgto = codInstitdrArrajPgto;
    }

    public SPBLocalDate getDtPrevtLiquid() {
        return dtPrevtLiquid;
    }

    public void setDtPrevtLiquid(SPBLocalDate dtPrevtLiquid) {
        this.dtPrevtLiquid = dtPrevtLiquid;
    }

    public SPBBigDecimal getVlrPercNegcdConstitr() {
        return vlrPercNegcdConstitr;
    }

    public void setVlrPercNegcdConstitr(SPBBigDecimal vlrPercNegcdConstitr) {
        this.vlrPercNegcdConstitr = vlrPercNegcdConstitr;
    }
}
