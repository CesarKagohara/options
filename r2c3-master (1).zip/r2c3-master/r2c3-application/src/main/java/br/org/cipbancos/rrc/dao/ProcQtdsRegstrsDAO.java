package br.org.cipbancos.rrc.dao;

import java.util.Date;
import java.util.Set;

public interface ProcQtdsRegstrsDAO {

    void inserir(Date dtRef, Long idAtlRoot, Integer nrQtdActo, Integer nrQtdRecd, Set<Long> idsOps);

    Set<Long> buscarIdsOps(Date dtRef, Long idAtlRoot);

    String calcularSitReq(Date dtRef, Long idAtlRoot);

}

