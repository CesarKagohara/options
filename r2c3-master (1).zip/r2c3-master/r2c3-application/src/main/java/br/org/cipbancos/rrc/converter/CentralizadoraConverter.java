package br.org.cipbancos.rrc.converter;

import br.org.cipbancos.rrc.funcional.Converter;
import br.org.cipbancos.rrc.interop.vo.EstabelecimentoComercialDTO;
import br.org.cipbancos.rrc.interop.vo.InstituicaoCredenciadoraDTO;

import br.org.cip.api.r2c3.model.EstabelecimentoComercialOutputDTO;
import br.org.cip.api.r2c3.model.InstituicaoCredenciadoraOutputDTO;

public class CentralizadoraConverter {

    private CentralizadoraConverter(){}

    /**
     * converte EstabelecimentoComercialDTO em InstituicaoCredenciadoraOutputDTO
     * @return
     */
    public static Converter<EstabelecimentoComercialDTO, InstituicaoCredenciadoraOutputDTO> InstituicaoCredenciadoraOutputDTO(){
        return origem -> {
            InstituicaoCredenciadoraOutputDTO ic = new InstituicaoCredenciadoraOutputDTO();
            ic.setCnpjCredenciadora(origem.getEntidadeCredenciadoraCnpj());
            ic.setEntidadeRegistradoraCnpj(origem.getEntidadeRegistradoraCnpj());
            ic.setStatus(InstituicaoCredenciadoraOutputDTO.StatusEnum.ATIVO);
            return ic;
        };
    }

    public static Converter<EstabelecimentoComercialDTO, EstabelecimentoComercialOutputDTO> EstabelecimentoComercialOutputDTO(){
        return origem -> {
            EstabelecimentoComercialOutputDTO destino = new EstabelecimentoComercialOutputDTO();
            destino.setEntidadeRegistradoraCnpj( origem.getEntidadeRegistradoraCnpj());
            destino.setDocumentoEstabelecimentoComercial(origem.getEntidadeEstabelecimentoCnpj());
            return destino;
        };

    }
    public static Converter<InstituicaoCredenciadoraDTO, EstabelecimentoComercialOutputDTO> icEmEstabelecimentoComercialOutputDTO(){
        return origem -> {
            EstabelecimentoComercialOutputDTO ec = new EstabelecimentoComercialOutputDTO();
            ec.setStatus(EstabelecimentoComercialOutputDTO.StatusEnum.ATIVO);
            ec.arranjoPagamentoId(origem.getArranjo_pagamento_id());
            return ec;
        };
    }

}
