package br.org.cipbancos.rrc.dao;

/**
 * Classe responsável por toda a manipulação de dados da tabela OP.
 */

import br.org.cipbancos.rrc.vo.DestinatarioOptInTipoDestino;
import br.org.cipbancos.rrc.vo.DestinatarioOptInVO;
import br.org.cipbancos.rrc.vo.OptinVO;

import java.util.Date;
import java.util.List;

public interface OptInDAO {

    List<OptinVO> obterOptIn(Date dataReferencia);

    List<DestinatarioOptInVO> obterDestinatarioOptIn(List<Integer> ids);

    List<DestinatarioOptInVO> obterDestinatarioOptInIndexOntem();

    List<DestinatarioOptInTipoDestino> obterIdsURsPorDestinatarioOptIn(DestinatarioOptInVO destinatarioOptInVO);

    List<DestinatarioOptInVO> obterDestinatarioOptInVOOntem(DestinatarioOptInVO destinatarioOptInVO);
}
