package br.org.cipbancos.rrc.bean.arrc017;

import java.io.Serializable;
import java.util.Objects;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

@XStreamAlias("Grupo_ARRC017_Part")
public class GrupoARRC017 extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("TpPessoa")
    private SPBString tpPessoa;

    @XStreamAlias("CNPJ_CPFPart")
    private SPBString cNPJPart;

    @XStreamAlias("Nom_RzSocPart")
    private SPBString rzSoc;

    @XStreamAlias("NumTelPart")
    private SPBString numTelPart;

    @XStreamAlias("EmailPart")
    private SPBString emailPart;

    @XStreamAlias("TpPart")
    private SPBString tpPart;

    @XStreamAlias("DtAdesHom")
    private SPBLocalDate dtAdesHom;

    @XStreamAlias("DtAdesProd")
    private SPBLocalDate dtAdesProd;

    @XStreamAlias("IndrDomcl")
    private SPBString IndrDomcl;

    public Integer getIspb() {
        return ispb;
    }

    public void setIspb(Integer ispb) {
        this.ispb = ispb;
    }

    @XStreamOmitField
    private Integer ispb;


    public SPBString getTpPessoa() {
        return tpPessoa;
    }

    public void setTpPessoa(SPBString tpPessoa) {
        this.tpPessoa = tpPessoa;
    }

    public SPBString getcNPJPart() {
        return cNPJPart;
    }

    public void setcNPJPart(SPBString cNPJPart) {
        this.cNPJPart = cNPJPart;
    }

    public SPBString getRzSoc() {
        return rzSoc;
    }

    public void setRzSoc(SPBString rzSoc) {
        this.rzSoc = rzSoc;
    }

    public SPBString getNumTelPart() {
        return numTelPart;
    }

    public void setNumTelPart(SPBString numTelPart) {
        this.numTelPart = numTelPart;
    }

    public SPBString getEmailPart() {
        return emailPart;
    }

    public void setEmailPart(SPBString emailPart) {
        this.emailPart = emailPart;
    }

    public SPBString getTpPart() {
        return tpPart;
    }

    public void setTpPart(SPBString tpPart) {
        this.tpPart = tpPart;
    }

    public SPBLocalDate getDtAdesHom() {
        return dtAdesHom;
    }

    public void setDtAdesHom(SPBLocalDate dtAdesHom) {
        this.dtAdesHom = dtAdesHom;
    }

    public SPBLocalDate getDtAdesProd() {
        return dtAdesProd;
    }

    public void setDtAdesProd(SPBLocalDate dtAdesProd) {
        this.dtAdesProd = dtAdesProd;
    }

    public SPBString getIndrDomcl() {
        return IndrDomcl;
    }

    public void setIndrDomcl(SPBString indrDomcl) {
        IndrDomcl = indrDomcl;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GrupoARRC017 that = (GrupoARRC017) o;
        return Objects.equals(cNPJPart, that.cNPJPart);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cNPJPart);
    }
}
