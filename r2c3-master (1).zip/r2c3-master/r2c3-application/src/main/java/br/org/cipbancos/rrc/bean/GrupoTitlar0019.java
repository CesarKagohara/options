package br.org.cipbancos.rrc.bean;

import java.util.List;
import java.util.Set;

public interface GrupoTitlar0019 extends GrupoTitlar {

    List<GrupoCreddrSub> getListaGrupoCreddrSub();

    List<GrupoUsuFinalRecbdr> getListaGrupoUsuFinalRecbdr();

    Set<String> getCredsAlcGeral();

}
