package br.org.cipbancos.rrc.bean.arrc018;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_ARRC018_DomclBancInst")
public class GrupoARRC018DomclBancInst extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CPFTitlarCt")
    private SPBString cNPJCPFTitlarCt;

    @XStreamAlias("TpCt")
    private SPBString tpCt;

    @XStreamAlias("Ag")
    private SPBString ag;

    @XStreamAlias("Ct")
    private SPBString ct;

    @XStreamAlias("CtPgto")
    private SPBString ctPgto;

    @XStreamAlias("DtEftLiquid")
    private SPBLocalDate dtEftLiquid;

    @XStreamAlias("VlrEftLiquid")
    private SPBBigDecimal vlrEftLiquid;

    @XStreamAlias("VlrLivre")
    private SPBBigDecimal vlrLivre;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC018_NegcRecbvlInst")
    private List<GrupoARRC018NegcRecbvlInst> listagrupoARRC018NegcRecbvlInst = new ArrayList<>();

    public SPBString getcNPJCPFTitlarCt() {
        return cNPJCPFTitlarCt;
    }

    public void setcNPJCPFTitlarCt(SPBString cNPJCPFTitlarCt) {
        this.cNPJCPFTitlarCt = cNPJCPFTitlarCt;
    }

    public SPBString getTpCt() {
        return tpCt;
    }

    public void setTpCt(SPBString tpCt) {
        this.tpCt = tpCt;
    }

    public SPBString getAg() {
        return ag;
    }

    public void setAg(SPBString ag) {
        this.ag = ag;
    }

    public SPBString getCt() {
        return ct;
    }

    public void setCt(SPBString ct) {
        this.ct = ct;
    }

    public SPBString getCtPgto() {
        return ctPgto;
    }

    public void setCtPgto(SPBString ctPgto) {
        this.ctPgto = ctPgto;
    }

    public SPBLocalDate getDtEftLiquid() {
        return dtEftLiquid;
    }

    public void setDtEftLiquid(SPBLocalDate dtEftLiquid) {
        this.dtEftLiquid = dtEftLiquid;
    }

    public SPBBigDecimal getVlrEftLiquid() {
        return vlrEftLiquid;
    }

    public void setVlrEftLiquid(SPBBigDecimal vlrEftLiquid) {
        this.vlrEftLiquid = vlrEftLiquid;
    }

    public SPBBigDecimal getVlrLivre() {
        return vlrLivre;
    }

    public void setVlrLivre(SPBBigDecimal vlrLivre) {
        this.vlrLivre = vlrLivre;
    }

    public List<GrupoARRC018NegcRecbvlInst> getListagrupoARRC018NegcRecbvlInst() {
        return listagrupoARRC018NegcRecbvlInst;
    }
    public void setListagrupoARRC018NegcRecbvlInst(List<GrupoARRC018NegcRecbvlInst> listagrupoARRC018NegcRecbvlInst) {
        this.listagrupoARRC018NegcRecbvlInst = listagrupoARRC018NegcRecbvlInst;
    }
}
