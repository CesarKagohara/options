package br.org.cipbancos.rrc.dao;

import java.util.Date;
import java.util.List;
import java.util.Set;

import br.org.cipbancos.rrc.vo.CredenciadoVO;

public interface ManutencaoCredenciadoDAO {

    CredenciadoVO obterCredenciado(String numDoc, Integer idPartCred);
    List<CredenciadoVO> obterCredenciados(String numDoc, Integer idPartCred, Set<String> arranjos);

    Set<Integer> buscarIdPartCreddsPorEstabelecimento(String numDoc);
    Set<Integer> buscarIdPartCreddsPorEstabelecimento(Set<String> numDoc);

    void inserir(List<CredenciadoVO> credenciados);

    void atualizar(List<CredenciadoVO> credenciados);

    void baixar(List<CredenciadoVO> credenciados);

    int[][] inserirEstabelecimentoReduzido(String ec, Set<String> arranjo, Date dtRef, Integer idPartAdm, String nrCnpjPartAdm, long rootId, String nmArqNuop, Integer idFuncdd);

    Set<CredenciadoVO>  buscarEstabelecimentosAgendaDoDia(Date dtRef);

    Set<String> buscarEstabelecimentos(Set<String> estabelecimentos);

}
