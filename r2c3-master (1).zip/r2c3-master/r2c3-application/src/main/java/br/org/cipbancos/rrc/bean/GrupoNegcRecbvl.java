package br.org.cipbancos.rrc.bean;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.enums.IndicadorInclusaoAlteracao;
import br.org.cipbancos.rrc.enums.IndicadorSimNao;
import br.org.cipbancos.rrc.enums.RegraDivisao;
import br.org.cipbancos.rrc.enums.TipoNegociacao;
import br.org.cipbancos.rrc.vo.Operacao;
import br.org.cipbancos.rrc.vo.ProcessamentoNegociacao;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface GrupoNegcRecbvl extends SPBBean {

    default SPBString getIdentdPartPrincipal() {
        return null;
    }

    default void setIdentdPartPrincipal(SPBString identdPartPrincipal) {

    }

    default SPBString getIdentdPartAdmtd() {
        return null;
    }

    default void setIdentdPartAdmtd(SPBString identdPartAdmtd) {

    }

    SPBString getIdentdNegcRecbvl();

    void setIdentdNegcRecbvl(SPBString identdNegcRecbvl);

    SPBString getIdentdOp();

    SPBString getIndrTpNegc();

    void setIndrTpNegc(SPBString indrTpNegc);

    SPBLocalDate getDtVencOp();

    void setDtVencOp(SPBLocalDate dtVencOp);

    SPBBigDecimal getVlrTotLimSldDevdr();

    void setVlrTotLimSldDevdr(SPBBigDecimal vlrTotLimSldDevdr);

    String getRecordId();

    void setRecordId(String recordId);

    SPBString getIndrGestER();

    SPBString getIndrRegrDivs();

    void setIndrRegrDivs(SPBString indrRegrDivs);

    SPBString getIndrActeIncondlOp();

    SPBString getIndrIA();

    void setIndrIA(SPBString indrIA);

    GrupoGestER getGrupoGestER();

    GrupoGestPart getGrupoGestPart();

    ProcessamentoNegociacao getProcessamentoNegociacao();

    void setProcessamentoNegociacao(ProcessamentoNegociacao processamentoNegociacao);

    List<String> getCnpjsRegistradoras();

    void setCnpjsRegistradoras(List<String> cnpjsRegistradoras);

    default boolean isInclusao() {
        return this.getIndrIA().getValue().equals(
                IndicadorInclusaoAlteracao.INCLUSAO.getDescricao());
    }

    default boolean isAlteracao() {
        return this.getIndrIA().getValue().equals(IndicadorInclusaoAlteracao.ALTERACAO.getDescricao());
    }

    default boolean isCessao() {
        return this.getIndrTpNegc().getValue().equals(TipoNegociacao.TC.getValue());
    }

    default boolean hasGestaoPelaRegistradora() {
        return this.getIndrGestER().getValue().equals(IndicadorSimNao.SIM.getValue());
    }

    default boolean hasGestaoPeloParticipante() {
        return this.getIndrGestER().getValue().equals(IndicadorSimNao.NAO.getValue());
    }

    default boolean hasAlcanceEspecifico() {
        return true;
    }

    default boolean hasAlcanceGeral() {
        return false;
    }

    default boolean hasDivisaoPorValor() {
        return this.getIndrRegrDivs().getValue().equals(RegraDivisao.VALOR.getRegra());
    }

    default boolean hasDivisaoPorPercentual() {
        return this.getIndrRegrDivs().getValue().equals(RegraDivisao.PERCENTUAL.getRegra());
    }

    default boolean hasAceiteIncondicional() {
        return this.getIndrActeIncondlOp().getValue().equals(IndicadorSimNao.SIM.getValue());
    }

    default boolean hasNoAceiteIncondicional() {
        return this.getIndrActeIncondlOp().getValue().equals(IndicadorSimNao.NAO.getValue());
    }

    default boolean isGestaoER() {
        return false;
    }

    default boolean isRenegociacao() {
        return false;
    }

    Operacao getOperacaoAtual();

    void setOperacaoAtual(Operacao operacao);

    Long[] getIdsOpsRecalculo();

    void setIdsOpsRecalculo(Long[] idsOpsRecalculo);

    public Map<String, Set<String>> getCredenciadorasArranjosOutrasIMFs();

}
