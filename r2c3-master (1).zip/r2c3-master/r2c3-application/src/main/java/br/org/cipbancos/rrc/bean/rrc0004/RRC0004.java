package br.org.cipbancos.rrc.bean.rrc0004;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

/**
 * @author anderson.martins
 * @since 1.0.0
 */
@XStreamAlias("RRC0004")
public class RRC0004 extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CodMsg")
    private SPBString codMsg;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamAlias("CNPJER")
    private SPBString cnpjER;

    @XStreamAlias("CPF_CNPJPartNegcdr")
    private SPBString cpfCnpjPartNegcdr;

    @XStreamAlias("IdentdNegcRecbvl")
    private SPBString identdNegcRecbvl;

    @XStreamAlias("IdentdOp")
    private SPBString identdOp;

    @XStreamAlias("CNPJ_CNPJBase_CPFTitlar")
    private SPBString cnpjCnpjBaseCpfTitlar;

    @XStreamAlias("IndrCancelVlrTotal")
    private SPBString indrCancelVlrTotal;

    @XStreamAlias("IdentdOpCancel")
    private SPBString identdOpCancel;

    @XStreamAlias("IndrCancelCessConstitr")
    private SPBString indrCancelCessConstitr;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0004_RegRecbvl")
    private List<GrupoRRC0004RegRecbvl> listagrupoRRC0004RegRecbvl = new ArrayList<GrupoRRC0004RegRecbvl>();

    public SPBString getCodMsg() {
        return codMsg;
    }

    public void setCodMsg(SPBString codMsg) {
        this.codMsg = codMsg;
    }

    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public SPBString getCnpjER() {
        return cnpjER;
    }

    public void setCnpjER(SPBString cnpjER) {
        this.cnpjER = cnpjER;
    }

    public SPBString getCpfCnpjPartNegcdr() {
        return cpfCnpjPartNegcdr;
    }

    public void setCpfCnpjPartNegcdr(SPBString cpfCnpjPartNegcdr) {
        this.cpfCnpjPartNegcdr = cpfCnpjPartNegcdr;
    }

    public SPBString getIdentdNegcRecbvl() {
        return identdNegcRecbvl;
    }

    public void setIdentdNegcRecbvl(SPBString identdNegcRecbvl) {
        this.identdNegcRecbvl = identdNegcRecbvl;
    }

    public SPBString getIdentdOp() {
        return identdOp;
    }

    public void setIdentdOp(SPBString identdOp) {
        this.identdOp = identdOp;
    }

    public SPBString getCnpjCnpjBaseCpfTitlar() {
        return cnpjCnpjBaseCpfTitlar;
    }

    public void setCnpjCnpjBaseCpfTitlar(SPBString cnpjCnpjBaseCpfTitlar) {
        this.cnpjCnpjBaseCpfTitlar = cnpjCnpjBaseCpfTitlar;
    }

    public SPBString getIndrCancelVlrTotal() {
        return indrCancelVlrTotal;
    }

    public void setIndrCancelVlrTotal(SPBString indrCancelVlrTotal) {
        this.indrCancelVlrTotal = indrCancelVlrTotal;
    }

    public SPBString getIdentdOpCancel() {
        return identdOpCancel;
    }

    public void setIdentdOpCancel(SPBString identdOpCancel) {
        this.identdOpCancel = identdOpCancel;
    }

    public SPBString getIndrCancelCessConstitr() {
        return indrCancelCessConstitr;
    }

    public void setIndrCancelCessConstitr(SPBString indrCancelCessConstitr) {
        this.indrCancelCessConstitr = indrCancelCessConstitr;
    }

    public List<GrupoRRC0004RegRecbvl> getListagrupoRRC0004RegRecbvl() {
        return listagrupoRRC0004RegRecbvl;
    }

    public void setListagrupoRRC0004RegRecbvl(List<GrupoRRC0004RegRecbvl> listagrupoRRC0004RegRecbvl) {
        this.listagrupoRRC0004RegRecbvl = listagrupoRRC0004RegRecbvl;
    }
}
