package br.org.cipbancos.rrc.bean.arrc031;

import br.org.cipbancos.atlante.xmlbinder.spb.*;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@XStreamAlias("Grupo_ARRC031_Titlar")
public class GrupoARRC031Titlar extends ErrorCodeBean implements Serializable{

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CNPJBase_CPFTitlar")
    private SPBString cNPJCNPJBaseCPFTitlar;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC031_DomclBanc")
    private List<GrupoARRC031DomclBanc> listaGrupoARRC031DomclBanc = new ArrayList<>();

    public void setcNPJCNPJBaseCPFTitlar(SPBString cNPJCNPJBaseCPFTitlar) {
        this.cNPJCNPJBaseCPFTitlar = cNPJCNPJBaseCPFTitlar;
    }

    public void setListaGrupoARRC031DomclBanc(List<GrupoARRC031DomclBanc> listaGrupoARRC031DomclBanc) {
        this.listaGrupoARRC031DomclBanc = listaGrupoARRC031DomclBanc;
    }

    public SPBString getcNPJCNPJBaseCPFTitlar() {
        return cNPJCNPJBaseCPFTitlar;
    }

    public List<GrupoARRC031DomclBanc> getListaGrupoARRC031DomclBanc() {
        return listaGrupoARRC031DomclBanc;
    }
}