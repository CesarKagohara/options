package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.rrc.vo.DestinoOptInIndexVO;
import br.org.cipbancos.rrc.vo.DestinoOptInVO;

import java.util.List;
import java.util.Set;

public interface DestinoOptInDAO {

    void inserirEmLote(List<DestinoOptInVO> destinoOptIn, Integer idCreddr);

    void inserirEmLoteOptinIndex(Set<DestinoOptInIndexVO> optInIndexVOS);

}
