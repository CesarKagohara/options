package br.org.cipbancos.rrc.bean.arrc018;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_ARRC018_Titlar")
public class GrupoARRC018Titlar2 extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CPFTitular")
    private SPBString cNPJCPFTitular;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC018_UniddRecbvl")
    private List<GrupoARRC018UniddRecbvl2> listagrupoARRC018UniddRecbvl = new ArrayList<>();

    public SPBString getcNPJCPFTitular() {
        return cNPJCPFTitular;
    }

    public void setcNPJCPFTitular(SPBString cNPJCPFTitular) {
        this.cNPJCPFTitular = cNPJCPFTitular;
    }

    public List<GrupoARRC018UniddRecbvl2> getListagrupoARRC018UniddRecbvl() {
        return listagrupoARRC018UniddRecbvl;
    }

    public void setListagrupoARRC018UniddRecbvl(List<GrupoARRC018UniddRecbvl2> listagrupoARRC018UniddRecbvl) {
        this.listagrupoARRC018UniddRecbvl = listagrupoARRC018UniddRecbvl;
    }
}
