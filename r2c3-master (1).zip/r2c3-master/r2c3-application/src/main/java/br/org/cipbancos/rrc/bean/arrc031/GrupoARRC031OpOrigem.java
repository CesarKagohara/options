package br.org.cipbancos.rrc.bean.arrc031;

import br.org.cipbancos.atlante.xmlbinder.spb.*;
import com.thoughtworks.xstream.annotations.XStreamAlias;

import java.io.Serializable;

@XStreamAlias("Grupo_ARRC031_OpOrigem")
public class GrupoARRC031OpOrigem extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdentdOpOrigem")
    private SPBString identdOpOrigem;

    public SPBString getIdentdOpOrigem() {
        return identdOpOrigem;
    }

    public void setIdentdOpOrigem(SPBString identdOpOrigem) {
        this.identdOpOrigem = identdOpOrigem;
    }
}