package br.org.cipbancos.rrc.bean.arrc022;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLong;

@XStreamAlias("Grupo_ARRC022RET_RenegcDiv")
public class GrupoARRC022RETRenegcDiv extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdentdOpOrRenegcDiv")
    private SPBLong identdOpOrRenegcDiv;

    public SPBLong getIdentdOpOrRenegcDiv() {
        return identdOpOrRenegcDiv;
    }

    public void setIdentdOpOrRenegcDiv(SPBLong identdOpOrRenegcDiv) {
        this.identdOpOrRenegcDiv = identdOpOrRenegcDiv;
    }

}
