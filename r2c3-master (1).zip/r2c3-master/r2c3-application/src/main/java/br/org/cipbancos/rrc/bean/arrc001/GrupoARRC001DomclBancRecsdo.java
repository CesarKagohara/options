package br.org.cipbancos.rrc.bean.arrc001;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

public class GrupoARRC001DomclBancRecsdo extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CPFTitlarCt")
    private SPBString cNPJCPFTitlarCt;

    @XStreamAlias("ISPBBcoRecbdr")
    private SPBString iSPBBcoRecbdr;

    @XStreamAlias("TpCt")
    private SPBString tpCt;

    @XStreamAlias("Ag")
    private SPBString ag;

    @XStreamAlias("Ct")
    private SPBString ct;

    @XStreamAlias("CtPgto")
    private SPBString ctPgto;

    @XStreamAlias("VlrPrevtLiquid")
    private SPBBigDecimal vlrPrevtLiquid;

    @XStreamAlias("DtEftLiquid")
    private SPBLocalDate dtEftLiquid;

    @XStreamAlias("VlrEftLiquid")
    private SPBBigDecimal vlrEftLiquid;

    @XStreamAlias("IdentdOp")
    private SPBString identdOp;

    public SPBString getcNPJCPFTitlarCt() {
        return cNPJCPFTitlarCt;
    }

    public void setcNPJCPFTitlarCt(SPBString cNPJCPFTitlarCt) {
        this.cNPJCPFTitlarCt = cNPJCPFTitlarCt;
    }

    public SPBString getiSPBBcoRecbdr() {
        return iSPBBcoRecbdr;
    }

    public void setiSPBBcoRecbdr(SPBString iSPBBcoRecbdr) {
        this.iSPBBcoRecbdr = iSPBBcoRecbdr;
    }

    public SPBString getTpCt() {
        return tpCt;
    }

    public void setTpCt(SPBString tpCt) {
        this.tpCt = tpCt;
    }

    public SPBString getAg() {
        return ag;
    }

    public void setAg(SPBString ag) {
        this.ag = ag;
    }

    public SPBString getCt() {
        return ct;
    }

    public void setCt(SPBString ct) {
        this.ct = ct;
    }

    public SPBString getCtPgto() {
        return ctPgto;
    }

    public void setCtPgto(SPBString ctPgto) {
        this.ctPgto = ctPgto;
    }

    public SPBBigDecimal getVlrPrevtLiquid() {
        return vlrPrevtLiquid;
    }

    public void setVlrPrevtLiquid(SPBBigDecimal vlrPrevtLiquid) {
        this.vlrPrevtLiquid = vlrPrevtLiquid;
    }

    public SPBLocalDate getDtEftLiquid() {
        return dtEftLiquid;
    }

    public void setDtEftLiquid(SPBLocalDate dtEftLiquid) {
        this.dtEftLiquid = dtEftLiquid;
    }

    public SPBBigDecimal getVlrEftLiquid() {
        return vlrEftLiquid;
    }

    public void setVlrEftLiquid(SPBBigDecimal vlrEftLiquid) {
        this.vlrEftLiquid = vlrEftLiquid;
    }

    public SPBString getIdentdOp() {
        return identdOp;
    }

    public void setIdentdOp(SPBString identdOp) {
        this.identdOp = identdOp;
    }
}
