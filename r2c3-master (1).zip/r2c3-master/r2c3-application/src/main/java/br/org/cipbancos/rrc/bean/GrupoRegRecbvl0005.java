package br.org.cipbancos.rrc.bean;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;

public interface GrupoRegRecbvl0005 extends GrupoRegRecbvl {

    SPBLocalDate getDtAntec();

    SPBLocalDate getDtEftLiquidAntec();

    SPBBigDecimal getVlrEftLiquidAntec();

    SPBBigDecimal getVlrAntecNRegtd();
}
