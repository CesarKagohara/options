package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.rrc.vo.ResumoDiario;

import java.util.Date;
import java.util.List;

public interface ResumoDiarioAgendaDAO {

    void inserir(ResumoDiario resumoDiario);

    Long obterSeqNumeroControleResumoDiario();

}
