package br.org.cipbancos.rrc.bean.rrc0019;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.rrc.bean.GrupoGestER;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.util.ArrayList;
import java.util.List;

@XStreamAlias("Grupo_RRC0019_GestER")
public class GrupoRRC0019GestER extends ErrorCodeBean implements GrupoGestER {

    private static final long serialVersionUID = 1L;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0019_Titlar")
    private List<GrupoRRC0019Titlar> listagrupoRRC0019Titlar = new ArrayList<>();

    public List<GrupoRRC0019Titlar> getListagrupoRRC0019Titlar() {
        return listagrupoRRC0019Titlar;
    }

    public void setListagrupoRRC0019Titlar(List<GrupoRRC0019Titlar> listagrupoRRC0019Titlar) {
        this.listagrupoRRC0019Titlar = listagrupoRRC0019Titlar;
    }

    @Override
    public List getListaGrupoTitlar() {
        return getListagrupoRRC0019Titlar();
    }

    @Override
    public String toString() {
        return "GrupoRRC0019GestER{" +
                "listagrupoRRC0019Titlar=" + listagrupoRRC0019Titlar +
                '}';
    }
}
