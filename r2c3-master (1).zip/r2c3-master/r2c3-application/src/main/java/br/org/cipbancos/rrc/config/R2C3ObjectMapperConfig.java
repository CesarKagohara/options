package br.org.cipbancos.rrc.config;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import br.org.cip.arche.commons.library.json.serializer.ArcJacksonSerializer;

@Component
public class R2C3ObjectMapperConfig {

    @Autowired
    ArcJacksonSerializer arcJacksonSerializer;

    @PostConstruct
    void configure() {
        ObjectMapper mapper = arcJacksonSerializer.getDefaultObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }
}
