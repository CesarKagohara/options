package br.org.cipbancos.rrc.builder;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBInteger;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.arrc018.GrupoARRC018NegcRecbvlInst2;
import br.org.cipbancos.rrc.util.DateUtil;

import java.math.BigDecimal;
import java.util.Date;

public class GrupoARRC018NegcRecbvlInst2Builder {

    private GrupoARRC018NegcRecbvlInst2 grupoARRC018NegcRecbvlInst2;

    private GrupoARRC018NegcRecbvlInst2Builder(){
        this.grupoARRC018NegcRecbvlInst2 = new GrupoARRC018NegcRecbvlInst2();
    }

    public static GrupoARRC018NegcRecbvlInst2Builder builder(){
        return new GrupoARRC018NegcRecbvlInst2Builder();
    }

    public GrupoARRC018NegcRecbvlInst2Builder comIdentOp(Long identOp){
        if (identOp != null) {
            String identificacaoOperacao = String.format("%019d", identOp);
            grupoARRC018NegcRecbvlInst2.setIdentdOp(new SPBString(identificacaoOperacao));
        }
        return this;
    }

    public GrupoARRC018NegcRecbvlInst2Builder comPriorddNegcRecbvl(Integer priorddNegcRecbvl){
        if (priorddNegcRecbvl != null) {
            grupoARRC018NegcRecbvlInst2.setPriorddNegcRecbvl(new SPBInteger(priorddNegcRecbvl));
        }
        return this;
    }

    public GrupoARRC018NegcRecbvlInst2Builder comCnpjRegistradora(String cnpjRegistradora){
        if (cnpjRegistradora != null) {
            grupoARRC018NegcRecbvlInst2.setcNPJER(new SPBString(cnpjRegistradora));
        }
        return this;
    }

    public GrupoARRC018NegcRecbvlInst2Builder comValorNegociado(BigDecimal valorNegociado){
        if (valorNegociado != null) {
            grupoARRC018NegcRecbvlInst2.setVlrNegcd(new SPBBigDecimal(valorNegociado));
        }
        return this;
    }

    public GrupoARRC018NegcRecbvlInst2Builder comValorPercentualNegociadoConstituir(BigDecimal valorPercentualNegociadoConstituir){
        if (valorPercentualNegociadoConstituir != null) {
            grupoARRC018NegcRecbvlInst2.setVlrPercNegcdConstitr(new SPBBigDecimal(valorPercentualNegociadoConstituir));
        }
        return this;
    }

    public GrupoARRC018NegcRecbvlInst2Builder comIndrRegraDivisao(String indrRegraDivisao){
        if (indrRegraDivisao != null) {
            grupoARRC018NegcRecbvlInst2.setIndrRegrDivs(new SPBString(indrRegraDivisao));
        }
        return this;
    }

    public GrupoARRC018NegcRecbvlInst2Builder comDataFimOperacao(Date dataFimOperacao){
        if (dataFimOperacao != null) {
            grupoARRC018NegcRecbvlInst2.setDtFimOp(new SPBLocalDate(DateUtil.toLocalDate(dataFimOperacao)));
        }
        return this;
    }

    public GrupoARRC018NegcRecbvlInst2 build(){
        return  this.grupoARRC018NegcRecbvlInst2;
    }
}