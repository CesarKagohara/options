package br.org.cipbancos.rrc.bean;


import br.org.cipbancos.atlante.xmlbinder.spb.SPBLong;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

public interface GrupoConsultaNegcRecbvl {

    SPBLong getIdentdOp();

    SPBString getcNPJCNPJBaseCPFUsuFinalRecbdr();

    SPBString getcNPJCNPJBaseCPFTitlar();

    void setErrorCode(String errorCode);

    boolean hasErrorCode();

    Boolean isFiltroConstituido();
}
