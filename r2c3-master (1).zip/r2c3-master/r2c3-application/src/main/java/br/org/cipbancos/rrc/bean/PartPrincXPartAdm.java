package br.org.cipbancos.rrc.bean;


import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

public interface PartPrincXPartAdm extends SPBBean{

    SPBString getIdentdPartPrincipal();

    SPBString getIdentdPartAdmtd();
}
