package br.org.cipbancos.rrc.bean;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

public interface CancelamentoGrupoRegRecbvl {

    SPBString getCnpjCreddrSub();

    SPBString getCnpjCpfUsuFinalRecbdr();

    SPBString getCodInstitdrArrajPgto();

    SPBLocalDate getDtPrevtLiquid();

    SPBString getCnpjCpfTitularVenddNegcdrRecbvl();

    SPBBigDecimal getVlrNegcdCancel();

    SPBBigDecimal getVlrPercNegcdConstitrCancel();

    void setErrorCode(String errorCode);

}
