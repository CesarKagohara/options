package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.rrc.vo.ParticipanteVO;

import java.util.Date;
import java.util.List;
import java.util.Set;

public interface OpOptInAutmtcDAO {

    void inserir(Long idOp, List<Long> idOptIn, ParticipanteVO participanteVO, Date dtRef, Long idAtlRoot, String nmArqNuopApi, Integer idFuncdd);

    Set<Long> buscarOptinsPoridOp(Long idOp);

    Set<Long> buscarOpsPoridOptin(Long idOptin);

    void cancelarOptin(Long idOpin);

}
