package br.org.cipbancos.rrc.bean.rrc0019;

import java.io.Serializable;

import br.org.cipbancos.atlante.xmlbinder.spb.*;
import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("Grupo_RRC0019R1_Constitr")
public class GrupoRRC0019R1Constitr extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("PriorddNegcRecbvl")
    private SPBInteger priorddNegcRecbvl;

    @XStreamAlias("CNPJ_CNPJBase_CPFUsuFinalRecbdr")
    private SPBString cNPJCPFUsuFinalRecbdr;

    @XStreamAlias("CNPJ_CNPJBase_CPFTitlar")
    private SPBString cNPJCNPJBaseCPFTitlar;

    @XStreamAlias("CNPJCreddrSub")
    private SPBString cNPJCreddrSub;

    @XStreamAlias("CodInstitdrArrajPgto")
    private SPBString codInstitdrArrajPgto;

    @XStreamAlias("DtPrevtLiquid")
    private SPBLocalDate dtPrevtLiquid;

    @XStreamAlias("IndrRegrDivs")
    private SPBString indrRegrDivs;

    @XStreamAlias("VlrPercNegcd")
    private SPBBigDecimal vlrPercNegcd;

    public SPBInteger getPriorddNegcRecbvl() {
        return priorddNegcRecbvl;
    }

    public void setPriorddNegcRecbvl(SPBInteger priorddNegcRecbvl) {
        this.priorddNegcRecbvl = priorddNegcRecbvl;
    }

    public SPBString getCNPJCPFUsuFinalRecbdr() {
        return cNPJCPFUsuFinalRecbdr;
    }

    public void setCNPJCPFUsuFinalRecbdr(SPBString cNPJCPFUsuFinalRecbdr) {
        this.cNPJCPFUsuFinalRecbdr = cNPJCPFUsuFinalRecbdr;
    }

    public SPBString getCNPJCNPJBaseCPFTitlar() {
        return cNPJCNPJBaseCPFTitlar;
    }

    public void setCNPJCNPJBaseCPFTitlar(SPBString cNPJCNPJBaseCPFTitlar) {
        this.cNPJCNPJBaseCPFTitlar = cNPJCNPJBaseCPFTitlar;
    }

    public SPBString getCNPJCreddrSub() {
        return cNPJCreddrSub;
    }

    public void setCNPJCreddrSub(SPBString cNPJCreddrSub) {
        this.cNPJCreddrSub = cNPJCreddrSub;
    }

    public SPBString getCodInstitdrArrajPgto() {
        return codInstitdrArrajPgto;
    }

    public void setCodInstitdrArrajPgto(SPBString codInstitdrArrajPgto) {
        this.codInstitdrArrajPgto = codInstitdrArrajPgto;
    }

    public SPBLocalDate getDtPrevtLiquid() {
        return dtPrevtLiquid;
    }

    public void setDtPrevtLiquid(SPBLocalDate dtPrevtLiquid) {
        this.dtPrevtLiquid = dtPrevtLiquid;
    }

    public SPBString getIndrRegrDivs() {
        return indrRegrDivs;
    }

    public void setIndrRegrDivs(SPBString indrRegrDivs) {
        this.indrRegrDivs = indrRegrDivs;
    }

    public SPBBigDecimal getVlrPercNegcd() {
        return vlrPercNegcd;
    }

    public void setVlrPercNegcd(SPBBigDecimal vlrPercNegcd) {
        this.vlrPercNegcd = vlrPercNegcd;
    }

}
