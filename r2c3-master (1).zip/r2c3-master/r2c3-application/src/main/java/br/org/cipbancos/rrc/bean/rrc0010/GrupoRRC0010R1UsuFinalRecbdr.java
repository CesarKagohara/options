package br.org.cipbancos.rrc.bean.rrc0010;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_RRC0010R1_UsuFinalRecbdr")
public class GrupoRRC0010R1UsuFinalRecbdr extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CPFUsuFinalRecbdr")
    private SPBString cNPJCPFUsuFinalRecbdr;

    @XStreamAlias("VlrLivreUsuFinalRecbdr")
    private SPBBigDecimal vlrLivreUsuFinalRecbdr;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0010R1_UniddRecbvl")
    private List<GrupoRRC0010R1UniddRecbvl> listagrupoRRC0010R1UniddRecbvl = new ArrayList<GrupoRRC0010R1UniddRecbvl>();

    public SPBString getCNPJCPFUsuFinalRecbdr() {
        return cNPJCPFUsuFinalRecbdr;
    }

    public void setCNPJCPFUsuFinalRecbdr(SPBString cNPJCPFUsuFinalRecbdr) {
        this.cNPJCPFUsuFinalRecbdr = cNPJCPFUsuFinalRecbdr;
    }

    public SPBBigDecimal getVlrLivreUsuFinalRecbdr() {
        return vlrLivreUsuFinalRecbdr;
    }

    public void setVlrLivreUsuFinalRecbdr(SPBBigDecimal vlrLivreUsuFinalRecbdr) {
        this.vlrLivreUsuFinalRecbdr = vlrLivreUsuFinalRecbdr;
    }

    public List<GrupoRRC0010R1UniddRecbvl> getListagrupoRRC0010R1UniddRecbvl() {
        return listagrupoRRC0010R1UniddRecbvl;
    }

    public void setListagrupoRRC0010R1UniddRecbvl(List<GrupoRRC0010R1UniddRecbvl> listagrupoRRC0010R1UniddRecbvl) {
        this.listagrupoRRC0010R1UniddRecbvl = listagrupoRRC0010R1UniddRecbvl;
    }

}
