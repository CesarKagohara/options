package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.rrc.enums.IndicadorSimNao;

public interface RegOpStgDAO {

    Long inserir(String ispb);

    Boolean isIspbIdRegOpExists(Long idRegOp, String ispb);

    Integer atualizaSitProcessamento(Long idRegOp, IndicadorSimNao simNao);

}

