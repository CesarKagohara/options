package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.rrc.vo.ControleOperacaoCredenciadorGradeVO;

import java.util.List;

public interface ControleOperacaoCredenciadorGradeDAO {

    List<ControleOperacaoCredenciadorGradeVO> buscar(ControleOperacaoCredenciadorGradeVO vo);

}
