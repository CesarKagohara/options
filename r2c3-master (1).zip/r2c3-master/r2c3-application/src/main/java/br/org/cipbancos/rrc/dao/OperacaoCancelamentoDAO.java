package br.org.cipbancos.rrc.dao;

/**
 * Classe responsável por toda a manipulação de dados da tabela OP Cancelamento.
 */

import java.util.List;

import br.org.cipbancos.rrc.vo.OperacaoCancelamento;

public interface OperacaoCancelamentoDAO {

    /**
     * Grava no BD da operacao Cancelamento
     *
     * @param operacaoCancelamento A ser inserida
     */
    void inserir(OperacaoCancelamento operacaoCancelamento);

    /**
     * Atualiza no BD da Operacao Cancelamento
     *
     * @param operacaoCancelamento A ser atualizada
     */
    void atualizar(OperacaoCancelamento operacaoCancelamento);

    /**
     * Exclui no BD da operacao Cancelamento
     *
     * @param operacaoCancelamento A ser excluída
     */
    void excluir(OperacaoCancelamento operacaoCancelamento);

    /**
     * Busca no BD a operacao Cancelamento
     *
     * @param operacaoCancelamento A ser buscada
     */
    OperacaoCancelamento buscar(OperacaoCancelamento operacaoCancelamento);

    /**
     * Busca no BD a operacoes Cancelamento
     *
     * @param operacaoCancelamento A ser buscada
     */
    List<OperacaoCancelamento> buscarOperacoes(OperacaoCancelamento operacaoCancelamento);

    /**
     * Busca no BD a operacao Cancelamento
     *
     * @param operacaoCancelamento A ser buscada
     */
    OperacaoCancelamento buscarId(OperacaoCancelamento operacaoCancelamento);

    Long obterSeqOperacaoCancelamento();

    List<OperacaoCancelamento> buscarInfoResumoDiario(Long idAtlRoot);
}