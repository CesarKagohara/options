package br.org.cipbancos.rrc.converter;

import java.util.Date;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import br.org.cipbancos.rrc.bean.GrupoConsultaNegcRecbvl;
import br.org.cipbancos.rrc.funcional.Converter;
import br.org.cipbancos.rrc.vo.ConsultaNegociacaoRecebivel;

/**
 * Classe utilitária para converter informações de Consulta Negociacao Recebiveis de entrada para realizar,
 * inserções no BD e conversões de Entrada para Retorno.
 *
 * @author anderson.martins
 * @since 1.0
 */
public class ConsultaNegociacaoRecebiveisConverter {

    private ConsultaNegociacaoRecebiveisConverter() {

    }

    public static Converter<GrupoConsultaNegcRecbvl, ConsultaNegociacaoRecebivel> paraConsulta(Date dtRef, Long idCreddr, Integer pagina, Integer tamanho) {
        return origem -> {

            ConsultaNegociacaoRecebivel destino = new ConsultaNegociacaoRecebivel();

            destino.setBatchReferenceDate(dtRef);

            if (idCreddr != null) {
                destino.setIdentdPartAdmtd(idCreddr);
            }

            if (origem.getcNPJCNPJBaseCPFTitlar()!=null){
                destino.setCnpjCnpjBaseCpfTitlar(origem.getcNPJCNPJBaseCPFTitlar().getValue());
            }

            if (origem.getcNPJCNPJBaseCPFUsuFinalRecbdr()!=null){
                destino.setCnpjCnpjBaseCpfUsuFinalRecbdr(origem.getcNPJCNPJBaseCPFUsuFinalRecbdr().getValue());
            }

            if (origem.getIdentdOp()!=null){
                destino.setIdentdOp(origem.getIdentdOp().getValue());
            }
            if(pagina != null){
                destino.setNumeroPagina(pagina);
            }
            if(tamanho != null){
                destino.setTamanhoPagina(tamanho);
            }

            destino.setFiltroConstituido(origem.isFiltroConstituido());

            return destino;
        };
    }

    /**
     * Popula os parametros utilizados para inserir um unidd_recbv no BD.
     *
     * @return Um conjunto de parametros para setar as informações no ElSql.
     */
    public static Converter<ConsultaNegociacaoRecebivel, MapSqlParameterSource> emConsultaNegociacaoRecebivelParaConsulta() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();

            parametros.addValue("nrCpfCnpjTitlar", origem.getCnpjCnpjBaseCpfTitlar());

            parametros.addValue("nrCpfCnpjUsuFinalRecbdr", origem.getCnpjCnpjBaseCpfUsuFinalRecbdr());

            parametros.addValue("identdOp", origem.getIdentdOp());

            return parametros;
        };
    }
}
