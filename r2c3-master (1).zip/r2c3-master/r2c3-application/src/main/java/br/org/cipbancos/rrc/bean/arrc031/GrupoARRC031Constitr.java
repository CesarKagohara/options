package br.org.cipbancos.rrc.bean.arrc031;

import br.org.cipbancos.atlante.xmlbinder.spb.*;
import com.thoughtworks.xstream.annotations.XStreamAlias;

import java.io.Serializable;

@XStreamAlias("Grupo_ARRC031_Constitr")
public class GrupoARRC031Constitr extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("PriorddNegcRecbvl")
    private SPBInteger priorddNegcRecbvl;

    @XStreamAlias("CNPJ_CNPJBase_CPFUsuFinalRecbdr")
    private SPBString cNPJCNPJBaseCPFUsuFinalRecbdr;

    @XStreamAlias("CNPJ_CNPJBase_CPFTitlar")
    private SPBString cNPJCNPJBaseCPFTitlar;

    @XStreamAlias("CodInstitdrArrajPgto")
    private SPBString codInstitdrArrajPgto;

    @XStreamAlias("DtPrevtLiquid")
    private SPBLocalDate dtPrevtLiquid;

    @XStreamAlias("VlrPercNegcd")
    private SPBBigDecimal vlrPercNegcd;

    public void setPriorddNegcRecbvl(SPBInteger priorddNegcRecbvl) {
        this.priorddNegcRecbvl = priorddNegcRecbvl;
    }

    public void setcNPJCNPJBaseCPFUsuFinalRecbdr(SPBString cNPJCNPJBaseCPFUsuFinalRecbdr) {
        this.cNPJCNPJBaseCPFUsuFinalRecbdr = cNPJCNPJBaseCPFUsuFinalRecbdr;
    }

    public void setcNPJCNPJBaseCPFTitlar(SPBString cNPJCNPJBaseCPFTitlar) {
        this.cNPJCNPJBaseCPFTitlar = cNPJCNPJBaseCPFTitlar;
    }

    public void setCodInstitdrArrajPgto(SPBString codInstitdrArrajPgto) {
        this.codInstitdrArrajPgto = codInstitdrArrajPgto;
    }

    public void setDtPrevtLiquid(SPBLocalDate dtPrevtLiquid) {
        this.dtPrevtLiquid = dtPrevtLiquid;
    }

    public void setVlrPercNegcd(SPBBigDecimal vlrPercNegcd) {
        this.vlrPercNegcd = vlrPercNegcd;
    }

    public SPBInteger getPriorddNegcRecbvl() {
        return priorddNegcRecbvl;
    }

    public SPBString getcNPJCNPJBaseCPFUsuFinalRecbdr() {
        return cNPJCNPJBaseCPFUsuFinalRecbdr;
    }

    public SPBString getcNPJCNPJBaseCPFTitlar() {
        return cNPJCNPJBaseCPFTitlar;
    }

    public SPBString getCodInstitdrArrajPgto() {
        return codInstitdrArrajPgto;
    }

    public SPBLocalDate getDtPrevtLiquid() {
        return dtPrevtLiquid;
    }

    public SPBBigDecimal getVlrPercNegcd() {
        return vlrPercNegcd;
    }
}