package br.org.cipbancos.rrc.bean.rrc0019;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoRegRecbvl0019;
import br.org.cipbancos.rrc.vo.FracaoUnidadeRecebivelOperacao;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

import java.util.List;

@XStreamAlias("Grupo_RRC0019_RegRecbvl")
public class GrupoRRC0019GrupoRegRecbvl extends ErrorCodeBean implements GrupoRegRecbvl0019 {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJCreddrSub")
    private SPBString cNPJCreddrSub;

    @XStreamAlias("CNPJ_CPFUsuFinalRecbdr")
    private SPBString cNPJCPFUsuFinalRecbdr;

    @XStreamAlias("CNPJ_CPFTitular")
    private SPBString cNPJCPFTitular;

    @XStreamAlias("CodInstitdrArrajPgto")
    private SPBString codInstitdrArrajPgto;

    @XStreamAlias("DtPrevtLiquid")
    private SPBLocalDate dtPrevtLiquid;

    @XStreamAlias("VlrPercNegcd")
    private SPBBigDecimal vlrPercNegcd;

    @XStreamOmitField
    private List<FracaoUnidadeRecebivelOperacao> fracoes;

    public SPBString getCNPJCreddrSub() {
        return cNPJCreddrSub;
    }

    public void setCNPJCreddrSub(SPBString cNPJCreddrSub) {
        this.cNPJCreddrSub = cNPJCreddrSub;
    }

    public SPBString getCNPJCPFUsuFinalRecbdr() {
        return cNPJCPFUsuFinalRecbdr;
    }

    public void setCNPJCPFUsuFinalRecbdr(SPBString cNPJCPFUsuFinalRecbdr) {
        this.cNPJCPFUsuFinalRecbdr = cNPJCPFUsuFinalRecbdr;
    }

    public SPBString getCNPJCPFTitular() {
        return cNPJCPFTitular;
    }

    public void setCNPJCPFTitular(SPBString cNPJCPFTitular) {
        this.cNPJCPFTitular = cNPJCPFTitular;
    }

    public SPBString getCodInstitdrArrajPgto() {
        return codInstitdrArrajPgto;
    }

    public void setCodInstitdrArrajPgto(SPBString codInstitdrArrajPgto) {
        this.codInstitdrArrajPgto = codInstitdrArrajPgto;
    }

    public SPBLocalDate getDtPrevtLiquid() {
        return dtPrevtLiquid;
    }

    public void setDtPrevtLiquid(SPBLocalDate dtPrevtLiquid) {
        this.dtPrevtLiquid = dtPrevtLiquid;
    }

    public SPBBigDecimal getVlrPercNegcd() {
        return vlrPercNegcd;
    }

    public void setVlrPercNegcd(SPBBigDecimal vlrPercNegcd) {
        this.vlrPercNegcd = vlrPercNegcd;
    }

    public List<FracaoUnidadeRecebivelOperacao> getFracoes() {
        return fracoes;
    }

    public void setFracoes(List<FracaoUnidadeRecebivelOperacao> fracoes) {
        this.fracoes = fracoes;
    }

    @Override
    public String toString() {
        return "GrupoRRC0019GrupoRegRecbvl{" +
                "cNPJCreddrSub=" + cNPJCreddrSub +
                ", cNPJCPFUsuFinalRecbdr=" + cNPJCPFUsuFinalRecbdr +
                ", cNPJCPFTitular=" + cNPJCPFTitular +
                ", codInstitdrArrajPgto=" + codInstitdrArrajPgto +
                ", dtPrevtLiquid=" + dtPrevtLiquid +
                ", vlrPercNegcd=" + vlrPercNegcd +
                '}';
    }
}
