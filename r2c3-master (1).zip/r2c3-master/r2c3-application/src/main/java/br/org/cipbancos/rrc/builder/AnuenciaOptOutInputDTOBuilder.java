package br.org.cipbancos.rrc.builder;

import br.org.cip.api.r2c3.model.AnuenciaOptOutInputDTO;
import br.org.cipbancos.rrc.util.DateUtil;
import br.org.cipbancos.rrc.vo.OptOutVO;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;



public class AnuenciaOptOutInputDTOBuilder {

    private AnuenciaOptOutInputDTO optOut;

    private AnuenciaOptOutInputDTOBuilder(){
        this.optOut = new AnuenciaOptOutInputDTO();
    }

    public static AnuenciaOptOutInputDTOBuilder builder(){
        return new AnuenciaOptOutInputDTOBuilder();
    }

    public AnuenciaOptOutInputDTOBuilder createAnuenciaOptOutParaCentralizadora(OptOutVO optOutVO){
        this.optOut.setCodigoControleOptIn(UUID.fromString(optOutVO.getNumeroControleBaseCentralizada()));
        this.optOut.setDataFim(DateUtil.convertDateTime(optOutVO.getDataInclusao()));
        this.optOut.setStatus(AnuenciaOptOutInputDTO.StatusEnum.INATIVO);

        return this;
    }

    public List<AnuenciaOptOutInputDTO> build(){
        return Arrays.asList(optOut);
    }
}