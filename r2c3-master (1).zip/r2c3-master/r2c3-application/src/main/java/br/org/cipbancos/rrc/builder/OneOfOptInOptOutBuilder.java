package br.org.cipbancos.rrc.builder;

import java.util.UUID;

import br.org.cipbancos.rrc.dominio.TipoIndr;
import br.org.cipbancos.rrc.enums.TipoOptin;
import br.org.cipbancos.rrc.util.DateUtil;
import br.org.cipbancos.rrc.vo.AutorizacaoEnvioAgenda;
import br.org.cipbancos.rrc.vo.OptOutVO;

import br.org.cip.api.r2c3.model.OneOfOptInOptOut;

public class OneOfOptInOptOutBuilder {

    private OneOfOptInOptOut oneOfOptInOptOut;

    private OneOfOptInOptOutBuilder(){
        this.oneOfOptInOptOut = new OneOfOptInOptOut();
    }

    public static OneOfOptInOptOutBuilder builder(){
        return new OneOfOptInOptOutBuilder();
    }

    public OneOfOptInOptOutBuilder createOneOfOptInOptOutParaEnvioAnuencia(AutorizacaoEnvioAgenda autorizacaoEnvioAgenda,
                                                            String codArranjoInterop, String cnpjPartAdm, String nrCtrlBaseCentralizada){
        oneOfOptInOptOut.setIdComunicacao(nrCtrlBaseCentralizada);
        oneOfOptInOptOut.setIdControle(nrCtrlBaseCentralizada);
        oneOfOptInOptOut.setCpfCnpjUsuarioFinalRecebedorOuTitular(autorizacaoEnvioAgenda.getDocumentoUsuarioFinalRecebedor());
        oneOfOptInOptOut.setCnpjCredenciadora(autorizacaoEnvioAgenda.getCnpjCredenciadorSubCredenciador());
        oneOfOptInOptOut.setArranjo(codArranjoInterop);
        oneOfOptInOptOut.setCpfCnpjSolicitante(cnpjPartAdm);
        oneOfOptInOptOut.setCpfCnpjCredor(autorizacaoEnvioAgenda.getCnpjFinanceira());
        oneOfOptInOptOut.setDataInicio(DateUtil.toJavaTimeLocalDate(autorizacaoEnvioAgenda.getDataInicioOptIn()));
        oneOfOptInOptOut.setDataFim(DateUtil.toJavaTimeLocalDate(autorizacaoEnvioAgenda.getDataFimOptIn()));
        oneOfOptInOptOut.setTipoComunicacao(autorizacaoEnvioAgenda.getTipoComunicacao());
        if(autorizacaoEnvioAgenda.getIcOptInAutmtc()==null || autorizacaoEnvioAgenda.getIcOptInAutmtc().equals(TipoIndr.N.getValue())){
            oneOfOptInOptOut.setTipo("OPTIN");
        } else {
            oneOfOptInOptOut.setTipo("CONTRATO");
        }
        return this;
    }

    public OneOfOptInOptOutBuilder createOneOfOptInOptOutParaCancelamentoAnuencia(OptOutVO optOutVO){
        oneOfOptInOptOut.setIdComunicacao(UUID.randomUUID().toString());
        oneOfOptInOptOut.setIdControle(String.valueOf(optOutVO.getNumeroControleBaseCentralizada()));
        oneOfOptInOptOut.setCpfCnpjSolicitante(optOutVO.getCpfCnpjRecebedor());
        oneOfOptInOptOut.setTipoComunicacao("OPTOUT");
        return this;
    }

    private String getDescricaoTipoOptin(String icOptInAutomatico){
        if(icOptInAutomatico != null){
            return TipoOptin.fromValue(icOptInAutomatico).getDescricao();
        }

        return null;
    }

    public OneOfOptInOptOut build(){
        return oneOfOptInOptOut;
    }
}