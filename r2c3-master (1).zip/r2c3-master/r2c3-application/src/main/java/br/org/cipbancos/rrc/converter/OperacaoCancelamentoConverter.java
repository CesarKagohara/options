package br.org.cipbancos.rrc.converter;

import java.util.Date;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import br.org.cipbancos.rrc.funcional.Converter;
import br.org.cipbancos.rrc.vo.OperacaoCancelamento;

/**
 * Classe utilitária para converter informações de op?cancelt de entrada para realizar,
 * inserções no BD e conversões de Entrada para Retorno.
 *
 * @author anderson.martins
 * @since 1.0
 */
public class OperacaoCancelamentoConverter {

    private OperacaoCancelamentoConverter() {}

    /**
     * Popula os parametros utilizados para buscar um OperacaoCancelamento no BD.
     * @return Um conjunto de parametros para setar as informações no ElSql.
     */
    public static Converter<OperacaoCancelamento, MapSqlParameterSource> emIdOperacaoParaBuscarOperacaoCancelamento() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();

            parametros.addValue("identificadorOperacaoCancelamento", origem.getIdentificadorOperacaoCancelamento());

            return parametros;
        };
    }

    /**
     * Popula os parametros utilizados para buscar um OperacaoCancelamento no BD.
     * @return Um conjunto de parametros para setar as informações no ElSql.
     */
    public static Converter<OperacaoCancelamento, MapSqlParameterSource> emOperacaoCancelamentoParaBuscarOperacaoCancelamento() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();

            parametros.addValue("identificadorOperacao", origem.getIdentificadorOperacao());
            parametros.addValue("identificadorNegociacaoRecebivelExterno", origem.getIdentificadorNegociacaoRecebivelExterno());
            parametros.addValue("indicadorCancelamentoTotal", origem.getIndicadorCancelamentoTotal());
            return parametros;
        };
    }


    /**
     * Popula os parametros utilizados para inserir um OperacaoCancelamento no BD.
     * @return Um conjunto de parametros para setar as informações no ElSql.
     */
    public static Converter<OperacaoCancelamento, MapSqlParameterSource> emInsercaoOperacaoCancelamento() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();

            parametros.addValue("identificadorOperacaoCancel", origem.getIdentificadorOperacaoCancelamento());
            parametros.addValue("identificadorOperacao", origem.getIdentificadorOperacao());
            parametros.addValue("identificadorNegociacaoRecebivelExterno", origem.getIdentificadorNegociacaoRecebivelExterno());
            parametros.addValue("nrCpfCnpjTitlar", origem.getNrCpfCnpjTitlar());
            parametros.addValue("indicadorCancelamentoTotal", origem.getIndicadorCancelamentoTotal());
            parametros.addValue("indicadorLiquidacaoOperacao", origem.getIndicadorLiquidacaoOperacao());
            parametros.addValue("idIntrdd", origem.getIdentificadorInteroperabilidade());
            parametros.addValue("nrCnpjRegr", origem.getNumeroCnpjRegistradora());
            parametros.addValue("indicadorCancelamentoCessaoConstituir", origem.getIndicadorCancelamentoCessaoConstituir());
            parametros.addValue("idPartPrincipal", origem.getIdentificadorPartPrincipal());
            parametros.addValue("idPartAdmtd", origem.getIdentificadorPartAdmtd());
            parametros.addValue("idPartOrigdr", origem.getIdentificadorPartOrigdr());
            parametros.addValue("dtRefSistIncl", origem.getDataRefSistIncl());
            parametros.addValue("dtRefSistUltAlt", origem.getDataRefSistAlt());
            parametros.addValue("indicadorAtlRoot", origem.getNumeroIdentificadorAtlanteRoot());
            parametros.addValue("nmArqNuopApi", origem.getNmArqNuOpApi());
            parametros.addValue("idFuncdd", origem.getIdentificadorFuncdd());
            parametros.addValue("dhIncl", new java.sql.Timestamp(new Date().getTime()));
            parametros.addValue("dhUltAlt", new java.sql.Timestamp(new Date().getTime()));
            return parametros;
        };
    }
}
