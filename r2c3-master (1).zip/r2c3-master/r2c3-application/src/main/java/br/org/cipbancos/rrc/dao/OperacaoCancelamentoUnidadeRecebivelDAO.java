package br.org.cipbancos.rrc.dao;

/**
 * Classe responsável por toda a manipulação de dados da tabela OP Cancelamento Unidade Recebivel.
 */

import java.util.List;

import br.org.cipbancos.rrc.vo.OperacaoCancelamentoUnidadeRecebivel;

public interface OperacaoCancelamentoUnidadeRecebivelDAO {

    /**
     * Grava no BD da operacao Cancelamento Unidade Recebivel
     *
     * @param operacaoCancelamentoUnidadeRecebivel A ser inserida
     *
     */
    void inserir(OperacaoCancelamentoUnidadeRecebivel operacaoCancelamentoUnidadeRecebivel);

    /**
     * Atualiza no BD da Operacao Cancelamento Unidade Recebivel
     *
     * @param operacaoCancelamentoUnidadeRecebivel A ser atualizada
     *
     */
    void atualizar(OperacaoCancelamentoUnidadeRecebivel operacaoCancelamentoUnidadeRecebivel);

    /**
     * Exclui no BD da Operacao Cancelamento Unidade Recebivel
     *
     * @param operacaoCancelamentoUnidadeRecebivel A ser excluída
     */
    void excluir(OperacaoCancelamentoUnidadeRecebivel operacaoCancelamentoUnidadeRecebivel);

    /**
     * Busca no BD da Operacao Cancelamento Unidade Recebivel
     *
     * @param operacaoCancelamentoUnidadeRecebivel A ser buscada
     *
     */
    List<OperacaoCancelamentoUnidadeRecebivel> buscarUnidadeRecebivel(OperacaoCancelamentoUnidadeRecebivel operacaoCancelamentoUnidadeRecebivel);

    /**
     * Busca no BD a operacao Cancelamento Unidade Recebivel
     *
     * @param operacaoCancelamentoUnidadeRecebivel A ser buscada
     *
     */
    OperacaoCancelamentoUnidadeRecebivel buscarId(OperacaoCancelamentoUnidadeRecebivel operacaoCancelamentoUnidadeRecebivel);

    Long obterSeqOperacaoCancelamentoUnidadeRecebivel();
}