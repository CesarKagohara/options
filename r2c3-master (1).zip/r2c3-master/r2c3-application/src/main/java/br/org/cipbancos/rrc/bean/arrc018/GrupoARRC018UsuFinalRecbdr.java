package br.org.cipbancos.rrc.bean.arrc018;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_ARRC018_UsuFinalRecbdr")
public class GrupoARRC018UsuFinalRecbdr extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CPFUsuFinalRecbdr")
    private SPBString cNPJCPFUsuFinalRecbdr;

    @XStreamAlias("VlrLivreUsuFinalRecbdr")
    private SPBBigDecimal vlrLivreUsuFinalRecbdr;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC018_UniddRecbvl")
    private List<GrupoARRC018UniddRecbvl> listagrupoARRC018UniddRecbvl = new ArrayList<>();

    public SPBString getcNPJCPFUsuFinalRecbdr() {
        return cNPJCPFUsuFinalRecbdr;
    }

    public void setcNPJCPFUsuFinalRecbdr(SPBString cNPJCPFUsuFinalRecbdr) {
        this.cNPJCPFUsuFinalRecbdr = cNPJCPFUsuFinalRecbdr;
    }

    public SPBBigDecimal getVlrLivreUsuFinalRecbdr() {
        return vlrLivreUsuFinalRecbdr;
    }

    public void setVlrLivreUsuFinalRecbdr(SPBBigDecimal vlrLivreUsuFinalRecbdr) {
        this.vlrLivreUsuFinalRecbdr = vlrLivreUsuFinalRecbdr;
    }

    public List<GrupoARRC018UniddRecbvl> getListagrupoARRC018UniddRecbvl() {
        return listagrupoARRC018UniddRecbvl;
    }
    public void setListagrupoARRC018UniddRecbvl(List<GrupoARRC018UniddRecbvl> listagrupoARRC018UniddRecbvl) {
        this.listagrupoARRC018UniddRecbvl = listagrupoARRC018UniddRecbvl;
    }
}
