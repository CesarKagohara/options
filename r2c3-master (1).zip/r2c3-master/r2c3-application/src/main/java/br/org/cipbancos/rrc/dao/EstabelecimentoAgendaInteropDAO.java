package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.rrc.vo.EstabelecimentoAgendaInteropVO;

import java.util.Collection;
import java.util.Date;
import java.util.Set;

public interface EstabelecimentoAgendaInteropDAO {

    void inserir(Collection<EstabelecimentoAgendaInteropVO> estabelecimentoAgendaInteropVO);

    Set<String> obterCredenciadorasECComAgendaInterop(Collection<String> ecs);

    Date obterMaxDhUltAltPorAgenda(Integer idPartCreddr, String nrCpfCnpjRecbdr, String cdArrjPgto);
}