package br.org.cipbancos.rrc.bean;

import java.io.Serializable;
import java.util.List;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

import java.io.Serializable;
import java.util.List;

public interface GrupoTitlar extends DomicilioBancario {

    SPBString getcNPJCNPJBaseCPFTitlar();

    SPBBigDecimal getVlrPercTotOpUniddRecbvl();

    SPBLocalDate getDtIniOp();

    SPBLocalDate getDtFimOp();

    List<GrupoArrajPgto> getListaGrupoArrajPgto();
}
