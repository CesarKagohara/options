package br.org.cipbancos.rrc.bean.arrc023;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.PartPrincXPartAdm;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author anderson.martins
 * @since 2.0.0
 */
@XStreamAlias("Grupo_ARRC023_CanceltNegcRecbvl")
public class GrupoARRC023RETCanceltNegcRecbvl extends ErrorCodeBean implements Serializable, PartPrincXPartAdm {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("SitRetReq")
    private SPBString sitRetReq;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamOmitField
    private String recordId;

    private List<GrupoARRC023CanceltNegcRecbvlActo> listaGrupoARRC023CanceltNegcRecbvlActo = new ArrayList<GrupoARRC023CanceltNegcRecbvlActo>();

    private List<GrupoARRC023CanceltNegcRecbvlRecsdo> listaGrupoARRC023CanceltNegcRecbvlRecsdo = new ArrayList<GrupoARRC023CanceltNegcRecbvlRecsdo>();

    public SPBString getSitRetReq() {
        return sitRetReq;
    }

    public void setSitRetReq(SPBString sitRetReq) {
        this.sitRetReq = sitRetReq;
    }

    @Override
    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    @Override
    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public List<GrupoARRC023CanceltNegcRecbvlActo> getListaGrupoARRC023CanceltNegcRecbvlActo() {
        return listaGrupoARRC023CanceltNegcRecbvlActo;
    }

    public void setListaGrupoARRC023CanceltNegcRecbvlActo(List<GrupoARRC023CanceltNegcRecbvlActo> listaGrupoARRC023CanceltNegcRecbvlActo) {
        this.listaGrupoARRC023CanceltNegcRecbvlActo = listaGrupoARRC023CanceltNegcRecbvlActo;
    }

    public List<GrupoARRC023CanceltNegcRecbvlRecsdo> getListaGrupoARRC023CanceltNegcRecbvlRecsdo() {
        return listaGrupoARRC023CanceltNegcRecbvlRecsdo;
    }

    public void setListaGrupoARRC023CanceltNegcRecbvlRecsdo(List<GrupoARRC023CanceltNegcRecbvlRecsdo> listaGrupoARRC023CanceltNegcRecbvlRecsdo) {
        this.listaGrupoARRC023CanceltNegcRecbvlRecsdo = listaGrupoARRC023CanceltNegcRecbvlRecsdo;
    }

    @Override
    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }
}
