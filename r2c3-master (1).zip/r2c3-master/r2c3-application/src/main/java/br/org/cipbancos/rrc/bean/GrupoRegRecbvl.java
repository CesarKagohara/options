package br.org.cipbancos.rrc.bean;

import java.io.Serializable;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

public interface GrupoRegRecbvl extends Serializable {

    SPBString getCNPJCPFUsuFinalRecbdr();

    SPBString getCNPJCPFTitular();

    SPBString getCodInstitdrArrajPgto();

    SPBLocalDate getDtPrevtLiquid();

    SPBBigDecimal getVlrPercNegcd();

    void setErrorCode(String errorCode);
}