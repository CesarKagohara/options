package br.org.cipbancos.rrc.bean.rrc0021;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBLong;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoConsultaNegcRecbvl;
import br.org.cipbancos.rrc.bean.PartPrincPartAdmComGrNegRec;

@XStreamAlias("RRC0021")
public class RRC0021 extends PartPrincPartAdmComGrNegRec implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CodMsg")
    private SPBString codMsg;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamAlias("Grupo_RRC0021_NegcRecbvl")
    private GrupoRRC0021NegcRecbvl grupoRRC0021NegcRecbvl;

    @XStreamOmitField
    private String recordId;
    @XStreamOmitField
    private boolean completavel = true;
    @XStreamOmitField
    private Integer numeroPagina;
    @XStreamOmitField
    private Integer tamanhoPagina;

    public RRC0021(){}

    public RRC0021(String codMsg, String identdPartPrincipal, String identdPartAdmtd, String identdOp){
        this.codMsg = new SPBString(codMsg);
        this.identdPartPrincipal = new SPBString(identdPartPrincipal);
        this.identdPartAdmtd = new SPBString(identdPartAdmtd);
        GrupoRRC0021NegcRecbvl grpNegcRecbvl = new GrupoRRC0021NegcRecbvl();
        grpNegcRecbvl.setIdentdOp(new SPBLong(Long.parseLong(identdOp)));
        //grpNegcRecbvl.setFiltroConstituido(true);
        this.setGrupoRRC0021NegcRecbvl(grpNegcRecbvl);
    }

    public RRC0021(String codMsg, String identdPartPrincipal, String identdPartAdmtd, String identdOp, boolean filtroConstituido){
        this.codMsg = new SPBString(codMsg);
        this.identdPartPrincipal = new SPBString(identdPartPrincipal);
        this.identdPartAdmtd = new SPBString(identdPartAdmtd);
        GrupoRRC0021NegcRecbvl grpNegcRecbvl = new GrupoRRC0021NegcRecbvl();
        grpNegcRecbvl.setIdentdOp(new SPBLong(Long.parseLong(identdOp)));
        grpNegcRecbvl.setFiltroConstituido(filtroConstituido);
        this.setGrupoRRC0021NegcRecbvl(grpNegcRecbvl);
    }

    public RRC0021(String codMsg,String identdPartPrincipal, String identdPartAdmtd, String cnpjOuCnpjBaseOuCpfTitlar, String cnpjOuCnpjBaseOuCpfUsuFinalRecbdr ){
        this.codMsg = new SPBString(codMsg);
        this.identdPartPrincipal = new SPBString(identdPartPrincipal);
        this.identdPartAdmtd = new SPBString(identdPartAdmtd);
        GrupoRRC0021NegcRecbvl grpNegcRecbvl = new GrupoRRC0021NegcRecbvl();
        if (cnpjOuCnpjBaseOuCpfTitlar != null) {
            grpNegcRecbvl.setcNPJCNPJBaseCPFTitlar(new SPBString(cnpjOuCnpjBaseOuCpfTitlar));
        }
        if (cnpjOuCnpjBaseOuCpfUsuFinalRecbdr != null) {
            grpNegcRecbvl.setcNPJCNPJBaseCPFUsuFinalRecbdr(new SPBString(cnpjOuCnpjBaseOuCpfUsuFinalRecbdr));
        }
        this.setGrupoRRC0021NegcRecbvl(grpNegcRecbvl);
    }

    public SPBString getCodMsg() {
        return codMsg;
    }

    public void setCodMsg(SPBString codMsg) {
        this.codMsg = codMsg;
    }

    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public GrupoRRC0021NegcRecbvl getGrupoRRC0021NegcRecbvl() {
        return grupoRRC0021NegcRecbvl;
    }

    public void setGrupoRRC0021NegcRecbvl(GrupoRRC0021NegcRecbvl grupoRRC0021NegcRecbvl) {
        this.grupoRRC0021NegcRecbvl = grupoRRC0021NegcRecbvl;
    }

    public GrupoConsultaNegcRecbvl getGrupoNegcRecbvl() {
        return grupoRRC0021NegcRecbvl;
    }

    @Override
    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }

    public boolean isCompletavel() {
        return completavel;
    }

    public void setCompletavel(boolean completavel) {
        this.completavel = completavel;
    }

    public void setPaginacao(Integer pagina, Integer tamanho){
        this.numeroPagina = pagina;
        this.tamanhoPagina = tamanho;
    }

    public Integer getNumeroPagina() {
        return numeroPagina;
    }

    public void setNumeroPagina(Integer numeroPagina) {
        this.numeroPagina = numeroPagina;
    }

    public Integer getTamanhoPagina() {
        return tamanhoPagina;
    }

    public void setTamanhoPagina(Integer tamanhoPagina) {
        this.tamanhoPagina = tamanhoPagina;
    }
}
