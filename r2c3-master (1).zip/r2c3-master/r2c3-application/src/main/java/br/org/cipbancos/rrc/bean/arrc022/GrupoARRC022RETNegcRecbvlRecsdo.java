package br.org.cipbancos.rrc.bean.arrc022;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_ARRC022RET_NegcRecbvlRecsdo")
public class GrupoARRC022RETNegcRecbvlRecsdo extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdentdNegcRecbvl")
    private SPBString identdNegcRecbvl;

    @XStreamAlias("IdentdOp")
    private SPBString identdOp;

    @XStreamAlias("IndrTpNegc")
    private SPBString indrTpNegc;

    @XStreamAlias("DtVencOp")
    private SPBLocalDate dtVencOp;

    @XStreamAlias("VlrTotLim_SldDevdr")
    private SPBBigDecimal vlrTotLimSldDevdr;

    @XStreamAlias("Vlr_Gar")
    private SPBBigDecimal vlrGar;

    @XStreamAlias("IndrGestER")
    private SPBString indrGestER;

    @XStreamAlias("IndrRegrDivs")
    private SPBString indrRegrDivs;

    @XStreamAlias("IndrAlcancContrtoCreddrSub")
    private SPBString indrAlcancContrtoCreddrSub;

    @XStreamAlias("IndrActeIncondlOp")
    private SPBString indrActeIncondlOp;

    @XStreamAlias("IndrActeUniddRecbvlReserv")
    private SPBString indrActeUniddRecbvlReserv;

    @XStreamAlias("IndrIA")
    private SPBString indrIA;

    @XStreamAlias("IdentdOpDescstcNegcRecbvl")
    private SPBString identdOpDescstcNegcRecbvl;

    @XStreamAlias("IndrAutcCess")
    private SPBString indrAutcCess;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC022RET_CesAutd")
    private List<GrupoARRC022CesAutd> listagrupoARRC022RETCesAutd = new ArrayList<>();

    @XStreamImplicit(itemFieldName = "Grupo_ARRC022RET_RenegcDiv")
    private List<GrupoARRC022RETRenegcDiv> listagrupoARRC022RETRenegcDiv = new ArrayList<>();

    @XStreamAlias("Grupo_ARRC022RET_GestER")
    private GrupoARRC022RETGestER grupoARRC022RETGestER;

    @XStreamAlias("Grupo_ARRC022RET_GestPart")
    private GrupoARRC022RETGestPart grupoARRC022RETGestPart;

    public SPBString getIdentdNegcRecbvl() {
        return identdNegcRecbvl;
    }

    public void setIdentdNegcRecbvl(SPBString identdNegcRecbvl) {
        this.identdNegcRecbvl = identdNegcRecbvl;
    }

    public SPBString getIdentdOp() {
        return identdOp;
    }

    public void setIdentdOp(SPBString identdOp) {
        this.identdOp = identdOp;
    }

    public SPBString getIndrTpNegc() {
        return indrTpNegc;
    }

    public void setIndrTpNegc(SPBString indrTpNegc) {
        this.indrTpNegc = indrTpNegc;
    }

    public SPBLocalDate getDtVencOp() {
        return dtVencOp;
    }

    public void setDtVencOp(SPBLocalDate dtVencOp) {
        this.dtVencOp = dtVencOp;
    }

    public SPBBigDecimal getVlrTotLimSldDevdr() {
        return vlrTotLimSldDevdr;
    }

    public void setVlrTotLimSldDevdr(SPBBigDecimal vlrTotLimSldDevdr) {
        this.vlrTotLimSldDevdr = vlrTotLimSldDevdr;
    }

    public SPBBigDecimal getVlrGar() {
        return vlrGar;
    }

    public void setVlrGar(SPBBigDecimal vlrGar) {
        this.vlrGar = vlrGar;
    }

    public SPBString getIndrGestER() {
        return indrGestER;
    }

    public void setIndrGestER(SPBString indrGestER) {
        this.indrGestER = indrGestER;
    }

    public SPBString getIndrRegrDivs() {
        return indrRegrDivs;
    }

    public void setIndrRegrDivs(SPBString indrRegrDivs) {
        this.indrRegrDivs = indrRegrDivs;
    }

    public SPBString getIndrAlcancContrtoCreddrSub() {
        return indrAlcancContrtoCreddrSub;
    }

    public void setIndrAlcancContrtoCreddrSub(SPBString indrAlcancContrtoCreddrSub) {
        this.indrAlcancContrtoCreddrSub = indrAlcancContrtoCreddrSub;
    }

    public SPBString getIndrActeIncondlOp() {
        return indrActeIncondlOp;
    }

    public void setIndrActeIncondlOp(SPBString indrActeIncondlOp) {
        this.indrActeIncondlOp = indrActeIncondlOp;
    }

    public SPBString getIndrActeUniddRecbvlReserv() {
        return indrActeUniddRecbvlReserv;
    }

    public void setIndrActeUniddRecbvlReserv(SPBString indrActeUniddRecbvlReserv) {
        this.indrActeUniddRecbvlReserv = indrActeUniddRecbvlReserv;
    }

    public SPBString getIndrIA() {
        return indrIA;
    }

    public void setIndrIA(SPBString indrIA) {
        this.indrIA = indrIA;
    }

    public SPBString getIdentdOpDescstcNegcRecbvl() {
        return identdOpDescstcNegcRecbvl;
    }

    public void setIdentdOpDescstcNegcRecbvl(SPBString identdOpDescstcNegcRecbvl) {
        this.identdOpDescstcNegcRecbvl = identdOpDescstcNegcRecbvl;
    }

    public SPBString getIndrAutcCess() {
        return indrAutcCess;
    }

    public void setIndrAutcCess(SPBString indrAutcCess) {
        this.indrAutcCess = indrAutcCess;
    }

    public List<GrupoARRC022CesAutd> getListagrupoARRC022RETCesAutd() {
        return listagrupoARRC022RETCesAutd;
    }

    public void setListagrupoARRC022RETCesAutd(List<GrupoARRC022CesAutd> listagrupoARRC022RETCesAutd) {
        this.listagrupoARRC022RETCesAutd = listagrupoARRC022RETCesAutd;
    }

    public List<GrupoARRC022RETRenegcDiv> getListagrupoARRC022RETRenegcDiv() {
        return listagrupoARRC022RETRenegcDiv;
    }

    public void setListagrupoARRC022RETRenegcDiv(List<GrupoARRC022RETRenegcDiv> listagrupoARRC022RETRenegcDiv) {
        this.listagrupoARRC022RETRenegcDiv = listagrupoARRC022RETRenegcDiv;
    }

    public GrupoARRC022RETGestER getGrupoARRC022RETGestER() {
        return grupoARRC022RETGestER;
    }

    public void setGrupoARRC022RETGestER(GrupoARRC022RETGestER grupoARRC022RETGestER) {
        this.grupoARRC022RETGestER = grupoARRC022RETGestER;
    }

    public GrupoARRC022RETGestPart getGrupoARRC022RETGestPart() {
        return grupoARRC022RETGestPart;
    }

    public void setGrupoARRC022RETGestPart(GrupoARRC022RETGestPart grupoARRC022RETGestPart) {
        this.grupoARRC022RETGestPart = grupoARRC022RETGestPart;
    }
}
