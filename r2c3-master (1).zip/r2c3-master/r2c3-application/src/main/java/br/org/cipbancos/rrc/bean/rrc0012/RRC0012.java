package br.org.cipbancos.rrc.bean.rrc0012;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.PartPrincXPartAdm;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@XStreamAlias("RRC0012")
public class RRC0012 extends ErrorCodeBean implements Serializable, PartPrincXPartAdm {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CodMsg")
    private SPBString codMsg;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamAlias("IdentdCtrlReqSolicte")
    private SPBString identdCtrlReqSolicte;

    @XStreamAlias("IdentdOp")
    private SPBString identdOp;

    @XStreamAlias("CNPJ_CNPJBase_CPFTitlar")
    private SPBString cNPJCNPJBaseCPFTitlar;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0012_RegRecbvl")
    private List<GrupoRRC0012RegRecbvl> listagrupoRRC0012RegRecbvl = new ArrayList<>();

    @XStreamOmitField
    private String recordId;

    public SPBString getCodMsg() {
        return codMsg;
    }

    public void setCodMsg(SPBString codMsg) {
        this.codMsg = codMsg;
    }

    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public SPBString getIdentdCtrlReqSolicte() {
        return identdCtrlReqSolicte;
    }

    public void setIdentdCtrlReqSolicte(SPBString identdCtrlReqSolicte) {
        this.identdCtrlReqSolicte = identdCtrlReqSolicte;
    }

    public SPBString getIdentdOp() {
        return identdOp;
    }

    public void setIdentdOp(SPBString identdOp) {
        this.identdOp = identdOp;
    }

    public SPBString getcNPJCNPJBaseCPFTitlar() {
        return cNPJCNPJBaseCPFTitlar;
    }

    public void setcNPJCNPJBaseCPFTitlar(SPBString cNPJCNPJBaseCPFTitlar) {
        this.cNPJCNPJBaseCPFTitlar = cNPJCNPJBaseCPFTitlar;
    }

    public List<GrupoRRC0012RegRecbvl> getListagrupoRRC0012RegRecbvl() {
        return listagrupoRRC0012RegRecbvl;
    }

    public void setListagrupoRRC0012RegRecbvl(List<GrupoRRC0012RegRecbvl> listagrupoRRC0012RegRecbvl) {
        this.listagrupoRRC0012RegRecbvl = listagrupoRRC0012RegRecbvl;
    }

    @Override
    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }
}
