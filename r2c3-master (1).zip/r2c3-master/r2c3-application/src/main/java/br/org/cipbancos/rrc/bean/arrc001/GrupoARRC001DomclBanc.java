package br.org.cipbancos.rrc.bean.arrc001;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.vo.FracaoUnidadeRecebivelOperacao;
import br.org.cipbancos.rrc.vo.Operacao;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilioUnidadeRecebivel;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilioUsuarioFinal;

public class GrupoARRC001DomclBanc extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CPFTitlarCt")
    private SPBString cNPJCPFTitlarCt;

    @XStreamAlias("ISPBBcoRecbdr")
    private SPBString iSPBBcoRecbdr;

    @XStreamAlias("TpCt")
    private SPBString tpCt;

    @XStreamAlias("Ag")
    private SPBString ag;

    @XStreamAlias("Ct")
    private SPBString ct;

    @XStreamAlias("CtPgto")
    private SPBString ctPgto;

    @XStreamAlias("VlrPrevtLiquid")
    private SPBBigDecimal vlrPrevtLiquid;

    @XStreamAlias("DtEftLiquid")
    private SPBLocalDate dtEftLiquid;

    @XStreamAlias("VlrEftLiquid")
    private SPBBigDecimal vlrEftLiquid;

    @XStreamAlias("IdentdOp")
    private SPBString identdOp;

    @XStreamOmitField
    private Operacao operacao;

    @XStreamOmitField
    private OperacaoTitularDomicilioUnidadeRecebivel operacaoTitularDomicilioUnidadeRecebivel;

    @XStreamOmitField
    private OperacaoTitularDomicilioUsuarioFinal operacaoTitularDomicilioUsuarioFinal;

    @XStreamOmitField
    private FracaoUnidadeRecebivelOperacao fracaoUnidadeRecebivelOperacao;

    public SPBString getcNPJCPFTitlarCt() {
        return cNPJCPFTitlarCt;
    }

    public void setcNPJCPFTitlarCt(SPBString cNPJCPFTitlarCt) {
        this.cNPJCPFTitlarCt = cNPJCPFTitlarCt;
    }

    public SPBString getiSPBBcoRecbdr() {
        return iSPBBcoRecbdr;
    }

    public void setiSPBBcoRecbdr(SPBString iSPBBcoRecbdr) {
        this.iSPBBcoRecbdr = iSPBBcoRecbdr;
    }

    public SPBString getTpCt() {
        return tpCt;
    }

    public void setTpCt(SPBString tpCt) {
        this.tpCt = tpCt;
    }

    public SPBString getAg() {
        return ag;
    }

    public void setAg(SPBString ag) {
        this.ag = ag;
    }

    public SPBString getCt() {
        return ct;
    }

    public void setCt(SPBString ct) {
        this.ct = ct;
    }

    public SPBString getCtPgto() {
        return ctPgto;
    }

    public void setCtPgto(SPBString ctPgto) {
        this.ctPgto = ctPgto;
    }

    public SPBBigDecimal getVlrPrevtLiquid() {
        return vlrPrevtLiquid;
    }

    public void setVlrPrevtLiquid(SPBBigDecimal vlrPrevtLiquid) {
        this.vlrPrevtLiquid = vlrPrevtLiquid;
    }

    public SPBLocalDate getDtEftLiquid() {
        return dtEftLiquid;
    }

    public void setDtEftLiquid(SPBLocalDate dtEftLiquid) {
        this.dtEftLiquid = dtEftLiquid;
    }

    public SPBBigDecimal getVlrEftLiquid() {
        return vlrEftLiquid;
    }

    public void setVlrEftLiquid(SPBBigDecimal vlrEftLiquid) {
        this.vlrEftLiquid = vlrEftLiquid;
    }

    public SPBString getIdentdOp() {
        return identdOp;
    }

    public void setIdentdOp(SPBString identdOp) {
        this.identdOp = identdOp;
    }

    public Operacao getOperacao() {
        return operacao;
    }

    public void setOperacao(Operacao operacao) {
        this.operacao = operacao;
    }

    public OperacaoTitularDomicilioUnidadeRecebivel getOperacaoTitularDomicilioUnidadeRecebivel() {
        return operacaoTitularDomicilioUnidadeRecebivel;
    }

    public void setOperacaoTitularDomicilioUnidadeRecebivel(OperacaoTitularDomicilioUnidadeRecebivel operacaoTitularDomicilioUnidadeRecebivel) {
        this.operacaoTitularDomicilioUnidadeRecebivel = operacaoTitularDomicilioUnidadeRecebivel;
    }

    public OperacaoTitularDomicilioUsuarioFinal getOperacaoTitularDomicilioUsuarioFinal() {
        return operacaoTitularDomicilioUsuarioFinal;
    }

    public void setOperacaoTitularDomicilioUsuarioFinal(OperacaoTitularDomicilioUsuarioFinal operacaoTitularDomicilioUsuarioFinal) {
        this.operacaoTitularDomicilioUsuarioFinal = operacaoTitularDomicilioUsuarioFinal;
    }

    public FracaoUnidadeRecebivelOperacao getFracaoUnidadeRecebivelOperacao() {
        return fracaoUnidadeRecebivelOperacao;
    }

    public void setFracaoUnidadeRecebivelOperacao(FracaoUnidadeRecebivelOperacao fracaoUnidadeRecebivelOperacao) {
        this.fracaoUnidadeRecebivelOperacao = fracaoUnidadeRecebivelOperacao;
    }
}
