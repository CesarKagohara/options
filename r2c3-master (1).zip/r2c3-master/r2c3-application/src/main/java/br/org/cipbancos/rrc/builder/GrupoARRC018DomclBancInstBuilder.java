package br.org.cipbancos.rrc.builder;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.arrc018.GrupoARRC018DomclBancInst;
import br.org.cipbancos.rrc.util.DateUtil;

import java.math.BigDecimal;
import java.util.Date;

public class GrupoARRC018DomclBancInstBuilder {

    private GrupoARRC018DomclBancInst grupoARRC018DomclBancInst;

    private GrupoARRC018DomclBancInstBuilder() {
        this.grupoARRC018DomclBancInst = new GrupoARRC018DomclBancInst();
    }

    public static GrupoARRC018DomclBancInstBuilder builder() {
        return new GrupoARRC018DomclBancInstBuilder();
    }

    public GrupoARRC018DomclBancInstBuilder comCnpjCpfTitularConta(String cnpjCpfTitularConta) {
        if (cnpjCpfTitularConta != null) {
            this.grupoARRC018DomclBancInst.setcNPJCPFTitlarCt(new SPBString(cnpjCpfTitularConta));
        }
        return this;
    }

    public GrupoARRC018DomclBancInstBuilder comTipoConta(String tipoConta) {
        if (tipoConta != null) {
            this.grupoARRC018DomclBancInst.setTpCt(new SPBString(tipoConta));
        }
        return this;
    }

    public GrupoARRC018DomclBancInstBuilder comDataEfetivacaoLiquidacao(Date dataEfetivacaoLiquidacao) {
        if (dataEfetivacaoLiquidacao != null) {
            this.grupoARRC018DomclBancInst.setDtEftLiquid(new SPBLocalDate(DateUtil.toLocalDate(dataEfetivacaoLiquidacao)));
        }
        return this;
    }

    public GrupoARRC018DomclBancInstBuilder comValorEfetivacaoLiquidacao(BigDecimal valorEfetivacaoLiquidacao) {
        if (valorEfetivacaoLiquidacao != null) {
            this.grupoARRC018DomclBancInst.setVlrEftLiquid(new SPBBigDecimal(valorEfetivacaoLiquidacao));
        }
        return this;
    }

    public GrupoARRC018DomclBancInstBuilder comValorLivre(BigDecimal valorLivre) {
        if (valorLivre != null) {
            this.grupoARRC018DomclBancInst.setVlrLivre(new SPBBigDecimal(valorLivre));
        }
        return this;
    }

    public GrupoARRC018DomclBancInstBuilder comAgencia(Integer agencia) {
        if (agencia != null) {
            this.grupoARRC018DomclBancInst.setAg(new SPBString(String.format("%04d", agencia)));
        }
        return this;
    }

    public GrupoARRC018DomclBancInstBuilder comNumeroConta(Long numeroConta) {
        if (numeroConta != null) {
            this.grupoARRC018DomclBancInst.setCt(new SPBString(String.format("%013d", numeroConta)));
        }
        return this;
    }

    public GrupoARRC018DomclBancInstBuilder comNumeroContaPagamento(String numeroContaPagamento) {
        if (numeroContaPagamento != null) {
            this.grupoARRC018DomclBancInst.setCtPgto(new SPBString(numeroContaPagamento));
        }
        return this;
    }

    public GrupoARRC018DomclBancInst build() {
        return this.grupoARRC018DomclBancInst;
    }
}
