package br.org.cipbancos.rrc.dao;

import java.util.Date;

import br.org.cipbancos.atlante.api.handler.Context;
import br.org.cipbancos.rrc.bean.rrc0012.RRC0012;
import br.org.cipbancos.rrc.vo.DesconstituicaoGarantia;
import br.org.cipbancos.rrc.vo.UnidadeRecebivel;

public interface DesconstituicaoDAO {

    /**
     * Grava uma nova Desconstituição de Garantia no BD.
     *
     * @param desconstituicaoGarantia a ser salva no BD.
     * @return O ID criado para essa Desconstituição.
     */
    Long inserirDesconstituicaoGarantia(DesconstituicaoGarantia desconstituicaoGarantia);

    /**
     * Grava uma nova Desconstituição de Garantia, com associaçºao de UR, no BD.
     *
     * @param context        Contexto do Atlante
     * @param rrc0012        Requisição de Desconstituição
     * @param idDescGarantia Para fazer o link com a Desconstituição.
     * @param ur             Que vai conter os dados para o link.
     */
    void inserirDesconstituicaoGarantiaUR(Context context, RRC0012 rrc0012, Long idDescGarantia, UnidadeRecebivel ur);

    /**
     * Atualiza status da Desconstituição de Garantia.
     *
     * @param idDesctcGar id da descontitucao de garantia.
     * @param idOperacao  id da operacao.
     * @param status      Status a ser setado.
     */
    void atualizarStatus(String idDesctcGar, Long idOperacao, Integer status, Date dtRef);

    /**
     * Busca Desconstituição de Garantia.
     *
     * @param idDescGarExtn id da descontitucao de garantia.
     * @return Boolean se existe.
     */
    Boolean buscar(String idDescGarExtn);

    /**
     * Busca Desconstituição de Garantia.
     *
     * @param idDescGarExtn id da descontitucao de garantia.
     * @return DesconstituicaoGarantia.
     */
    DesconstituicaoGarantia buscarId(String idDescGarExtn);

    DesconstituicaoGarantia buscarInfoResumoDiario(Long idAtlRoot);

    Long buscarIdAtlRoot(Long idDescGarantia);

    String buscarNrCnpjCreddrPorIdOp(Long idOp);
}
