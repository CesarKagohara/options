package br.org.cipbancos.rrc.bean.rrc0008;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoConsultaNegcRecbvl;
import br.org.cipbancos.rrc.bean.PartPrincPartAdmComGrNegRec;

@XStreamAlias("RRC0008")
public class RRC0008 extends PartPrincPartAdmComGrNegRec implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CodMsg")
    private SPBString codMsg;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamAlias("Grupo_RRC0008_NegcRecbvl")
    private GrupoRRC0008NegcRecbvl grupoRRC0008NegcRecbvl;

    @XStreamOmitField
    private boolean retornarApenasUrs;

    @XStreamOmitField
    private String recordId;

    @XStreamOmitField
    private boolean completavel = true;
    @XStreamOmitField
    private Integer numeroPagina;
    @XStreamOmitField
    private Integer tamanhoPagina;

    public SPBString getCodMsg() {
        return codMsg;
    }

    public void setCodMsg(SPBString codMsg) {
        this.codMsg = codMsg;
    }

    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public GrupoRRC0008NegcRecbvl getGrupoRRC0008NegcRecbvl() {
        return grupoRRC0008NegcRecbvl;
    }

    public void setGrupoRRC0008NegcRecbvl(GrupoRRC0008NegcRecbvl grupoRRC0008NegcRecbvl) {
        this.grupoRRC0008NegcRecbvl = grupoRRC0008NegcRecbvl;
    }

    public GrupoConsultaNegcRecbvl getGrupoNegcRecbvl() {
        return grupoRRC0008NegcRecbvl;
    }

    public boolean isRetornarApenasUrs() {
        return retornarApenasUrs;
    }

    public void setRetornarApenasUrs(boolean retornarApenasUrs) {
        this.retornarApenasUrs = retornarApenasUrs;
    }

    @Override
    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }

    public boolean isCompletavel() {
        return completavel;
    }

    public void setCompletavel(boolean completavel) {
        this.completavel = completavel;
    }



    public void setPaginacao(Integer pagina, Integer tamanho){
        this.numeroPagina = pagina;
        this.tamanhoPagina = tamanho;
    }

    public Integer getNumeroPagina() {
        return numeroPagina;
    }

    public void setNumeroPagina(Integer numeroPagina) {
        this.numeroPagina = numeroPagina;
    }

    public Integer getTamanhoPagina() {
        return tamanhoPagina;
    }

    public void setTamanhoPagina(Integer tamanhoPagina) {
        this.tamanhoPagina = tamanhoPagina;
    }
}
