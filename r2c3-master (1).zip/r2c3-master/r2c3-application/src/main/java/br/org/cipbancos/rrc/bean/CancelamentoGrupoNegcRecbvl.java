package br.org.cipbancos.rrc.bean;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

import java.util.List;

public interface CancelamentoGrupoNegcRecbvl extends SPBBean {

    SPBString getIdentdNegcRecbvl();

    SPBString getIdentdOp();

    SPBString getIndrCancelVlrTotal();

    SPBString getIndrLiquidOp();

    SPBString getCnpjCnpjBaseCpfTitlar();

    SPBString getIndrCancelCessConstitr();

    List<CancelamentoGrupoRegRecbvl> getListaGrupoRegRecbvl();

    void setErrorCode(String errorCode);

    String getRecordId();

    void setRecordId(String recordId);

    Long getAtlRootId();

    void setAtlRootId(Long atlRootId);
}