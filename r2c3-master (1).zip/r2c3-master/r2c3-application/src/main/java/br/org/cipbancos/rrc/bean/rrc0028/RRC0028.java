package br.org.cipbancos.rrc.bean.rrc0028;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("RRC0028")
public class RRC0028 extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CodMsg")
    private SPBString codMsg;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamAlias("IdentdCtrlOptIn")
    private SPBString identdCtrlOptIn;

    @XStreamAlias("CNPJ_CNPJBase_CPFUsuFinalRecbdr_Titlar")
    private SPBString cNPJCNPJBaseCPFUsuFinalRecbdrTitular;

    @XStreamAlias("CNPJCreddrSub")
    private SPBString cnpjCreddrSub;

    @XStreamAlias("CNPJFincdr")
    private SPBString cnpjFincdr;

    @XStreamAlias("CodInstitdrArrajPgto")
    private SPBString codInstitdrArrajPgto;

    @XStreamAlias("DtOptIn")
    private SPBLocalDate dtOptIn;

    @XStreamAlias("DtIniOptIn")
    private SPBLocalDate dtIniOptIn;

    @XStreamAlias("DtFimOptIn")
    private SPBLocalDate dtFimOptIn;

    @XStreamAlias("IndrDomcl")
    private SPBString indrDomcl;

    @XStreamAlias("CNPJER")
    private SPBString cnpjER;

    @XStreamAlias("CPF_CNPJRecbdrOptIn")
    private SPBString cpfCNPJRecbdrOptIn;

    public SPBString getCodMsg() {
        return codMsg;
    }

    public void setCodMsg(SPBString codMsg) {
        this.codMsg = codMsg;
    }

    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public SPBString getIdentdCtrlOptIn() {
        return identdCtrlOptIn;
    }

    public void setIdentdCtrlOptIn(SPBString identdCtrlOptIn) {
        this.identdCtrlOptIn = identdCtrlOptIn;
    }

    public SPBString getcNPJCNPJBaseCPFUsuFinalRecbdrTitular() {
        return cNPJCNPJBaseCPFUsuFinalRecbdrTitular;
    }

    public void setcNPJCNPJBaseCPFUsuFinalRecbdrTitular(SPBString cNPJCNPJBaseCPFUsuFinalRecbdrTitular) {
        this.cNPJCNPJBaseCPFUsuFinalRecbdrTitular = cNPJCNPJBaseCPFUsuFinalRecbdrTitular;
    }

    public SPBString getCnpjCreddrSub() {
        return cnpjCreddrSub;
    }

    public void setCnpjCreddrSub(SPBString cnpjCreddrSub) {
        this.cnpjCreddrSub = cnpjCreddrSub;
    }

    public SPBString getCnpjFincdr() {
        return cnpjFincdr;
    }

    public void setCnpjFincdr(SPBString cnpjFincdr) {
        this.cnpjFincdr = cnpjFincdr;
    }

    public SPBString getCodInstitdrArrajPgto() {
        return codInstitdrArrajPgto;
    }

    public void setCodInstitdrArrajPgto(SPBString codInstitdrArrajPgto) {
        this.codInstitdrArrajPgto = codInstitdrArrajPgto;
    }

    public SPBLocalDate getDtOptIn() {
        return dtOptIn;
    }

    public void setDtOptIn(SPBLocalDate dtOptIn) {
        this.dtOptIn = dtOptIn;
    }

    public SPBLocalDate getDtIniOptIn() {
        return dtIniOptIn;
    }

    public void setDtIniOptIn(SPBLocalDate dtIniOptIn) {
        this.dtIniOptIn = dtIniOptIn;
    }

    public SPBLocalDate getDtFimOptIn() {
        return dtFimOptIn;
    }

    public void setDtFimOptIn(SPBLocalDate dtFimOptIn) {
        this.dtFimOptIn = dtFimOptIn;
    }

    public SPBString getIndrDomcl() {
        return indrDomcl;
    }

    public void setIndrDomcl(SPBString indrDomcl) {
        this.indrDomcl = indrDomcl;
    }

    public SPBString getCnpjER() {
        return cnpjER;
    }

    public void setCnpjER(SPBString cnpjER) {
        this.cnpjER = cnpjER;
    }

    public SPBString getCpfCNPJRecbdrOptIn() {
        return cpfCNPJRecbdrOptIn;
    }

    public void setCpfCNPJRecbdrOptIn(SPBString cpfCNPJRecbdrOptIn) {
        this.cpfCNPJRecbdrOptIn = cpfCNPJRecbdrOptIn;
    }
}
