package br.org.cipbancos.rrc.dao;

import java.util.List;

import br.org.cipbancos.rrc.vo.DominioVO;

public interface DominioDAO {

    List<DominioVO> obtemDominios();

}
