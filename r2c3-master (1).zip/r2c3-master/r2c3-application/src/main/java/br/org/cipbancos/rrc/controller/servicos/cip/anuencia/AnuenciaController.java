package br.org.cipbancos.rrc.controller.servicos.cip.anuencia;

import br.org.cip.api.r2c3.AnuenciasApi;
import br.org.cip.api.r2c3.model.Anuencia;
import br.org.cip.api.r2c3.model.AnuenciaExclusaoChave;
import br.org.cip.api.r2c3.model.Erro;
import br.org.cip.api.r2c3.model.ResponsesolicitaOptIn;
import br.org.cip.arche.commons.library.exceptions.ArcConditionalException;

import br.org.cipbancos.atlante.api.ApplicationErrorAPIException;
import br.org.cipbancos.atlante.api.handler.Context;
import br.org.cipbancos.atlante.api.handler.ContextLocator;
import br.org.cipbancos.atlante.config.HttpTransportConfig;
import br.org.cipbancos.atlante.session.AtlanteSession;
import br.org.cipbancos.atlante.spb.transformer.SPBObjectTransformer;
import br.org.cipbancos.atlante.spb.transformer.base.ObjectTransformException;
import br.org.cipbancos.atlante.util.PartyUtility;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.rrc0011.GrupoRRC0011AutcEnvAgenda;
import br.org.cipbancos.rrc.bean.rrc0011.RRC0011;
import br.org.cipbancos.rrc.bean.rrc0013.GrupoRRC0013CanceltAutcEnvAgenda;
import br.org.cipbancos.rrc.bean.rrc0013.RRC0013;
import br.org.cipbancos.rrc.enums.TipoFuncionalidade;
import br.org.cipbancos.rrc.handler.rrc0011.RRC0011Handler;
import br.org.cipbancos.rrc.handler.rrc0013.RRC0013Handler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS)
@Controller
public class AnuenciaController implements AnuenciasApi {

    private static final Logger LOG = LoggerFactory.getLogger(AnuenciaController.class);

    @Autowired
    private RRC0011Handler rrc0011Handler;

    @Autowired
    private RRC0013Handler rrc0013Handler;

    private Context getContext() {
        return ContextLocator.getContext();
    }

    @Override
    public ResponseEntity<AnuenciaExclusaoChave> deleteAnuenciasIdentdCtrlOptIn(String xJwsSignature, String identdCtrlOptIn, String identdCtrlReqSolicte, String acceptEncoding, String contentEncoding) {
        LOG.info("Iniciando processamento do OPT-IN RRC0013 via HTTP. IdentdCtrlOptIn {} e IdentdCtrlReqSolicte {},  ", identdCtrlOptIn, identdCtrlReqSolicte);
        Context ctx = getContext();

        RRC0013 rrc0013 = new RRC0013();
        rrc0013.setIdentdPartPrincipal(new SPBString(PartyUtility.partyIdToIspb(ctx.getPartyId())));
        String partyAdmin = PartyUtility.partyIdToIspb(Integer.valueOf(ctx.getProperties().get(HttpTransportConfig.HEADER_PARTY_ADMIN_ID).toString()));
        rrc0013.setIdentdPartAdmtd(new SPBString(partyAdmin));
        rrc0013.setCodMsg(new SPBString(TipoFuncionalidade.RRC0013.getValue()));

        GrupoRRC0013CanceltAutcEnvAgenda grupoRRC0013CanceltAutcEnvAgenda = new GrupoRRC0013CanceltAutcEnvAgenda();
        grupoRRC0013CanceltAutcEnvAgenda.setIdentdCtrlOptIn(new SPBString(identdCtrlOptIn));
        grupoRRC0013CanceltAutcEnvAgenda.setIdentdCtrlReqSolicte(new SPBString(identdCtrlReqSolicte));
        rrc0013.setGrupoRRC0013CanceltAutcEnvAgenda(grupoRRC0013CanceltAutcEnvAgenda);

        rrc0013Handler.process(rrc0013, ctx);

        Object o = AtlanteSession.getSession().getHttpRecords().get(0);

        if (o instanceof AnuenciaExclusaoChave) {
            return new ResponseEntity<>((AnuenciaExclusaoChave) o, HttpStatus.OK);
        } else if (o instanceof Erro) {
            return new ResponseEntity(o, HttpStatus.BAD_REQUEST);
        }

        throw new ApplicationErrorAPIException(o, new ArcConditionalException());
    }

    @Override
    public ResponseEntity<ResponsesolicitaOptIn> postAnuencias(String xJwsSignature, Anuencia body, String acceptEncoding, String contentEncoding) {
        LOG.info("Iniciando processamento do OPT-IN RRC0011 via HTTP. Anuencia {} recebida", body);
        Context ctx = getContext();

        RRC0011 rrc0011 = new RRC0011();
        rrc0011.setIdentdPartPrincipal(new SPBString(PartyUtility.partyIdToIspb(ctx.getPartyId())));
        String partyAdmin = PartyUtility.partyIdToIspb(Integer.valueOf(ctx.getProperties().get(HttpTransportConfig.HEADER_PARTY_ADMIN_ID).toString()));
        rrc0011.setIdentdPartAdmtd(new SPBString(partyAdmin));
        rrc0011.setCodMsg(new SPBString(TipoFuncionalidade.RRC0011.getValue()));
        SPBObjectTransformer transformer = new SPBObjectTransformer();
        try {
            rrc0011.setGrupoRRC0011AutcEnvAgenda(transformer.toSPB(body, GrupoRRC0011AutcEnvAgenda.class));
        } catch (ObjectTransformException e) {
            throw new RuntimeException(e);
        }
        rrc0011Handler.process(rrc0011, ctx);
        Object o = AtlanteSession.getSession().getHttpRecords().get(0);

        if (o instanceof ResponsesolicitaOptIn) {
            return new ResponseEntity<>((ResponsesolicitaOptIn) o, HttpStatus.OK);
        } else if (o instanceof Erro) {
            return new ResponseEntity(o, HttpStatus.BAD_REQUEST);
        }

        throw new ApplicationErrorAPIException(o, new ArcConditionalException());
    }
}
