package br.org.cipbancos.rrc.bean.rrc0019;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoCreddrSub;

@XStreamAlias("Grupo_RRC0019_CreddrSub")
public class GrupoRRC0019CreddrSub extends ErrorCodeBean implements GrupoCreddrSub {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJCreddrSub")
    private SPBString cNPJCreddrSub;


    public SPBString getCNPJCreddrSub() {
        return cNPJCreddrSub;
    }

    public void setCNPJCreddrSub(SPBString cNPJCreddrSub) {
        this.cNPJCreddrSub = cNPJCreddrSub;
    }

    @Override
    public String toString() {
        return "GrupoRRC0019CreddrSub{" +
                "cNPJCreddrSub=" + cNPJCreddrSub +
                '}';
    }
}
