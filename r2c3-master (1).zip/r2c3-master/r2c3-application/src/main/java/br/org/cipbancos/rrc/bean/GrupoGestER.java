package br.org.cipbancos.rrc.bean;

import java.io.Serializable;
import java.util.List;

public interface GrupoGestER extends Serializable {

    List<GrupoTitlar> getListaGrupoTitlar();

    void setErrorCode(String errorCode);

}
