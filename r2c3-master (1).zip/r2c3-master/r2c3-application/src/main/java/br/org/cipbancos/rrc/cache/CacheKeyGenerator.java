package br.org.cipbancos.rrc.cache;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Objects;

import org.springframework.cache.interceptor.KeyGenerator;

public class CacheKeyGenerator implements KeyGenerator {

    @Override
    public Object generate(Object target, Method method, Object... params) {
        return new MethodKey(target, method, params);
    }

    private static final class MethodKey {
        private Object target;
        private Method method;
        private Object[] params;

        public MethodKey(Object target, Method method, Object[] params) {
            this.target = target;
            this.method = method;
            this.params = params;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }

            MethodKey methodKey = (MethodKey) o;

            if (!Objects.equals(method, methodKey.method)) {
                return false;
            }
            if (!Arrays.equals(params, methodKey.params)) {
                return false;
            }

            return Objects.equals(target, methodKey.target);
        }

        @Override
        public int hashCode() {
            int result = target != null ? target.hashCode() : 0;
            result = 31 * result + (method != null ? method.hashCode() : 0);
            result = 31 * result + (params != null ? Arrays.hashCode(params) : 0);
            return result;
        }
    }

}
