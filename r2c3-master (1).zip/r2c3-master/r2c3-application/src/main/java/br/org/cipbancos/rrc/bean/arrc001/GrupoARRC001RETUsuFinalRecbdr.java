package br.org.cipbancos.rrc.bean.arrc001;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_ARRC001RET_UsuFinalRecbdr")
public class GrupoARRC001RETUsuFinalRecbdr extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CPFUsuFinalRecbdr")
    private SPBString cNPJCPFUsuFinalRecbdr;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC001RET_ArrajPgto")
    private List<GrupoARRC001RETArrajPgto> listagrupoARRC001ArrajPgto = new ArrayList<>();

    public SPBString getCNPJCPFUsuFinalRecbdr() {
        return cNPJCPFUsuFinalRecbdr;
    }

    public void setCNPJCPFUsuFinalRecbdr(SPBString cNPJCPFUsuFinalRecbdr) {
        this.cNPJCPFUsuFinalRecbdr = cNPJCPFUsuFinalRecbdr;
    }

    public List<GrupoARRC001RETArrajPgto> getListagrupoARRC001ArrajPgto() {
        return listagrupoARRC001ArrajPgto;
    }

    public void setListagrupoARRC001ArrajPgto(List<GrupoARRC001RETArrajPgto> listagrupoARRC001ArrajPgto) {
        this.listagrupoARRC001ArrajPgto = listagrupoARRC001ArrajPgto;
    }

}
