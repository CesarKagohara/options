package br.org.cipbancos.rrc.bean;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

import java.io.Serializable;

public interface GrupoArrajPgto extends Serializable {

    SPBString getCodInstitdrArrajPgto();

    default String getCodInstitdrArrajPgtoValue() {
        return getCodInstitdrArrajPgto().getValue();
    }
}
