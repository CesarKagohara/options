package br.org.cipbancos.rrc.bean;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.rrc0019.GrupoNegcRecbvlInterop;
import br.org.cipbancos.rrc.enums.AlcanceContrato;
import br.org.cipbancos.rrc.enums.TipoNegociacao;
import br.org.cipbancos.rrc.handler.recalculo.bean.RecalculoObjetoParametro;
import br.org.cipbancos.rrc.vo.Operacao;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface GrupoNegcRecbvl0019 extends GrupoNegcRecbvl, GrupoNegcRecbvlInterop {

    SPBBigDecimal getVlrGar();

    SPBString getIndrAlcancContrtoCreddrSub();

    SPBString getIndrActeUniddRecbvlReserv();

    SPBString getIdentdOpDescstcNegcRecbvl();

    SPBString getIndrAutcCess();

    Operacao getOperacaoAtual();

    void setOperacaoAtual(Operacao operacaoAtual);

    String getRecordId();

    void setRecordId(String recordId);

    Long getAtlRootId();

    void setAtlRootId(Long atlRootId);

    List<GrupoCesAutd> getListaGrupoCesAutd();

    List<GrupoRenegcDiv> getListaGrupoRenegcDiv();

    boolean isInterop();

    default boolean isGravame() {
        return this.getIndrTpNegc().getValue().equals(TipoNegociacao.OG.getValue());
    }

    default boolean isCessao() {
        return this.getIndrTpNegc().getValue().equals(TipoNegociacao.TC.getValue());
    }

    Set<String> getEstabelecimentosBloqueados();

    void setEstabelecimentosBloqueados(Set<String> estabelecimentosBloqueados);

    void setCredenciadorasAlcanceGeral(Set<String> creds);

    Set<String> getCredenciadorasAlcanceGeral();

    RecalculoObjetoParametro<Long> getRecalculoObjetoParametro();

    void setRecalculoObjetoParametro(RecalculoObjetoParametro<Long> recalculoObjetoParametro);

    void setCredenciadorasArranjosOutrasIMFs(Map<String, Set<String>> credenciadorasArranjosOutrasIMFs );

    Map<String, Set<String>> getCredenciadorasArranjosOutrasIMFs();

    @Override
    default boolean hasAlcanceEspecifico() {
        return AlcanceContrato.ESPECIFICO.getValue().equals(getIndrAlcancContrtoCreddrSub().getValue());
    }

    @Override
    default boolean hasAlcanceGeral() {
        return AlcanceContrato.GERAL.getValue().equals(getIndrAlcancContrtoCreddrSub().getValue());
    }

    @Override
    default boolean isGestaoER() {
        return "S".equals(this.getIndrGestER().getValue());
    }

    @Override
    default boolean isRenegociacao() {
        return this.getListaGrupoRenegcDiv() != null &&
                !this.getListaGrupoRenegcDiv().isEmpty() &&
                this.getListaGrupoRenegcDiv().size() > 0;
    }

}
