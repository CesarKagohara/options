package br.org.cipbancos.rrc.bean.arrc030;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

public class GrupoARRC030ArrajPgto extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CodInstitdrArrajPgto")
    private SPBString codInstitdrArrajPgto;

    public SPBString getCodInstitdrArrajPgto() {
        return codInstitdrArrajPgto;
    }

    public void setCodInstitdrArrajPgto(SPBString codInstitdrArrajPgto) {
        this.codInstitdrArrajPgto = codInstitdrArrajPgto;
    }

}
