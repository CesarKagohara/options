package br.org.cipbancos.rrc.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Set;

public interface OpEntrgRecalclDAO {

    void inserirLote(Set<Long> idsOps, Date dtRef, Long idAtlRootRecalcl);

    void inserir(Long idOp, Date dtRef, Long idAtlRootRecalcl, int qtdFracaoEncontrada, int qtdFracaoConstituida, int qtdFracaoFumaca, int qtdFracaoInserida, int qtdFracaoAtualizada, BigDecimal nrVlrSomaConstituido);

    void atualizar(Long idOp, Date dtRef, Long idAtlRootEntregop);

    List<Long> buscarIdsOpsPorDtRef(Date dtRef);

    List<Long> buscarSeRegistroExiste(Long idOp, Date dtRef, Long idAtlRoot);

}