package br.org.cipbancos.rrc.bean.rrc0019;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoCesAutd;
import org.apache.commons.lang3.builder.ToStringBuilder;

@XStreamAlias("Grupo_RRC0019_CesAutd")
public class GrupoRRC0019CesAutd extends ErrorCodeBean implements GrupoCesAutd {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CPFCesAutd")
    private SPBString cNPJCPFCesAutd;

    public SPBString getCNPJCPFCesAutd() {
        return cNPJCPFCesAutd;
    }

    public void setCNPJCPFCesAutd(SPBString cNPJCPFCesAutd) {
        this.cNPJCPFCesAutd = cNPJCPFCesAutd;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("cNPJCPFCesAutd", cNPJCPFCesAutd)
                .toString();
    }
}
