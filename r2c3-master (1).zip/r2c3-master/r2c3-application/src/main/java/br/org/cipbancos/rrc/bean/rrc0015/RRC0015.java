package br.org.cipbancos.rrc.bean.rrc0015;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDateTime;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("RRC0015")
public class RRC0015 extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CodMsg")
    private SPBString codMsg;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamAlias("DtHrAbert")
    private SPBLocalDateTime dtHrAbert;

    @XStreamAlias("DtHrER")
    private SPBLocalDateTime dtHrER;

    @XStreamAlias("DtRef")
    private SPBLocalDate dtRef;

    public SPBString getCodMsg() {
        return codMsg;
    }

    public void setCodMsg(SPBString codMsg) {
        this.codMsg = codMsg;
    }

    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public SPBLocalDateTime getDtHrAbert() {
        return dtHrAbert;
    }

    public void setDtHrAbert(SPBLocalDateTime dtHrAbert) {
        this.dtHrAbert = dtHrAbert;
    }

    public SPBLocalDateTime getDtHrER() {
        return dtHrER;
    }

    public void setDtHrER(SPBLocalDateTime dtHrER) {
        this.dtHrER = dtHrER;
    }

    public SPBLocalDate getDtRef() {
        return dtRef;
    }

    public void setDtRef(SPBLocalDate dtRef) {
        this.dtRef = dtRef;
    }
}
