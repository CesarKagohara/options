package br.org.cipbancos.rrc.bean.rrc0021;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("RRC0021R1")
public class RRC0021R1 extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CodMsg")
    private SPBString codMsg;

    @XStreamAlias("SitRetReq")
    private SPBString sitRetReq;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0021R1_NegcRecbvl")
    private List<GrupoRRC0021R1NegcRecbvl> listagrupoRRC0021R1NegcRecbvl = new ArrayList<GrupoRRC0021R1NegcRecbvl>();

    public SPBString getCodMsg() {
        return codMsg;
    }

    public void setCodMsg(SPBString codMsg) {
        this.codMsg = codMsg;
    }

    public SPBString getSitRetReq() {
        return sitRetReq;
    }

    public void setSitRetReq(SPBString sitRetReq) {
        this.sitRetReq = sitRetReq;
    }

    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public List<GrupoRRC0021R1NegcRecbvl> getListagrupoRRC0021R1NegcRecbvl() {
        return listagrupoRRC0021R1NegcRecbvl;
    }

    public void setListagrupoRRC0021R1NegcRecbvl(List<GrupoRRC0021R1NegcRecbvl> listagrupoRRC0021R1NegcRecbvl) {
        this.listagrupoRRC0021R1NegcRecbvl = listagrupoRRC0021R1NegcRecbvl;
    }

}
