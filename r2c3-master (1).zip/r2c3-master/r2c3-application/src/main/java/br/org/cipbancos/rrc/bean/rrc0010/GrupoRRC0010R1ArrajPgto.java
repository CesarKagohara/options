package br.org.cipbancos.rrc.bean.rrc0010;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_RRC0010R1_ArrajPgto")
public class GrupoRRC0010R1ArrajPgto extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CodInstitdrArrajPgto")
    private SPBString codInstitdrArrajPgto;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0010R1_UsuFinalRecbdr")
    private List<GrupoRRC0010R1UsuFinalRecbdr> listagrupoRRC0010R1UsuFinalRecbdr = new ArrayList<GrupoRRC0010R1UsuFinalRecbdr>();

    @XStreamImplicit(itemFieldName = "Grupo_RRC0010_Titlar")
    private List<GrupoRRC0010R1Titlar> listagrupoRRC0010Titlar = new ArrayList<GrupoRRC0010R1Titlar>();

    public SPBString getCodInstitdrArrajPgto() {
        return codInstitdrArrajPgto;
    }

    public void setCodInstitdrArrajPgto(SPBString codInstitdrArrajPgto) {
        this.codInstitdrArrajPgto = codInstitdrArrajPgto;
    }

    public List<GrupoRRC0010R1UsuFinalRecbdr> getListagrupoRRC0010R1UsuFinalRecbdr() {
        return listagrupoRRC0010R1UsuFinalRecbdr;
    }

    public void setListagrupoRRC0010R1UsuFinalRecbdr(List<GrupoRRC0010R1UsuFinalRecbdr> listagrupoRRC0010R1UsuFinalRecbdr) {
        this.listagrupoRRC0010R1UsuFinalRecbdr = listagrupoRRC0010R1UsuFinalRecbdr;
    }

    public List<GrupoRRC0010R1Titlar> getListagrupoRRC0010Titlar() {
        return listagrupoRRC0010Titlar;
    }

    public void setListagrupoRRC0010Titlar(List<GrupoRRC0010R1Titlar> listagrupoRRC0010Titlar) {
        this.listagrupoRRC0010Titlar = listagrupoRRC0010Titlar;
    }

}
