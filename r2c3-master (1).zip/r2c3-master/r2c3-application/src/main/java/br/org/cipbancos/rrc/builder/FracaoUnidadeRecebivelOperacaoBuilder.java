package br.org.cipbancos.rrc.builder;

import br.org.cipbancos.rrc.vo.FracaoUnidadeRecebivelOperacao;
import br.org.cipbancos.rrc.vo.UnidadeRecebivel;
import org.joda.time.DateTime;

public class FracaoUnidadeRecebivelOperacaoBuilder {

    private FracaoUnidadeRecebivelOperacao fracaoUnidadeRecebivel;

    public static FracaoUnidadeRecebivelOperacaoBuilder newFumacaBuilder() {
        FracaoUnidadeRecebivelOperacaoBuilder builder = new FracaoUnidadeRecebivelOperacaoBuilder();
        builder.fracaoUnidadeRecebivel.setIcContr("S");
        return builder;
    }

    public FracaoUnidadeRecebivelOperacaoBuilder() {
        fracaoUnidadeRecebivel = new FracaoUnidadeRecebivelOperacao();
        fracaoUnidadeRecebivel.setDhIncl(DateTime.now());
        fracaoUnidadeRecebivel.setDhUltAlt(DateTime.now());
        fracaoUnidadeRecebivel.setIcSit("A");
    }

    public FracaoUnidadeRecebivelOperacaoBuilder withUR(UnidadeRecebivel ur) {
        fracaoUnidadeRecebivel.setNrVlrTot(ur.getNrVlrTot());
        fracaoUnidadeRecebivel.setCdIspbBcoRecbdr(ur.getCdIspbBcoRecbdr());
        fracaoUnidadeRecebivel.setCanal(ur.getCanal());
        fracaoUnidadeRecebivel.setCdArrjPgto(ur.getCdArrjPgto());
        fracaoUnidadeRecebivel.setDtAntec(ur.getDtAntec());
        fracaoUnidadeRecebivel.setDtPrevtLiquid(ur.getDtPrevtLiqui());
        fracaoUnidadeRecebivel.setIcTpCt(ur.getTipoConta());
        fracaoUnidadeRecebivel.setIdFuncdd(ur.getIdFuncdd()); //duvida: o que é esse campo
        fracaoUnidadeRecebivel.setIdIntrdd(ur.getIdIntrdd()); //duvida: o que é esse campo
        fracaoUnidadeRecebivel.setIdPartAdmtd(ur.getIdPartAdmtd());
        fracaoUnidadeRecebivel.setIdPartOrigdr(ur.getIdPartOrigdr());
        fracaoUnidadeRecebivel.setIdPartPrincipal(ur.getIdPartPrincipal());
        fracaoUnidadeRecebivel.setIdUniddRecbv(ur.getIdUniddRecbv());
        fracaoUnidadeRecebivel.setNrCpfCnpjUsurioFinlRecbdr(ur.getNrCpfCnpjUsurioFinlRecbdr());
        fracaoUnidadeRecebivel.setNrVlAntecNRegtd(ur.getNrVlAntecNRegtd());
        fracaoUnidadeRecebivel.setNrVlrPrevtPreconttd(ur.getNrVlrPrevtPreconttd());
//        fracaoUnidadeRecebivel.setDtEftLiquidc();
//        fracaoUnidadeRecebivel.setDtRefSistIncl();
//        fracaoUnidadeRecebivel.setDtRefSistUltAlt();
//        fracaoUnidadeRecebivel.setFuncdd();
//        fracaoUnidadeRecebivel.setIdAtlRoot();
//        fracaoUnidadeRecebivel.setIdOp();
//        fracaoUnidadeRecebivel.setIdOpSusps();
//        fracaoUnidadeRecebivel.setNegociada();
//        fracaoUnidadeRecebivel.setNmArqNuopApi();
//        fracaoUnidadeRecebivel.setNrVlrEftLiquid();
//        fracaoUnidadeRecebivel.setNrVlrPrevtLiquid();
//        fracaoUnidadeRecebivel.setOperacao();

        //duvida : muda com cessao?
        fracaoUnidadeRecebivel.setNrAg(ur.getAgencia());
        fracaoUnidadeRecebivel.setNrCnpjCreddr(ur.getNrCnpjCreddr());
        fracaoUnidadeRecebivel.setNrCnpjRegtdr(ur.getNrCnpjRegtdr());
        fracaoUnidadeRecebivel.setNrCpfCnpjTitlar(ur.getNrCpfCnpjTitlar());
        fracaoUnidadeRecebivel.setNrCpfCnpjTitlarCt(ur.getNrCpfCnpjTitlarCt());
        fracaoUnidadeRecebivel.setNrCt(ur.getConta());
        fracaoUnidadeRecebivel.setNrCtPgto(ur.getContaPagamento());
        //duvida : muda com cessao?
        return this;
    }

    public FracaoUnidadeRecebivelOperacaoBuilder nrPridd(Integer nrPridd) {
        fracaoUnidadeRecebivel.setNrPridd(nrPridd);
        return this;
    }

    public FracaoUnidadeRecebivelOperacao build() {
        return fracaoUnidadeRecebivel;
    }
}
