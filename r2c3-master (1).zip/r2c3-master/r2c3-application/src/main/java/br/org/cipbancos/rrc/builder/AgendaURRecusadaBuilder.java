package br.org.cipbancos.rrc.builder;

import java.util.List;

import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001DomclBanc;
import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001UniddRecbvl;
import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001UniddRecbvlRecsdo;
import br.org.cipbancos.rrc.converter.DomicilioBancarioConverter;
import br.org.cipbancos.rrc.converter.UnidadeRecebivelArquivoConverter;

/**
 * Classe responsável por montar a estrutura de uma Unidade Recebível Recusada no arquivo RET.
 *
 * @author otavio.ferreira
 * @since 1.0
 */
public class AgendaURRecusadaBuilder {

    private GrupoARRC001UniddRecbvlRecsdo urRecusada;

    /**
     * Monta a estrutura basica da Unidade Recebível Recusada.
     *
     * @param unidade Unidade Recebível que veio na entrada.
     */
    public AgendaURRecusadaBuilder montaURRecusada(GrupoARRC001UniddRecbvl unidade) {
        urRecusada = UnidadeRecebivelArquivoConverter.emUnidadeRecebivelRecusada().convert(unidade);

        if (unidade.hasErrorCode())
            urRecusada.setCodErro(unidade.getErrorCode());

        return this;
    }

    /**
     * Monta a estrutura do Grupo Domicilio Bancário Recusado
     *
     * @param domiciliosRecusados Lista de Domicilios Bancarios recusados.
     */
    public AgendaURRecusadaBuilder comGrupoDomicilioBancarioRecusado(List<GrupoARRC001DomclBanc> domiciliosRecusados) {
        if (null != urRecusada) {
            domiciliosRecusados.forEach(domicilio ->
                urRecusada.getListagrupoARRC001DomclBancRecsdo().add(
                        DomicilioBancarioConverter.emDomicilioBancarioRecusado().convert(domicilio))
            );
        }

        return this;
    }

    /**
     * Constroi e retona a UR que foi montada nas chamadas anteriores.
     *
     * @return Uma nova Unidade Recebível recusada.
     */
    public GrupoARRC001UniddRecbvlRecsdo build() {
        return urRecusada;
    }
}
