package br.org.cipbancos.rrc.builder;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import br.org.cipbancos.rrc.util.CpfCnpjUtil;
import br.org.cipbancos.rrc.util.DateUtil;
import br.org.cipbancos.rrc.vo.AutorizacaoEnvioAgenda;

import br.org.cip.api.r2c3.model.AnuenciaOptInInputDTO;



public class AnuenciaOptInInputDTOBuilder {

    private AnuenciaOptInInputDTO anuenciaOptInInputDTO;

    private AnuenciaOptInInputDTOBuilder(){
        this.anuenciaOptInInputDTO = new AnuenciaOptInInputDTO();
    }

    public static AnuenciaOptInInputDTOBuilder builder(){
        return new AnuenciaOptInInputDTOBuilder();
    }

    public AnuenciaOptInInputDTOBuilder createAnuenciaOptInParaCentralizadora(AutorizacaoEnvioAgenda autorizacaoEnvioAgenda,
            String codArranjoInterop){
        anuenciaOptInInputDTO.setArranjoPagamentoId(codArranjoInterop);
        anuenciaOptInInputDTO.setCnpjCredenciadora(autorizacaoEnvioAgenda.getCnpjCredenciadorSubCredenciador());
        anuenciaOptInInputDTO.setDocumentoUsuarioFinalRecebedorOuTitular(autorizacaoEnvioAgenda.getDocumentoUsuarioFinalRecebedor());
        anuenciaOptInInputDTO.setStatus(AnuenciaOptInInputDTO.StatusEnum.ATIVO);
        anuenciaOptInInputDTO.setTipo(AnuenciaOptInInputDTO.TipoEnum.OPTIN);
        anuenciaOptInInputDTO.setTipoDocumentoUsuarioFinalRecebedorOuTitular(
                getTipoDocumentoUsuarioFinalRecebedorOuTitular(autorizacaoEnvioAgenda.getDocumentoUsuarioFinalRecebedor()));
        anuenciaOptInInputDTO.setDataInicio(DateUtil.convertDateTime(autorizacaoEnvioAgenda.getDataInicioOptIn()));
        anuenciaOptInInputDTO.setDataFim(DateUtil.convertDateTime(autorizacaoEnvioAgenda.getDataFimOptIn()).replace("00:00:00.000", "23:59:59.999"));
        if (StringUtils.isNotEmpty(autorizacaoEnvioAgenda.getCnpjFinanceira())) {
            anuenciaOptInInputDTO.setTipoDocumentoCredor(autorizacaoEnvioAgenda.getCnpjFinanceira().length() > 11 ?
                    AnuenciaOptInInputDTO.TipoDocumentoCredorEnum.CNPJ : AnuenciaOptInInputDTO.TipoDocumentoCredorEnum.CPF);
            anuenciaOptInInputDTO.setDocumentoCredor(autorizacaoEnvioAgenda.getCnpjFinanceira());
        }
        return this;
    }

    private AnuenciaOptInInputDTO.TipoDocumentoUsuarioFinalRecebedorOuTitularEnum
        getTipoDocumentoUsuarioFinalRecebedorOuTitular(String documentoUsuarioFinalRecebedor){
        Integer cpfOuCnpjOuBase = CpfCnpjUtil.isCpfOuCnpjOuBase(documentoUsuarioFinalRecebedor);

        return cpfOuCnpjOuBase == 1 ?
                AnuenciaOptInInputDTO.TipoDocumentoUsuarioFinalRecebedorOuTitularEnum.CPF :
                AnuenciaOptInInputDTO.TipoDocumentoUsuarioFinalRecebedorOuTitularEnum.CNPJ;
    }

    public List<AnuenciaOptInInputDTO> build(){
        return Arrays.asList(anuenciaOptInInputDTO);
    }
}