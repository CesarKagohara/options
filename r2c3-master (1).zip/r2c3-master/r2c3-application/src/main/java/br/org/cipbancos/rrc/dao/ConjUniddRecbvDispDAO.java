package br.org.cipbancos.rrc.dao;

import java.util.List;

import br.org.cipbancos.rrc.vo.UnidadeRecebivel;

import br.org.cip.api.r2c3.model.UnidadeRecebivelDisponivelCredenciadora;
import br.org.cip.api.r2c3.model.UnidadeRecebivelDisponivelFinanciadora;

public interface ConjUniddRecbvDispDAO {

    Long inserir(String identPartAdmtd, List<UnidadeRecebivel> urs);

    List<UnidadeRecebivelDisponivelCredenciadora> buscarUnidadeRecebivelDisponivelCredenciadoraPorId(String identPartAdmtd, Long id);

    List<UnidadeRecebivelDisponivelFinanciadora> buscarUnidadeRecebivelDisponivelFinanciadoraPorId(String identPartAdmtd, Long id);
    List<UnidadeRecebivelDisponivelFinanciadora> buscarUnidadeRecebivelDisponivelFinanciadoraPorId(String identPartAdmtd, Long id, Integer numeroPagina, Integer tamanhoPagina);

}