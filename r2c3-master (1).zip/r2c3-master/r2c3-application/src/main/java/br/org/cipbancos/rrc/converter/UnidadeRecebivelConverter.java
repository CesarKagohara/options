package br.org.cipbancos.rrc.converter;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBInteger;
import br.org.cipbancos.rrc.bean.GrupoRegRecbvl;
import br.org.cipbancos.rrc.bean.GrupoRegRecbvl0005;
import br.org.cipbancos.rrc.bean.GrupoRegRecbvl0019;
import br.org.cipbancos.rrc.bean.arrc022.GrupoARRC022RETRegRecbvl;
import br.org.cipbancos.rrc.bean.rrc0005.GrupoRRC0005R1Constitr;
import br.org.cipbancos.rrc.bean.rrc0005.GrupoRRC0005R1RegRecbvl;
import br.org.cipbancos.rrc.bean.rrc0005.GrupoRRC0005R1UniddRecbvlDisp;
import br.org.cipbancos.rrc.bean.rrc0010.GrupoRRC0010UniddRecbvl;
import br.org.cipbancos.rrc.bean.rrc0012.GrupoRRC0012RegRecbvl;
import br.org.cipbancos.rrc.bean.rrc0019.GrupoRRC0019R1Constitr;
import br.org.cipbancos.rrc.bean.rrc0019.GrupoRRC0019R1RegRecbvl;
import br.org.cipbancos.rrc.bean.rrc0019.GrupoRRC0019R1UniddRecbvlDisp;
import br.org.cipbancos.rrc.enums.RegraDivisao;
import br.org.cipbancos.rrc.funcional.Converter;
import br.org.cipbancos.rrc.util.CpfCnpjUtil;
import br.org.cipbancos.rrc.vo.*;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Classe utilitária para converter informações de Unidades Recebíveis de entrada para realizar,
 * inserções no BD e conversões de Entrada para Retorno.
 *
 * @author anderson.martins
 * @since 1.0
 */
public class UnidadeRecebivelConverter {

    private UnidadeRecebivelConverter() {
    }

    /**
     * Popula os parametros utilizados para inserir um unidd_recbv no BD.
     *
     * @return Um conjunto de parametros para setar as informações no ElSql.
     */
    public static Converter<UnidadeRecebivel, MapSqlParameterSource> emUnidadeRecebivelParaInsercao() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();

            populaChavePrimaria(origem, parametros);

            populaUnidadeRecebivel(origem, parametros);

            parametros.addValue("dhIncl", new java.sql.Timestamp(new Date().getTime()));
            parametros.addValue("dtRefSistUltAlt", new java.sql.Timestamp(new Date().getTime()));

            return parametros;
        };
    }

    /**
     * Popula os parametros utilizados para inserir um unidd_recbv no BD.
     *
     * @return Um conjunto de parametros para setar as informações no ElSql.
     */
    public static Converter<UnidadeRecebivel, MapSqlParameterSource> emUnidadeRecebivelParaAtualizacao() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();

            populaChavePrimaria(origem, parametros);

            populaUnidadeRecebivel(origem, parametros);

            parametros.addValue("dhUltAlt", new java.sql.Timestamp(new Date().getTime()));

            return parametros;
        };
    }

    /**
     * Popula os parametros utilizados para inserir um unidd_recbv no BD.
     *
     * @return Um conjunto de parametros para setar as informações no ElSql.
     */
    public static Converter<UnidadeRecebivel, MapSqlParameterSource> emUnidadeRecebivelParaConsulta() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();

            populaChavePrimaria(origem, parametros);

            if (origem.getNrCpfCnpjTitlar() != null) {
                parametros.addValue("nrCpfCnpjTitlar", origem.getNrCpfCnpjTitlar());
            }
            if (origem.getNrVlrLivreTot() != null) {
                parametros.addValue("nrVlrLivreTot", origem.getNrVlrLivreTot());
            }

            parametros.addValue("dtPrevtLiquiIni",
                    (origem.getDtPrevtLiquiIni() == null || origem.getDtPrevtLiquiFim() == null) ?
                            origem.getDtPrevtLiqui() : origem.getDtPrevtLiquiIni());
            parametros.addValue("dtPrevtLiquiFim",
                    (origem.getDtPrevtLiquiIni() == null || origem.getDtPrevtLiquiFim() == null) ?
                            origem.getDtPrevtLiqui() : origem.getDtPrevtLiquiFim());

            return parametros;
        };
    }

    /**
     * Popula a chave primária para a Fracao de Unidade Recebível no BD.
     *
     * @param unidade    Unidade Recebível com os dados da chave primária.
     * @param parametros Cadeia de parametros a serem utilizados no SQL.
     */
    public static void populaChavePrimaria(UnidadeRecebivel unidade, MapSqlParameterSource parametros) {
        parametros.addValue("nrCnpjCreddr", unidade.getNrCnpjCreddr());
        parametros.addValue("nrCpfCnpjUsurioFinlRecbdr", unidade.getNrCpfCnpjUsurioFinlRecbdr());
        parametros.addValue("cdArrjPgto", unidade.getCdArrjPgto());
        parametros.addValue("dtPrevtLiqui", unidade.getDtPrevtLiqui());
        parametros.addValue("dtRefMovto", unidade.getDtRefSistIncl());
        parametros.addValue("nrCpfCnpjTitlar", unidade.getNrCpfCnpjTitlar());
    }

    private static void populaUnidadeRecebivel(UnidadeRecebivel unidade, MapSqlParameterSource parametros) {
        parametros.addValue("nrCnpjRegtdr", unidade.getNrCnpjRegtdr());
        parametros.addValue("nrCpfCnpjTitlar", unidade.getNrCpfCnpjTitlar());
        parametros.addValue("cdIspbBcoRecbdr", unidade.getCdIspbBcoRecbdr());
        parametros.addValue("nrVlrTot", unidade.getNrVlrTot());
        parametros.addValue("nrVlrTotComptd", unidade.getNrVlrTotComptd());
        parametros.addValue("nrVlrLivreTot", unidade.getNrVlrLivreTot());
        parametros.addValue("nrVlrLivreOnus", unidade.getNrVlrLivreOnus());
        parametros.addValue("nrVlrLivreAntec", unidade.getNrVlrLivreAntec());
        parametros.addValue("nrVlrLivreTrocaTitlard", unidade.getNrVlrLivreTrocaTitlard());
        parametros.addValue("nrVlrRes", unidade.getNrVlrRes());
        parametros.addValue("nrVlrPrevtPreconttd", unidade.getNrVlrPrevtPreconttd());

        //Novos Campos
        parametros.addValue("idIntrdd", unidade.getIdIntrdd());
        parametros.addValue("idPartPrincipal", unidade.getIdPartPrincipal());
        parametros.addValue("idPartAdmtd", unidade.getIdPartAdmtd());
        parametros.addValue("idPartOrigdr", unidade.getIdPartAdmtd());
        parametros.addValue("dtRefSistIncl", unidade.getDtRefSistIncl());
        parametros.addValue("dtRefSistUltAlt", unidade.getDtRefSistUltAlt());
        parametros.addValue("idAtlRoot", unidade.getIdAtlRoot());
        parametros.addValue("nmArqNuopApi", unidade.getNmArqNuopApi());
        parametros.addValue("idFuncdd", unidade.getIdFuncdd());
        parametros.addValue("canal", unidade.getCanal());
        parametros.addValue("icSit", unidade.getIcSit());
    }

    /**
     * Converte uma unidade recebivel em uma UR Constituida durante uma negociação.
     */
    public static Converter<UnidadeRecebivel, FracaoConstituidaNegociacao> emUrConstituida(BigDecimal valor) {
        return origem -> {
            FracaoConstituidaNegociacao destino = new FracaoConstituidaNegociacao();

            destino.setPriorddNegcRecbvl(new SPBInteger(origem.getFracoes().size()-1));

            destino.setcNPJCreddrSub(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(origem.getNrCnpjCreddr())));
            destino.setcNPJCPFUsuFinalRecbdr(SPBConverter.stringToSPBString(origem.getNrCpfCnpjUsurioFinlRecbdr()));
            destino.setcNPJCPFTitular(SPBConverter.stringToSPBString(origem.getNrCpfCnpjTitlar()));
            destino.setCodInstitdrArrajPgto(SPBConverter.stringToSPBString(origem.getCdArrjPgto()));
            destino.setDtPrevtLiquid(SPBConverter.dateToSPBLocalDate(origem.getDtPrevtLiqui()));
            destino.setVlrPercNegcd(SPBConverter.stringToSPBBigDecimal(valor.toString()));

            return destino;
        };
    }

    /**
     * Converte uma unidade recebivel em uma UR a constituir durante uma negociação.
     */
    public static Converter<UnidadeRecebivel, FracaoAConstituirNegociacao> emUrAConstituir(RegraDivisao regra, BigDecimal valor) {
        return origem -> {
            FracaoAConstituirNegociacao destino = new FracaoAConstituirNegociacao();

            destino.setPriorddNegcRecbvl(new SPBInteger(origem.getFracoes().size()-1));

            destino.setcNPJCreddrSub(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(origem.getNrCnpjCreddr())));
            destino.setcNPJCPFUsuFinalRecbdr(SPBConverter.stringToSPBString(origem.getNrCpfCnpjUsurioFinlRecbdr()));
            destino.setcNPJCNPJBaseCPFTitlar(SPBConverter.stringToSPBString(origem.getNrCpfCnpjTitlar()));
            destino.setCodInstitdrArrajPgto(SPBConverter.stringToSPBString(origem.getCdArrjPgto()));
            destino.setDtPrevtLiquid(SPBConverter.dateToSPBLocalDate(origem.getDtPrevtLiqui()));
            destino.setVlrPercNegcd(SPBConverter.stringToSPBBigDecimal(valor.toString()));
            destino.setIndrRegrDivs(SPBConverter.stringToSPBString(regra.getRegra()));

            return destino;
        };
    }

    /**
     * Converte uma unidade recebivel em uma UR disponivel para uma negociação.
     */
    public static Converter<UnidadeRecebivel, UnidadeRecebivelDisponivelNegociacao> emUrDisponivel() {
        return origem -> {
            UnidadeRecebivelDisponivelNegociacao destino = new UnidadeRecebivelDisponivelNegociacao();

            destino.setcNPJCreddrSub(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(origem.getNrCnpjCreddr())));
            destino.setcNPJCPFUsuFinalRecbdr(SPBConverter.stringToSPBString(origem.getNrCpfCnpjUsurioFinlRecbdr()));
            destino.setcNPJCPFTitular(SPBConverter.stringToSPBString(origem.getNrCpfCnpjTitlar()));
            destino.setCodInstitdrArrajPgto(SPBConverter.stringToSPBString(origem.getCdArrjPgto()));
            destino.setDtPrevtLiquid(SPBConverter.dateToSPBLocalDate(origem.getDtPrevtLiqui()));
            destino.setVlrTot(SPBConverter.stringToSPBBigDecimal(origem.getNrVlrTot().toString()));
            destino.setVlrLivreTot(SPBConverter.stringToSPBBigDecimal(origem.getNrVlrLivreTot().toString()));
            destino.setVlrPreContrd(SPBConverter.stringToSPBBigDecimal(origem.getNrVlrTotComptd().toString()));

            return destino;
        };
    }

    /**
     * Converte uma unidade recebivel constituida em uma UR constituida para o R1.
     */
    public static Converter<FracaoConstituidaNegociacao, GrupoRRC0019R1RegRecbvl> emURConstituida019R1() {
        return origem -> {
            GrupoRRC0019R1RegRecbvl destino = new GrupoRRC0019R1RegRecbvl();

            destino.setCNPJCreddrSub(origem.getcNPJCreddrSub());
            destino.setVlrNegcd(origem.getVlrPercNegcd());
            destino.setPriorddNegcRecbvl(origem.getPriorddNegcRecbvl());
            destino.setCodInstitdrArrajPgto(origem.getCodInstitdrArrajPgto());
            destino.setCNPJCPFUsuFinalRecbdr(origem.getcNPJCPFUsuFinalRecbdr());
            destino.setCNPJCPFTitular(origem.getcNPJCPFTitular());
            destino.setDtPrevtLiquid(origem.getDtPrevtLiquid());

            return destino;
        };
    }

    /**
     * Converte uma unidade recebivel constituida em uma UR constituida para o RET.
     */
    public static Converter<FracaoConstituidaNegociacao, GrupoARRC022RETRegRecbvl> emURConstituida022() {
        return origem -> {
            GrupoARRC022RETRegRecbvl destino = new GrupoARRC022RETRegRecbvl();

            destino.setVlrNegcd(origem.getVlrPercNegcd());
            destino.setCodInstitdrArrajPgto(origem.getCodInstitdrArrajPgto());
            destino.setcNPJCPFUsuFinalRecbdr(origem.getcNPJCPFUsuFinalRecbdr());
            destino.setcNPJCPFTitular(origem.getcNPJCPFTitular());
            destino.setDtPrevtLiquid(origem.getDtPrevtLiquid());

            return destino;
        };
    }

    /**
     * Converte uma unidade recebivel constituida em uma UR a constituir para o R1.
     */
    public static Converter<FracaoAConstituirNegociacao, GrupoRRC0019R1Constitr> emURAConstituir019R1() {
        return origem -> {
            GrupoRRC0019R1Constitr destino = new GrupoRRC0019R1Constitr();

            destino.setCNPJCreddrSub(origem.getcNPJCreddrSub());
            destino.setVlrPercNegcd(origem.getVlrPercNegcd());
            destino.setPriorddNegcRecbvl(origem.getPriorddNegcRecbvl());
            destino.setCodInstitdrArrajPgto(origem.getCodInstitdrArrajPgto());
            destino.setCNPJCPFUsuFinalRecbdr(origem.getcNPJCPFUsuFinalRecbdr());
            destino.setDtPrevtLiquid(origem.getDtPrevtLiquid());
            destino.setIndrRegrDivs(origem.getIndrRegrDivs());
            destino.setCNPJCNPJBaseCPFTitlar(origem.getcNPJCNPJBaseCPFTitlar());

            return destino;
        };
    }

    /**
     * Converte uma unidade recebivel constituida em uma UR disponivel para o R1.
     */
    public static Converter<UnidadeRecebivelDisponivelNegociacao, GrupoRRC0019R1UniddRecbvlDisp> emURDisponivel019R1() {
        return origem -> {
            GrupoRRC0019R1UniddRecbvlDisp destino = new GrupoRRC0019R1UniddRecbvlDisp();

            destino.setCodInstitdrArrajPgto(origem.getCodInstitdrArrajPgto());
            destino.setcNPJCreddrSub(origem.getcNPJCreddrSub());
            destino.setcNPJCPFUsuFinalRecbdr(origem.getcNPJCPFUsuFinalRecbdr());
            destino.setDtPrevtLiquid(origem.getDtPrevtLiquid());
            destino.setVlrTot(origem.getVlrTot());
            destino.setVlrPreContrd(origem.getVlrPreContrd());
            destino.setVlrOnusResTec(origem.getVlrOnusResTec());
            destino.setVlrLivreTot(origem.getVlrLivreTot());
            destino.setVlrLivreAntecCreddrSub(origem.getVlrLivreAntecCreddrSub());
            destino.setcNPJCPFTitular(origem.getcNPJCPFTitular());

            if (origem.hasErrorCode())
                destino.setErrorCode(origem.getErrorCode());

            return destino;
        };
    }

    /**
     * Converte uma unidade recebivel constituida em uma UR constituida para o R1.
     */
    public static Converter<FracaoConstituidaNegociacao, GrupoRRC0005R1RegRecbvl> emURConstituida005R1() {
        return origem -> {
            GrupoRRC0005R1RegRecbvl destino = new GrupoRRC0005R1RegRecbvl();

            destino.setVlrNegcd(origem.getVlrPercNegcd());
            destino.setPriorddNegcRecbvl(origem.getPriorddNegcRecbvl());
            destino.setCodInstitdrArrajPgto(origem.getCodInstitdrArrajPgto());
            destino.setcNPJCPFUsuFinalRecbdr(origem.getcNPJCPFUsuFinalRecbdr());
            destino.setcNPJCPFTitular(SPBConverter
                    .stringToSPBString(CpfCnpjUtil.formataCnpj(origem.getcNPJCPFTitular().getValue())));
            destino.setDtPrevtLiquid(origem.getDtPrevtLiquid());

            return destino;
        };
    }

    /**
     * Converte uma unidade recebivel constituida em uma UR a constituir para o R1.
     */
    public static Converter<FracaoAConstituirNegociacao, GrupoRRC0005R1Constitr> emURAConstituir005R1() {
        return origem -> {
            GrupoRRC0005R1Constitr destino = new GrupoRRC0005R1Constitr();

            destino.setcNPJCNPJBaseCPFTitlar(SPBConverter
                    .stringToSPBString(CpfCnpjUtil.formataCnpj(origem.getcNPJCNPJBaseCPFTitlar().getValue())));
            destino.setcNPJCNPJBaseCPFUsuFinalRecbdr(origem.getcNPJCPFUsuFinalRecbdr());
            destino.setVlrPercNegcd(origem.getVlrPercNegcd());
            destino.setPriorddNegcRecbvl(origem.getPriorddNegcRecbvl());
            destino.setCodInstitdrArrajPgto(origem.getCodInstitdrArrajPgto());
            destino.setDtPrevtLiquid(origem.getDtPrevtLiquid());
            destino.setIndrRegrDivs(origem.getIndrRegrDivs());

            return destino;
        };
    }

    /**
     * Converte uma unidade recebivel constituida em uma UR disponivel para o R1.
     */
    public static Converter<UnidadeRecebivelDisponivelNegociacao, GrupoRRC0005R1UniddRecbvlDisp> emURDisponivel005R1() {
        return origem -> {
            GrupoRRC0005R1UniddRecbvlDisp destino = new GrupoRRC0005R1UniddRecbvlDisp();

            destino.setcNPJCPFTitular(SPBConverter
                    .stringToSPBString(CpfCnpjUtil.formataCnpj(origem.getcNPJCPFTitular().getValue())));
            destino.setcNPJCreddrSub(SPBConverter
                    .stringToSPBString(CpfCnpjUtil.formataCnpj(origem.getcNPJCreddrSub().getValue())));
            destino.setCodInstitdrArrajPgto(origem.getCodInstitdrArrajPgto());
            destino.setcNPJCPFUsuFinalRecbdr(SPBConverter
                    .stringToSPBString(CpfCnpjUtil.formataCnpj(origem.getcNPJCPFUsuFinalRecbdr().getValue())));
            destino.setDtPrevtLiquid(origem.getDtPrevtLiquid());
            destino.setVlrTot(origem.getVlrTot());
            destino.setVlrPreContrd(origem.getVlrPreContrd());
            destino.setVlrOnusResTec(null != origem.getVlrOnusResTec() ?
                    new SPBBigDecimal(BigDecimal.ZERO) : origem.getVlrOnusResTec());
            destino.setVlrLivreTot(origem.getVlrLivreTot());
            destino.setVlrLivreAntecCreddrSub(null != origem.getVlrLivreAntecCreddrSub() ?
                    new SPBBigDecimal(BigDecimal.ZERO) : origem.getVlrLivreAntecCreddrSub());

            if (origem.hasErrorCode())
                destino.setErrorCode(origem.getErrorCode());

            return destino;
        };
    }

    /**
     * Converte uma Unidade Recebível
     */
    public static Converter<GrupoRRC0012RegRecbvl, UnidadeRecebivel> deRRC0012ParaInsercao() {
        return origem -> {

            UnidadeRecebivel destino = new UnidadeRecebivel();

            destino.setNrCnpjCreddr(origem.getcNPJCreddrSub().getValue());
            destino.setNrCpfCnpjTitlar(origem.getcNPJCPFTitular().getValue());
            destino.setNrCpfCnpjUsurioFinlRecbdr(origem.getcNPJCPFUsuFinalRecbdr().getValue());
            destino.setCdArrjPgto(origem.getCodInstitdrArrajPgto().getValue());
            destino.setDtPrevtLiqui(new java.sql.Date(origem.getDtPrevtLiquid().getValue().toDate().getTime()));
            destino.setNrVlrTot(origem.getVlrDescst().getValue());

            return destino;
        };
    }

    /**
     * Converte um RegistroRecebivelDomicilioTitularGestaoParticipante em um UnidadeRecebivelNegociacao.
     */
    public static Converter<GrupoRegRecbvl, UnidadeRecebivelNegociacao> emUnidadeRecebivelNegociacao() {
        return origem -> {
            UnidadeRecebivelNegociacao destino = new UnidadeRecebivelNegociacao();
            if (origem instanceof GrupoRegRecbvl0019) {
                destino.setcNPJCreddrSub(((GrupoRegRecbvl0019)origem).getCNPJCreddrSub());
            }
            destino.setcNPJCPFTitular(origem.getCNPJCPFTitular());
            destino.setcNPJCPFUsuFinalRecbdr(origem.getCNPJCPFUsuFinalRecbdr());
            destino.setCodInstitdrArrajPgto(origem.getCodInstitdrArrajPgto());
            destino.setDtPrevtLiquid(origem.getDtPrevtLiquid());
            destino.setVlrPercNegcd(origem.getVlrPercNegcd());

            if(origem instanceof GrupoRegRecbvl0005) {
                destino.setVlrAntecNRegtd(((GrupoRegRecbvl0005)origem).getVlrAntecNRegtd());
                destino.setDtAntec(((GrupoRegRecbvl0005)origem).getDtAntec());
                destino.setVlrEftLiquidAntec(((GrupoRegRecbvl0005)origem).getVlrEftLiquidAntec());
            }

            return destino;
        };
    }

    /**
     * Converte um TitularGestaoRegistradora em um UnidadeRecebivelNegociacao.
     */
//    public static Converter<TitularGestaoRegistradora, UnidadeRecebivelNegociacao> deTitularGestRegParaURNegociacao() {
//        return origem -> {
//            UnidadeRecebivelNegociacao destino = new UnidadeRecebivelNegociacao();
//            origem.getCredenciadoras().forEach(item -> destino.setcNPJCreddrSub(item.getCnpjCreddSub()));
//            origem.getArranjos().forEach(item -> destino.setCodInstitdrArrajPgto(item.getCodInstitdrArrjPgto()));
//            origem.getUsuariosFinais().forEach(item ->
//                    destino.setcNPJCPFUsuFinalRecbdr(item.getCnpjCnpjBaseCpfUsuFinalRecbdr()));
//            destino.setcNPJCPFTitular(origem.getCnpjCnpjBaseCpfTitlar());
//            return destino;
//        };
//    }

    public static Converter<GrupoRRC0010UniddRecbvl, UnidadeRecebivel> deRRC0010ParaConsulta() {
        return origem -> {
            UnidadeRecebivel destino = new UnidadeRecebivel();
            destino.setNrCpfCnpjUsurioFinlRecbdr((origem.getCNPJCNPJBaseCPFUsuFinalRecbdr() != null
                    && !origem.getCNPJCNPJBaseCPFUsuFinalRecbdr().getValue().isEmpty()) ?
                    origem.getCNPJCNPJBaseCPFUsuFinalRecbdr().getValue() : null);
            destino.setCdArrjPgto((origem.getCodInstitdrArrajPgto() != null) ?
                    origem.getCodInstitdrArrajPgto().getValue() : null);
            destino.setNrCnpjCreddr((origem.getCNPJCreddrSub() != null
                    && !origem.getCNPJCreddrSub().getValue().isEmpty()) ?
                    origem.getCNPJCreddrSub().getValue() : null);
            destino.setDtPrevtLiqui((origem.getDtPrevtLiquid() != null) ?
                    new java.sql.Date(origem.getDtPrevtLiquid().getValue().toDate().getTime()) : null);
            destino.setNrVlrLivreTot((origem.getVlrLivre() != null) ?
                    origem.getVlrLivre().getValue() : null);
            destino.setDtPrevtLiquiIni((origem.getDtIniPrevtLiquid() != null) ?
                    new java.sql.Date(origem.getDtIniPrevtLiquid().getValue().toDate().getTime()) : null);
            destino.setDtPrevtLiquiFim((origem.getDtFimPrevtLiquid() != null) ?
                    new java.sql.Date(origem.getDtFimPrevtLiquid().getValue().toDate().getTime()) : null);
            destino.setNrCpfCnpjTitlar((origem.getCNPJCNPJBaseCPFTitlar() != null
                    && !origem.getCNPJCNPJBaseCPFTitlar().getValue().isEmpty()) ?
                    origem.getCNPJCNPJBaseCPFTitlar().getValue() : null);
            return destino;
        };
    }
}
