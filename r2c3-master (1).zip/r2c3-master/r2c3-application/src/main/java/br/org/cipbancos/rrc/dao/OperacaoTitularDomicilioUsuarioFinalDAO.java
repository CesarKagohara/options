package br.org.cipbancos.rrc.dao;

/**
 * Classe responsável por toda a manipulação de dados da tabela OP.
 */

import br.org.cipbancos.rrc.vo.Operacao;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilio;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilioUsuarioFinal;

import java.util.List;

public interface OperacaoTitularDomicilioUsuarioFinalDAO {

    void inserir(OperacaoTitularDomicilioUsuarioFinal operacaoTitularDomicilio);

    OperacaoTitularDomicilioUsuarioFinal buscarPorOperacaoEUsuarioFinal(Operacao operacao, String usuarioFinal);

    List<String> buscarNrCpfCnpjUsurioFinlRecbr(Long idOp);

    List<OperacaoTitularDomicilioUsuarioFinal> buscar(OperacaoTitularDomicilio operacaoTitularDomicilio);

    void remover(OperacaoTitularDomicilio operacaoTitularDomicilio, Operacao operacao, String usuFinal);

    List<OperacaoTitularDomicilioUsuarioFinal> buscar(List<OperacaoTitularDomicilio> operacoes);

    void inativarUsuariosFinaisPorIdOp(Long idOp);
}
