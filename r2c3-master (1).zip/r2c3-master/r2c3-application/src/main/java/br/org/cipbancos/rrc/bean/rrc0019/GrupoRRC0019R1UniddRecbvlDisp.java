package br.org.cipbancos.rrc.bean.rrc0019;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_RRC0019R1_UniddRecbvlDisp")
public class GrupoRRC0019R1UniddRecbvlDisp extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJCreddrSub")
    private SPBString cNPJCreddrSub;

    @XStreamAlias("CNPJ_CPFUsuFinalRecbdr")
    private SPBString cNPJCPFUsuFinalRecbdr;

    @XStreamAlias("CNPJ_CPFTitular")
    private SPBString cNPJCPFTitular;

    @XStreamAlias("CodInstitdrArrajPgto")
    private SPBString codInstitdrArrajPgto;

    @XStreamAlias("DtPrevtLiquid")
    private SPBLocalDate dtPrevtLiquid;

    @XStreamAlias("VlrTot")
    private SPBBigDecimal vlrTot;

    @XStreamAlias("VlrComprtdOutrInst")
    private SPBBigDecimal vlrComprtdOutrInst;

    @XStreamAlias("VlrComprtdInst")
    private SPBBigDecimal vlrComprtdInst;

    @XStreamAlias("VlrLivreTot")
    private SPBBigDecimal vlrLivreTot;

    @XStreamAlias("VlrLivreAntecCreddrSub")
    private SPBBigDecimal vlrLivreAntecCreddrSub;

    @XStreamAlias("VlrPreContrd")
    private SPBBigDecimal vlrPreContrd;

    @XStreamAlias("VlrOnusResTec")
    private SPBBigDecimal vlrOnusResTec;

    public SPBString getcNPJCreddrSub() {
        return cNPJCreddrSub;
    }

    public void setcNPJCreddrSub(SPBString cNPJCreddrSub) {
        this.cNPJCreddrSub = cNPJCreddrSub;
    }

    public SPBString getcNPJCPFUsuFinalRecbdr() {
        return cNPJCPFUsuFinalRecbdr;
    }

    public void setcNPJCPFUsuFinalRecbdr(SPBString cNPJCPFUsuFinalRecbdr) {
        this.cNPJCPFUsuFinalRecbdr = cNPJCPFUsuFinalRecbdr;
    }

    public SPBString getcNPJCPFTitular() {
        return cNPJCPFTitular;
    }

    public void setcNPJCPFTitular(SPBString cNPJCPFTitular) {
        this.cNPJCPFTitular = cNPJCPFTitular;
    }

    public SPBString getCodInstitdrArrajPgto() {
        return codInstitdrArrajPgto;
    }

    public void setCodInstitdrArrajPgto(SPBString codInstitdrArrajPgto) {
        this.codInstitdrArrajPgto = codInstitdrArrajPgto;
    }

    public SPBLocalDate getDtPrevtLiquid() {
        return dtPrevtLiquid;
    }

    public void setDtPrevtLiquid(SPBLocalDate dtPrevtLiquid) {
        this.dtPrevtLiquid = dtPrevtLiquid;
    }

    public SPBBigDecimal getVlrTot() {
        return vlrTot;
    }

    public void setVlrTot(SPBBigDecimal vlrTot) {
        this.vlrTot = vlrTot;
    }

    public SPBBigDecimal getVlrComprtdOutrInst() {
        return vlrComprtdOutrInst;
    }

    public void setVlrComprtdOutrInst(SPBBigDecimal vlrComprtdOutrInst) {
        this.vlrComprtdOutrInst = vlrComprtdOutrInst;
    }

    public SPBBigDecimal getVlrComprtdInst() {
        return vlrComprtdInst;
    }

    public void setVlrComprtdInst(SPBBigDecimal vlrComprtdInst) {
        this.vlrComprtdInst = vlrComprtdInst;
    }

    public SPBBigDecimal getVlrLivreTot() {
        return vlrLivreTot;
    }

    public void setVlrLivreTot(SPBBigDecimal vlrLivreTot) {
        this.vlrLivreTot = vlrLivreTot;
    }

    public SPBBigDecimal getVlrLivreAntecCreddrSub() {
        return vlrLivreAntecCreddrSub;
    }

    public void setVlrLivreAntecCreddrSub(SPBBigDecimal vlrLivreAntecCreddrSub) {
        this.vlrLivreAntecCreddrSub = vlrLivreAntecCreddrSub;
    }

    public SPBBigDecimal getVlrPreContrd() {
        return vlrPreContrd;
    }

    public void setVlrPreContrd(SPBBigDecimal vlrPreContrd) {
        this.vlrPreContrd = vlrPreContrd;
    }

    public SPBBigDecimal getVlrOnusResTec() {
        return vlrOnusResTec;
    }

    public void setVlrOnusResTec(SPBBigDecimal vlrOnusResTec) {
        this.vlrOnusResTec = vlrOnusResTec;
    }
}
