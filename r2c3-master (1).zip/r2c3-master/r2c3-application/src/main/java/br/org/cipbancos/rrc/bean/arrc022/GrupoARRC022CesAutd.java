package br.org.cipbancos.rrc.bean.arrc022;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoCesAutd;

@XStreamAlias("Grupo_ARRC022RET_CesAutd")
public class GrupoARRC022CesAutd extends ErrorCodeBean implements GrupoCesAutd {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CPFCesAutd")
    private SPBString cNPJCPFCesAutd;

    public SPBString getCNPJCPFCesAutd() {
        return cNPJCPFCesAutd;
    }

    public void setCNPJCPFCesAutd(SPBString cNPJCPFCesAutd) {
        this.cNPJCPFCesAutd = cNPJCPFCesAutd;
    }

}
