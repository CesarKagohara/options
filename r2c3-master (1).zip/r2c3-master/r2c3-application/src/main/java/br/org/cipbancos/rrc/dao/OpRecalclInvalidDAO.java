package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.atlante.api.handler.Context;

public interface OpRecalclInvalidDAO {

    void inserir(Long idOp, Context context, Exception exception);

}