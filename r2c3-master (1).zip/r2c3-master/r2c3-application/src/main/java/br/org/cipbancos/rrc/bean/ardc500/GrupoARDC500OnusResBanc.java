package br.org.cipbancos.rrc.bean.ardc500;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;

@XStreamAlias("Grupo_ARDC500_OnusRes")
public class GrupoARDC500OnusResBanc extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdentdNegcRecbvl")
    private String identdNegcRecbvl;

    @XStreamAlias("IdentdCIPOp")
    private Long identdCIPOp;

    @XStreamAlias("IndrTpOpOnusRes")
    private String indrTpOpOnusRes;

    @XStreamAlias("DtVencOp")
    private LocalDate dtVencOp;

    @XStreamAlias("IndrRegrDivs")
    private String indrRegrDivs;

    @XStreamAlias("Vlr_PercTotOpUniddRecbvl")
    private BigDecimal vlrPercTotOpUniddRecbvl;

    public String getIdentdNegcRecbvl() {
        return identdNegcRecbvl;
    }

    public void setIdentdNegcRecbvl(String identdNegcRecbvl) {
        this.identdNegcRecbvl = identdNegcRecbvl;
    }

    public Long getIdentdCIPOp() {
        return identdCIPOp;
    }

    public void setIdentdCIPOp(Long identdCIPOp) {
        this.identdCIPOp = identdCIPOp;
    }

    public String getIndrTpOpOnusRes() {
        return indrTpOpOnusRes;
    }

    public void setIndrTpOpOnusRes(String indrTpOpOnusRes) {
        this.indrTpOpOnusRes = indrTpOpOnusRes;
    }

    public LocalDate getDtVencOp() {
        return dtVencOp;
    }

    public void setDtVencOp(LocalDate dtVencOp) {
        this.dtVencOp = dtVencOp;
    }

    public String getIndrRegrDivs() {
        return indrRegrDivs;
    }

    public void setIndrRegrDivs(String indrRegrDivs) {
        this.indrRegrDivs = indrRegrDivs;
    }

    public BigDecimal getVlrPercTotOpUniddRecbvl() {
        return vlrPercTotOpUniddRecbvl;
    }

    public void setVlrPercTotOpUniddRecbvl(BigDecimal vlrPercTotOpUniddRecbvl) {
        this.vlrPercTotOpUniddRecbvl = vlrPercTotOpUniddRecbvl;
    }

}
