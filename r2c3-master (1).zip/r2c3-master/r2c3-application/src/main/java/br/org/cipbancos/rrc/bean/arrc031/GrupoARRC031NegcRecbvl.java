package br.org.cipbancos.rrc.bean.arrc031;

import br.org.cipbancos.atlante.xmlbinder.spb.*;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@XStreamAlias("Grupo_ARRC031_NegcRecbvl")
public class GrupoARRC031NegcRecbvl extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJER")
    private SPBLong cNPJER;

    @XStreamAlias("CPF_CNPJPartNegcdr")
    private SPBString cPFCNPJPartNegcdr;

    @XStreamAlias("IdentdOp")
    private SPBString identdOp;

    @XStreamAlias("IdentdNegcRecbvl")
    private SPBString identdNegcRecbvl;

    @XStreamAlias("IndrTpNegc")
    private SPBString indrTpNegc;

    @XStreamAlias("IndrIA")
    private SPBString indrIA;

    @XStreamAlias("IndrRegrDivs")
    private SPBString IndrRegrDivs;

    @XStreamAlias("IndrAutcCess")
    private SPBString indrAutcCess;

    @XStreamAlias("IndrSitOp")
    private SPBString indrSitOp;

    @XStreamAlias("IndrTpOpOrigem")
    private SPBString indrTpOpOrigem;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC031_OpOrigem")
    private List<GrupoARRC031OpOrigem> listaGrupoARRC031OpOrigem = new ArrayList<>();

    @XStreamImplicit(itemFieldName = "Grupo_ARRC031_Titlar")
    private List<GrupoARRC031Titlar> listaGrupoARRC031Titlar = new ArrayList<>();

    public void setcNPJER(SPBLong cNPJER) {
        this.cNPJER = cNPJER;
    }

    public void setcPFCNPJPartNegcdr(SPBString cPFCNPJPartNegcdr) {
        this.cPFCNPJPartNegcdr = cPFCNPJPartNegcdr;
    }

    public void setIdentdOp(SPBString identdOp) {
        this.identdOp = identdOp;
    }

    public void setIdentdNegcRecbvl(SPBString identdNegcRecbvl) {
        this.identdNegcRecbvl = identdNegcRecbvl;
    }

    public void setIndrTpNegc(SPBString indrTpNegc) {
        this.indrTpNegc = indrTpNegc;
    }

    public void setIndrIA(SPBString indrIA) {
        this.indrIA = indrIA;
    }

    public void setIndrRegrDivs(SPBString indrRegrDivs) {
        IndrRegrDivs = indrRegrDivs;
    }

    public void setIndrAutcCess(SPBString indrAutcCess) {
        this.indrAutcCess = indrAutcCess;
    }

    public void setIndrSitOp(SPBString indrSitOp) {
        this.indrSitOp = indrSitOp;
    }

    public void setIndrTpOpOrigem(SPBString indrTpOpOrigem) {
        this.indrTpOpOrigem = indrTpOpOrigem;
    }

    public void setListaGrupoARRC031OpOrigem(List<GrupoARRC031OpOrigem> listaGrupoARRC031OpOrigem) {
        this.listaGrupoARRC031OpOrigem = listaGrupoARRC031OpOrigem;
    }

    public void setListaGrupoARRC031Titlar(List<GrupoARRC031Titlar> listaGrupoARRC031Titlar) {
        this.listaGrupoARRC031Titlar = listaGrupoARRC031Titlar;
    }

    public SPBLong getcNPJER() {
        return cNPJER;
    }

    public SPBString getcPFCNPJPartNegcdr() {
        return cPFCNPJPartNegcdr;
    }

    public SPBString getIdentdOp() {
        return identdOp;
    }

    public SPBString getIdentdNegcRecbvl() {
        return identdNegcRecbvl;
    }

    public SPBString getIndrTpNegc() {
        return indrTpNegc;
    }

    public SPBString getIndrIA() {
        return indrIA;
    }

    public SPBString getIndrRegrDivs() {
        return IndrRegrDivs;
    }

    public SPBString getIndrAutcCess() {
        return indrAutcCess;
    }

    public SPBString getIndrSitOp() {
        return indrSitOp;
    }

    public SPBString getIndrTpOpOrigem() {
        return indrTpOpOrigem;
    }

    public List<GrupoARRC031OpOrigem> getListaGrupoARRC031OpOrigem() {
        return listaGrupoARRC031OpOrigem;
    }

    public List<GrupoARRC031Titlar> getListaGrupoARRC031Titlar() {
        return listaGrupoARRC031Titlar;
    }
}