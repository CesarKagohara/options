package br.org.cipbancos.rrc.dao;

public interface NegociacaoRecebivelSimuladorDAO {

    String obterInput(Long rootId);

}
