package br.org.cipbancos.rrc.builder;

import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001ArrajPgto;
import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001RETArrajPgto;
import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001RETUsuFinalRecbdr;
import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001UniddRecbvl;
import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001UniddRecbvlActo;
import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001UniddRecbvlRecsdo;
import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001UsuFinalRecbdr;

/**
 * Classe responsável por montar a estrutura dos itens do Grupo de Usuários Finais para o arquivo RET.
 *
 * @author otavio.ferreira
 * @since 1.0
 */
public class AgendaRETBuilder {

    /**
     * Responsável por montar a estrutura somente do elemento de Usuário Final Recebedor.
     *
     * @param recebedor Elemento Usuario Final Recebedor que veio na entrada.
     * @return Um novo elemento do Grupo de Usuário Final Recebedor.
     */
    public GrupoARRC001RETUsuFinalRecbdr montaUsuarioRecebedor(GrupoARRC001UsuFinalRecbdr recebedor) {
        GrupoARRC001RETUsuFinalRecbdr entregador = new GrupoARRC001RETUsuFinalRecbdr();
        entregador.setCNPJCPFUsuFinalRecbdr(recebedor.getCNPJCPFUsuFinalRecbdr());
        return entregador;
    }

    /**
     * Responsável por montar a estrutura somente do elemento de Arranjo de Pagamento.
     *
     * @param arranjo Elemento Arranjo de Pagamento que veio na entrada.
     * @return Um novo elemento do Grupo de Arranjo de Pagamento.
     */
    public GrupoARRC001RETArrajPgto comArranjo(GrupoARRC001ArrajPgto arranjo) {
        GrupoARRC001RETArrajPgto arranjoRET = new GrupoARRC001RETArrajPgto();
        arranjoRET.setCodInstitdrArrajPgto(arranjo.getCodInstitdrArrajPgto());
        return arranjoRET;
    }

    /**
     * Responsável por montar a estrutura somente do elemento de Unidade Recebível Recusada.
     *
     * @param unidade Unidade Recebível que veio na entrada.
     * @return Um novo elemento de Unidade Recebível Recusada.
     */
    public GrupoARRC001UniddRecbvlRecsdo comURTotalmenteRecusada(GrupoARRC001UniddRecbvl unidade) {
        return new AgendaURRecusadaBuilder()
                .montaURRecusada(unidade)
                .comGrupoDomicilioBancarioRecusado(unidade.getListagrupoARRC001DomclBanc())
                .build();
    }

    /**
     * Responsável por montar a estrutura somente do elemento de Unidade Recebível totalmente Aceita.
     *
     * @param unidade Unidade Recebível que veio na entrada.
     * @return Um novo elemento de Unidade Recebível completamente Aceita.
     */
    public GrupoARRC001UniddRecbvlActo comURTotalmenteAceita(GrupoARRC001UniddRecbvl unidade) {
        return new AgendaURAceitaBuilder()
                .montaURAceita(unidade)
                .build();
    }
}
