package br.org.cipbancos.rrc.bean.rrc0010;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBInteger;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLong;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_RRC0010R1_NegcRecbvlInst")
public class GrupoRRC0010R1NegcRecbvlInst extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdentdOp")
    private SPBLong identdOp;

    @XStreamAlias("PriorddNegcRecbvl")
    private SPBInteger priorddNegcRecbvl;

    @XStreamAlias("CNPJER")
    private SPBString cNPJER;

    @XStreamAlias("VlrNegcd")
    private SPBBigDecimal vlrNegcd;

    @XStreamAlias("VlrPercNegcdConstitr")
    private SPBBigDecimal vlrPercNegcdConstitr;

    @XStreamAlias("IndrRegrDivs")
    private SPBString indrRegrDivs;

    @XStreamAlias("DtFimOp")
    private SPBLocalDate dtFimOp;

    public SPBLong getIdentdOp() {
        return identdOp;
    }

    public void setIdentdOp(SPBLong identdOp) {
        this.identdOp = identdOp;
    }

    public SPBInteger getPriorddNegcRecbvl() {
        return priorddNegcRecbvl;
    }

    public void setPriorddNegcRecbvl(SPBInteger priorddNegcRecbvl) {
        this.priorddNegcRecbvl = priorddNegcRecbvl;
    }

    public SPBString getCNPJER() {
        return cNPJER;
    }

    public void setCNPJER(SPBString cNPJER) {
        this.cNPJER = cNPJER;
    }

    public SPBBigDecimal getVlrNegcd() {
        return vlrNegcd;
    }

    public void setVlrNegcd(SPBBigDecimal vlrNegcd) {
        this.vlrNegcd = vlrNegcd;
    }

    public SPBBigDecimal getVlrPercNegcdConstitr() {
        return vlrPercNegcdConstitr;
    }

    public void setVlrPercNegcdConstitr(SPBBigDecimal vlrPercNegcdConstitr) {
        this.vlrPercNegcdConstitr = vlrPercNegcdConstitr;
    }

    public SPBString getIndrRegrDivs() {
        return indrRegrDivs;
    }

    public void setIndrRegrDivs(SPBString indrRegrDivs) {
        this.indrRegrDivs = indrRegrDivs;
    }

    public SPBLocalDate getDtFimOp() {
        return dtFimOp;
    }

    public void setDtFimOp(SPBLocalDate dtFimOp) {
        this.dtFimOp = dtFimOp;
    }

}
