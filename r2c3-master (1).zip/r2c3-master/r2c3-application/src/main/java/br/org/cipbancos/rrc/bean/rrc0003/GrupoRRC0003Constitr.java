package br.org.cipbancos.rrc.bean.rrc0003;

import java.io.Serializable;

import br.org.cipbancos.atlante.xmlbinder.spb.*;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@XStreamAlias("Grupo_RRC0003_Constitr")
public class GrupoRRC0003Constitr extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("PriorddNegcRecbvl")
    private SPBInteger priorddNegcRecbvl;

    @XStreamAlias("CNPJ_CNPJBase_CPFUsuFinalRecbdr")
    private SPBString cNPJCNPJBaseCPFUsuFinalRecbdr;

    @XStreamAlias("CNPJ_CNPJBase_CPFTitlar")
    private SPBString cNPJCNPJBaseCPFTitlar;

    @XStreamAlias("CodInstitdrArrajPgto")
    private SPBString codInstitdrArrajPgto;

    @XStreamAlias("DtPrevtLiquid")
    private SPBLocalDate dtPrevtLiquid;

    @XStreamAlias("VlrPercNegcd")
    private SPBBigDecimal vlrPercNegcd;

    public SPBInteger getPriorddNegcRecbvl() {
        return priorddNegcRecbvl;
    }

    public void setPriorddNegcRecbvl(SPBInteger priorddNegcRecbvl) {
        this.priorddNegcRecbvl = priorddNegcRecbvl;
    }

    public SPBString getcNPJCNPJBaseCPFUsuFinalRecbdr() {
        return cNPJCNPJBaseCPFUsuFinalRecbdr;
    }

    public void setcNPJCNPJBaseCPFUsuFinalRecbdr(SPBString cNPJCNPJBaseCPFUsuFinalRecbdr) {
        this.cNPJCNPJBaseCPFUsuFinalRecbdr = cNPJCNPJBaseCPFUsuFinalRecbdr;
    }

    public SPBString getcNPJCNPJBaseCPFTitlar() {
        return cNPJCNPJBaseCPFTitlar;
    }

    public void setcNPJCNPJBaseCPFTitlar(SPBString cNPJCNPJBaseCPFTitlar) {
        this.cNPJCNPJBaseCPFTitlar = cNPJCNPJBaseCPFTitlar;
    }

    public SPBString getCodInstitdrArrajPgto() {
        return codInstitdrArrajPgto;
    }

    public void setCodInstitdrArrajPgto(SPBString codInstitdrArrajPgto) {
        this.codInstitdrArrajPgto = codInstitdrArrajPgto;
    }

    public SPBLocalDate getDtPrevtLiquid() {
        return dtPrevtLiquid;
    }

    public void setDtPrevtLiquid(SPBLocalDate dtPrevtLiquid) {
        this.dtPrevtLiquid = dtPrevtLiquid;
    }

    public SPBBigDecimal getVlrPercNegcd() {
        return vlrPercNegcd;
    }

    public void setVlrPercNegcd(SPBBigDecimal vlrPercNegcd) {
        this.vlrPercNegcd = vlrPercNegcd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GrupoRRC0003Constitr that = (GrupoRRC0003Constitr) o;
        return new EqualsBuilder()
                .append(getPriorddNegcRecbvl(), that.getPriorddNegcRecbvl())
                .append(getcNPJCNPJBaseCPFUsuFinalRecbdr(), that.getcNPJCNPJBaseCPFUsuFinalRecbdr())
                .append(getcNPJCNPJBaseCPFTitlar(), that.getcNPJCNPJBaseCPFTitlar())
                .append(getCodInstitdrArrajPgto(), that.getCodInstitdrArrajPgto())
                .append(getDtPrevtLiquid(), that.getDtPrevtLiquid())
                .append(getVlrPercNegcd(), that.getVlrPercNegcd())
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(getPriorddNegcRecbvl())
                .append(getcNPJCNPJBaseCPFUsuFinalRecbdr())
                .append(getcNPJCNPJBaseCPFTitlar())
                .append(getCodInstitdrArrajPgto())
                .append(getDtPrevtLiquid())
                .append(getVlrPercNegcd())
                .toHashCode();
    }
}
