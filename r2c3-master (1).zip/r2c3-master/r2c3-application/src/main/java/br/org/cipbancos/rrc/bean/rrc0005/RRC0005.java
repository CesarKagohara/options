package br.org.cipbancos.rrc.bean.rrc0005;

import br.org.cip.api.r2c3.model.Contrato;
import br.org.cip.api.r2c3.model.NotificacaoPosContratada;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoNegcRecbvl0005;
import br.org.cipbancos.rrc.bean.rrc0019.GrupoNegcRecbvlInterop;
import br.org.cipbancos.rrc.interop.helper.HeaderReception;
import br.org.cipbancos.rrc.vo.Operacao;
import br.org.cipbancos.rrc.vo.ProcessamentoNegociacao;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@XStreamAlias("RRC0005")
public class RRC0005 extends ErrorCodeBean implements GrupoNegcRecbvl0005, GrupoNegcRecbvlInterop {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CodMsg")
    private SPBString codMsg;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamAlias("IdentdNegcRecbvl")
    private SPBString identdNegcRecbvl;

    @XStreamAlias("IdentdOp")
    private SPBString identdOp;

    @XStreamAlias("IndrTpNegc")
    private SPBString indrTpNegc;

    @XStreamAlias("DtVencOp")
    private SPBLocalDate dtVencOp;

    @XStreamAlias("VlrTotLim_SldDevdr")
    private SPBBigDecimal vlrTotLimSldDevdr;

    @XStreamAlias("IndrGestER")
    private SPBString indrGestER;

    @XStreamAlias("IndrRegrDivs")
    private SPBString indrRegrDivs;

    @XStreamAlias("IndrActeIncondlOp")
    private SPBString indrActeIncondlOp;

    @XStreamAlias("IndrIA")
    private SPBString indrIA;

    @XStreamAlias("Grupo_RRC0005_GestER")
    private GrupoRRC0005GestER grupoRRC0005GestER;

    @XStreamAlias("Grupo_RRC0005_GestPart")
    private GrupoRRC0005GestPart grupoRRC0005GestPart;

    @XStreamOmitField
    private Contrato contrato;

    @XStreamOmitField
    private NotificacaoPosContratada notificacaoPosContratada;

    @XStreamOmitField
    private HeaderReception headerReception;

    @XStreamOmitField
    private ProcessamentoNegociacao processamentoNegociacao;

    @XStreamOmitField
    private Operacao operacaoAtual;

    @XStreamOmitField
    private List<String> cnpjsRegistradoras;

    @XStreamOmitField
    private Set<String> estabelecimentosBloqueados;

    @XStreamOmitField
    private String recordId;

    @XStreamOmitField
    private String recordId2;

    @XStreamOmitField
    private Long[] idsOpsRecalculo;

    public SPBString getCodMsg() {
        return codMsg;
    }

    public void setCodMsg(SPBString codMsg) {
        this.codMsg = codMsg;
    }

    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public SPBString getIdentdNegcRecbvl() {
        return identdNegcRecbvl;
    }

    public void setIdentdNegcRecbvl(SPBString identdNegcRecbvl) {
        this.identdNegcRecbvl = identdNegcRecbvl;
    }

    public SPBString getIdentdOp() {
        return identdOp;
    }

    public void setIdentdOp(SPBString identdOp) {
        this.identdOp = identdOp;
    }

    public SPBString getIndrTpNegc() {
        return indrTpNegc;
    }

    public void setIndrTpNegc(SPBString indrTpNegc) {
        this.indrTpNegc = indrTpNegc;
    }

    public SPBLocalDate getDtVencOp() {
        return dtVencOp;
    }

    public void setDtVencOp(SPBLocalDate dtVencOp) {
        this.dtVencOp = dtVencOp;
    }

    public SPBBigDecimal getVlrTotLimSldDevdr() {
        return vlrTotLimSldDevdr;
    }

    public void setVlrTotLimSldDevdr(SPBBigDecimal vlrTotLimSldDevdr) {
        this.vlrTotLimSldDevdr = vlrTotLimSldDevdr;
    }

    public SPBString getIndrGestER() {
        return indrGestER;
    }

    public void setIndrGestER(SPBString indrGestER) {
        this.indrGestER = indrGestER;
    }

    public SPBString getIndrRegrDivs() {
        return indrRegrDivs;
    }

    public void setIndrRegrDivs(SPBString indrRegrDivs) {
        this.indrRegrDivs = indrRegrDivs;
    }

    public SPBString getIndrActeIncondlOp() {
        return indrActeIncondlOp;
    }

    public void setIndrActeIncondlOp(SPBString indrActeIncondlOp) {
        this.indrActeIncondlOp = indrActeIncondlOp;
    }

    public SPBString getIndrIA() {
        return indrIA;
    }

    public void setIndrIA(SPBString indrIA) {
        this.indrIA = indrIA;
    }

    public GrupoRRC0005GestER getGrupoGestER() {
        return grupoRRC0005GestER;
    }

    public void setGrupoRRC0005GestER(GrupoRRC0005GestER grupoRRC0005GestER) {
        this.grupoRRC0005GestER = grupoRRC0005GestER;
    }

    public GrupoRRC0005GestPart getGrupoGestPart() {
        return grupoRRC0005GestPart;
    }

    @Override
    public ProcessamentoNegociacao getProcessamentoNegociacao() {
        return processamentoNegociacao;
    }

    @Override
    public void setProcessamentoNegociacao(ProcessamentoNegociacao processamentoNegociacao) {
        this.processamentoNegociacao = processamentoNegociacao;
    }

    @Override
    public List<String> getCnpjsRegistradoras() {
        return cnpjsRegistradoras;
    }

    @Override
    public void setCnpjsRegistradoras(List<String> cnpjsRegistradoras) {
        this.cnpjsRegistradoras = cnpjsRegistradoras;
    }

    public void setGrupoRRC0005GestPart(GrupoRRC0005GestPart grupoRRC0005GestPart) {
        this.grupoRRC0005GestPart = grupoRRC0005GestPart;
    }

    public Contrato getContrato() {
        return contrato;
    }

    public void setContrato(Contrato contrato) {
        this.contrato = contrato;
    }

    public NotificacaoPosContratada getNotificacaoPosContratada() {
        return notificacaoPosContratada;
    }

    public void setNotificacaoPosContratada(NotificacaoPosContratada notificacaoPosContratada) {
        this.notificacaoPosContratada = notificacaoPosContratada;
    }

    public HeaderReception getHeaderReception() {
        return headerReception;
    }

    public void setHeaderReception(HeaderReception headerReception) {
        this.headerReception = headerReception;
    }

    @Override
    public boolean isInterop() {
        return notificacaoPosContratada != null || contrato != null;
    }

    @Override
    public Operacao getOperacaoAtual() {
        return operacaoAtual;
    }

    @Override
    public void setOperacaoAtual(Operacao operacao) {
        this.operacaoAtual = operacao;
    }

    @Override
    public String getRecordId() {
        return recordId;
    }

    @Override
    public void setRecordId(String recordId) {
    }

    @Override
    public Set<String> getEstabelecimentosBloqueados() {
        return null;
    }

    @Override
    public void setEstabelecimentosBloqueados(Set<String> estabelecimentosBloqueados) {
    }

    public Long[] getIdsOpsRecalculo() {
        return idsOpsRecalculo;
    }

    public void setIdsOpsRecalculo(Long[] idsOpsRecalculo) {
        this.idsOpsRecalculo = idsOpsRecalculo;
    }

    @Override
    public Map<String, Set<String>> getCredenciadorasArranjosOutrasIMFs() {
        return new HashMap<>();
    }
}
