package br.org.cipbancos.rrc.bean.arrc018;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_ARRC018_ArrajPgto")
public class GrupoARRC018ArrajPgto extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CodInstitdrArrajPgto")
    private SPBString codInstitdrArrajPgto;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC018_UsuFinalRecbdr")
    private List<GrupoARRC018UsuFinalRecbdr> listagrupoARRC018UsuFinalRecbdr = new ArrayList<>();

    @XStreamImplicit(itemFieldName = "Grupo_ARRC018_Titlar")
    private List<GrupoARRC018Titlar2> listagrupoARRC018Titlar = new ArrayList<>();

    public SPBString getCodInstitdrArrajPgto() {
        return codInstitdrArrajPgto;
    }

    public void setCodInstitdrArrajPgto(SPBString codInstitdrArrajPgto) {
        this.codInstitdrArrajPgto = codInstitdrArrajPgto;
    }

    public List<GrupoARRC018UsuFinalRecbdr> getListagrupoARRC018UsuFinalRecbdr() {
        return listagrupoARRC018UsuFinalRecbdr;
    }

    public void setListagrupoARRC018UsuFinalRecbdr(List<GrupoARRC018UsuFinalRecbdr> listagrupoARRC018UsuFinalRecbdr) {
        this.listagrupoARRC018UsuFinalRecbdr = listagrupoARRC018UsuFinalRecbdr;
    }

    public List<GrupoARRC018Titlar2> getListagrupoARRC018Titlar() {
        return listagrupoARRC018Titlar;
    }

    public void setListagrupoARRC018Titlar(List<GrupoARRC018Titlar2> listagrupoARRC018Titlar) {
        this.listagrupoARRC018Titlar = listagrupoARRC018Titlar;
    }
}
