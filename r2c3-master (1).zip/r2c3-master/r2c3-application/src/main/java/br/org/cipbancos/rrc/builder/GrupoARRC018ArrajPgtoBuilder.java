package br.org.cipbancos.rrc.builder;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.arrc018.GrupoARRC018ArrajPgto;

public class GrupoARRC018ArrajPgtoBuilder {

    private GrupoARRC018ArrajPgto grupoARRC018ArrajPgto;

    private GrupoARRC018ArrajPgtoBuilder(){
        this.grupoARRC018ArrajPgto = new GrupoARRC018ArrajPgto();
    }

    public static GrupoARRC018ArrajPgtoBuilder builder(){
        return new GrupoARRC018ArrajPgtoBuilder();
    }

    public GrupoARRC018ArrajPgtoBuilder comCodigoArranjoPagamento(String codArranjoPagamento){
        this.grupoARRC018ArrajPgto.setCodInstitdrArrajPgto(new SPBString(codArranjoPagamento));
        return this;
    }

    public GrupoARRC018ArrajPgto build(){
        return grupoARRC018ArrajPgto;
    }
}