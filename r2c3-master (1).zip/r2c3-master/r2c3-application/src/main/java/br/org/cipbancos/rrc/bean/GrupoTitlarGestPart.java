package br.org.cipbancos.rrc.bean;

import java.io.Serializable;
import java.util.List;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

public interface GrupoTitlarGestPart extends Serializable {

    SPBString getCNPJCNPJBaseCPFTitlar();

    List<GrupoDomclBanc> getListaGrupoDomclBanc();

}
