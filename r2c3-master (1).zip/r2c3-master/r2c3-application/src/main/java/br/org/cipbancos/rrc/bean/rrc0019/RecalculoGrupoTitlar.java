package br.org.cipbancos.rrc.bean.rrc0019;


import static br.org.cipbancos.atlante.xmlbinder.spb.SPBTypesFactory.newSPBLocalDate;
import static br.org.cipbancos.atlante.xmlbinder.spb.SPBTypesFactory.newSPBString;

import java.util.LinkedList;
import java.util.List;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoArrajPgto;
import br.org.cipbancos.rrc.bean.GrupoTitlar;
import br.org.cipbancos.rrc.util.DateUtil;
import br.org.cipbancos.rrc.util.R2C3SPBUtil;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilio;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilioArranjoPagamento;

public class RecalculoGrupoTitlar implements GrupoTitlar {

    private final OperacaoTitularDomicilio operacaoTitularDomicilio;

    private List<GrupoArrajPgto> arranjos;

    public RecalculoGrupoTitlar(OperacaoTitularDomicilio operacaoTitularDomicilio) {
        this.operacaoTitularDomicilio = operacaoTitularDomicilio;
        arranjos = new LinkedList<>();
        for (OperacaoTitularDomicilioArranjoPagamento arranjo : operacaoTitularDomicilio.getArranjos()) {
            arranjos.add((GrupoArrajPgto)() -> newSPBString(arranjo.getCdArrjoPgto()));
        }
    }

    @Override
    public SPBString getcNPJCNPJBaseCPFTitlar() {
        return newSPBString(operacaoTitularDomicilio.getNrCpfCnpjTitular());
    }

    @Override
    public SPBBigDecimal getVlrPercTotOpUniddRecbvl() {
        return R2C3SPBUtil.newSPBBigDecimal(operacaoTitularDomicilio.getNrVlrTotOpUniddRecbv());
    }

    @Override
    public SPBLocalDate getDtIniOp() {
        return newSPBLocalDate(DateUtil.toLocalDate(operacaoTitularDomicilio.getDtIniOp()));
    }

    @Override
    public SPBLocalDate getDtFimOp() {
        return newSPBLocalDate(DateUtil.toLocalDate(operacaoTitularDomicilio.getDtFimOp()));
    }

    @Override
    public List<GrupoArrajPgto> getListaGrupoArrajPgto() {
        return arranjos;
    }

    @Override
    public SPBString getCNPJCPFTitlarCt() {
        return operacaoTitularDomicilio.getCNPJCPFTitlarCt();
    }

    @Override
    public SPBString getISPBBcoRecbdr() {
        return operacaoTitularDomicilio.getISPBBcoRecbdr();
    }

    @Override
    public SPBString getTpCt() {
        return operacaoTitularDomicilio.getTpCt();
    }

    @Override
    public SPBString getAg() {
        return operacaoTitularDomicilio.getAg();
    }

    @Override
    public SPBString getCt() {
        return operacaoTitularDomicilio.getCt();
    }

    @Override
    public SPBString getCtPgto() {
        return operacaoTitularDomicilio.getCtPgto();
    }
}
