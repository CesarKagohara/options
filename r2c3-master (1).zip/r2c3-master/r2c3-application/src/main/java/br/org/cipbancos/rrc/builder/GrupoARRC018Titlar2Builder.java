package br.org.cipbancos.rrc.builder;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.arrc018.GrupoARRC018Titlar2;

public class GrupoARRC018Titlar2Builder {

    private GrupoARRC018Titlar2 grupoARRC018Titlar2;

    private GrupoARRC018Titlar2Builder(){
        this.grupoARRC018Titlar2 = new GrupoARRC018Titlar2();
    }

    public static GrupoARRC018Titlar2Builder builder(){
        return new GrupoARRC018Titlar2Builder();
    }

    public GrupoARRC018Titlar2Builder comCpfCnpjTitular(String cpfCnpjTitular){
        this.grupoARRC018Titlar2.setcNPJCPFTitular(new SPBString(cpfCnpjTitular));
        return this;
    }

    public GrupoARRC018Titlar2 build(){
        return this.grupoARRC018Titlar2;
    }
}