package br.org.cipbancos.rrc.config;

import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

//@Configuration
//@EnableAsync(mode = AdviceMode.ASPECTJ)
public class R2C3AsyncConfig implements AsyncConfigurer {

//    @Bean(name = "constituicaoThreadPoolExecutor")
    public Executor constituicaoThreadPoolExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(8);
        return executor;
    }
}
