package br.org.cipbancos.rrc.bean;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

import java.io.Serializable;
import java.util.List;

public interface DomicilioBancario extends Serializable {

    SPBString getCNPJCPFTitlarCt();

    SPBString getISPBBcoRecbdr();

    SPBString getTpCt();

    SPBString getAg();

    SPBString getCt();

    SPBString getCtPgto();
}
