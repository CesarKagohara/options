package br.org.cipbancos.rrc.bean.rrc0009;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

public class GrupoRRC0009Titlar implements Serializable {

    @XStreamAlias("CNPJ_CNPJBase_CPFTitlar")
    private SPBString cnpjCnpjBaseCpfTitlar;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0009_DomclBanc")
    private List<GrupoRRC0009DomiclBanc> grupoRRC0009DomiclBanc = new ArrayList<>();

    public SPBString getCnpjCnpjBaseCpfTitlar() {
        return cnpjCnpjBaseCpfTitlar;
    }

    public void setCnpjCnpjBaseCpfTitlar(SPBString cnpjCnpjBaseCpfTitlar) {
        this.cnpjCnpjBaseCpfTitlar = cnpjCnpjBaseCpfTitlar;
    }

    public List<GrupoRRC0009DomiclBanc> getGrupoRRC0009DomiclBanc() {
        return grupoRRC0009DomiclBanc;
    }

    public void setGrupoRRC0009DomiclBanc(List<GrupoRRC0009DomiclBanc> grupoRRC0009DomiclBanc) {
        this.grupoRRC0009DomiclBanc = grupoRRC0009DomiclBanc;
    }
}
