package br.org.cipbancos.rrc.bean.rrc0010;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_RRC0010R1_Titlar")
public class GrupoRRC0010R1Titlar extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CPFTitular")
    private SPBString cNPJCPFTitular;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0010R1_UniddRecbvl")
    private List<GrupoRRC0010R1TitlarUniddRecbvl> listagrupoRRC0010R1UniddRecbvl = new ArrayList<>();

    public SPBString getCNPJCPFTitular() {
        return cNPJCPFTitular;
    }

    public void setCNPJCPFTitular(SPBString cNPJCPFTitular) {
        this.cNPJCPFTitular = cNPJCPFTitular;
    }

    public List<GrupoRRC0010R1TitlarUniddRecbvl> getListagrupoRRC0010R1UniddRecbvl() {
        return listagrupoRRC0010R1UniddRecbvl;
    }

    public void setListagrupoRRC0010R1UniddRecbvl(List<GrupoRRC0010R1TitlarUniddRecbvl> listagrupoRRC0010R1UniddRecbvl) {
        this.listagrupoRRC0010R1UniddRecbvl = listagrupoRRC0010R1UniddRecbvl;
    }

}
