package br.org.cipbancos.rrc.bean.arrc022;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoRenegcDiv;

@XStreamAlias("Grupo_ARRC022_RenegcDiv")
public class GrupoARRC022RenegcDiv extends ErrorCodeBean implements GrupoRenegcDiv {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdentdOpOrRenegcDiv")
    private SPBString identdOpOrRenegcDiv;

    public SPBString getIdentdOpOrRenegcDiv() {
        return identdOpOrRenegcDiv;
    }

    public void setIdentdOpOrRenegcDiv(SPBString identdOpOrRenegcDiv) {
        this.identdOpOrRenegcDiv = identdOpOrRenegcDiv;
    }

}
