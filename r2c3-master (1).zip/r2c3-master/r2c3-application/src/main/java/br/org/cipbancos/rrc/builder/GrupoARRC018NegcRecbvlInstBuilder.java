package br.org.cipbancos.rrc.builder;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBInteger;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.arrc018.GrupoARRC018NegcRecbvlInst;
import br.org.cipbancos.rrc.util.DateUtil;

import java.math.BigDecimal;
import java.util.Date;

public class GrupoARRC018NegcRecbvlInstBuilder {

    private GrupoARRC018NegcRecbvlInst grupoARRC018NegcRecbvlInst;

    private GrupoARRC018NegcRecbvlInstBuilder(){
        this.grupoARRC018NegcRecbvlInst = new GrupoARRC018NegcRecbvlInst();
    }

    public static GrupoARRC018NegcRecbvlInstBuilder builder(){
        return new GrupoARRC018NegcRecbvlInstBuilder();
    }

    public GrupoARRC018NegcRecbvlInstBuilder comIdentOp(Long identOp){
        if (identOp != null) {
            grupoARRC018NegcRecbvlInst.setIdentdOp(new SPBString(identOp.toString()));
        }
        return this;
    }

    public GrupoARRC018NegcRecbvlInstBuilder comPriorddNegcRecbvl(Integer priorddNegcRecbvl){
        if (priorddNegcRecbvl != null) {
            grupoARRC018NegcRecbvlInst.setPriorddNegcRecbvl(new SPBInteger(priorddNegcRecbvl));
        }
        return this;
    }

    public GrupoARRC018NegcRecbvlInstBuilder comCnpjRegistradora(String cnpjRegistradora){
        if (cnpjRegistradora != null) {
            grupoARRC018NegcRecbvlInst.setcNPJER(new SPBString(cnpjRegistradora));
        }
        return this;
    }

    public GrupoARRC018NegcRecbvlInstBuilder comValorNegociado(BigDecimal valorNegociado){
        if (valorNegociado != null) {
            grupoARRC018NegcRecbvlInst.setVlrNegcd(new SPBBigDecimal(valorNegociado));
        }
        return this;
    }

    public GrupoARRC018NegcRecbvlInstBuilder comValorPercentualNegociadoConstituir(BigDecimal valorPercentualNegociadoConstituir){
        if (valorPercentualNegociadoConstituir != null) {
            grupoARRC018NegcRecbvlInst.setVlrPercNegcdConstitr(new SPBBigDecimal(valorPercentualNegociadoConstituir));
        }
        return this;
    }

    public GrupoARRC018NegcRecbvlInstBuilder comIndrRegraDivisao(String indrRegraDivisao){
        if (indrRegraDivisao != null) {
            grupoARRC018NegcRecbvlInst.setIndrRegrDivs(new SPBString(indrRegraDivisao));
        }
        return this;
    }

    public GrupoARRC018NegcRecbvlInstBuilder comDataFimOperacao(Date dataFimOperacao){
        if (dataFimOperacao != null) {
            grupoARRC018NegcRecbvlInst.setDtFimOp(new SPBLocalDate(DateUtil.toLocalDate(dataFimOperacao)));
        }
        return this;
    }

    public GrupoARRC018NegcRecbvlInst build(){
        return this.grupoARRC018NegcRecbvlInst;
    }
}
