package br.org.cipbancos.rrc.bean.arrc022;

import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoTitlarGestPart;

@XStreamAlias("Grupo_ARRC022_Titlar")
public class GrupoARRC022TitlarGestPart extends ErrorCodeBean implements GrupoTitlarGestPart {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CNPJBase_CPFTitlar")
    private SPBString cNPJCNPJBaseCPFTitlar;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC022_DomclBanc")
    private List<GrupoARRC022DomclBanc> listagrupoARRC022DomclBanc = new ArrayList<>();

    public SPBString getCNPJCNPJBaseCPFTitlar() {
        return cNPJCNPJBaseCPFTitlar;
    }

    public void setCNPJCNPJBaseCPFTitlar(SPBString cNPJCNPJBaseCPFTitlar) {
        this.cNPJCNPJBaseCPFTitlar = cNPJCNPJBaseCPFTitlar;
    }

    public List<GrupoARRC022DomclBanc> getListagrupoARRC022DomclBanc() {
        return listagrupoARRC022DomclBanc;
    }

    public void setListagrupoARRC022DomclBanc(List<GrupoARRC022DomclBanc> listagrupoARRC022DomclBanc) {
        this.listagrupoARRC022DomclBanc = listagrupoARRC022DomclBanc;
    }

    @Override
    public List getListaGrupoDomclBanc() {
        return getListagrupoARRC022DomclBanc();
    }
}
