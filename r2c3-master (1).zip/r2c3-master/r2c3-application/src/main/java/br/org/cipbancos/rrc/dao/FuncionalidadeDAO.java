package br.org.cipbancos.rrc.dao;


import br.org.cipbancos.rrc.dominio.TipoCanal;
import br.org.cipbancos.rrc.enums.TipoFuncionalidade;

public interface FuncionalidadeDAO {

    Integer obterIdFuncddPorTipoFuncionalidadeCanal(TipoFuncionalidade tipoFuncionalidade, TipoCanal tipoCanal);
}
