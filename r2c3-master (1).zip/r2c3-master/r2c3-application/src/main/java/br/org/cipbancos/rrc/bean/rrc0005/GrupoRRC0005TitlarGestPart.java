package br.org.cipbancos.rrc.bean.rrc0005;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoTitlarGestPart;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_RRC0005_Titlar")
public class GrupoRRC0005TitlarGestPart extends ErrorCodeBean implements GrupoTitlarGestPart {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CNPJBase_CPFTitlar")
    private SPBString cNPJCNPJBaseCPFTitlar;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0005_DomclBanc")
    private List<GrupoRRC0005DomclBanc> listagrupoRRC0005DomclBanc = new ArrayList<>();

    public SPBString getCNPJCNPJBaseCPFTitlar() {
        return cNPJCNPJBaseCPFTitlar;
    }

    public void setCNPJCNPJBaseCPFTitlar(SPBString cNPJCNPJBaseCPFTitlar) {
        this.cNPJCNPJBaseCPFTitlar = cNPJCNPJBaseCPFTitlar;
    }

    public List<GrupoRRC0005DomclBanc> getListagrupoRRC0005DomclBanc() {
        return listagrupoRRC0005DomclBanc;
    }

    public void setListagrupoRRC0005DomclBanc(List<GrupoRRC0005DomclBanc> listagrupoRRC0005DomclBanc) {
        this.listagrupoRRC0005DomclBanc = listagrupoRRC0005DomclBanc;
    }

    @Override
    public List getListaGrupoDomclBanc() {
        return getListagrupoRRC0005DomclBanc();
    }

}
