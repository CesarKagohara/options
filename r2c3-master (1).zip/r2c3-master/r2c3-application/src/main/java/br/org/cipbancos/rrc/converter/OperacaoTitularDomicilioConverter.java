package br.org.cipbancos.rrc.converter;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import br.org.cipbancos.atlante.api.ContextPropertyKeys;
import br.org.cipbancos.atlante.api.CustomTransportType;
import br.org.cipbancos.atlante.api.handler.Context;
import br.org.cipbancos.rrc.bean.GrupoArrajPgto;
import br.org.cipbancos.rrc.dominio.SituacaoAtivoInativo;
import br.org.cipbancos.rrc.funcional.Converter;
import br.org.cipbancos.rrc.vo.Operacao;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilio;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilioCredenciadora;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilioUsuarioFinal;
import br.org.cipbancos.rrc.util.DateUtil;
import br.org.cipbancos.rrc.util.R2C3SPBUtil;
import br.org.cipbancos.rrc.vo.*;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

public class OperacaoTitularDomicilioConverter {

    private OperacaoTitularDomicilioConverter() {
    }

    public static Converter<OperacaoTitularDomicilio, MapSqlParameterSource>
                    emOperacaoTitularDomicilioParaInsercao() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();
            parametros.addValue("idOp", origem.getIdOperacao());
            parametros.addValue("idOpTitlarDomcl", origem.getIdOpTitlarDomcl());
            parametros.addValue("nrCpfCnpjTitlar", origem.getNrCpfCnpjTitular());
            parametros.addValue("nrCpfCnpjTitlarCt", origem.getNrCpfCnpjTitularConta());
            parametros.addValue("cdIspbBcoRecbdr", Integer.parseInt(origem.getIspbBancoRecebedor()));
            parametros.addValue("icTpCt", origem.getTipoConta());
            parametros.addValue("nrAg", origem.getAgencia());
            parametros.addValue("nrCt", origem.getConta());
            parametros.addValue("nrCtPgto", origem.getContaPagamento());
            parametros.addValue("nrVlrTotOpUniddRecbv", origem.getNrVlrTotOpUniddRecbv());
            parametros.addValue("idPartPrincipal", origem.getIdPartPrincipal());
            parametros.addValue("idPartAdmtd", origem.getIdPartAdmtd());
            parametros.addValue("idPartOrigdr", origem.getIdPartOrigdr());
            parametros.addValue("dtRefSistIncl", origem.getDtRefSistIncl());
            parametros.addValue("dtRefSistUltAlt", origem.getDtRefSistUltAlt());
            parametros.addValue("idAtlRoot", origem.getIdAtlRoot());
            parametros.addValue("nmArqNuopApi", origem.getNmArqNuopApi());
            parametros.addValue("idFuncdd", origem.getIdFuncdd());
            parametros.addValue("canal", origem.getCanal());
            parametros.addValue("dtIniOp", origem.getDtIniOp());
            parametros.addValue("dtFimOp", origem.getDtFimOp());
            parametros.addValue("icSit", origem.getIcSit());
            return parametros;
        };
    }

    public static Converter<OperacaoTitularDomicilio, MapSqlParameterSource>
    emOperacaoTitularDomicilioParaAtualizacaoSituacao() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();
            parametros.addValue("idOp", origem.getIdOperacao());
            parametros.addValue("icSit", origem.getIcSit());
            return parametros;
        };
    }

    public static Converter<OperacaoTitularDomicilio, OperacaoTitularDomicilioCredenciadora>
                    titularGestaoRegistradoraEmOperacaoTitularDomicilioCredenciadora(Context context, Operacao operacao, String credenciadora) {
        return origem -> {
            OperacaoTitularDomicilioCredenciadora destino = new OperacaoTitularDomicilioCredenciadora();
            CustomTransportType canal = (CustomTransportType) context.getProperties().get(ContextPropertyKeys.TRANSPORT_TYPE);

            final String nmNuopApi = null == context.getProperties().get(ContextPropertyKeys.LOGICAL_IDENTIFIER)
                    || ((String) context.getProperties().get(ContextPropertyKeys.LOGICAL_IDENTIFIER)).isEmpty() ?
                    (String) context.getProperties().get(ContextPropertyKeys.PHYSICAL_IDENTIFIER) :
                    (String) context.getProperties().get(ContextPropertyKeys.LOGICAL_IDENTIFIER);

            destino.setIdOperacao(operacao.getIdOp());
            destino.setIdOperacaoTitDomcl(origem.getIdOpTitlarDomcl());
            destino.setCnpjCreddr(credenciadora);
            destino.setIdPartPrincipal(operacao.getIdPartPrincipal());
            destino.setIdPartAdmtd(operacao.getIdPartAdmtd());
            destino.setIdPartOrigdr(operacao.getIdPartAdmtd());
            destino.setIdAtlRoot(context.getRootId());
            destino.setNmArqNuopApi(nmNuopApi);
            destino.setCanal(canal.getValue());
            destino.setFuncdd(context.getDataTypeId());
            destino.setDtRefSistIncl(context.getBatchReferenceDate());
            destino.setDtRefSistUltAlt(context.getBatchReferenceDate());
            destino.setIcSit(SituacaoAtivoInativo.ATIVO.getValue());
            destino.setIdFuncdd(operacao.getIdFuncdd());

            return destino;
        };
    }

    public static Converter<OperacaoTitularDomicilio, OperacaoTitularDomicilioUsuarioFinal>
                    titularGestaoRegistradoraEmOperacaoTitularDomicilioUsuarioFinal(Context context, Operacao operacao, String usuarioFinal) {
        return origem -> {
            OperacaoTitularDomicilioUsuarioFinal destino = new OperacaoTitularDomicilioUsuarioFinal();
            destino.setIdOperacao(operacao.getIdOp());
            destino.setIdOperacaoTitDomcl(origem.getIdOpTitlarDomcl());
            destino.setCnpjCpfUsuarioFinalRecbdr(usuarioFinal);
            destino.setIdPartPrincipal(operacao.getIdPartPrincipal());
            destino.setIdPartAdmtd(operacao.getIdPartAdmtd());
            destino.setIdPartOrigdr(operacao.getIdPartAdmtd());
            destino.setIdAtlRoot(context.getRootId());

            String nmNuopApi = (String) context.getProperties().get(ContextPropertyKeys.LOGICAL_IDENTIFIER);
            if (null == nmNuopApi || nmNuopApi.isEmpty()) {
                nmNuopApi = (String) context.getProperties().get(ContextPropertyKeys.PHYSICAL_IDENTIFIER);
            }

            destino.setNmArqNuopApi(nmNuopApi);
            destino.setIdFuncdd(operacao.getIdFuncdd());
            destino.setFuncdd(context.getDataTypeId());
            destino.setDtRefSistIncl(context.getBatchReferenceDate());
            destino.setDtRefSistUltAlt(context.getBatchReferenceDate());
            destino.setIcSit(SituacaoAtivoInativo.ATIVO.getValue());
            return destino;
        };
    }

    public static Converter<OperacaoTitularDomicilio, OperacaoTitularDomicilioArranjoPagamento> emOperacaoTitularDomicilioArranjoPagamentoParaInsercao(Context context, Operacao operacao, String arranjoPagto) {
        return origem -> {
            OperacaoTitularDomicilioArranjoPagamento destino = new OperacaoTitularDomicilioArranjoPagamento();
            destino.setIdOp(origem.getIdOperacao());
            destino.setIdOpTitlarDomcl(origem.getIdOpTitlarDomcl());
            destino.setCdArrjoPgto(arranjoPagto);
            destino.setIdFuncdd(operacao.getIdFuncdd());
            destino.setDtRefSistIncl(DateUtil.toLocalDate(context.getBatchReferenceDate()));
            destino.setDtRefSistUltAlt(DateUtil.toLocalDate(context.getBatchReferenceDate()));
            destino.setIdAtlRoot(context.getRootId());
            String nmNuopApi = (String) context.getProperties().get(ContextPropertyKeys.LOGICAL_IDENTIFIER);
            if (null == nmNuopApi || nmNuopApi.isEmpty()) {
                nmNuopApi = (String) context.getProperties().get(ContextPropertyKeys.PHYSICAL_IDENTIFIER);
            }
            destino.setNmArqNuOpApi(nmNuopApi);
            return destino;
        };
    }
}
