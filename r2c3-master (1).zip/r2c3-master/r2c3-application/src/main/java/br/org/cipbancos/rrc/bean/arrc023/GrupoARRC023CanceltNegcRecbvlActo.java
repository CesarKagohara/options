package br.org.cipbancos.rrc.bean.arrc023;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

/**
 * @author anderson.martins
 * @since 1.0.0
 */
@XStreamAlias("Grupo_ARRC023RET_CanceltNegcRecbvlActo")
public class GrupoARRC023CanceltNegcRecbvlActo extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdentdNegcRecbvl")
    private SPBString identdNegcRecbvl;

    @XStreamAlias("IdentdOp")
    private SPBString identdOp;

    @XStreamAlias("IdentdOpCancel")
    private SPBString identdOpCancel;

    public SPBString getIdentdNegcRecbvl() {
        return identdNegcRecbvl;
    }

    public void setIdentdNegcRecbvl(SPBString identdNegcRecbvl) {
        this.identdNegcRecbvl = identdNegcRecbvl;
    }

    public SPBString getIdentdOp() {
        return identdOp;
    }

    public void setIdentdOp(SPBString identdOp) {
        this.identdOp = identdOp;
    }

    public SPBString getIdentdOpCancel() {
        return identdOpCancel;
    }

    public void setIdentdOpCancel(SPBString identdOpCancel) {
        this.identdOpCancel = identdOpCancel;
    }

}
