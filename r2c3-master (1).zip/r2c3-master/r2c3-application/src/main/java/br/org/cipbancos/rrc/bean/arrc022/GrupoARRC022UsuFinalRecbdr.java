package br.org.cipbancos.rrc.bean.arrc022;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoUsuFinalRecbdr;

@XStreamAlias("Grupo_ARRC022_UsuFinalRecbdr")
public class GrupoARRC022UsuFinalRecbdr extends ErrorCodeBean implements GrupoUsuFinalRecbdr {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CNPJBase_CPFUsuFinalRecbdr")
    private SPBString cNPJCNPJBaseCPFUsuFinalRecbdr;

    public SPBString getCNPJCNPJBaseCPFUsuFinalRecbdr() {
        return cNPJCNPJBaseCPFUsuFinalRecbdr;
    }

    public void setCNPJCNPJBaseCPFUsuFinalRecbdr(SPBString cNPJCNPJBaseCPFUsuFinalRecbdr) {
        this.cNPJCNPJBaseCPFUsuFinalRecbdr = cNPJCNPJBaseCPFUsuFinalRecbdr;
    }

}
