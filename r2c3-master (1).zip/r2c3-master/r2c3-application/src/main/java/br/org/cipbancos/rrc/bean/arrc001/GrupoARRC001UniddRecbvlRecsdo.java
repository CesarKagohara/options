package br.org.cipbancos.rrc.bean.arrc001;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;

public class GrupoARRC001UniddRecbvlRecsdo extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("DtPrevtLiquid")
    private SPBLocalDate dtPrevtLiquid;

    @XStreamAlias("VlrTot")
    private SPBBigDecimal vlrTot;

    @XStreamAlias("VlrPreContrd")
    private SPBBigDecimal vlrPreContrd;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC001RET_DomclBancRecsdo")
    private List<GrupoARRC001DomclBancRecsdo> listagrupoARRC001DomclBancRecsdo = new ArrayList<>();

    public SPBLocalDate getDtPrevtLiquid() {
        return dtPrevtLiquid;
    }

    public void setDtPrevtLiquid(SPBLocalDate dtPrevtLiquid) {
        this.dtPrevtLiquid = dtPrevtLiquid;
    }

    public SPBBigDecimal getVlrTot() {
        return vlrTot;
    }

    public void setVlrTot(SPBBigDecimal vlrTot) {
        this.vlrTot = vlrTot;
    }

    public SPBBigDecimal getVlrPreContrd() {
        return vlrPreContrd;
    }

    public void setVlrPreContrd(SPBBigDecimal vlrPreContrd) {
        this.vlrPreContrd = vlrPreContrd;
    }

    public List<GrupoARRC001DomclBancRecsdo> getListagrupoARRC001DomclBancRecsdo() {
        return listagrupoARRC001DomclBancRecsdo;
    }

    public void setListagrupoARRC001DomclBancRecsdo(List<GrupoARRC001DomclBancRecsdo> listagrupoARRC001DomclBancRecsdo) {
        this.listagrupoARRC001DomclBancRecsdo = listagrupoARRC001DomclBancRecsdo;
    }
}
