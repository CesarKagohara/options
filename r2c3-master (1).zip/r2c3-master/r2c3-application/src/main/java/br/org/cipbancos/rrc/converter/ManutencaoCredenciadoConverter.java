package br.org.cipbancos.rrc.converter;

import java.sql.Timestamp;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import br.org.cipbancos.atlante.api.ContextPropertyKeys;
import br.org.cipbancos.atlante.api.handler.Context;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.arrc030.GrupoARRC030Credd;
import br.org.cipbancos.rrc.enums.IndicadorManutencaoDomicilio;
import br.org.cipbancos.rrc.enums.TipoPessoa;
import br.org.cipbancos.rrc.funcional.Converter;
import br.org.cipbancos.rrc.vo.CredenciadoVO;

import br.org.cip.api.r2c3.model.EstabelecimentoComercialInputDTO;
import br.org.cip.api.r2c3.model.InstituicaoCredenciadoraArranjoPagamentoInputDTO;
import br.org.cip.api.r2c3.model.RegistradoraEstabelecimentoComercialCredenciadoraDTO;

public class ManutencaoCredenciadoConverter {

    private static DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;

    private ManutencaoCredenciadoConverter() {
    }


    /**
     * Converte um GrupoARRC030Credd para inserção
     * @param context
     * @param idPartCred
     * @param idFuncdd
     * @param arranjo
     */
    public static Converter<GrupoARRC030Credd, CredenciadoVO> deGrupoARRC030CreddParaCredenciadoVO(Context context, Integer idPartCred, Integer idFuncdd, String arranjo, String nrCnpjCreddr) {
        return origem -> {

            CredenciadoVO credenciado = new CredenciadoVO();
            IndicadorManutencaoDomicilio indicador = IndicadorManutencaoDomicilio.fromString(origem.
                    getIndicadorManutencaoCadastro().getValue());
            credenciado.setIndicadorManutencaoDomicilio(indicador);

            TipoPessoa tipoPessoa = TipoPessoa.fromStringFromSPB(origem.getTipoPessoa().getValue());
            if (tipoPessoa != null) {
                credenciado.setTipoPessoa(tipoPessoa.getValue());
            }

            credenciado.setIdParticipanteCredenciador(idPartCred);
            credenciado.setDocumentoEstabelecimentoComercial(origem.getCpfCNPJCliente().getValue());

            SPBString nomeRazaoSocialCliente = origem.getNomeRazaoSocialCliente();
            if (nomeRazaoSocialCliente != null) {
                credenciado.setNomeRazaoSocial(nomeRazaoSocialCliente.getValue());
            }

            SPBString nomeFantasia = origem.getNomeFantasia();
            if (nomeFantasia != null) {
                credenciado.setNomeFantasia(nomeFantasia.getValue());
            }

            SPBString endereco = origem.getEndereco();
            if (endereco != null) {
                credenciado.setEndereco(endereco.getValue());
            }

            SPBString cep = origem.getCep();
            if (cep != null) {
                credenciado.setCep(cep.getValue());
            }

            SPBString municipio = origem.getMunicipio();
            if (municipio != null) {
                credenciado.setMunicipio(municipio.getValue());
            }

            SPBString uf = origem.getUf();
            if (uf != null) {
                credenciado.setUf(uf.getValue());
            }

            if (indicador != null && indicador.equals(IndicadorManutencaoDomicilio.INCLUSAO)) {
                credenciado.setDataInclusao(new Date());
            } else {
                credenciado.setDataInclusao(origem.getDataInclusao());
            }
            credenciado.setDataUltimaAlteracao(new Date());
            credenciado.setDataRefInclusao(context.getBatchReferenceDate());
            credenciado.setDataRefUltimaAlteracao(context.getBatchReferenceDate());
            credenciado.setRootId(context.getRootId());
            credenciado.setNomeArquivo((String)context.getProperties().get(ContextPropertyKeys.PHYSICAL_IDENTIFIER));
            credenciado.setIdFuncdd(idFuncdd);
            credenciado.setArranjos(arranjo);
            credenciado.setNrCnpjCreddr(nrCnpjCreddr);

            return credenciado;
        };
    }

    public static Converter<CredenciadoVO, RegistradoraEstabelecimentoComercialCredenciadoraDTO> deCredenciadoVOParaRegistradoraEstabelecimentoComercialCredenciadoraDTO() {

        return origem ->  {
            RegistradoraEstabelecimentoComercialCredenciadoraDTO estabelecimentoComercialInputDTO = new RegistradoraEstabelecimentoComercialCredenciadoraDTO();

            String tipoPessoa = origem.getTipoPessoa();
            estabelecimentoComercialInputDTO.setTipoDocumentoEstabelecimentoComercial(
                    tipoPessoa.equals(TipoPessoa.FISICA.getValue())?
                            RegistradoraEstabelecimentoComercialCredenciadoraDTO.TipoDocumentoEstabelecimentoComercialEnum.CPF :
                            RegistradoraEstabelecimentoComercialCredenciadoraDTO.TipoDocumentoEstabelecimentoComercialEnum.CNPJ);

            estabelecimentoComercialInputDTO.setCnpjCredenciadora(origem.getNrCnpjCreddr());
            estabelecimentoComercialInputDTO.setDocumentoEstabelecimentoComercial(origem.getDocumentoEstabelecimentoComercial());

            boolean isBaixa = origem.getIndicadorManutencaoDomicilio().equals(IndicadorManutencaoDomicilio.BAIXA);
            if (!isBaixa) {
                estabelecimentoComercialInputDTO.setStatus(RegistradoraEstabelecimentoComercialCredenciadoraDTO.StatusEnum.ATIVO);
            } else {
                estabelecimentoComercialInputDTO.setStatus(RegistradoraEstabelecimentoComercialCredenciadoraDTO.StatusEnum.INATIVO);
            }

            estabelecimentoComercialInputDTO.setDataInicio(new Timestamp(origem.getDataInclusao().getTime()).toLocalDateTime().format(formatter));

            if (isBaixa) {
                estabelecimentoComercialInputDTO.setDataFim(new Timestamp (origem.getDataUltimaAlteracao().getTime()).toLocalDateTime().format(formatter));
            }
            return estabelecimentoComercialInputDTO;
        };
    }

    public static Converter<CredenciadoVO, InstituicaoCredenciadoraArranjoPagamentoInputDTO> deCredenciadoVOParaInstituicaoArranjoInputDTO() {

        return origem ->  {
            InstituicaoCredenciadoraArranjoPagamentoInputDTO instituicaoArranjoInputDTO = new InstituicaoCredenciadoraArranjoPagamentoInputDTO();
            instituicaoArranjoInputDTO.setArranjoPagamentoId(origem.getArranjos());
            instituicaoArranjoInputDTO.setCnpjCredenciadora(origem.getNrCnpjCreddr());

            boolean isBaixa = origem.getIndicadorManutencaoDomicilio().equals(IndicadorManutencaoDomicilio.BAIXA);
            if (!isBaixa) {
                instituicaoArranjoInputDTO.setStatus(InstituicaoCredenciadoraArranjoPagamentoInputDTO.StatusEnum.ATIVO);
            } else {
                instituicaoArranjoInputDTO.setStatus(InstituicaoCredenciadoraArranjoPagamentoInputDTO.StatusEnum.INATIVO);
            }

            instituicaoArranjoInputDTO.setDataInicio(new Timestamp(origem.getDataInclusao().getTime()).toLocalDateTime().format(formatter));

            if (isBaixa) {
                instituicaoArranjoInputDTO.setDataFim(new Timestamp (origem.getDataUltimaAlteracao().getTime()).toLocalDateTime().format(formatter));
            }
            return instituicaoArranjoInputDTO;
        };
    }

    public static Converter<CredenciadoVO, EstabelecimentoComercialInputDTO> deCredenciadoVOParaEstabelecimentoComercialInputDTO() {

        return origem ->  {
            EstabelecimentoComercialInputDTO estabelecimentoComercialInputDTO = new EstabelecimentoComercialInputDTO();

            String tipoPessoa = origem.getTipoPessoa();
            estabelecimentoComercialInputDTO.setTipoDocumentoEstabelecimentoComercial(
                    tipoPessoa.equals(TipoPessoa.FISICA.getValue())?
                            EstabelecimentoComercialInputDTO.TipoDocumentoEstabelecimentoComercialEnum.CPF :
                            EstabelecimentoComercialInputDTO.TipoDocumentoEstabelecimentoComercialEnum.CNPJ);

            estabelecimentoComercialInputDTO.setDocumentoEstabelecimentoComercial(origem.getDocumentoEstabelecimentoComercial());
            estabelecimentoComercialInputDTO.setArranjoPagamentoId(origem.getArranjos());
            boolean isBaixa = origem.getIndicadorManutencaoDomicilio().equals(IndicadorManutencaoDomicilio.BAIXA);
            if (!isBaixa) {
                estabelecimentoComercialInputDTO.setStatus(EstabelecimentoComercialInputDTO.StatusEnum.ATIVO);
            } else {
                estabelecimentoComercialInputDTO.setStatus(EstabelecimentoComercialInputDTO.StatusEnum.INATIVO);
            }

            estabelecimentoComercialInputDTO.setDataInicio(new Timestamp(origem.getDataInclusao().getTime()).toLocalDateTime().format(formatter));

            if (isBaixa) {
                estabelecimentoComercialInputDTO.setDataFim(new Timestamp (origem.getDataUltimaAlteracao().getTime()).toLocalDateTime().format(formatter));
            }
            return estabelecimentoComercialInputDTO;
        };

    }
}
