package br.org.cipbancos.rrc.bean.arrc023;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;

/**
 * @author anderson.martins
 * @since 1.0.0
 */
@XStreamAlias("ARRC023RET")
public class ARRC023RET extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("Grupo_ARRC023RET_CanceltNegcRecbvl")
    private GrupoARRC023CanceltNegcRecbvlRET grupoARRC023RETCanceltNegcRecbvl;

    public GrupoARRC023CanceltNegcRecbvlRET getGrupoARRC023RETCanceltNegcRecbvl() {
        return grupoARRC023RETCanceltNegcRecbvl;
    }

    public void setGrupoARRC023RETCanceltNegcRecbvl(GrupoARRC023CanceltNegcRecbvlRET grupoARRC023RETCanceltNegcRecbvl) {
        this.grupoARRC023RETCanceltNegcRecbvl = grupoARRC023RETCanceltNegcRecbvl;
    }
}
