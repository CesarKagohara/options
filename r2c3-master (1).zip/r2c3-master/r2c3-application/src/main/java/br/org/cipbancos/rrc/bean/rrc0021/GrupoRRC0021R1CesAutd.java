package br.org.cipbancos.rrc.bean.rrc0021;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_RRC0021R1_CesAutd")
public class GrupoRRC0021R1CesAutd extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CPFCesAutd")
    private SPBString cNPJCPFCesAutd;

    public SPBString getCNPJCPFCesAutd() {
        return cNPJCPFCesAutd;
    }

    public void setCNPJCPFCesAutd(SPBString cNPJCPFCesAutd) {
        this.cNPJCPFCesAutd = cNPJCPFCesAutd;
    }

}
