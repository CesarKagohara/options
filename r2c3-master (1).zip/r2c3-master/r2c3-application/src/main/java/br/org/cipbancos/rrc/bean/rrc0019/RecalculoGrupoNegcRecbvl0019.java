package br.org.cipbancos.rrc.bean.rrc0019;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.*;
import br.org.cipbancos.rrc.handler.recalculo.bean.RecalculoObjetoParametro;
import br.org.cipbancos.rrc.util.DateUtil;
import br.org.cipbancos.rrc.vo.Operacao;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilio;
import br.org.cipbancos.rrc.vo.ProcessamentoNegociacao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static br.org.cipbancos.atlante.xmlbinder.spb.SPBTypesFactory.newSPBLocalDate;
import static br.org.cipbancos.atlante.xmlbinder.spb.SPBTypesFactory.newSPBString;
import static br.org.cipbancos.rrc.util.R2C3SPBUtil.newSPBBigDecimal;

import com.thoughtworks.xstream.annotations.XStreamOmitField;

public class RecalculoGrupoNegcRecbvl0019 implements GrupoNegcRecbvl0019 {

    public RecalculoGrupoNegcRecbvl0019(Operacao operacao, List<OperacaoTitularDomicilio> opTitularDomomicilioList) {
        this.operacao = operacao;
        this.grupoGestER = new RecalculoGrupoGestER(opTitularDomomicilioList);
    }

    private final Operacao operacao;
    private GrupoGestER grupoGestER;

    private Set<String> estabelecimentosBloqueados;

    private Set<String> credenciadorasAlcanceGeral;

    private RecalculoObjetoParametro<Long> recalculoObjetoParametro;

    private Long[] idsOpsRecalculo;

    private Map<String, Set<String>> credenciadorasArranjosOutrasIMFs = new HashMap<>();

    @Override
    public SPBBigDecimal getVlrGar() {
        return newSPBBigDecimal(operacao.getNrVlrGar());
    }

    @Override
    public SPBString getIndrAlcancContrtoCreddrSub() {
        return newSPBString(operacao.getIcAlcccontrto());
    }

    @Override
    public SPBString getIndrActeUniddRecbvlReserv() {
        throw new UnsupportedOperationException("Nao implementado");
    }

    @Override
    public SPBString getIdentdOpDescstcNegcRecbvl() {
        throw new UnsupportedOperationException("Nao implementado");
    }

    @Override
    public SPBString getIndrAutcCess() {
        return newSPBString(operacao.getIcAutcCess());
    }

    @Override
    public Operacao getOperacaoAtual() {
        return operacao;
    }

    @Override
    public void setOperacaoAtual(Operacao operacaoAtual) {
        throw new UnsupportedOperationException("Read Only");
    }

    @Override
    public String getRecordId() {
        throw new UnsupportedOperationException("Nao implementado");
    }

    @Override
    public void setRecordId(String recordId) {
        throw new UnsupportedOperationException("Read Only");
    }

    @Override
    public Long getAtlRootId() {
        return operacao.getIdAtlRoot();
    }

    @Override
    public void setAtlRootId(Long atlRootId) {
        throw new UnsupportedOperationException("Read Only");
    }

    @Override
    public List<GrupoCesAutd> getListaGrupoCesAutd() {
        throw new UnsupportedOperationException("Nao implementado");
    }

    @Override
    public List<GrupoRenegcDiv> getListaGrupoRenegcDiv() {
        throw new UnsupportedOperationException("Nao implementado");
    }

    @Override
    public boolean isInterop() {
        return operacao.getIdEfeitoContrato() != null;
    }

    @Override
    public SPBString getIdentdNegcRecbvl() {
        return newSPBString(operacao.getIdNegcRecbvExtn());
    }

    @Override
    public void setIdentdNegcRecbvl(SPBString identdNegcRecbvl) {
        throw new UnsupportedOperationException("Nao implementado");
    }

    @Override
    public SPBString getIdentdOp() {
        return newSPBString(Long.toString(operacao.getIdOp()));
    }

    @Override
    public SPBString getIndrTpNegc() {
        return newSPBString(operacao.getIcTpNegc());
    }

    @Override
    public void setIndrTpNegc(SPBString indrTpNegc) {
        throw new UnsupportedOperationException("Nao implementado");
    }

    @Override
    public SPBLocalDate getDtVencOp() {
        return newSPBLocalDate(DateUtil.toLocalDate(operacao.getDtVencOp()));
    }

    @Override
    public void setDtVencOp(SPBLocalDate dtVencOp) {

    }

    @Override
    public SPBBigDecimal getVlrTotLimSldDevdr() {
        return newSPBBigDecimal(operacao.getNrLimConcdSldDevdr());
    }

    @Override
    public void setVlrTotLimSldDevdr(SPBBigDecimal vlrTotLimSldDevdr) {
        throw new UnsupportedOperationException("Nao implementado");
    }

    @Override
    public SPBString getIndrGestER() {
        return newSPBString(operacao.getIcGesteNtRegtdr());
    }

    @Override
    public SPBString getIndrRegrDivs() {
        return newSPBString(operacao.getIcRegrDivs());
    }

    @Override
    public void setIndrRegrDivs(SPBString indrRegrDivs) {
        throw new UnsupportedOperationException("Nao implementado");
    }

    @Override
    public SPBString getIndrActeIncondlOp() {
        return newSPBString(operacao.getIcActeOp());
    }

    @Override
    public SPBString getIndrIA() {
        return newSPBString(operacao.getIcTpOp());
    }

    @Override
    public void setIndrIA(SPBString indrIA) {
        throw new UnsupportedOperationException("Nao implementado");
    }

    @Override
    public GrupoGestER getGrupoGestER() {
        return grupoGestER;
    }

    @Override
    public GrupoGestPart getGrupoGestPart() {
        return null;
    }

    @Override
    public ProcessamentoNegociacao getProcessamentoNegociacao() {
        throw new UnsupportedOperationException("Nao implementado");
    }

    @Override
    public void setProcessamentoNegociacao(ProcessamentoNegociacao processamentoNegociacao) {
        throw new UnsupportedOperationException("Nao implementado");
    }

    @Override
    public List<String> getCnpjsRegistradoras() {
        throw new UnsupportedOperationException("Nao implementado");
    }

    @Override
    public void setCnpjsRegistradoras(List<String> cnpjsRegistradoras) {
        throw new UnsupportedOperationException("Read Only");
    }

    @Override
    public Set<String> getEstabelecimentosBloqueados() {
        return estabelecimentosBloqueados;
    }

    @Override
    public void setEstabelecimentosBloqueados(Set<String> estabelecimentosBloqueados) {
        this.estabelecimentosBloqueados = estabelecimentosBloqueados;
    }

    @Override
    public void setCredenciadorasAlcanceGeral(Set<String> credenciadorasAlcanceGeral) {
        this.credenciadorasAlcanceGeral = credenciadorasAlcanceGeral;
    }

    @Override
    public Set<String> getCredenciadorasAlcanceGeral() {
        return credenciadorasAlcanceGeral;
    }

    @Override
    public RecalculoObjetoParametro<Long> getRecalculoObjetoParametro() {
        return recalculoObjetoParametro;
    }

    @Override
    public void setRecalculoObjetoParametro(RecalculoObjetoParametro<Long> recalculoObjetoParametro) {
        this.recalculoObjetoParametro = recalculoObjetoParametro;
    }

    @Override
    public void setCredenciadorasArranjosOutrasIMFs(Map<String, Set<String>> credenciadorasArranjosOutrasIMFs) {
        this.credenciadorasArranjosOutrasIMFs = credenciadorasArranjosOutrasIMFs;
    }

    @Override
    public Map<String, Set<String>> getCredenciadorasArranjosOutrasIMFs() {
        return credenciadorasArranjosOutrasIMFs;
    }

    @Override
    public Long[] getIdsOpsRecalculo() {
        return idsOpsRecalculo;
    }

    @Override
    public void setIdsOpsRecalculo(Long[] idsOpsRecalculo) {
        this.idsOpsRecalculo = idsOpsRecalculo;
    }
}
