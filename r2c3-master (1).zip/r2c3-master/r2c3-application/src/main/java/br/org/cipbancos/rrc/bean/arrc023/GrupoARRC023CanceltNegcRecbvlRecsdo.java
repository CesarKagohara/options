package br.org.cipbancos.rrc.bean.arrc023;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

/**
 * @author anderson.martins
 * @since 1.0.0
 */
@XStreamAlias("Grupo_ARRC023RET_CanceltNegcRecbvlRecsdo")
public class GrupoARRC023CanceltNegcRecbvlRecsdo extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdentdNegcRecbvl")
    private SPBString identdNegcRecbvl;

    @XStreamAlias("IdentdOp")
    private SPBString identdOp;

    @XStreamAlias("CNPJ_CNPJBase_CPFTitlar")
    private SPBString cnpjCnpjBaseCpfTitlar;

    @XStreamAlias("IndrCancelVlrTotal")
    private SPBString indrCancelVlrTotal;

    @XStreamAlias("IndrLiquidOp")
    private SPBString indrLiquidOp;

    @XStreamAlias("IndrCancelCessConstitr")
    private SPBString indrCancelCessConstitr;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC023RET_RegRecbvl")
    private List<GrupoARRC023RegRecbvl> listaGrupoRRC0020RegRecbvl = new ArrayList<GrupoARRC023RegRecbvl>();

    public SPBString getIdentdNegcRecbvl() {
        return identdNegcRecbvl;
    }

    public void setIdentdNegcRecbvl(SPBString identdNegcRecbvl) {
        this.identdNegcRecbvl = identdNegcRecbvl;
    }

    public SPBString getIdentdOp() {
        return identdOp;
    }

    public void setIdentdOp(SPBString identdOp) {
        this.identdOp = identdOp;
    }

    public SPBString getCnpjCnpjBaseCpfTitlar() {
        return cnpjCnpjBaseCpfTitlar;
    }

    public void setCnpjCnpjBaseCpfTitlar(SPBString cnpjCnpjBaseCpfTitlar) {
        this.cnpjCnpjBaseCpfTitlar = cnpjCnpjBaseCpfTitlar;
    }

    public SPBString getIndrCancelVlrTotal() {
        return indrCancelVlrTotal;
    }

    public void setIndrCancelVlrTotal(SPBString indrCancelVlrTotal) {
        this.indrCancelVlrTotal = indrCancelVlrTotal;
    }

    public SPBString getIndrLiquidOp() {
        return indrLiquidOp;
    }

    public void setIndrLiquidOp(SPBString indrLiquidOp) {
        this.indrLiquidOp = indrLiquidOp;
    }

    public SPBString getIndrCancelCessConstitr() {
        return indrCancelCessConstitr;
    }

    public void setIndrCancelCessConstitr(SPBString indrCancelCessConstitr) {
        this.indrCancelCessConstitr = indrCancelCessConstitr;
    }

    public List<GrupoARRC023RegRecbvl> getListaGrupoRRC0020RegRecbvl() {
        return listaGrupoRRC0020RegRecbvl;
    }

    public void setListaGrupoRRC0020RegRecbvl(List<GrupoARRC023RegRecbvl> listaGrupoRRC0020RegRecbvl) {
        this.listaGrupoRRC0020RegRecbvl = listaGrupoRRC0020RegRecbvl;
    }
}
