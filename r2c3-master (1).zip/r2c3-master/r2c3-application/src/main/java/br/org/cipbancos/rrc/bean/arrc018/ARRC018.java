package br.org.cipbancos.rrc.bean.arrc018;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("ARRC018")
public class ARRC018 extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamAlias("CNPJER")
    private SPBString cNPJER;

    @XStreamAlias("CNPJCreddrSub")
    private SPBString cNPJCreddrSub;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC018_ArrajPgto")
    private List<GrupoARRC018ArrajPgto> listagrupoARRC018ArrajPgto = new ArrayList<>();

    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public SPBString getcNPJER() {
        return cNPJER;
    }

    public void setcNPJER(SPBString cNPJER) {
        this.cNPJER = cNPJER;
    }

    public SPBString getcNPJCreddrSub() {
        return cNPJCreddrSub;
    }

    public void setcNPJCreddrSub(SPBString cNPJCreddrSub) {
        this.cNPJCreddrSub = cNPJCreddrSub;
    }

    public List<GrupoARRC018ArrajPgto> getListagrupoARRC018ArrajPgto() {
        return listagrupoARRC018ArrajPgto;
    }

    public void setListagrupoARRC018ArrajPgto(List<GrupoARRC018ArrajPgto> listagrupoARRC018ArrajPgto) {
        this.listagrupoARRC018ArrajPgto = listagrupoARRC018ArrajPgto;
    }
}