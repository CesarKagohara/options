package br.org.cipbancos.rrc.bean.rrc0027;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_RRC0027_Contstc")
public class GrupoRRC0027Contstc extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdendPartOrigdrContstc")
    private SPBString idendPartOrigdrContstc;

    @XStreamAlias("IdendPartContstd")
    private SPBString idendPartContstd;

    @XStreamAlias("IdentdCtrlReqSolicte")
    private SPBString identdCtrlReqSolicte;

    @XStreamAlias("IdentdOpContstc")
    private SPBString identdOpContstc;

    @XStreamAlias("IndrMotvContstc")
    private SPBString indrMotvContstc;

    @XStreamAlias("DescContstc")
    private SPBString descContstc;

    @XStreamAlias("IdentdCtrlOptIn")
    private SPBString identdCtrlOptIn;

    @XStreamAlias("IdentdOp")
    private SPBString identdOp;

    public SPBString getIdendPartOrigdrContstc() {
        return idendPartOrigdrContstc;
    }

    public void setIdendPartOrigdrContstc(SPBString idendPartOrigdrContstc) {
        this.idendPartOrigdrContstc = idendPartOrigdrContstc;
    }

    public SPBString getIdendPartContstd() {
        return idendPartContstd;
    }

    public void setIdendPartContstd(SPBString idendPartContstd) {
        this.idendPartContstd = idendPartContstd;
    }

    public SPBString getIdentdCtrlReqSolicte() {
        return identdCtrlReqSolicte;
    }

    public void setIdentdCtrlReqSolicte(SPBString identdCtrlReqSolicte) {
        this.identdCtrlReqSolicte = identdCtrlReqSolicte;
    }

    public SPBString getIdentdOpContstc() {
        return identdOpContstc;
    }

    public void setIdentdOpContstc(SPBString identdOpContstc) {
        this.identdOpContstc = identdOpContstc;
    }

    public SPBString getIndrMotvContstc() {
        return indrMotvContstc;
    }

    public void setIndrMotvContstc(SPBString indrMotvContstc) {
        this.indrMotvContstc = indrMotvContstc;
    }

    public SPBString getDescContstc() {
        return descContstc;
    }

    public void setDescContstc(SPBString descContstc) {
        this.descContstc = descContstc;
    }

    public SPBString getIdentdCtrlOptIn() {
        return identdCtrlOptIn;
    }

    public void setIdentdCtrlOptIn(SPBString identdCtrlOptIn) {
        this.identdCtrlOptIn = identdCtrlOptIn;
    }

    public SPBString getIdentdOp() {
        return identdOp;
    }

    public void setIdentdOp(SPBString identdOp) {
        this.identdOp = identdOp;
    }
}
