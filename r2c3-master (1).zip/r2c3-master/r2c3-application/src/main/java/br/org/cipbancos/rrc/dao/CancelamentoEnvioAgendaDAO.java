package br.org.cipbancos.rrc.dao;

import java.util.Date;
import java.util.List;

import br.org.cipbancos.rrc.dominio.SituacaoAtivoInativo;
import br.org.cipbancos.rrc.vo.CancelEnvioAgenda;
import br.org.cipbancos.rrc.vo.CancelamentoEnvioAgenda;
import br.org.cipbancos.rrc.vo.OptOutVO;

public interface CancelamentoEnvioAgendaDAO {

    int inserirCancelamento(CancelEnvioAgenda cancelamentoEnvioAgenda);

    boolean optInCancelado(String identdOptIn);

    Long obterSeqNumeroControleOptOut();

    void atualizarCancelamentoOptIn(String identdOptIn, Date dataRef, Date dtFimOptIn, SituacaoAtivoInativo situacaoAtivoInativo);

    CancelamentoEnvioAgenda buscarInfoResumoDiario(Long idAtlRoot);

    OptOutVO buscarOptOutPorId(Long idOptOut);

    List<OptOutVO> buscarOptOutsPorId(Long idOptOut);
}
