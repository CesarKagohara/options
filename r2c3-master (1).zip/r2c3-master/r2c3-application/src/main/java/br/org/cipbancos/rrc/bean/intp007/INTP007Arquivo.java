package br.org.cipbancos.rrc.bean.intp007;

import br.org.cipbancos.rrc.bean.SPBBean;

public class INTP007Arquivo implements SPBBean {

    private String arquivo;

    private String recordId;

    public INTP007Arquivo(){
    }

    public INTP007Arquivo(String arquivo){
        this.arquivo = arquivo;
    }

    public String getArquivo() {
        return arquivo;
    }

    public void setArquivo(String arquivo) {
        this.arquivo = arquivo;
    }

    @Override
    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }
}
