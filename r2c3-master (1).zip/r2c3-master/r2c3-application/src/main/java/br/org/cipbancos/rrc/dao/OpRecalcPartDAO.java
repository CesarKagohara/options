package br.org.cipbancos.rrc.dao;

/**
 * Classe responsável por toda a manipulação de dados da tabela OP.
 */

import java.util.Date;
import java.util.List;

public interface OpRecalcPartDAO {

    List<Long> obterOperacoesParaRecalcular(Date dtRef);

    void iniciarProcessamento(Long idOp, Long idAtlRootReclc, Date dtRef);

    void fecharProcessamento(Long idOp, Long idAtlRootReclc, Date dtRef);

}
