package br.org.cipbancos.rrc.bean.arrc022;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_ARRC022RET_Titlar")
public class GrupoARRC022RETTitlar extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CNPJBase_CPFTitlar")
    private SPBString cNPJCNPJBaseCPFTitlar;

    @XStreamAlias("Vlr_PercTotOpUniddRecbvl")
    private SPBBigDecimal vlrPercTotOpUniddRecbvl;

    @XStreamAlias("DtIniOp")
    private SPBLocalDate dtIniOp;

    @XStreamAlias("DtFimOp")
    private SPBLocalDate dtFimOp;

    @XStreamAlias("CNPJ_CPFTitlarCt")
    private SPBString cNPJCPFTitlarCt;

    @XStreamAlias("ISPBBcoRecbdr")
    private SPBString iSPBBcoRecbdr;

    @XStreamAlias("TpCt")
    private SPBString tpCt;

    @XStreamAlias("Ag")
    private SPBString ag;

    @XStreamAlias("Ct")
    private SPBString ct;

    @XStreamAlias("CtPgto")
    private SPBString ctPgto;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC022RET_CreddrSub")
    private List<GrupoARRC022CreddrSub> listagrupoARRC022CreddrSub = new ArrayList<>();

    @XStreamImplicit(itemFieldName = "Grupo_ARRC022RET_ArrajPgto")
    private List<GrupoARRC022ArrajPgto> listagrupoARRC022ArrajPgto = new ArrayList<>();

    @XStreamImplicit(itemFieldName = "Grupo_ARRC022RET_UsuFinalRecbdr")
    private List<GrupoARRC022UsuFinalRecbdr> listagrupoARRC022UsuFinalRecbdr = new ArrayList<>();

    public SPBString getcNPJCNPJBaseCPFTitlar() {
        return cNPJCNPJBaseCPFTitlar;
    }

    public void setcNPJCNPJBaseCPFTitlar(SPBString cNPJCNPJBaseCPFTitlar) {
        this.cNPJCNPJBaseCPFTitlar = cNPJCNPJBaseCPFTitlar;
    }

    public SPBBigDecimal getVlrPercTotOpUniddRecbvl() {
        return vlrPercTotOpUniddRecbvl;
    }

    public void setVlrPercTotOpUniddRecbvl(SPBBigDecimal vlrPercTotOpUniddRecbvl) {
        this.vlrPercTotOpUniddRecbvl = vlrPercTotOpUniddRecbvl;
    }

    public SPBLocalDate getDtIniOp() {
        return dtIniOp;
    }

    public void setDtIniOp(SPBLocalDate dtIniOp) {
        this.dtIniOp = dtIniOp;
    }

    public SPBLocalDate getDtFimOp() {
        return dtFimOp;
    }

    public void setDtFimOp(SPBLocalDate dtFimOp) {
        this.dtFimOp = dtFimOp;
    }

    public SPBString getcNPJCPFTitlarCt() {
        return cNPJCPFTitlarCt;
    }

    public void setcNPJCPFTitlarCt(SPBString cNPJCPFTitlarCt) {
        this.cNPJCPFTitlarCt = cNPJCPFTitlarCt;
    }

    public SPBString getiSPBBcoRecbdr() {
        return iSPBBcoRecbdr;
    }

    public void setiSPBBcoRecbdr(SPBString iSPBBcoRecbdr) {
        this.iSPBBcoRecbdr = iSPBBcoRecbdr;
    }

    public SPBString getTpCt() {
        return tpCt;
    }

    public void setTpCt(SPBString tpCt) {
        this.tpCt = tpCt;
    }

    public SPBString getAg() {
        return ag;
    }

    public void setAg(SPBString ag) {
        this.ag = ag;
    }

    public SPBString getCt() {
        return ct;
    }

    public void setCt(SPBString ct) {
        this.ct = ct;
    }

    public SPBString getCtPgto() {
        return ctPgto;
    }

    public void setCtPgto(SPBString ctPgto) {
        this.ctPgto = ctPgto;
    }

    public List<GrupoARRC022CreddrSub> getListagrupoARRC022CreddrSub() {
        return listagrupoARRC022CreddrSub;
    }

    public void setListagrupoARRC022CreddrSub(List<GrupoARRC022CreddrSub> listagrupoARRC022CreddrSub) {
        this.listagrupoARRC022CreddrSub = listagrupoARRC022CreddrSub;
    }

    public List<GrupoARRC022ArrajPgto> getListagrupoARRC022ArrajPgto() {
        return listagrupoARRC022ArrajPgto;
    }

    public void setListagrupoARRC022ArrajPgto(List<GrupoARRC022ArrajPgto> listagrupoARRC022ArrajPgto) {
        this.listagrupoARRC022ArrajPgto = listagrupoARRC022ArrajPgto;
    }

    public List<GrupoARRC022UsuFinalRecbdr> getListagrupoARRC022UsuFinalRecbdr() {
        return listagrupoARRC022UsuFinalRecbdr;
    }

    public void setListagrupoARRC022UsuFinalRecbdr(List<GrupoARRC022UsuFinalRecbdr> listagrupoARRC022UsuFinalRecbdr) {
        this.listagrupoARRC022UsuFinalRecbdr = listagrupoARRC022UsuFinalRecbdr;
    }
}
