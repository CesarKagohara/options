package br.org.cipbancos.rrc.builder;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.arrc018.GrupoARRC018Titlar;
import br.org.cipbancos.rrc.util.CpfCnpjUtil;

import java.math.BigDecimal;

public class GrupoARRC018TitlarBuilder {

    private GrupoARRC018Titlar grupoARRC018Titlar;

    private GrupoARRC018TitlarBuilder(){
        this.grupoARRC018Titlar = new GrupoARRC018Titlar();
    }

    public static GrupoARRC018TitlarBuilder builder(){
        return new GrupoARRC018TitlarBuilder();
    }

    public GrupoARRC018TitlarBuilder comValorLivreTotal(BigDecimal valorLivreTotal){
        if (valorLivreTotal != null) {
            grupoARRC018Titlar.setVlrLivreTot(new SPBBigDecimal(valorLivreTotal));
        }
        return this;
    }

    public GrupoARRC018TitlarBuilder comValorLivreAntecCredenciadora(BigDecimal valorLivreAntecCredenciadora){
        if (valorLivreAntecCredenciadora != null) {
            grupoARRC018Titlar.setVlrLivreAntecCreddrSub(new SPBBigDecimal(valorLivreAntecCredenciadora));
        }
        return this;
    }

    public GrupoARRC018TitlarBuilder comValorPreContratado(BigDecimal valorPreContratado){
        if (valorPreContratado != null) {
            grupoARRC018Titlar.setVlrPreContrd(new SPBBigDecimal(valorPreContratado));
        }
        return this;
    }

    public GrupoARRC018TitlarBuilder comValorOnusResTec(BigDecimal valorOnusResTec) {
        if (valorOnusResTec != null) {
            grupoARRC018Titlar.setVlrOnusResTec(new SPBBigDecimal(valorOnusResTec));
        }
        return this;
    }

    public GrupoARRC018TitlarBuilder comCpfCnpjTitular(String cpfCnpjTitular){
        if (cpfCnpjTitular != null) {
            grupoARRC018Titlar.setcNPJCPFTitular(new SPBString(CpfCnpjUtil.formataCnpjOuCpf(cpfCnpjTitular)));
        }
        return this;
    }

    public GrupoARRC018TitlarBuilder comValorTotalTitular(BigDecimal valorTotalTitular){
        if (valorTotalTitular != null) {
            grupoARRC018Titlar.setVlrTotTitlar(new SPBBigDecimal(valorTotalTitular));
        }
        return this;
    }

    public GrupoARRC018TitlarBuilder comValorComprometidoOutraInstituicao(BigDecimal valorComprometidoOutraInstituicao){
        if (valorComprometidoOutraInstituicao != null) {
            grupoARRC018Titlar.setVlrComprtdOutrInst(new SPBBigDecimal(valorComprometidoOutraInstituicao));
        }
        return this;
    }

    public GrupoARRC018TitlarBuilder comValorComprometidoInstituicao(BigDecimal valorComprometidoInstituicao){
        if (valorComprometidoInstituicao != null) {
            grupoARRC018Titlar.setVlrComprtdInst(new SPBBigDecimal(valorComprometidoInstituicao));
        }
        return this;
    }

    public GrupoARRC018Titlar build(){
        return this.grupoARRC018Titlar;
    }
}
