package br.org.cipbancos.rrc.builder;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.arrc018.GrupoARRC018UsuFinalRecbdr;

import java.math.BigDecimal;

public class GrupoARRC018UsuFinalRecbdrBuilder {

    private GrupoARRC018UsuFinalRecbdr grupoARRC018UsuFinalRecbdr;

    private GrupoARRC018UsuFinalRecbdrBuilder(){
        this.grupoARRC018UsuFinalRecbdr = new GrupoARRC018UsuFinalRecbdr();
    }

    public static GrupoARRC018UsuFinalRecbdrBuilder builder(){
        return new GrupoARRC018UsuFinalRecbdrBuilder();
    }

    public GrupoARRC018UsuFinalRecbdrBuilder comCpfCnpjUsuarioFinalRecebedor(String cpfCnpjUsuarioFinalRecebedor){
        if (cpfCnpjUsuarioFinalRecebedor != null) {
            this.grupoARRC018UsuFinalRecbdr.setcNPJCPFUsuFinalRecbdr(new SPBString(cpfCnpjUsuarioFinalRecebedor));
        }
        return this;
    }

    public GrupoARRC018UsuFinalRecbdrBuilder comValorLivreUsuFinalRecbdr(BigDecimal valorLivreUsuFinalRecbdr){
        if (valorLivreUsuFinalRecbdr != null) {
            this.grupoARRC018UsuFinalRecbdr.setVlrLivreUsuFinalRecbdr(new SPBBigDecimal(valorLivreUsuFinalRecbdr));
        }
        return this;
    }

    public GrupoARRC018UsuFinalRecbdr build(){
        return this.grupoARRC018UsuFinalRecbdr;
    }
}