package br.org.cipbancos.rrc.bean;

import java.io.Serializable;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

public interface GrupoCesAutd extends Serializable {

    SPBString getCNPJCPFCesAutd();
}
