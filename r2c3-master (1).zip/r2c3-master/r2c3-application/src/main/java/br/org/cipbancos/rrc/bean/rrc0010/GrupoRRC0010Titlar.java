package br.org.cipbancos.rrc.bean.rrc0010;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_RRC0010_Titlar")
public class GrupoRRC0010Titlar extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CPFTitlar")
    private SPBString cNPJCPFTitlar;

    @XStreamAlias("VlrTotTitlar")
    private SPBBigDecimal vlrTotTitlar;

    @XStreamAlias("VlrComprtdOutrInst")
    private SPBBigDecimal vlrComprtdOutrInst;

    @XStreamAlias("VlrComprtdInst")
    private SPBBigDecimal vlrComprtdInst;

    @XStreamAlias("VlrLivreTot")
    private SPBBigDecimal vlrLivreTot;

    @XStreamAlias("VlrLivreAntecCreddrSub")
    private SPBBigDecimal vlrLivreAntecCreddrSub;

    @XStreamAlias("VlrPreContrd")
    private SPBBigDecimal vlrPreContrd;

    @XStreamAlias("VlrOnusResTec")
    private SPBBigDecimal vlrOnusResTec;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0010R1_DomclBancInst")
    private List<GrupoRRC0010R1DomclBancInst> listagrupoRRC0010R1DomclBancInst = new ArrayList<GrupoRRC0010R1DomclBancInst>();

    @XStreamImplicit(itemFieldName = "Grupo_RRC0010R1_NegcRecbvOutrasInst")
    private List<GrupoRRC0010R1NegcRecbvOutrasInst> listagrupoRRC0010R1NegcRecbvOutrasInst = new ArrayList<GrupoRRC0010R1NegcRecbvOutrasInst>();

    public SPBString getCNPJCPFTitlar() {
        return cNPJCPFTitlar;
    }

    public void setCNPJCPFTitlar(SPBString cNPJCPFTitlar) {
        this.cNPJCPFTitlar = cNPJCPFTitlar;
    }

    public SPBBigDecimal getVlrTotTitlar() {
        return vlrTotTitlar;
    }

    public void setVlrTotTitlar(SPBBigDecimal vlrTotTitlar) {
        this.vlrTotTitlar = vlrTotTitlar;
    }

    public SPBBigDecimal getVlrComprtdOutrInst() {
        return vlrComprtdOutrInst;
    }

    public void setVlrComprtdOutrInst(SPBBigDecimal vlrComprtdOutrInst) {
        this.vlrComprtdOutrInst = vlrComprtdOutrInst;
    }

    public SPBBigDecimal getVlrComprtdInst() {
        return vlrComprtdInst;
    }

    public void setVlrComprtdInst(SPBBigDecimal vlrComprtdInst) {
        this.vlrComprtdInst = vlrComprtdInst;
    }

    public SPBBigDecimal getVlrLivreTot() {
        return vlrLivreTot;
    }

    public void setVlrLivreTot(SPBBigDecimal vlrLivreTot) {
        this.vlrLivreTot = vlrLivreTot;
    }

    public SPBBigDecimal getVlrLivreAntecCreddrSub() {
        return vlrLivreAntecCreddrSub;
    }

    public void setVlrLivreAntecCreddrSub(SPBBigDecimal vlrLivreAntecCreddrSub) {
        this.vlrLivreAntecCreddrSub = vlrLivreAntecCreddrSub;
    }

    public SPBBigDecimal getVlrPreContrd() {
        return vlrPreContrd;
    }

    public void setVlrPreContrd(SPBBigDecimal vlrPreContrd) {
        this.vlrPreContrd = vlrPreContrd;
    }

    public SPBBigDecimal getVlrOnusResTec() {
        return vlrOnusResTec;
    }

    public void setVlrOnusResTec(SPBBigDecimal vlrOnusResTec) {
        this.vlrOnusResTec = vlrOnusResTec;
    }

    public List<GrupoRRC0010R1DomclBancInst> getListagrupoRRC0010R1DomclBancInst() {
        return listagrupoRRC0010R1DomclBancInst;
    }

    public void setListagrupoRRC0010R1DomclBancInst(List<GrupoRRC0010R1DomclBancInst> listagrupoRRC0010R1DomclBancInst) {
        this.listagrupoRRC0010R1DomclBancInst = listagrupoRRC0010R1DomclBancInst;
    }

    public List<GrupoRRC0010R1NegcRecbvOutrasInst> getListagrupoRRC0010R1NegcRecbvOutrasInst() {
        return listagrupoRRC0010R1NegcRecbvOutrasInst;
    }

    public void setListagrupoRRC0010R1NegcRecbvOutrasInst(List<GrupoRRC0010R1NegcRecbvOutrasInst> listagrupoRRC0010R1NegcRecbvOutrasInst) {
        this.listagrupoRRC0010R1NegcRecbvOutrasInst = listagrupoRRC0010R1NegcRecbvOutrasInst;
    }

}
