package br.org.cipbancos.rrc.bean;


import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;

public abstract class PartPrincPartAdmComGrNegRec extends ErrorCodeBean implements PartPrincXPartAdm {

    public abstract GrupoConsultaNegcRecbvl getGrupoNegcRecbvl();
}
