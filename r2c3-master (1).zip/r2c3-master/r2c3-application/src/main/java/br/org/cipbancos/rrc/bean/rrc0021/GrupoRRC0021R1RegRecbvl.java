package br.org.cipbancos.rrc.bean.rrc0021;

import java.io.Serializable;

import br.org.cipbancos.atlante.xmlbinder.spb.*;
import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("Grupo_RRC0021R1_RegRecbvl")
public class GrupoRRC0021R1RegRecbvl extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("PriorddNegcRecbvl")
    private SPBInteger priorddNegcRecbvl;

    @XStreamAlias("CNPJCreddrSub")
    private SPBString cNPJCreddrSub;

    @XStreamAlias("CNPJ_CPFUsuFinalRecbdr")
    private SPBString cNPJCPFUsuFinalRecbdr;

    @XStreamAlias("CodInstitdrArrajPgto")
    private SPBString codInstitdrArrajPgto;

    @XStreamAlias("DtPrevtLiquid")
    private SPBLocalDate dtPrevtLiquid;

    @XStreamAlias("VlrNegcd")
    private SPBBigDecimal vlrNegcd;

    public SPBInteger getPriorddNegcRecbvl() {
        return priorddNegcRecbvl;
    }

    public void setPriorddNegcRecbvl(SPBInteger priorddNegcRecbvl) {
        this.priorddNegcRecbvl = priorddNegcRecbvl;
    }

    public SPBString getCNPJCreddrSub() {
        return cNPJCreddrSub;
    }

    public void setCNPJCreddrSub(SPBString cNPJCreddrSub) {
        this.cNPJCreddrSub = cNPJCreddrSub;
    }

    public SPBString getCNPJCPFUsuFinalRecbdr() {
        return cNPJCPFUsuFinalRecbdr;
    }

    public void setCNPJCPFUsuFinalRecbdr(SPBString cNPJCPFUsuFinalRecbdr) {
        this.cNPJCPFUsuFinalRecbdr = cNPJCPFUsuFinalRecbdr;
    }

    public SPBString getCodInstitdrArrajPgto() {
        return codInstitdrArrajPgto;
    }

    public void setCodInstitdrArrajPgto(SPBString codInstitdrArrajPgto) {
        this.codInstitdrArrajPgto = codInstitdrArrajPgto;
    }

    public SPBLocalDate getDtPrevtLiquid() {
        return dtPrevtLiquid;
    }

    public void setDtPrevtLiquid(SPBLocalDate dtPrevtLiquid) {
        this.dtPrevtLiquid = dtPrevtLiquid;
    }

    public SPBBigDecimal getVlrNegcd() {
        return vlrNegcd;
    }

    public void setVlrNegcd(SPBBigDecimal vlrNegcd) {
        this.vlrNegcd = vlrNegcd;
    }

}
