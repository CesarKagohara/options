package br.org.cipbancos.rrc.builder;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.rrc.bean.arrc018.GrupoARRC018UniddRecbvl2;
import br.org.cipbancos.rrc.util.DateUtil;

import java.math.BigDecimal;
import java.util.Date;

public class GrupoARRC018UniddRecbvl2Builder {

    private GrupoARRC018UniddRecbvl2 grupoARRC018UniddRecbvl2;

    private GrupoARRC018UniddRecbvl2Builder(){
        this.grupoARRC018UniddRecbvl2 = new GrupoARRC018UniddRecbvl2();
    }

    public static GrupoARRC018UniddRecbvl2Builder builder(){
        return new GrupoARRC018UniddRecbvl2Builder();
    }

    public GrupoARRC018UniddRecbvl2Builder comDataPrevistaLiquidacao(Date dataPrevistatLiquidacao){
        this.grupoARRC018UniddRecbvl2.setDtPrevtLiquid(new SPBLocalDate(DateUtil.toLocalDate(dataPrevistatLiquidacao)));
        return this;
    }

    public GrupoARRC018UniddRecbvl2Builder comValorLivreTotal(BigDecimal valorLivreTotal){
        if (valorLivreTotal != null) {
            this.grupoARRC018UniddRecbvl2.setVlrLivreTot(new SPBBigDecimal(valorLivreTotal));
        }
        return this;
    }

    public GrupoARRC018UniddRecbvl2Builder comValorComprometidoOutraInstituicao(BigDecimal valorComprometidoOutraInstituicao){
        if (valorComprometidoOutraInstituicao != null) {
            this.grupoARRC018UniddRecbvl2.setVlrComprtdOutrInst(new SPBBigDecimal(valorComprometidoOutraInstituicao));
        }
        return this;
    }

    public GrupoARRC018UniddRecbvl2Builder comValorComprometidoInstituicao(BigDecimal valorComprometidoInstituicao){
        if (valorComprometidoInstituicao != null) {
            this.grupoARRC018UniddRecbvl2.setVlrComprtdInst(new SPBBigDecimal(valorComprometidoInstituicao));
        }
        return this;
    }

    public GrupoARRC018UniddRecbvl2Builder comValorLivreAntecCredenciadora(BigDecimal valorLivreAntecCredenciadora){
        if (valorLivreAntecCredenciadora != null) {
            this.grupoARRC018UniddRecbvl2.setVlrLivreAntecCreddrSub(new SPBBigDecimal(valorLivreAntecCredenciadora));
        }
        return this;
    }

    public GrupoARRC018UniddRecbvl2Builder comValorPreContratado(BigDecimal valorPreContratado){
        if (valorPreContratado != null) {
            this.grupoARRC018UniddRecbvl2.setVlrPreContrd(new SPBBigDecimal(valorPreContratado));
        }
        return this;
    }

    public GrupoARRC018UniddRecbvl2Builder comValorOnusResTec(BigDecimal valorOnusResTec){
        if (valorOnusResTec != null) {
            this.grupoARRC018UniddRecbvl2.setVlrOnusResTec(new SPBBigDecimal(valorOnusResTec));
        }
        return this;
    }

    public GrupoARRC018UniddRecbvl2Builder comValorTotalTitular(BigDecimal valorTotalTitular){
        if (valorTotalTitular != null) {
            this.grupoARRC018UniddRecbvl2.setVlrTotTitlar(new SPBBigDecimal(valorTotalTitular));
        }
        return this;
    }

    public GrupoARRC018UniddRecbvl2 build(){
        return this.grupoARRC018UniddRecbvl2;
    }
}