package br.org.cipbancos.rrc.bean.arrc022;

import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoDomclBanc;

@XStreamAlias("Grupo_ARRC022_DomclBanc")
public class GrupoARRC022DomclBanc extends ErrorCodeBean implements GrupoDomclBanc {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CPFTitlarCt")
    private SPBString cNPJCPFTitlarCt;

    @XStreamAlias("ISPBBcoRecbdr")
    private SPBString iSPBBcoRecbdr;

    @XStreamAlias("TpCt")
    private SPBString tpCt;

    @XStreamAlias("Ag")
    private SPBString ag;

    @XStreamAlias("Ct")
    private SPBString ct;

    @XStreamAlias("CtPgto")
    private SPBString ctPgto;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC022_RegRecbvl")
    private List<GrupoARRC022RegRecbvl> listagrupoARRC022RegRecbvl = new ArrayList<GrupoARRC022RegRecbvl>();

    public SPBString getCNPJCPFTitlarCt() {
        return cNPJCPFTitlarCt;
    }

    public void setCNPJCPFTitlarCt(SPBString cNPJCPFTitlarCt) {
        this.cNPJCPFTitlarCt = cNPJCPFTitlarCt;
    }

    public SPBString getISPBBcoRecbdr() {
        return iSPBBcoRecbdr;
    }

    public void setISPBBcoRecbdr(SPBString iSPBBcoRecbdr) {
        this.iSPBBcoRecbdr = iSPBBcoRecbdr;
    }

    public SPBString getTpCt() {
        return tpCt;
    }

    public void setTpCt(SPBString tpCt) {
        this.tpCt = tpCt;
    }

    public SPBString getAg() {
        return ag;
    }

    public void setAg(SPBString ag) {
        this.ag = ag;
    }

    public SPBString getCt() {
        return ct;
    }

    public void setCt(SPBString ct) {
        this.ct = ct;
    }

    public SPBString getCtPgto() {
        return ctPgto;
    }

    public void setCtPgto(SPBString ctPgto) {
        this.ctPgto = ctPgto;
    }

    public List<GrupoARRC022RegRecbvl> getListagrupoARRC022RegRecbvl() {
        return listagrupoARRC022RegRecbvl;
    }

    public void setListagrupoARRC022RegRecbvl(List<GrupoARRC022RegRecbvl> listagrupoARRC022RegRecbvl) {
        this.listagrupoARRC022RegRecbvl = listagrupoARRC022RegRecbvl;
    }

    @Override
    public List getListaGrupoRegRecbvl() {
        return getListagrupoARRC022RegRecbvl();
    }
}
