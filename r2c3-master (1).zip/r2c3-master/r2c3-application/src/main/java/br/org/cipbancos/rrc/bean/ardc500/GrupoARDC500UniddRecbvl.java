package br.org.cipbancos.rrc.bean.ardc500;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;

@XStreamAlias("Grupo_ARDC500_UniddRecbvl")
public class GrupoARDC500UniddRecbvl extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("DtPrevtLiquid")
    private LocalDate dtPrevtLiquid;

    @XStreamAlias("VlrTot")
    private BigDecimal vlrTot;

    @XStreamAlias("VlrPrevtPreContrd")
    private BigDecimal vlrPrevtPreContrd;

    @XStreamAlias("IndrTpOp")
    private String indrTpOp;

    @XStreamImplicit(itemFieldName = "Grupo_ARDC500_DomclBanc")
    private List<GrupoARDC500DomclBanc> listagrupoARDC500DomclBanc = new ArrayList<>();

    @XStreamAlias("Grupo_ARDC500_OnusRes")
    private GrupoARDC500OnusResBanc grupoARDC3001OnusRes;

    public LocalDate getDtPrevtLiquid() {
        return dtPrevtLiquid;
    }

    public void setDtPrevtLiquid(LocalDate dtPrevtLiquid) {
        this.dtPrevtLiquid = dtPrevtLiquid;
    }

    public BigDecimal getVlrTot() {
        return vlrTot;
    }

    public void setVlrTot(BigDecimal vlrTot) {
        this.vlrTot = vlrTot;
    }

    public BigDecimal getVlrPrevtPreContrd() {
        return vlrPrevtPreContrd;
    }

    public void setVlrPrevtPreContrd(BigDecimal vlrPrevtPreContrd) {
        this.vlrPrevtPreContrd = vlrPrevtPreContrd;
    }

    public String getIndrTpOp() {
        return indrTpOp;
    }

    public void setIndrTpOp(String indrTpOp) {
        this.indrTpOp = indrTpOp;
    }

    public List<GrupoARDC500DomclBanc> getListagrupoARDC500DomclBanc() {
        return listagrupoARDC500DomclBanc;
    }

    public void setListagrupoARDC500DomclBanc(List<GrupoARDC500DomclBanc> listagrupoARDC500DomclBanc) {
        this.listagrupoARDC500DomclBanc = listagrupoARDC500DomclBanc;
    }

    public GrupoARDC500OnusResBanc getGrupoARDC3001OnusRes() {
        return grupoARDC3001OnusRes;
    }

    public void setGrupoARDC3001OnusRes(GrupoARDC500OnusResBanc grupoARDC3001OnusRes) {
        this.grupoARDC3001OnusRes = grupoARDC3001OnusRes;
    }

}
