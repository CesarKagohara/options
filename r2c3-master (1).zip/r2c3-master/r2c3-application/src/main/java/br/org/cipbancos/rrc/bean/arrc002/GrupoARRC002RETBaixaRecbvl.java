package br.org.cipbancos.rrc.bean.arrc002;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_ARRC002_BaixaRecbvl")
public class GrupoARRC002RETBaixaRecbvl extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamAlias("SitRetReq")
    private SPBString sitRetReq;

    @XStreamAlias("MotvRecs")
    private SPBString motvRecs;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC002_RegRecbvlBaixaActo")
    private List<GrupoARRC002RegRecbvlBaixaActo> listagrupoARRC002RegRecbvlBaixaActo = new ArrayList<>();

    @XStreamImplicit(itemFieldName = "Grupo_ARRC002_RegRecbvlBaixaRecsdo")
    private List<GrupoARRC002RegRecbvlBaixaRecsdo> listagrupoARRC002RegRecbvlBaixaRecsdo = new ArrayList<>();

    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public SPBString getSitRetReq() {
        return sitRetReq;
    }

    public void setSitRetReq(SPBString sitRetReq) {
        this.sitRetReq = sitRetReq;
    }

    public SPBString getMotvRecs() {
        return motvRecs;
    }

    public void setMotvRecs(SPBString motvRecs) {
        this.motvRecs = motvRecs;
    }

    public List<GrupoARRC002RegRecbvlBaixaActo> getListagrupoARRC002RegRecbvlBaixaActo() {
        return listagrupoARRC002RegRecbvlBaixaActo;
    }

    public void setListagrupoARRC002RegRecbvlBaixaActo(List<GrupoARRC002RegRecbvlBaixaActo> listagrupoARRC002RegRecbvlBaixaActo) {
        this.listagrupoARRC002RegRecbvlBaixaActo = listagrupoARRC002RegRecbvlBaixaActo;
    }

    public List<GrupoARRC002RegRecbvlBaixaRecsdo> getListagrupoARRC002RegRecbvlBaixaRecsdo() {
        return listagrupoARRC002RegRecbvlBaixaRecsdo;
    }

    public void setListagrupoARRC002RegRecbvlBaixaRecsdo(List<GrupoARRC002RegRecbvlBaixaRecsdo> listagrupoARRC002RegRecbvlBaixaRecsdo) {
        this.listagrupoARRC002RegRecbvlBaixaRecsdo = listagrupoARRC002RegRecbvlBaixaRecsdo;
    }
}
