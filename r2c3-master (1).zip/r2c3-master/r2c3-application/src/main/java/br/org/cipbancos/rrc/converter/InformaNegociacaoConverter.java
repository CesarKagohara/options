package br.org.cipbancos.rrc.converter;

import java.math.BigDecimal;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBInteger;
import org.apache.commons.lang3.StringUtils;

import br.org.cipbancos.atlante.util.PartyUtility;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.rrc0003.GrupoRRC0003Constitr;
import br.org.cipbancos.rrc.bean.rrc0003.GrupoRRC0003DomclBanc;
import br.org.cipbancos.rrc.bean.rrc0003.GrupoRRC0003RegRecbvl;
import br.org.cipbancos.rrc.bean.rrc0003.GrupoRRC0003Titlar;
import br.org.cipbancos.rrc.bean.rrc0003.RRC0003;
import br.org.cipbancos.rrc.bean.rrc0009.GrupoRRC0009Constitr;
import br.org.cipbancos.rrc.bean.rrc0009.GrupoRRC0009DomiclBanc;
import br.org.cipbancos.rrc.bean.rrc0009.GrupoRRC0009RegRecbvl;
import br.org.cipbancos.rrc.bean.rrc0009.GrupoRRC0009Titlar;
import br.org.cipbancos.rrc.bean.rrc0009.RRC0009;
import br.org.cipbancos.rrc.enums.TipoConta;
import br.org.cipbancos.rrc.enums.TipoFuncionalidade;
import br.org.cipbancos.rrc.funcional.Converter;
import br.org.cipbancos.rrc.util.CpfCnpjUtil;
import br.org.cipbancos.rrc.util.R2C3SPBUtil;
import br.org.cipbancos.rrc.vo.FracaoUnidadeRecebivelOperacao;
import br.org.cipbancos.rrc.vo.Operacao;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilio;
import br.org.cipbancos.rrc.vo.PartAdmPrincVO;

/**
 * Classe utilitária para converter informações de Contestações.
 *
 * @author otavio.ferreira
 * @since 1.0
 */
public class InformaNegociacaoConverter {

    private InformaNegociacaoConverter() {
    }

    public static Converter<Operacao, RRC0003> emRRC003(PartAdmPrincVO partAdmPrincVO) {
        return origem -> {
            RRC0003 destino = new RRC0003();

            destino.setCodMsg(new SPBString(TipoFuncionalidade.RRC0003.getValue()));
            destino.setIdentdPartPrincipal(SPBConverter.stringToSPBString(partAdmPrincVO.getCodIspbPrinc()));
            destino.setIdentdPartAdmtd(SPBConverter.stringToSPBString(partAdmPrincVO.getCodIspbAdm()));
            destino.setcNPJER(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(origem.getNrCnpjRegtdr())));
            destino.setIdentdOp(SPBConverter.stringToSPBString(origem.getIdOp().toString().equals("0") ?
                    "0000000000000000000" : origem.getIdOp().toString()));

            String identNegoc = origem.getIdNegcRecbvExtn();
            if(StringUtils.isBlank(identNegoc)) {
                identNegoc = origem.getIdEfeitoContrato();
            }
            destino.setIdentdNegcRecbvl(SPBConverter.stringToSPBString(identNegoc));
            destino.setIndrTpNegc(SPBConverter.stringToSPBString(origem.getIcTpNegc()));
            destino.setIndrIA(SPBConverter.stringToSPBString(origem.getIcTpOp()));
            destino.setIndrActeUniddRecbvlReserv(SPBConverter.stringToSPBString("N"));
            destino.setDtHrIncl(SPBConverter.dateTimeToSPBLocalDateTime(origem.getDhIncl().toDateTime(), "yyyy-MM-dd'T'HH:mm:ss"));
            destino.setIndrRegrDivs(SPBConverter.stringToSPBString(origem.getIcRegrDivs()));
            if(origem.getIcAutcCess() != null ) {
                destino.setIndrAutcCess(SPBConverter.stringToSPBString(origem.getIcAutcCess()));
            } else {
                destino.setIndrAutcCess(SPBConverter.stringToSPBString("N"));
            }
            return destino;
        };
    }

    public static Converter<OperacaoTitularDomicilio, GrupoRRC0003Titlar> emRRC003Titular() {
        return origem -> {
            GrupoRRC0003Titlar destino = new GrupoRRC0003Titlar();

            String cnpfCnpjTitular = origem.getNrCpfCnpjTitular();
            if (CpfCnpjUtil.validaCnpj(cnpfCnpjTitular)) {
                destino.setCNPJCNPJBaseCPFTitlar(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(cnpfCnpjTitular)));
            } else if (CpfCnpjUtil.validaCpf(cnpfCnpjTitular)) {
                destino.setCNPJCNPJBaseCPFTitlar(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCpf(cnpfCnpjTitular)));
            } else {
                destino.setCNPJCNPJBaseCPFTitlar(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpjBase(cnpfCnpjTitular)));
            }

            return destino;
        };
    }

    public static Converter<OperacaoTitularDomicilio, GrupoRRC0009Titlar> emRRC009Titular() {
        return origem -> {
            GrupoRRC0009Titlar destino = new GrupoRRC0009Titlar();

            String cnpfCnpjTitular = origem.getNrCpfCnpjTitular();
            if (CpfCnpjUtil.validaCnpj(cnpfCnpjTitular)) {
                destino.setCnpjCnpjBaseCpfTitlar(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(cnpfCnpjTitular)));
            } else if (CpfCnpjUtil.validaCpf(cnpfCnpjTitular)) {
                destino.setCnpjCnpjBaseCpfTitlar(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCpf(cnpfCnpjTitular)));
            } else {
                destino.setCnpjCnpjBaseCpfTitlar(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpjBase(cnpfCnpjTitular)));
            }
            return destino;
        };
    }

    public static Converter<OperacaoTitularDomicilio, GrupoRRC0003DomclBanc> emRRC003TitularDomicilio() {
        return origem -> {
            GrupoRRC0003DomclBanc destino = new GrupoRRC0003DomclBanc();

            String nrCpfCnpjTitularConta = origem.getNrCpfCnpjTitularConta();
            if (CpfCnpjUtil.validaCnpj(nrCpfCnpjTitularConta)) {
                destino.setcNPJCPFTitlarCt(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(nrCpfCnpjTitularConta)));
            } else {
                destino.setcNPJCPFTitlarCt(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCpf(nrCpfCnpjTitularConta)));
            }

            destino.setiSPBBcoRecbdr(SPBConverter.stringToSPBString(PartyUtility.partyIdToIspb(Integer.parseInt(origem.getIspbBancoRecebedor()))));
            destino.setTpCt(SPBConverter.stringToSPBString(origem.getTipoConta()));

            TipoConta tipoConta = TipoConta.fromString(origem.getTipoConta());
            if (null != origem.getAgencia())
                destino.setAg(SPBConverter
                        .stringToSPBString(StringUtils.leftPad(origem.getAgencia().toString(), 4, "0")));

            if (null != origem.getConta() && !tipoConta.equals(TipoConta.CONTA_PAGAMENTO))
                destino.setCt(SPBConverter
                        .stringToSPBString(StringUtils.leftPad(origem.getConta().toString(), 13, "0")));

            if (null != origem.getContaPagamento() && tipoConta.equals(TipoConta.CONTA_PAGAMENTO))
                destino.setCtPgto(SPBConverter
                        .stringToSPBString(StringUtils.leftPad(origem.getContaPagamento(), 20, "0")));

            return destino;
        };
    }

    public static Converter<OperacaoTitularDomicilio, GrupoRRC0009DomiclBanc> emRRC009TitularDomicilio() {
        return origem -> {
            GrupoRRC0009DomiclBanc destino = new GrupoRRC0009DomiclBanc();

            String nrCpfCnpjTitularConta = origem.getNrCpfCnpjTitularConta();
            if (CpfCnpjUtil.validaCnpj(nrCpfCnpjTitularConta)) {
                destino.setCnpjCpfTitlarCt(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(nrCpfCnpjTitularConta)));
            } else {
                destino.setCnpjCpfTitlarCt(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCpf(nrCpfCnpjTitularConta)));
            }

            destino.setIspbBcoRecbdr(SPBConverter.stringToSPBString(PartyUtility.partyIdToIspb(Integer.parseInt(origem.getIspbBancoRecebedor()))));
            destino.setTpCt(SPBConverter.stringToSPBString(origem.getTipoConta()));

            TipoConta tipoConta = TipoConta.fromString(origem.getTipoConta());
            if (null != origem.getAgencia()) {
                destino.setAg(SPBConverter.integerToSPBInteger(origem.getAgencia()));
            }

            if (null != origem.getConta() && !tipoConta.equals(TipoConta.CONTA_PAGAMENTO)) {
                destino.setCt(new SPBString(String.format("%013d", origem.getConta())));
            }

            if (null != origem.getContaPagamento() && tipoConta.equals(TipoConta.CONTA_PAGAMENTO)) {
                destino.setCtPgto(new SPBString(StringUtils.leftPad(origem.getContaPagamento(), 20, '0')));
            }

            return destino;
        };
    }

    public static Converter<FracaoUnidadeRecebivelOperacao, GrupoRRC0003Constitr> emRRC003UrAConstituir() {
        return origem -> {
            GrupoRRC0003Constitr destino = new GrupoRRC0003Constitr();

            destino.setPriorddNegcRecbvl(new SPBInteger(origem.getNrPridd()));

            String nrCpfCnpjTitlar = origem.getNrCpfCnpjTitlar();
            if (CpfCnpjUtil.validaCnpj(nrCpfCnpjTitlar)) {
                destino.setcNPJCNPJBaseCPFTitlar(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(nrCpfCnpjTitlar)));
            } else if (CpfCnpjUtil.validaCpf(nrCpfCnpjTitlar)) {
                destino.setcNPJCNPJBaseCPFTitlar(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCpf(nrCpfCnpjTitlar)));
            } else {
                destino.setcNPJCNPJBaseCPFTitlar(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpjBase(nrCpfCnpjTitlar)));
            }

            String nrCpfCnpjUsuarioFinalRec = origem.getNrCpfCnpjUsurioFinlRecbdr();
            if (CpfCnpjUtil.validaCnpj(nrCpfCnpjUsuarioFinalRec)) {
                destino.setcNPJCNPJBaseCPFUsuFinalRecbdr(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(nrCpfCnpjUsuarioFinalRec)));
            } else if (CpfCnpjUtil.validaCpf(nrCpfCnpjUsuarioFinalRec)) {
                destino.setcNPJCNPJBaseCPFUsuFinalRecbdr(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCpf(nrCpfCnpjUsuarioFinalRec)));
            } else {
                destino.setcNPJCNPJBaseCPFUsuFinalRecbdr(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpjBase(nrCpfCnpjUsuarioFinalRec)));
            }

            destino.setCodInstitdrArrajPgto(SPBConverter.stringToSPBString(origem.getCdArrjPgto()));
            destino.setDtPrevtLiquid(SPBConverter.dateToSPBLocalDate(origem.getDtPrevtLiquid()));
            destino.setVlrPercNegcd(SPBConverter.stringToSPBBigDecimal(origem.getNrVlrPrevtLiquid().toString()));

            return destino;
        };
    }

    public static Converter<FracaoUnidadeRecebivelOperacao, GrupoRRC0003Constitr> emRRC003UrAConstituir(BigDecimal valorAConstituir) {
        return origem -> {
            GrupoRRC0003Constitr destino = new GrupoRRC0003Constitr();

            destino.setPriorddNegcRecbvl(new SPBInteger(origem.getNrPridd()));

            String nrCpfCnpjTitlar = origem.getNrCpfCnpjTitlar();
            if (CpfCnpjUtil.validaCnpj(nrCpfCnpjTitlar)) {
                destino.setcNPJCNPJBaseCPFTitlar(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(nrCpfCnpjTitlar)));
            } else if (CpfCnpjUtil.validaCpf(nrCpfCnpjTitlar)) {
                destino.setcNPJCNPJBaseCPFTitlar(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCpf(nrCpfCnpjTitlar)));
            } else {
                destino.setcNPJCNPJBaseCPFTitlar(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpjBase(nrCpfCnpjTitlar)));
            }

            String nrCpfCnpjUsuarioFinalRec = origem.getNrCpfCnpjUsurioFinlRecbdr();
            if (CpfCnpjUtil.validaCnpj(nrCpfCnpjUsuarioFinalRec)) {
                destino.setcNPJCNPJBaseCPFUsuFinalRecbdr(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(nrCpfCnpjUsuarioFinalRec)));
            } else if (CpfCnpjUtil.validaCpf(nrCpfCnpjUsuarioFinalRec)) {
                destino.setcNPJCNPJBaseCPFUsuFinalRecbdr(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCpf(nrCpfCnpjUsuarioFinalRec)));
            } else {
                destino.setcNPJCNPJBaseCPFUsuFinalRecbdr(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpjBase(nrCpfCnpjUsuarioFinalRec)));
            }

            destino.setCodInstitdrArrajPgto(SPBConverter.stringToSPBString(origem.getCdArrjPgto()));
            destino.setDtPrevtLiquid(SPBConverter.dateToSPBLocalDate(origem.getDtPrevtLiquid()));
            destino.setVlrPercNegcd(R2C3SPBUtil.newSPBBigDecimal(valorAConstituir));

            return destino;
        };
    }

    public static Converter<FracaoUnidadeRecebivelOperacao, GrupoRRC0009Constitr> emRRC009UrAConstituir() {
        return origem -> {
            GrupoRRC0009Constitr destino = new GrupoRRC0009Constitr();

            destino.setPriorddNegcRecbvl(new SPBInteger(origem.getNrPridd()));

            String nrCpfCnpjTitlar = origem.getNrCpfCnpjTitlar();
            if (CpfCnpjUtil.validaCnpj(nrCpfCnpjTitlar)) {
                destino.setCnpjCnpjBaseCPFTitlar(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(nrCpfCnpjTitlar)));
            } else {
                destino.setCnpjCnpjBaseCPFTitlar(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCpf(nrCpfCnpjTitlar)));
            }

            String nrCpfCnpjUsuarioFinalRec = origem.getNrCpfCnpjUsurioFinlRecbdr();
            if (CpfCnpjUtil.validaCnpj(nrCpfCnpjUsuarioFinalRec)) {
                destino.setCnpjCnpjBaseCpfUsuFinalRecbdr(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(nrCpfCnpjUsuarioFinalRec)));
            } else if (CpfCnpjUtil.validaCpf(nrCpfCnpjUsuarioFinalRec)) {
                destino.setCnpjCnpjBaseCpfUsuFinalRecbdr(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCpf(nrCpfCnpjUsuarioFinalRec)));
            } else {
                destino.setCnpjCnpjBaseCpfUsuFinalRecbdr(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpjBase(nrCpfCnpjUsuarioFinalRec)));
            }

            destino.setCodInstitdrArrajPgto(SPBConverter.stringToSPBString(origem.getCdArrjPgto()));
            destino.setDtPrevtLiquid(SPBConverter.dateToSPBLocalDate(origem.getDtPrevtLiquid()));
            destino.setVlrPercNegcdConstitr(SPBConverter.stringToSPBBigDecimal(origem.getNrVlrPrevtLiquid().toString()));
            destino.setCnpjCreddrSub(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(origem.getNrCnpjCreddr())));

            return destino;
        };
    }

    public static Converter<FracaoUnidadeRecebivelOperacao, GrupoRRC0003RegRecbvl> emRRC003UrConstituida() {
        return origem -> {
            GrupoRRC0003RegRecbvl destino = new GrupoRRC0003RegRecbvl();

            destino.setPriorddNegcRecbvl(new SPBInteger(origem.getNrPridd()));
            destino.setCodInstitdrArrajPgto(SPBConverter.stringToSPBString(origem.getCdArrjPgto()));
            destino.setDtPrevtLiquid(SPBConverter.dateToSPBLocalDate(origem.getDtPrevtLiquid()));

            String nrCpfCnpjTitlar = origem.getNrCpfCnpjTitlar();
            if (CpfCnpjUtil.validaCnpj(nrCpfCnpjTitlar)) {
                destino.setcNPJCPFTitular(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(nrCpfCnpjTitlar)));
            } else {
                destino.setcNPJCPFTitular(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCpf(nrCpfCnpjTitlar)));
            }

            String nrCpfCnpjUsuarioFinalRec = origem.getNrCpfCnpjUsurioFinlRecbdr();
            if (CpfCnpjUtil.validaCnpj(nrCpfCnpjUsuarioFinalRec)) {
                destino.setcNPJCPFUsuFinalRecbdr(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(nrCpfCnpjUsuarioFinalRec)));
            } else {
                destino.setcNPJCPFUsuFinalRecbdr(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCpf(nrCpfCnpjUsuarioFinalRec)));
            }
            destino.setVlrNegcd(SPBConverter.stringToSPBBigDecimal(origem.getNrVlrPrevtLiquid().toString()));

            return destino;
        };
    }

    public static Converter<FracaoUnidadeRecebivelOperacao, GrupoRRC0003RegRecbvl> emRRC003UrConstituida(BigDecimal valorConstituido) {
        return origem -> {
            GrupoRRC0003RegRecbvl destino = new GrupoRRC0003RegRecbvl();

            destino.setPriorddNegcRecbvl(new SPBInteger(origem.getNrPridd()));
            destino.setCodInstitdrArrajPgto(SPBConverter.stringToSPBString(origem.getCdArrjPgto()));
            destino.setDtPrevtLiquid(SPBConverter.dateToSPBLocalDate(origem.getDtPrevtLiquid()));

            String nrCpfCnpjTitlar = origem.getNrCpfCnpjTitlar();
            if (CpfCnpjUtil.validaCnpj(nrCpfCnpjTitlar)) {
                destino.setcNPJCPFTitular(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(nrCpfCnpjTitlar)));
            } else {
                destino.setcNPJCPFTitular(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCpf(nrCpfCnpjTitlar)));
            }

            String nrCpfCnpjUsuarioFinalRec = origem.getNrCpfCnpjUsurioFinlRecbdr();
            if (CpfCnpjUtil.validaCnpj(nrCpfCnpjUsuarioFinalRec)) {
                destino.setcNPJCPFUsuFinalRecbdr(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(nrCpfCnpjUsuarioFinalRec)));
            } else {
                destino.setcNPJCPFUsuFinalRecbdr(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCpf(nrCpfCnpjUsuarioFinalRec)));
            }
            destino.setVlrNegcd(R2C3SPBUtil.newSPBBigDecimal(valorConstituido));

            return destino;
        };
    }

    public static Converter<FracaoUnidadeRecebivelOperacao, GrupoRRC0009RegRecbvl> emRRC009UrConstituida() {
        return origem -> {
            GrupoRRC0009RegRecbvl destino = new GrupoRRC0009RegRecbvl();

            destino.setPriorddNegcRecbvl(new SPBInteger(origem.getNrPridd()));
            destino.setCodInstitdrArrajPgto(SPBConverter.stringToSPBString(origem.getCdArrjPgto()));
            destino.setDtPrevtLiquid(SPBConverter.dateToSPBLocalDate(origem.getDtPrevtLiquid()));

            String nrCpfCnpjTitlar = origem.getNrCpfCnpjTitlar();
            if (CpfCnpjUtil.validaCnpj(nrCpfCnpjTitlar)) {
                destino.setCnpjCpfTitular(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(nrCpfCnpjTitlar)));
            } else {
                destino.setCnpjCpfTitular(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCpf(nrCpfCnpjTitlar)));
            }

            String nrCpfCnpjUsuarioFinalRec = origem.getNrCpfCnpjUsurioFinlRecbdr();
            if (CpfCnpjUtil.validaCnpj(nrCpfCnpjUsuarioFinalRec)) {
                destino.setCnpjCpfUsuFinalRecbdr(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(nrCpfCnpjUsuarioFinalRec)));
            } else {
                destino.setCnpjCpfUsuFinalRecbdr(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCpf(nrCpfCnpjUsuarioFinalRec)));
            }

            destino.setVlrNegcd(SPBConverter.stringToSPBBigDecimal(origem.getNrVlrPrevtLiquid().toString()));
            destino.setCnpjCreddrSub(SPBConverter.stringToSPBString(CpfCnpjUtil.formataCnpj(origem.getNrCnpjCreddr())));

            return destino;
        };
    }


    public static Converter<Operacao, RRC0009> emRRC009(PartAdmPrincVO partAdmPrincVO) {
        return origem -> {
            RRC0009 destino = new RRC0009();

            destino.setCodMsg(new SPBString(TipoFuncionalidade.RRC0009.getValue()));
            destino.setIdentdPartPrincipal(SPBConverter.stringToSPBString(PartyUtility.partyIdToIspb(partAdmPrincVO.getNumIspbPrinc())));
            destino.setIdentdPartAdmtd(SPBConverter.stringToSPBString(PartyUtility.partyIdToIspb(partAdmPrincVO.getNumIspbAdm())));
            destino.setCnpjER(SPBConverter.stringToSPBString(origem.getNrCnpjRegtdr()));
            destino.setIdentdNegcRecbvl(SPBConverter.stringToSPBString(origem.getIdNegcRecbvExtn()));
            destino.setIdentdOp(SPBConverter.stringToSPBString(origem.getIdOp().toString()));
            destino.setIndrTpNegc(SPBConverter.stringToSPBString(origem.getIcTpNegc()));
            destino.setDtVencOp(SPBConverter.dateToSPBLocalDate(origem.getDtVencOp()));
            destino.setVlrTotLimSldDevdr(SPBConverter.stringToSPBBigDecimal(origem.getNrLimConcdSldDevdr().toString()));
            BigDecimal nrVlrGar = origem.getNrVlrGar();
            if (nrVlrGar != null) {
                destino.setVlrGar(SPBConverter.stringToSPBBigDecimal(nrVlrGar.toString()));
            }
            destino.setIndrGestER(SPBConverter.stringToSPBString(origem.getIcGesteNtRegtdr()));
            destino.setIndrRegrDivs(SPBConverter.stringToSPBString(origem.getIcRegrDivs()));
            destino.setIndrAlcancContrtoCreddrSub(SPBConverter.stringToSPBString(origem.getIcAlcccontrto()));
            destino.setIndrActeIncondlOp(SPBConverter.stringToSPBString(origem.getIcActeOp()));

            Long idOpor = origem.getIdOpor();
            if (idOpor > 0) {
                destino.setIdentdCIPOpOrRenegcDiv(SPBConverter.stringToSPBString(idOpor.toString()));
            }

            destino.setIndrActeUniddRecbvlReserv(SPBConverter.stringToSPBString(origem.getIcActeOp()));
            destino.setDtHrIncl(SPBConverter.dateTimeToSPBLocalDateTime(origem.getDhIncl().toDateTime(), "yyyy-MM-dd'T'HH:mm:ss"));
            destino.setIndrAutcCess(SPBConverter.stringToSPBString(origem.getIcAutcCess()));
            return destino;
        };
    }
}