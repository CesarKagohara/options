package br.org.cipbancos.rrc.bean.rrc0019;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoDomclBanc;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.util.ArrayList;
import java.util.List;

@XStreamAlias("Grupo_RRC0019_DomclBanc")
public class GrupoRRC0019DomclBanc extends ErrorCodeBean implements GrupoDomclBanc {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CPFTitlarCt")
    private SPBString cNPJCPFTitlarCt;

    @XStreamAlias("ISPBBcoRecbdr")
    private SPBString iSPBBcoRecbdr;

    @XStreamAlias("TpCt")
    private SPBString tpCt;

    @XStreamAlias("Ag")
    private SPBString ag;

    @XStreamAlias("Ct")
    private SPBString ct;

    @XStreamAlias("CtPgto")
    private SPBString ctPgto;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0019_RegRecbvl")
    private List<GrupoRRC0019GrupoRegRecbvl> listagrupoRRC0019RegRecbvl = new ArrayList<>();

    public SPBString getCNPJCPFTitlarCt() {
        return cNPJCPFTitlarCt;
    }

    public void setcNPJCPFTitlarCt(SPBString cNPJCPFTitlarCt) {
        this.cNPJCPFTitlarCt = cNPJCPFTitlarCt;
    }

    public SPBString getISPBBcoRecbdr() {
        return iSPBBcoRecbdr;
    }

    public void setiSPBBcoRecbdr(SPBString iSPBBcoRecbdr) {
        this.iSPBBcoRecbdr = iSPBBcoRecbdr;
    }

    public SPBString getTpCt() {
        return tpCt;
    }

    public void setTpCt(SPBString tpCt) {
        this.tpCt = tpCt;
    }

    public SPBString getAg() {
        return ag;
    }

    public void setAg(SPBString ag) {
        this.ag = ag;
    }

    public SPBString getCt() {
        return ct;
    }

    public void setCt(SPBString ct) {
        this.ct = ct;
    }

    public SPBString getCtPgto() {
        return ctPgto;
    }

    public void setCtPgto(SPBString ctPgto) {
        this.ctPgto = ctPgto;
    }

    public List<GrupoRRC0019GrupoRegRecbvl> getListagrupoRRC0019RegRecbvl() {
        return listagrupoRRC0019RegRecbvl;
    }

    public void setListagrupoRRC0019RegRecbvl(List<GrupoRRC0019GrupoRegRecbvl> listagrupoRRC0019RegRecbvl) {
        this.listagrupoRRC0019RegRecbvl = listagrupoRRC0019RegRecbvl;
    }

    @Override
    public List getListaGrupoRegRecbvl() {
        return getListagrupoRRC0019RegRecbvl();
    }

    @Override
    public String toString() {
        return "GrupoRRC0019DomclBanc{" +
                "cNPJCPFTitlarCt=" + cNPJCPFTitlarCt +
                ", iSPBBcoRecbdr=" + iSPBBcoRecbdr +
                ", tpCt=" + tpCt +
                ", ag=" + ag +
                ", ct=" + ct +
                ", ctPgto=" + ctPgto +
                ", listagrupoRRC0019RegRecbvl=" + listagrupoRRC0019RegRecbvl +
                '}';
    }
}
