package br.org.cipbancos.rrc.bean.rrc0019;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoUsuFinalRecbdr;

@XStreamAlias("Grupo_RRC0019_UsuFinalRecbdr")
public class GrupoRRC0019UsuFinalRecbdr extends ErrorCodeBean implements GrupoUsuFinalRecbdr {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CNPJBase_CPFUsuFinalRecbdr")
    private SPBString cNPJCNPJBaseCPFUsuFinalRecbdr;

    public SPBString getCNPJCNPJBaseCPFUsuFinalRecbdr() {
        return cNPJCNPJBaseCPFUsuFinalRecbdr;
    }

    public void setCNPJCNPJBaseCPFUsuFinalRecbdr(SPBString cNPJCNPJBaseCPFUsuFinalRecbdr) {
        this.cNPJCNPJBaseCPFUsuFinalRecbdr = cNPJCNPJBaseCPFUsuFinalRecbdr;
    }

    @Override
    public String toString() {
        return "GrupoRRC0019UsuFinalRecbdr{" +
                "cNPJCNPJBaseCPFUsuFinalRecbdr=" + cNPJCNPJBaseCPFUsuFinalRecbdr +
                '}';
    }
}
