package br.org.cipbancos.rrc.bean.rrc0011;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.spb.transformer.base.annotation.Transformable;
import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.util.CpfCnpjUtil;

@Transformable
public class GrupoRRC0011AutcEnvAgenda extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdentdCtrlReqSolicte")
    private SPBString identdCtrlReqSolicte;

    @XStreamAlias("CNPJ_CNPJBase_CPFUsuFinalRecbdr_Titlar")
    @Transformable("cnpjOuCnpjBaseOuCpfUsuFinalRecbdrOuTitlar")
    private SPBString cnpjCNPJBaseCPFUsuFinalRecbdrTitular;

    @XStreamAlias("CNPJCreddrSub")
    private SPBString cnpjCreddrSub;

    @XStreamAlias("CNPJFincdr")
    private SPBString cnpjFincdr;

    @XStreamAlias("CodInstitdrArrajPgto")
    private SPBString codInstitdrArrajPgto;

    @XStreamAlias("DtOptIn")
    private SPBLocalDate dtOptIn;

    @XStreamAlias("DtIniOptIn")
    private SPBLocalDate dtIniOptIn;

    @XStreamAlias("DtFimOptIn")
    private SPBLocalDate dtFimOptIn;

    @XStreamAlias("IndrDomcl")
    private SPBString indrDomcl;

    public boolean isCnpjCompleto() {
        return cnpjCNPJBaseCPFUsuFinalRecbdrTitular.getValue().length() == CpfCnpjUtil.CNPJ_DIGITO;
    }

    public boolean isCpf() {
        return cnpjCNPJBaseCPFUsuFinalRecbdrTitular.getValue().length() == CpfCnpjUtil.CPF_DIGITO;
    }

    public SPBString getIdentdCtrlReqSolicte() {
        return identdCtrlReqSolicte;
    }

    public void setIdentdCtrlReqSolicte(SPBString identdCtrlReqSolicte) {
        this.identdCtrlReqSolicte = identdCtrlReqSolicte;
    }

    public SPBString getCnpjCNPJBaseCPFUsuFinalRecbdrTitular() {
        return cnpjCNPJBaseCPFUsuFinalRecbdrTitular;
    }

    public void setCnpjCNPJBaseCPFUsuFinalRecbdrTitular(SPBString cnpjCNPJBaseCPFUsuFinalRecbdrTitular) {
        this.cnpjCNPJBaseCPFUsuFinalRecbdrTitular = cnpjCNPJBaseCPFUsuFinalRecbdrTitular;
    }

    public SPBString getCnpjCreddrSub() {
        return cnpjCreddrSub;
    }

    public void setCnpjCreddrSub(SPBString cnpjCreddrSub) {
        this.cnpjCreddrSub = cnpjCreddrSub;
    }

    public SPBString getCnpjFincdr() {
        return cnpjFincdr;
    }

    public void setCnpjFincdr(SPBString cnpjFincdr) {
        this.cnpjFincdr = cnpjFincdr;
    }

    public SPBString getCodInstitdrArrajPgto() {
        return codInstitdrArrajPgto;
    }

    public void setCodInstitdrArrajPgto(SPBString codInstitdrArrajPgto) {
        this.codInstitdrArrajPgto = codInstitdrArrajPgto;
    }

    public SPBLocalDate getDtOptIn() {
        return dtOptIn;
    }

    public void setDtOptIn(SPBLocalDate dtOptIn) {
        this.dtOptIn = dtOptIn;
    }

    public SPBLocalDate getDtIniOptIn() {
        return dtIniOptIn;
    }

    public void setDtIniOptIn(SPBLocalDate dtIniOptIn) {
        this.dtIniOptIn = dtIniOptIn;
    }

    public SPBLocalDate getDtFimOptIn() {
        return dtFimOptIn;
    }

    public void setDtFimOptIn(SPBLocalDate dtFimOptIn) {
        this.dtFimOptIn = dtFimOptIn;
    }

    public SPBString getIndrDomcl() {
        return indrDomcl;
    }

    public void setIndrDomcl(SPBString indrDomcl) {
        this.indrDomcl = indrDomcl;
    }
}
