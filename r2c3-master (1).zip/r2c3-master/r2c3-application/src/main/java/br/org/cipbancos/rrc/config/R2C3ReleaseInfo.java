package br.org.cipbancos.rrc.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Configurable;

/**
 * Classe para carregar as configurações sobre a release
 */
@Configurable
public class R2C3ReleaseInfo {

    private String name;
    private String version;
    private String buildDate;
    private String description;
    private String ppackage;
    private String fullVersionInfo;
    private static final Logger LOG = LoggerFactory.getLogger(R2C3ReleaseInfo.class);

    public R2C3ReleaseInfo(String name, String version, String buildDate, String description, String ppackage) {
        this.name = name;
        this.version = version;
        this.buildDate = buildDate;
        this.description = description;
        this.ppackage = ppackage;
        this.fullVersionInfo = "" + "\n\n########################################### \n"
                + "  ____   ____      ____                                           \n"
                + " / ___| |  _ \\  / /   \\                                         \n"
                + "| |     | | |_) | |    | |                                        \n"
                + "| |___  |  __/| | |    | |                                        \n"
                + "\\____| |_|     \\ ____/ /   v " + this.version + "\n\n" + this.description
                + "                                         \n\n" + "########################################### ";

    }

    public static void main(String[] args) {
        String cpoReleaseInfo = new R2C3ReleaseInfo("CPO", "1.0.0", "2019-08-29", "sei la", "").fullVersionInfo;
        LOG.warn(cpoReleaseInfo);
    }

    public void shutdown() {
        // Necessary only if needs to show message on shutdown.
    }

    public String getName() {
        return name;
    }

    public String getVersion() {
        return version;
    }

    public String getBuildDate() {
        return buildDate;
    }

    public String getDescription() {
        return description;
    }

    public String getPpackage() {
        return ppackage;
    }
}
