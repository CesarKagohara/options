package br.org.cipbancos.rrc.builder;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.converter.FracaoUnidadeRecebivelOperacaoConverter;
import br.org.cipbancos.rrc.converter.UnidadeRecebivelConverter;
import br.org.cipbancos.rrc.enums.RegraDivisao;
import br.org.cipbancos.rrc.enums.SituacaoRetornoRequisicao;
import br.org.cipbancos.rrc.vo.FracaoAConstituirNegociacao;
import br.org.cipbancos.rrc.vo.FracaoConstituidaNegociacao;
import br.org.cipbancos.rrc.vo.Negociacao;
import br.org.cipbancos.rrc.vo.NegociacaoAceita;
import br.org.cipbancos.rrc.vo.NegociacaoR1;
import br.org.cipbancos.rrc.vo.NegociacaoRecusada;
import br.org.cipbancos.rrc.vo.UnidadeRecebivel;

/**
 * Classe responsável por montar a estrutura de Negociação para o R1.
 *
 * @author otavio.ferreira
 * @since 1.0
 */
public class NegociacaoR1Builder {

    private NegociacaoR1 retorno;

    public NegociacaoR1Builder montaNegociacaoR1(Negociacao entrada) {
        retorno = new NegociacaoR1();

        retorno.setCodMsg(new SPBString("RRC0005R1"));
        retorno.setIdentPartPrincipal(entrada.getIdentdPartPrincipal());
        retorno.setIdentPartAdmtd(entrada.getIdentdPartAdmtd());
        retorno.setIdentdNegcRecbvl(entrada.getIdentdNegcRecbvl());
        retorno.setIdentdOp(entrada.getIdentdOp());

        return this;
    }

    public NegociacaoR1Builder comProcessamentoAceito() {
        retorno.setNegociacaoAceita(new NegociacaoAceita());
        retorno.setSitRetReq(new SPBString(StringUtils.leftPad(SituacaoRetornoRequisicao.ACEITO.getCodigo().toString(), 3, '0')));
        return this;
    }

    public NegociacaoR1Builder comProcessamentoRecusado(Negociacao entrada) {
        retorno.setNegociacaoRecusada(new NegociacaoRecusada());

        if (entrada.getVlrTotLimSldDevdr().hasErrorCode())
            retorno.getNegociacaoRecusada().setErrorCode(entrada.getVlrTotLimSldDevdr().getErrorCode());

        retorno.setSitRetReq(new SPBString(StringUtils.leftPad(SituacaoRetornoRequisicao.RECUSADO.getCodigo().toString(), 3, '0')));
        return this;
    }

    public NegociacaoR1Builder comListaConstituidas(List<UnidadeRecebivel> urs) {
        urs.forEach(ur ->
                ur.getFracoes().forEach(fracao -> {
                    if (fracao.constituida() && fracao.negociada()) {
                        FracaoConstituidaNegociacao fracaoConstituida = FracaoUnidadeRecebivelOperacaoConverter
                                .emFracaoConstituidaNegociacao()
                                .convert(fracao);

                        retorno
                                .getNegociacaoAceita()
                                .getListaRegRecbvl()
                                .add(fracaoConstituida);
                    }
                })
        );

        return this;
    }

    public NegociacaoR1Builder comListaAConstituir(List<UnidadeRecebivel> urs, RegraDivisao regraDivisao) {
        urs.forEach(ur ->
                ur.getFracoes().forEach(fracao -> {
                    if (fracao.aConstituir() && fracao.negociada()) {
                        FracaoAConstituirNegociacao fracaoAConstituir = FracaoUnidadeRecebivelOperacaoConverter
                                .emFracaoAConstituirNegociacao(regraDivisao)
                                .convert(fracao);

                        retorno
                                .getNegociacaoAceita()
                                .getListaConstitr()
                                .add(fracaoAConstituir);
                    }
                })
        );

        return this;
    }

    public NegociacaoR1Builder comListaDisponiveis(List<UnidadeRecebivel> urs) {
        urs.forEach(ur ->
                retorno
                        .getNegociacaoRecusada()
                        .getListaUniddRecbvlDisp()
                        .add(UnidadeRecebivelConverter.emUrDisponivel().convert(ur))
        );

        return this;
    }

    public NegociacaoR1Builder comListaDisponiveisPorTitular(Map<String, List<UnidadeRecebivel>> titulares) {
        titulares.values().forEach(urs ->
                urs.forEach(ur -> retorno
                        .getNegociacaoRecusada()
                        .getListaUniddRecbvlDisp()
                        .add(UnidadeRecebivelConverter.emUrDisponivel().convert(ur))
                )
        );

        return this;
    }

    public NegociacaoR1 build() {
        return retorno;
    }
}
