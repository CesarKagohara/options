package br.org.cipbancos.rrc.bean.rrc0021;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_RRC0021R1_DomclBanc")
public class GrupoRRC0021R1DomclBanc extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CPFTitlarCt")
    private SPBString cNPJCPFTitlarCt;

    @XStreamAlias("ISPBBcoRecbdr")
    private SPBString iSPBBcoRecbdr;

    @XStreamAlias("TpCt")
    private SPBString tpCt;

    @XStreamAlias("Ag")
    private SPBString ag;

    @XStreamAlias("Ct")
    private SPBString ct;

    @XStreamAlias("CtPgto")
    private SPBString ctPgto;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0021R1_RegRecbvl")
    private List<GrupoRRC0021R1RegRecbvl> listagrupoRRC0021R1RegRecbvl = new ArrayList<GrupoRRC0021R1RegRecbvl>();

    @XStreamImplicit(itemFieldName = "Grupo_RRC0021R1_Constitr")
    private List<GrupoRRC0021R1Constitr> listagrupoRRC0021R1Constitr = new ArrayList<GrupoRRC0021R1Constitr>();

    public SPBString getCNPJCPFTitlarCt() {
        return cNPJCPFTitlarCt;
    }

    public void setCNPJCPFTitlarCt(SPBString cNPJCPFTitlarCt) {
        this.cNPJCPFTitlarCt = cNPJCPFTitlarCt;
    }

    public SPBString getISPBBcoRecbdr() {
        return iSPBBcoRecbdr;
    }

    public void setISPBBcoRecbdr(SPBString iSPBBcoRecbdr) {
        this.iSPBBcoRecbdr = iSPBBcoRecbdr;
    }

    public SPBString getTpCt() {
        return tpCt;
    }

    public void setTpCt(SPBString tpCt) {
        this.tpCt = tpCt;
    }

    public SPBString getAg() {
        return ag;
    }

    public void setAg(SPBString ag) {
        this.ag = ag;
    }

    public SPBString getCt() {
        return ct;
    }

    public void setCt(SPBString ct) {
        this.ct = ct;
    }

    public SPBString getCtPgto() {
        return ctPgto;
    }

    public void setCtPgto(SPBString ctPgto) {
        this.ctPgto = ctPgto;
    }

    public List<GrupoRRC0021R1RegRecbvl> getListagrupoRRC0021R1RegRecbvl() {
        return listagrupoRRC0021R1RegRecbvl;
    }

    public void setListagrupoRRC0021R1RegRecbvl(List<GrupoRRC0021R1RegRecbvl> listagrupoRRC0021R1RegRecbvl) {
        this.listagrupoRRC0021R1RegRecbvl = listagrupoRRC0021R1RegRecbvl;
    }

    public List<GrupoRRC0021R1Constitr> getListagrupoRRC0021R1Constitr() {
        return listagrupoRRC0021R1Constitr;
    }

    public void setListagrupoRRC0021R1Constitr(List<GrupoRRC0021R1Constitr> listagrupoRRC0021R1Constitr) {
        this.listagrupoRRC0021R1Constitr = listagrupoRRC0021R1Constitr;
    }

}
