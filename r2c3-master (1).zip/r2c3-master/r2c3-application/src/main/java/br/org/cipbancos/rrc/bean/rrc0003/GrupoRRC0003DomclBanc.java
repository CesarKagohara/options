package br.org.cipbancos.rrc.bean.rrc0003;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_RRC0003_DomclBanc")
public class GrupoRRC0003DomclBanc extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CPFTitlarCt")
    private SPBString cNPJCPFTitlarCt;

    @XStreamAlias("ISPBBcoRecbdr")
    private SPBString iSPBBcoRecbdr;

    @XStreamAlias("TpCt")
    private SPBString tpCt;

    @XStreamAlias("Ag")
    private SPBString ag;

    @XStreamAlias("Ct")
    private SPBString ct;

    @XStreamAlias("CtPgto")
    private SPBString ctPgto;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0003_RegRecbvl")
    private List<GrupoRRC0003RegRecbvl> listagrupoRRC0003RegRecbvl = new ArrayList<>();

    @XStreamImplicit(itemFieldName = "Grupo_RRC0003_Constitr")
    private List<GrupoRRC0003Constitr> listagrupoRRC0003Constitr = new ArrayList<>();

    public SPBString getcNPJCPFTitlarCt() {
        return cNPJCPFTitlarCt;
    }

    public void setcNPJCPFTitlarCt(SPBString cNPJCPFTitlarCt) {
        this.cNPJCPFTitlarCt = cNPJCPFTitlarCt;
    }

    public SPBString getiSPBBcoRecbdr() {
        return iSPBBcoRecbdr;
    }

    public void setiSPBBcoRecbdr(SPBString iSPBBcoRecbdr) {
        this.iSPBBcoRecbdr = iSPBBcoRecbdr;
    }

    public SPBString getTpCt() {
        return tpCt;
    }

    public void setTpCt(SPBString tpCt) {
        this.tpCt = tpCt;
    }

    public SPBString getAg() {
        return ag;
    }

    public void setAg(SPBString ag) {
        this.ag = ag;
    }

    public SPBString getCt() {
        return ct;
    }

    public void setCt(SPBString ct) {
        this.ct = ct;
    }

    public SPBString getCtPgto() {
        return ctPgto;
    }

    public void setCtPgto(SPBString ctPgto) {
        this.ctPgto = ctPgto;
    }

    public List<GrupoRRC0003RegRecbvl> getListagrupoRRC0003RegRecbvl() {
        return listagrupoRRC0003RegRecbvl;
    }

    public void setListagrupoRRC0003RegRecbvl(List<GrupoRRC0003RegRecbvl> listagrupoRRC0003RegRecbvl) {
        this.listagrupoRRC0003RegRecbvl = listagrupoRRC0003RegRecbvl;
    }

    public List<GrupoRRC0003Constitr> getListagrupoRRC0003Constitr() {
        return listagrupoRRC0003Constitr;
    }

    public void setListagrupoRRC0003Constitr(List<GrupoRRC0003Constitr> listagrupoRRC0003Constitr) {
        this.listagrupoRRC0003Constitr = listagrupoRRC0003Constitr;
    }


}
