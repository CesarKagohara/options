package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.rrc.vo.GrupoRegOpStg;

import java.util.Date;
import java.util.List;

public interface GrupoRegOpStgDAO {

    void inserir(List<GrupoRegOpStg> grupos, Date dtRef);

    List<GrupoRegOpStg> obterGruposRegOpStgPorIdRegOp(Long idRegOp, Date dtRef);

}

