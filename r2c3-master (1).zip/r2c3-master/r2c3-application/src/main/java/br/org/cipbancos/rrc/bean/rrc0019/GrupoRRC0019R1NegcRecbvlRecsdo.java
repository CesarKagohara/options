package br.org.cipbancos.rrc.bean.rrc0019;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;

@XStreamAlias("Grupo_RRC0019R1_NegcRecbvlRecsdo")
public class GrupoRRC0019R1NegcRecbvlRecsdo extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0019R1_UniddRecbvlDisp")
    private List<GrupoRRC0019R1UniddRecbvlDisp> listagrupoRRC0019R1UniddRecbvlDisp = new ArrayList<GrupoRRC0019R1UniddRecbvlDisp>();

    public List<GrupoRRC0019R1UniddRecbvlDisp> getListagrupoRRC0019R1UniddRecbvlDisp() {
        return listagrupoRRC0019R1UniddRecbvlDisp;
    }

    public void setListagrupoRRC0019R1UniddRecbvlDisp(List<GrupoRRC0019R1UniddRecbvlDisp> listagrupoRRC0019R1UniddRecbvlDisp) {
        this.listagrupoRRC0019R1UniddRecbvlDisp = listagrupoRRC0019R1UniddRecbvlDisp;
    }

}
