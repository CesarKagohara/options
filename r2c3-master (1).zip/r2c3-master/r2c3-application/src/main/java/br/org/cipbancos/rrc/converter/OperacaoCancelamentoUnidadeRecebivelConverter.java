package br.org.cipbancos.rrc.converter;

import java.util.Date;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import br.org.cipbancos.rrc.funcional.Converter;
import br.org.cipbancos.rrc.vo.OperacaoCancelamentoUnidadeRecebivel;

/**
 * Classe utilitária para converter informações de Operacao Cancelamento Unidade Recebivel de entrada para realizar,
 * inserções no BD e conversões de Entrada para Retorno.
 *
 * @author anderson.martins
 * @since 1.0
 */
public class OperacaoCancelamentoUnidadeRecebivelConverter {

    private OperacaoCancelamentoUnidadeRecebivelConverter() {}

    /**
     * Popula os parametros utilizados para buscar um OperacaoCancelamento no BD.
     * @return Um conjunto de parametros para setar as informações no ElSql.
     */
    public static Converter<OperacaoCancelamentoUnidadeRecebivel, MapSqlParameterSource> emIdOperacaoParaBuscarOperacaoCancelamentoUnidadeRecebivel() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();

            parametros.addValue("identificadorOperacaoCancelamentoUnidadeRecebivel", origem.getIdentificadorOperacaoCancelamentoUnidadeRecebivel());

            return parametros;
        };
    }

    /**
     * Popula os parametros utilizados para buscar um OperacaoCancelamentoUnidadeRecebivel no BD.
     * @return Um conjunto de parametros para setar as informações no ElSql.
     */
    public static Converter<OperacaoCancelamentoUnidadeRecebivel, MapSqlParameterSource> emOperacaoCancelamentoUnidadeRecebivelParaBuscarUnidadeRecebivel() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();

            parametros.addValue("cdArrjPgto", origem.getCdArrjPgto());
            parametros.addValue("nrCnpjCreddr", origem.getNrCnpjCredenciadora());
            parametros.addValue("nrCpfCnpjUsurioFinlRecbdr", origem.getNrCpfCnpjUsuarioFinlRecbdr());
            parametros.addValue("dtPrevtLiquid", origem.getDtPrevtLiquid());

            return parametros;
        };
    }

    /**
     * Popula os parametros utilizados para inserir um OperacaoCancelamentoUnidadeRecebivel no BD.
     * @return Um conjunto de parametros para setar as informações no ElSql.
     */
    public static Converter<OperacaoCancelamentoUnidadeRecebivel, MapSqlParameterSource> emInsercaoOperacaoCancelamentoUnidadeRecebivel() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();

            parametros.addValue("identificadorOperacaoCancelamentoUnidadeRecebivel", origem.getIdentificadorOperacaoCancelamentoUnidadeRecebivel());
            parametros.addValue("identificadorOperacaoCancelamento", origem.getIdentificadorOperacaoCancelamento());
            parametros.addValue("cdArrjPgto", origem.getCdArrjPgto());
            parametros.addValue("nrCnpjCreddr", origem.getNrCnpjCredenciadora());
            parametros.addValue("nrCpfCnpjUsurioFinlRecbdr", origem.getNrCpfCnpjUsuarioFinlRecbdr());
            parametros.addValue("dtPrevtLiquid", origem.getDtPrevtLiquid());
            parametros.addValue("nrCpfCnpjTitlarVenddrNegcdrRecbv", origem.getNrCpfCnpjTitlarVenddrNegcdrRecbv());
            parametros.addValue("nrVlNegcdCancel", origem.getNrVlNegcdCancel());
            parametros.addValue("nrVlPcNegcdCancel", origem.getNrVlPcNegcdCancel());
            parametros.addValue("idPartPrincipal", origem.getIdPartPrincipal());
            parametros.addValue("idPartAdmtd", origem.getIdPartAdmtd());
            parametros.addValue("idPartOrigdr", origem.getIdPartOrigdr());
            parametros.addValue("dtRefSistIncl", origem.getDtRefSistIncl());
            parametros.addValue("dtRefSistUltAlt", origem.getDtRefSistUltAlt());
            parametros.addValue("indicadorAtlRoot", origem.getIdAtlRoot());
            parametros.addValue("nmArqNuopApi", origem.getNmArqNuopApi());
            parametros.addValue("idFuncdd", origem.getIdFuncdd());
            parametros.addValue("dhIncl", new java.sql.Timestamp(new Date().getTime()));
            parametros.addValue("dhUltAlt", new java.sql.Timestamp(new Date().getTime()));

          return parametros;
        };
    }

}
