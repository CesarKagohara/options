package br.org.cipbancos.rrc.bean.rrc0029;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("RRC0029")
public class RRC0029 extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CodMsg")
    private SPBString codMsg;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamAlias("IdentdCtrlOptOut")
    private SPBString identdCtrlOptOut;

    @XStreamAlias("IdentdCtrlOptIn")
    private SPBString identdCtrlOptIn;

    @XStreamAlias("DtFimOptIn")
    private SPBLocalDate dtFimOptIn;

    @XStreamAlias("CPF_CNPJRecbdrOptOut")
    private SPBString cNPJRecbdrOptOut;

    public SPBString getCodMsg() {
        return codMsg;
    }

    public void setCodMsg(SPBString codMsg) {
        this.codMsg = codMsg;
    }

    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public SPBString getIdentdCtrlOptOut() {
        return identdCtrlOptOut;
    }

    public void setIdentdCtrlOptOut(SPBString identdCtrlOptOut) {
        this.identdCtrlOptOut = identdCtrlOptOut;
    }

    public SPBString getIdentdCtrlOptIn() {
        return identdCtrlOptIn;
    }

    public void setIdentdCtrlOptIn(SPBString identdCtrlOptIn) {
        this.identdCtrlOptIn = identdCtrlOptIn;
    }

    public SPBLocalDate getDtFimOptIn() {
        return dtFimOptIn;
    }

    public void setDtFimOptIn(SPBLocalDate dtFimOptIn) {
        this.dtFimOptIn = dtFimOptIn;
    }

    public SPBString getCNPJRecbdrOptOut() {
        return cNPJRecbdrOptOut;
    }

    public void setCNPJRecbdrOptOut(SPBString cNPJRecbdrOptOut) {
        this.cNPJRecbdrOptOut = cNPJRecbdrOptOut;
    }

}
