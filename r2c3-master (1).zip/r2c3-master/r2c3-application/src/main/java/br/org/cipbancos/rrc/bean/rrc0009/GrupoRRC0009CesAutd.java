package br.org.cipbancos.rrc.bean.rrc0009;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;


public class GrupoRRC0009CesAutd implements Serializable {

    @XStreamAlias("CNPJ_CPFCesAutd")
    private SPBString CNPJCPFCesAutd;

    public SPBString getCNPJCPFCesAutd() {
        return CNPJCPFCesAutd;
    }

    public void setCNPJCPFCesAutd(SPBString CNPJCPFCesAutd) {
        this.CNPJCPFCesAutd = CNPJCPFCesAutd;
    }
}