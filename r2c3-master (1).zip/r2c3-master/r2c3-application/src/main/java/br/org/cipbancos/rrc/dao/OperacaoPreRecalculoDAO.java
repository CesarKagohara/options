package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.rrc.vo.Operacao;

public interface OperacaoPreRecalculoDAO {

    void inserir(Operacao operacao);
}


