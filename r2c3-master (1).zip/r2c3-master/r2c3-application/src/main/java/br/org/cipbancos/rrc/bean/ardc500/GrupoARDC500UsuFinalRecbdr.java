package br.org.cipbancos.rrc.bean.ardc500;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;

@XStreamAlias("Grupo_ARDC500_UsuFinalRecbdr")
public class GrupoARDC500UsuFinalRecbdr extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CPFUsuFinalRecbdr")
    private String cNPJCPFUsuFinalRecbdr;

    @XStreamImplicit(itemFieldName = "Grupo_ARDC500_ArrajPgto")
    private List<GrupoARDC500ArrajPgto> listaGrupoARDC500ArrajPgto = new ArrayList<>();

    public String getCNPJCPFUsuFinalRecbdr() {
        return cNPJCPFUsuFinalRecbdr;
    }

    public void setCNPJCPFUsuFinalRecbdr(String cNPJCPFUsuFinalRecbdr) {
        this.cNPJCPFUsuFinalRecbdr = cNPJCPFUsuFinalRecbdr;
    }

    public List<GrupoARDC500ArrajPgto> getListaGrupoARDC500ArrajPgto() {
        return listaGrupoARDC500ArrajPgto;
    }

    public void setListaGrupoARDC500ArrajPgto(List<GrupoARDC500ArrajPgto> listaGrupoARDC500ArrajPgto) {
        this.listaGrupoARDC500ArrajPgto = listaGrupoARDC500ArrajPgto;
    }
}
