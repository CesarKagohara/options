package br.org.cipbancos.rrc.bean.rrc0013;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_RRC0013_CanceltAutcEnvAgenda")
public class GrupoRRC0013CanceltAutcEnvAgenda extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdentdCtrlReqSolicte")
    private SPBString identdCtrlReqSolicte;

    @XStreamAlias("IdentdCtrlOptIn")
    private SPBString identdCtrlOptIn;

    public SPBString getIdentdCtrlReqSolicte() {
        return identdCtrlReqSolicte;
    }

    public void setIdentdCtrlReqSolicte(SPBString identdCtrlReqSolicte) {
        this.identdCtrlReqSolicte = identdCtrlReqSolicte;
    }

    public SPBString getIdentdCtrlOptIn() {
        return identdCtrlOptIn;
    }

    public void setIdentdCtrlOptIn(SPBString identdCtrlOptIn) {
        this.identdCtrlOptIn = identdCtrlOptIn;
    }

}
