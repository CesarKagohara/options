package br.org.cipbancos.rrc.bean;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("R2C3AtivarVarredura")
public class AtivarVarredura {

    @XStreamAlias("CodMsg")
    private SPBString codMsg;

    @XStreamImplicit(itemFieldName = "Parametro")
    private List<AtivarVarreduraParametro> parametros;

    @Override
    public String toString() {
        return "AtivarVarredura{" + "codMsg=" + codMsg + '}';
    }

    public SPBString getCodMsg() {
        return codMsg;
    }

    public void setCodMsg(SPBString codMsg) {
        this.codMsg = codMsg;
    }

    public List<AtivarVarreduraParametro> getParametros() {
        return parametros;
    }

    public void setParametros(List<AtivarVarreduraParametro> parametros) {
        this.parametros = parametros;
    }
}
