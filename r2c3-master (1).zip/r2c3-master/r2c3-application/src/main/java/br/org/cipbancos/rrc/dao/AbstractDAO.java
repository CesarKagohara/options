package br.org.cipbancos.rrc.dao;


import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.opengamma.elsql.ElSql;
import com.opengamma.elsql.ElSqlConfig;

import br.org.cipbancos.atlante.repository.query.AtlanteQueryBehaviour;
import br.org.cipbancos.rrc.datasource.DataSourceRouter;

public class AbstractDAO  {

    private static final Logger LOG = LoggerFactory.getLogger(AbstractDAO.class);

    @Autowired
    @Qualifier("dataSourceRouter")
    protected DataSourceRouter dataSourceRouter;

    @Autowired
    private AtlanteQueryBehaviour atlanteQueryBehaviour;

    @Autowired
    private ParametroConfiguracaoSistemaDAO parametroConfiguracaoSistemaDAO;

    private final Map<String,Map<String,NamedParameterJdbcTemplate>> queryKeyNamedParameter = new ConcurrentHashMap<>();
    private final Map<String,Map<String,JdbcTemplate>> queryKeyJdbcTemplate = new ConcurrentHashMap<>();

    public static final String defaultDataSourceKey = "R2C3";
    public static final String atlanteDataSourceKey = "ATL";
    public static final String cpcDataSourceKey = "CPC";
    public static final String ctzDataSourceKey = "CTZ";

    protected NamedParameterJdbcTemplate getNamedTemplate(){
        return namedTemplate(defaultDataSourceKey, dataSourceRouter.getR2c3DS());
    }
    protected NamedParameterJdbcTemplate getNamedTemplateCtz(){
        return namedTemplate(ctzDataSourceKey, dataSourceRouter.getCtzDS());
    }

    protected NamedParameterJdbcTemplate getNamedTemplate(String dataSourceKey){
        return namedTemplate(dataSourceKey, dataSourceRouter.getDataSourceMap(dataSourceKey));
    }
    protected NamedParameterJdbcTemplate getNamedTemplateCtz(String dataSourceKey){
        return namedTemplate(dataSourceKey, dataSourceRouter.getDataSourceMap(dataSourceKey));
    }
    protected NamedParameterJdbcTemplate getNamedTemplateCtz(String dataSourceKey, Integer queryTimeout){
        return namedTemplate(ctzDataSourceKey, dataSourceRouter.getDataSourceMap(dataSourceKey), queryTimeout);
    }

    protected NamedParameterJdbcTemplate getNamedTemplate(String dataSourceKey, Integer queryTimeout){
        return namedTemplate(dataSourceKey, dataSourceRouter.getDataSourceMap(dataSourceKey), queryTimeout);
    }

    protected NamedParameterJdbcTemplate getNamedTemplateCpc(){
        return namedTemplate(cpcDataSourceKey, dataSourceRouter.getCpcDS());
    }


    protected NamedParameterJdbcTemplate getNamedTemplateAtl(){
        return namedTemplate(atlanteDataSourceKey, dataSourceRouter.getAtlanteDS());
    }

    protected JdbcTemplate getJdbcTemplate(){
        return jdbcTemplate(defaultDataSourceKey, dataSourceRouter.getR2c3DS());
    }

    protected JdbcTemplate getJdbcTemplate(String dataSourceKey){
        return jdbcTemplate(dataSourceKey, dataSourceRouter.getDataSourceMap(dataSourceKey));
    }

    protected JdbcTemplate getJdbcTemplateCpc(){
        return jdbcTemplate(defaultDataSourceKey, dataSourceRouter.getCpcDS());
    }

    protected JdbcTemplate getJdbcTemplateCtz(){
        return jdbcTemplate(defaultDataSourceKey, dataSourceRouter.getCtzDS());
    }

    protected JdbcTemplate getJdbcTemplateAtl(){
        return jdbcTemplate(atlanteDataSourceKey, dataSourceRouter.getAtlanteDS());
    }

    private NamedParameterJdbcTemplate namedTemplate(String dataSourceKey, DataSource ds) {
        if(atlanteQueryBehaviour!=null) {
            if(!queryKeyNamedParameter.containsKey(dataSourceKey)) {
                queryKeyNamedParameter.put(dataSourceKey,new ConcurrentHashMap<>());
            }
            String queryKey = this.atlanteQueryBehaviour.queryKey();
            Integer queryTimeOut = this.atlanteQueryBehaviour.getTimeOut();
            if(queryKey!=null && queryTimeOut!=null) {
                Map<String,NamedParameterJdbcTemplate> qknp = queryKeyNamedParameter.get(dataSourceKey);
                if(!qknp.containsKey(queryKey)) {
                    JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
                    jdbcTemplate.setQueryTimeout(queryTimeOut);
                    NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate);
                    qknp.put(queryKey, namedParameterJdbcTemplate);
                }
                return qknp.get(queryKey);
            }
        }
        JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
        return new NamedParameterJdbcTemplate(jdbcTemplate);
    }

    private NamedParameterJdbcTemplate namedTemplate(String dataSourceKey, DataSource ds, Integer queryTimeOut) {
        if(atlanteQueryBehaviour!=null) {
            if(!queryKeyNamedParameter.containsKey(dataSourceKey)) {
                queryKeyNamedParameter.put(dataSourceKey,new ConcurrentHashMap<>());
            }
            String queryKey = this.atlanteQueryBehaviour.queryKey();
            if(queryKey!=null && queryTimeOut!=null) {
                Map<String,NamedParameterJdbcTemplate> qknp = queryKeyNamedParameter.get(dataSourceKey);
                if(!qknp.containsKey(queryKey)) {
                    JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
                    jdbcTemplate.setQueryTimeout(queryTimeOut);
                    NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate);
                    qknp.put(queryKey, namedParameterJdbcTemplate);
                }
                return qknp.get(queryKey);
            }
        }
        JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
        return new NamedParameterJdbcTemplate(jdbcTemplate);
    }

    private JdbcTemplate jdbcTemplate(String dataSourceKey, DataSource ds) {
        if(atlanteQueryBehaviour!=null) {
            if(!queryKeyJdbcTemplate.containsKey(dataSourceKey)) {
                queryKeyJdbcTemplate.put(dataSourceKey,new ConcurrentHashMap<>());
            }
            String queryKey = this.atlanteQueryBehaviour.queryKey();
            Integer queryTimeOut = this.atlanteQueryBehaviour.getTimeOut();
            if(queryKey!=null && queryTimeOut!=null) {
                Map<String,JdbcTemplate> qknp = queryKeyJdbcTemplate.get(dataSourceKey);
                if(!qknp.containsKey(queryKey)) {
                    JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
                    jdbcTemplate.setQueryTimeout(queryTimeOut);
                    qknp.put(queryKey, jdbcTemplate);
                }
                return qknp.get(queryKey);
            }
        }
        return new JdbcTemplate(ds);
    }

    private final ElSql bundle;

    public AbstractDAO() {
        List<URL> url = getListUrlResource(getClass());
        bundle = ElSql.parse(ElSqlConfig.DEFAULT, url.toArray(new URL[url.size()]));
    }

    /**
     * Obtém todos os resources de SQL das classes filhas
     *
     * @param clazz
     * @return String
     */
    private List<URL> getListUrlResource(Class clazz) {
        List<URL> urls = new ArrayList<>();
        if (clazz.getSuperclass() != null) {
            urls.addAll(getListUrlResource(clazz.getSuperclass()));
            urls.add(clazz.getResource(clazz.getSimpleName() + ".elsql"));
        }
        return urls;
    }

    /**
     * Obtém a query externalizada do arquivo de configuração
     *
     * @param sqlName
     *            Nome da query
     * @return String
     */
    protected String getSql(String sqlName) {
        String sql = bundle.getSql(sqlName);
        LOG.debug("Query: {}", sql);
        return sql;
    }

    /**
     * Obtém a query externalizada do arquivo de configuração
     *
     * @param sqlName
     *            Nome da query
     * @param params
     *            Parâmetros para compor a query dinâmica
     * @return String
     */
    protected String getSqlDinamico(String sqlName, MapSqlParameterSource params) {
        return getSqlDinamico(sqlName, params.getValues());
    }

    /**
     * Obtém a query externalizada do arquivo de configuração
     *
     * @param sqlName
     *            Nome da query
     * @param params
     *            Parâmetros para compor a query dinâmica
     * @return String
     */
    protected String getSqlDinamico(String sqlName, Map<String, Object> params) {
        Map<String, Object> map = new HashMap<>();
        for (Map.Entry<String,Object> pair : params.entrySet()) {
            map.put(pair.getKey(), pair.getValue());
        }

        if(map.get("sufixo")!=null){
            String param = parametroConfiguracaoSistemaDAO.obterValorPelaChave("DESENV");
            if(param!=null && param.equals("TRUE")){
                map.put("sufixo", "000");
            }
        }

        String sql = bundle.getSql(sqlName, map);
        LOG.debug("Query: {}", sql);
        LOG.debug("Query Params: {}", map);
        return sql;
    }
}
