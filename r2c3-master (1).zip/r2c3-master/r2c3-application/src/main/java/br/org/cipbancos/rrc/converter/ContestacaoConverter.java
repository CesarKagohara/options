package br.org.cipbancos.rrc.converter;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.rrc0027.RRC0027;
import br.org.cipbancos.rrc.bean.rrc0027.RRC0027R1;
import br.org.cipbancos.rrc.funcional.Converter;

/**
 * Classe utilitária para converter informações de Contestações.
 *
 * @author otavio.ferreira
 * @since 1.0
 */
public class ContestacaoConverter {

    private ContestacaoConverter() {}

    public static Converter<RRC0027, RRC0027R1> emRRC0027R1() {
        return origem -> {
            RRC0027R1 destino = new RRC0027R1();

            destino.setCodMsg(new SPBString("RRC0027R1"));
            destino.setIdentdCtrlReqSolicte(origem.getGrupoRRC0027Contstc().getIdentdCtrlReqSolicte());
            destino.setSitRetReq(new SPBString("001"));
            destino.setIdentdOpContstc(origem.getGrupoRRC0027Contstc().getIdentdOpContstc());
            destino.setIdentdPartPrincipal(origem.getIdentdPartPrincipal());
            destino.setIdentdPartAdmtd(origem.getIdentdPartAdmtd());

            return destino;
        };
    }
}
