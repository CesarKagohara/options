package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.rrc.vo.ArqRecordOutputData;

import java.util.Date;
import java.util.List;

public interface ArqRecordOutputDataDAO {

   List<ArqRecordOutputData> obterPorAtlRootId(Long atlRootId, Date dtRef);

   int countArquivosPorAtlRootId(Long atlRootId, Date dtRef);

   int countPorAtlRootId(Long atlRootId, Date dtRef);

   void removerPorAtlRootId(Long atlRootId, Date dtRef);

   void inserir(ArqRecordOutputData record);

   boolean existeLockArquivo(Long atlRootId);

   void inserirLockArquivo(Long atlRootId);

   void criaArquivosRegistros(Integer inputRecords, Date dtRef, Long rootId);

   Integer obterQtdRegistros(Date dtRef, Long rootId);

}