package br.org.cipbancos.rrc.dao;

/**
 * Classe responsável por toda a manipulação de dados da tabela OP Renegociacao.
 */

import br.org.cipbancos.rrc.vo.OperacaoRenegociacao;

public interface OperacaoRenegociacaoDAO {

    /**
     * Grava no BD da operacao Renegociacao
     *
     * @param operacaoRenegociacao A ser inserida
     */
    void inserir(OperacaoRenegociacao operacaoRenegociacao);

    /**
     * Atualiza no BD da Operacao Renegociacao
     *
     * @param operacaoRenegociacao A ser atualizada
     */
    void atualizar(OperacaoRenegociacao operacaoRenegociacao);

    /**
     * Exclui no BD da operacao Renegociacao
     *
     * @param operacaoRenegociacao A ser excluída
     */
    void excluir(OperacaoRenegociacao operacaoRenegociacao);

    /**
     * Busca no BD a operacao Renegociacao
     *
     * @param operacaoRenegociacao A ser buscada
     */
    OperacaoRenegociacao buscar(Long id);

}