package br.org.cipbancos.rrc.bean;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;

import java.io.Serializable;
import java.util.List;

public interface GrupoGestPart extends Serializable {

    List<GrupoTitlarGestPart> getListaGrupoTitlar();

    void setErrorCode(String errorCode);
}
