package br.org.cipbancos.rrc.bean.rrc0005;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.rrc.bean.GrupoGestPart;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;

@XStreamAlias("Grupo_RRC0005_GestPart")
public class GrupoRRC0005GestPart extends ErrorCodeBean implements GrupoGestPart {

    private static final long serialVersionUID = 1L;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0005_Titlar")
    private List<GrupoRRC0005TitlarGestPart> listagrupoRRC0005Titlar = new ArrayList<>();

    public List<GrupoRRC0005TitlarGestPart> getListagrupoRRC0005Titlar() {
        return listagrupoRRC0005Titlar;
    }

    public void setListagrupoRRC0005Titlar(List<GrupoRRC0005TitlarGestPart> listagrupoRRC0005Titlar) {
        this.listagrupoRRC0005Titlar = listagrupoRRC0005Titlar;
    }

    @Override
    public List getListaGrupoTitlar() {
        return getListagrupoRRC0005Titlar();
    }

}
