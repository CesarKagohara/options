package br.org.cipbancos.rrc.bean.arrc022;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.arrc023.GrupoARRC023CanceltNegcRecbvlActoRET;
import br.org.cipbancos.rrc.bean.arrc023.GrupoARRC023CanceltNegcRecbvlRecsdoRET;

@XStreamAlias("Grupo_ARRC022RET_NegcRecbvl")
public class GrupoARRC022RETNegcRecbvl extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("SitRetReq")
    private SPBString sitRetReq;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC022RET_NegcRecbvlActo")
    private List<GrupoARRC022RETNegcRecbvlActo> listaGrupoARRC022RETNegcRecbvlActo = new ArrayList<GrupoARRC022RETNegcRecbvlActo>();

    @XStreamImplicit(itemFieldName = "Grupo_ARRC022RET_NegcRecbvlRecsdo")
    private List<GrupoARRC022RETNegcRecbvlRecsdo> listaGrupoARRC022RETNegcRecbvlRecsdo = new ArrayList<GrupoARRC022RETNegcRecbvlRecsdo>();

    public SPBString getSitRetReq() {
        return sitRetReq;
    }

    public void setSitRetReq(SPBString sitRetReq) {
        this.sitRetReq = sitRetReq;
    }

    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public List<GrupoARRC022RETNegcRecbvlActo> getListaGrupoARRC022RETNegcRecbvlActo() {
        return listaGrupoARRC022RETNegcRecbvlActo;
    }

    public void setListaGrupoARRC022RETNegcRecbvlActo(List<GrupoARRC022RETNegcRecbvlActo> listaGrupoARRC022RETNegcRecbvlActo) {
        this.listaGrupoARRC022RETNegcRecbvlActo = listaGrupoARRC022RETNegcRecbvlActo;
    }

    public List<GrupoARRC022RETNegcRecbvlRecsdo> getListaGrupoARRC022RETNegcRecbvlRecsdo() {
        return listaGrupoARRC022RETNegcRecbvlRecsdo;
    }

    public void setListaGrupoARRC022RETNegcRecbvlRecsdo(List<GrupoARRC022RETNegcRecbvlRecsdo> listaGrupoARRC022RETNegcRecbvlRecsdo) {
        this.listaGrupoARRC022RETNegcRecbvlRecsdo = listaGrupoARRC022RETNegcRecbvlRecsdo;
    }
}
