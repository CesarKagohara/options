package br.org.cipbancos.rrc.bean.arrc001;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.rrc.vo.UnidadeRecebivel;

public class GrupoARRC001UniddRecbvl extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("DtPrevtLiquid")
    private SPBLocalDate dtPrevtLiquid;

    @XStreamAlias("VlrTot")
    private SPBBigDecimal vlrTot;

    @XStreamAlias("VlrPreContrd")
    private SPBBigDecimal vlrPreContrd;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC001_DomclBanc")
    private List<GrupoARRC001DomclBanc> listagrupoARRC001DomclBanc = new ArrayList<>();

    @XStreamOmitField
    private boolean erroValidacao;

    @XStreamOmitField
    private UnidadeRecebivel unidadeRecebivel;

    public SPBLocalDate getDtPrevtLiquid() {
        return dtPrevtLiquid;
    }

    public void setDtPrevtLiquid(SPBLocalDate dtPrevtLiquid) {
        this.dtPrevtLiquid = dtPrevtLiquid;
    }

    public SPBBigDecimal getVlrTot() {
        return vlrTot;
    }

    public void setVlrTot(SPBBigDecimal vlrTot) {
        this.vlrTot = vlrTot;
    }

    public SPBBigDecimal getVlrPreContrd() {
        return vlrPreContrd;
    }

    public void setVlrPreContrd(SPBBigDecimal vlrPreContrd) {
        this.vlrPreContrd = vlrPreContrd;
    }

    public List<GrupoARRC001DomclBanc> getListagrupoARRC001DomclBanc() {
        return listagrupoARRC001DomclBanc;
    }

    public void setListagrupoARRC001DomclBanc(List<GrupoARRC001DomclBanc> listagrupoARRC001DomclBanc) {
        this.listagrupoARRC001DomclBanc = listagrupoARRC001DomclBanc;
    }

    public boolean hasErroValidacao() {
        return hasErrorCode() || erroValidacao;
    }

    public void setErroValidacao(boolean erroValidacao) {
        this.erroValidacao = erroValidacao;
    }

    public UnidadeRecebivel getUnidadeRecebivel() {
        return unidadeRecebivel;
    }

    public void setUnidadeRecebivel(UnidadeRecebivel unidadeRecebivel) {
        this.unidadeRecebivel = unidadeRecebivel;
    }
}
