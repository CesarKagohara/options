package br.org.cipbancos.rrc.bean.rrc0021;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_RRC0021R1_RenegcDiv")
public class GrupoRRC0021R1RenegcDiv extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdentdOpOrRenegcDiv")
    private SPBString identdOpOrRenegcDiv;

    public SPBString getIdentdOpOrRenegcDiv() {
        return identdOpOrRenegcDiv;
    }

    public void setIdentdOpOrRenegcDiv(SPBString identdOpOrRenegcDiv) {
        this.identdOpOrRenegcDiv = identdOpOrRenegcDiv;
    }

}
