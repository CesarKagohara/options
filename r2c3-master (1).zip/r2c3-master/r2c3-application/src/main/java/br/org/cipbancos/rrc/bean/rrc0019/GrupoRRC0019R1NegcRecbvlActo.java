package br.org.cipbancos.rrc.bean.rrc0019;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;

@XStreamAlias("Grupo_RRC0019R1_NegcRecbvlActo")
public class GrupoRRC0019R1NegcRecbvlActo extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0019R1_RegRecbvl")
    private List<GrupoRRC0019R1RegRecbvl> listagrupoRRC0019R1RegRecbvl = new ArrayList<GrupoRRC0019R1RegRecbvl>();

    @XStreamImplicit(itemFieldName = "Grupo_RRC0019R1_Constitr")
    private List<GrupoRRC0019R1Constitr> listagrupoRRC0019R1Constitr = new ArrayList<GrupoRRC0019R1Constitr>();

    public List<GrupoRRC0019R1RegRecbvl> getListagrupoRRC0019R1RegRecbvl() {
        return listagrupoRRC0019R1RegRecbvl;
    }

    public void setListagrupoRRC0019R1RegRecbvl(List<GrupoRRC0019R1RegRecbvl> listagrupoRRC0019R1RegRecbvl) {
        this.listagrupoRRC0019R1RegRecbvl = listagrupoRRC0019R1RegRecbvl;
    }

    public List<GrupoRRC0019R1Constitr> getListagrupoRRC0019R1Constitr() {
        return listagrupoRRC0019R1Constitr;
    }

    public void setListagrupoRRC0019R1Constitr(List<GrupoRRC0019R1Constitr> listagrupoRRC0019R1Constitr) {
        this.listagrupoRRC0019R1Constitr = listagrupoRRC0019R1Constitr;
    }

}
