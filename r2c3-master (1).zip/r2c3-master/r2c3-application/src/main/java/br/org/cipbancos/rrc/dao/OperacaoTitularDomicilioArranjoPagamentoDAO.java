package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.rrc.vo.Operacao;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilio;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilioArranjoPagamento;

import java.util.List;

public interface OperacaoTitularDomicilioArranjoPagamentoDAO {

    void inserir(OperacaoTitularDomicilioArranjoPagamento operacaoArranjoPagamento);

    List<OperacaoTitularDomicilioArranjoPagamento> buscarByIdOpTitlarDomicilio(List<Long> idOpTitlarDomc);

    List<OperacaoTitularDomicilioArranjoPagamento> buscar(OperacaoTitularDomicilio operacaoTitularDomicilio);

    void remover(OperacaoTitularDomicilio operacaoTitularDomicilio, Operacao operacao, String arranjo);

    void removerArranjosPorIdOp(Long idOp);
}
