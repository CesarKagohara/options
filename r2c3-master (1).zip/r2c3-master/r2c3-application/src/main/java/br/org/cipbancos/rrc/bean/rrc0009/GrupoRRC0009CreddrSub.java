package br.org.cipbancos.rrc.bean.rrc0009;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;


public class GrupoRRC0009CreddrSub extends ErrorCodeBean implements Serializable {

    @XStreamAlias("CNPJCreddrSub")
    private SPBString cNPJCreddrSub;

    public SPBString getcNPJCreddrSub() {
        return cNPJCreddrSub;
    }

    public void setcNPJCreddrSub(SPBString cNPJCreddrSub) {
        this.cNPJCreddrSub = cNPJCreddrSub;
    }
}
