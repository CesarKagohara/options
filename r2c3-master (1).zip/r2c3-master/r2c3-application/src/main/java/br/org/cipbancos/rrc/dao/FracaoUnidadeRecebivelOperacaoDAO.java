package br.org.cipbancos.rrc.dao;

import br.org.cip.api.r2c3.model.AgendaOnline;
import br.org.cipbancos.atlante.api.handler.Context;
import br.org.cipbancos.rrc.bean.rrc0010.GrupoRRC0010UniddRecbvl;
import br.org.cipbancos.rrc.enums.IcSitFracaoUniddRecbvl;
import br.org.cipbancos.rrc.enums.TipoNegociacao;
import br.org.cipbancos.rrc.handler.recalculo.bean.RecalculoFracaoVO;
import br.org.cipbancos.rrc.vo.*;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface FracaoUnidadeRecebivelOperacaoDAO {

    void inserir(FracaoUnidadeRecebivelOperacao fracao);

    int atualizar(FracaoUnidadeRecebivelOperacao fracao,  Date dtRef);

    void atualizarLote(Date dtRef, List<FracaoUnidadeRecebivelOperacao> fracao, String sufixo);

    void removerFumacasPorIds(Map<String, Set<Long>> idUniddRecbvsFumacaParaRemoverPorSufixo);

    void atualizarLote(Date dtRef, List<FracaoUnidadeRecebivelOperacao> fracoes, String sufixo, boolean isCancelamento);

    int baixar(Integer idPartCreddr, Date dtRef, List<Long> idsUniddRecbvl, String sufixo);

    List<FracaoUnidadeRecebivelOperacao> buscarPorRecebivel(Date dtRef, String nrCnpjCreddr, String cdArrjPgto, String cpfCnpjRecebedor, Date dtPrevtLiquid, String nrCpfCnpjTitlar, String nrCpfCnpjTitlarAnterior);

    List<FracaoUnidadeRecebivelOperacao> buscarPorFiltroParaCancelamento(Date refDate, Set<String> codArrjPgtos, Set<String> cnpjCreddrs, Set<String> cnpjUsuRecbdrs, String cnpjCnpjBaseCpfTitlar, Date dtIniOp, Date dtFimOp, Long idOp);

    List<FracaoUnidadeRecebivelOperacao> buscarPorFiltroParaCancelamento(Date refDate, String cnpjUsuRecbdr, String cnpjCnpjBaseCpfTitlar, Integer idPartCreddr, Set<Long> idUniddRecbvs, Long idOp);

    Map<Integer, Map<Long, Integer>> buscarUltimosNrPriddNovo(Date refDate, Set<String> codArrjPgtos, Set<String> cnpjCreddrs, Set<String> cnpjUsuRecbdrs, String cnpjCnpjBaseCpfTitlar, Date dtIniOp, Date dtFimOp);

    List<FracaoUnidadeRecebivelOperacao> buscarPorFiltroNegociacaoLivreAtivo(Date refDate, Set<String> codArrjPgtos, Set<String> cnpjCreddrs, Set<String> cnpjUsuRecbdrs, String cnpjCnpjBaseCpfTitlar, Date dtIniOp, Date dtFimOp, IcSitFracaoUniddRecbvl icSit);

    List<FracaoUnidadeRecebivelOperacao> buscarPorFiltroNegociacaoOutrasOperacoesAtivo(Date refDate, Set<String> codArrjPgtos, Set<String> cnpjCreddrs, Set<String> cnpjUsuRecbdrs, String cnpjCnpjBaseCpfTitlar, Date dtIniOp, Date dtFimOp, IcSitFracaoUniddRecbvl icSit, TipoNegociacao[] tiposPermitidos);

    List<FracaoUnidadeRecebivelOperacao> buscarComFiltros(GrupoRRC0010UniddRecbvl grupoRRC0010UniddRecbvl, Date dtRef, Boolean validarAnuencia, Integer nrIspbPartAdmtdFinanciadora, String nrCnpjFinanciadora, List<OptinVO> optinVOList);

    List<FracaoUnidadeRecebivelOperacao> buscarFracoesPorIdOp(Long idOp, Date dtRef);

    List<FracaoUnidadeRecebivelOperacao> buscarFracoesPorIdOpComCancelada(Long idOp, Date dtRef);

    List<FracaoUnidadeRecebivelOperacao> buscarPorIdOpIdPartCreddr(Date dtRef, Long idOp, Integer idPartCreddr);

    List<FracaoUnidadeRecebivelOperacao> buscaFracaoUnidadeRecebivelOperacaoComFiltros(ConsultaNegociacaoRecebivel consultaNegociacaoRecebivel);

    Map<Long, Map<String, List<FracaoUnidadeRecebivelOperacao>>> buscarFumacasPorIdsOpsCnpjBaseRecebedores(Integer idPartCreddr, Date dtRefAnterior, Set<Long> idOps, Set<String> cnpjsBase);

    void inserirLote(List<FracaoUnidadeRecebivelOperacao> fracoes);

    void copiarFracoesDoOntemParaHoje(Long idAtlRoot, Date dtRefOntem, Date dtRefAtual, Map<String, Set<Long>> fracoesOntem);

    List<FracaoUnidadeRecebivelOperacao> buscarURsFiltroAgendaOnLine(AgendaOnline agendaOnline, String registradora, Date dtRef, String cnpjUsrFinalRecbdr);

    List<FracaoUnidadeRecebivelOperacao> buscarFracoesAgendaPorReduzido(List<UrReduzidaVO> urs, Integer idPartCredd, Date dtref, boolean apenasAConstituir, String nrCPFCNPJUsuFinalRecbdr);

    List<FracaoUnidadeRecebivelOperacao> buscarPorIdUniddRecbvsAtivoLivre(Date dtRef, String sufixo, Integer idPartCreddr, List<Long> idUniddRecbvs);

    List<FracaoUnidadeRecebivelOperacao> buscarPorIdUniddRecbvsAtivoOutrasOperacoes(Date dtRef, String sufixo, Integer idPartCreddr, List<Long> idUniddRecbvs, TipoNegociacao[] tiposNegociacao);

    Map<Long, List<FracaoUnidadeRecebivelOperacao>> buscarPorIdUniddRecbvs(Date dtRef, String sufixo, Integer idPartCreddr, List<Long> idUniddRecbvs);

    List<FracaoUnidadeRecebivelOperacao> buscaFracaoUnidadeRecebivelOperacaoPorIdOp(ConsultaNegociacaoRecebivel consulta);

    List<FracaoUnidadeRecebivelOperacao> buscaFracaoUnidadeRecebivelOperacaoComFiltrosBaseCNPJ(ConsultaNegociacaoRecebivel consultaNegociacaoRecebivel);

    Map<Long, Integer> buscarUltimosNrPridd(String sufixo, Integer idPartCreddr, List<Long> idUniddRecbvs, Date referenceDate);

    List<FracaoUnidadeRecebivelOperacao> buscarPorIdsURs(Date dtRef, String sufixo, Integer idPartCreddr, List<Long> idUniddRecbvs, boolean filtraOperacoes, boolean retornarApenasNaoFumacas);

    void atualizarLotePorId(Context context, ParticipanteVO participanteVO, String sufixo, List<FracaoUnidadeRecebivelOperacao> fracoes);

    List<InfoAdicTotalizadoresUr> buscarTotalizadoresAdicionaisUr(Integer idPartAdm, Date refDate, String sufixo, Integer idPartCred, Set<Long> listaIdUrs);

    List<RecalculoFracaoVO> obterFracoesPorOpRecalcDesc(Long idOp, Date refDate);

    List<RecalculoFracaoVO> obterFracoesLivresRecalcDesc(String sufixo, Integer idPartCreddr, List<Long> idUniddRecbvs, Date referenceDate);

    void atualizarLoteFracaoRecalcPeloId(String sufixo, Integer idFunc, Date dtRef, List<RecalculoFracaoVO> fracoes);

    List<FracaoUnidadeRecebivelOperacao> buscarFumacasPorIdOpIdPartCreddr(Date dtRef, Date dtPrevtLiquidInicio, Long idOp, Integer idPartCreddr, String sufixo);
}
