package br.org.cipbancos.rrc.dao;

import java.util.Date;
import java.util.List;

public interface DominioCodigoArranjoPagamentoDAO {

    String getCodArranjoFromInterop(String cdArranjoInterop);

    String getCodArranjoInteropFromCodArranjo(String cdArranjo);

    List<String> getCodigosDominiosArranjo();

    List<String> getCodigosDominiosArranjoInterop();

    List<String> getArranjosIncluidosFromDate(Date dhInclusao);

    boolean existeCodArranjo(String cdArranjo);
}
