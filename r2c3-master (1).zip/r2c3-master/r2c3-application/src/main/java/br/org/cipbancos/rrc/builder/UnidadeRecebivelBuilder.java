package br.org.cipbancos.rrc.builder;

import br.org.cipbancos.rrc.vo.UnidadeRecebivel;

import java.util.Date;

public class UnidadeRecebivelBuilder {
    private UnidadeRecebivel unidadeRecebivel;

    public UnidadeRecebivelBuilder(){
        unidadeRecebivel = new UnidadeRecebivel();
    }

    public UnidadeRecebivelBuilder comIdParticipantePrincipal(Long idParticipantePrincipal) {
        this.unidadeRecebivel.setIdPartPrincipal(idParticipantePrincipal);
        return this;
    }

    public UnidadeRecebivelBuilder comIdParticipanteAdministrado(Long idParticipanteAdministrado) {
        this.unidadeRecebivel.setIdPartAdmtd(idParticipanteAdministrado);
        return this;
    }

    public UnidadeRecebivelBuilder comCpfCnpjUsuarioFinalRecebedor(String cpfCnpjUsuraioFinalRecebedor) {
        this.unidadeRecebivel.setNrCpfCnpjUsurioFinlRecbdr(cpfCnpjUsuraioFinalRecebedor);
        return this;
    }

    public UnidadeRecebivelBuilder comCodigoArranjoPagamento(String codigoArranjoPagamento) {
        this.unidadeRecebivel.setCdArrjPgto(codigoArranjoPagamento);
        return this;
    }

    public UnidadeRecebivelBuilder comDataPrevistaLiquidacao(Date dataPrevistaLiquidacao) {
        this.unidadeRecebivel.setDtPrevtLiqui(dataPrevistaLiquidacao);
        return this;
    }

    public UnidadeRecebivelBuilder comIcSit(String icSit) {
        this.unidadeRecebivel.setIcSit(icSit);
        return this;
    }

    public UnidadeRecebivel build() {
            return this.unidadeRecebivel;
    }

}
