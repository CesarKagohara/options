package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.rrc.bean.PaginacaoApi;
import java.util.List;

public interface PaginacaoApiDAO {

    int insereDadosAPaginar(List<Object> data, Long rootId);

    Long qtdPages(Long rootId);

    List<PaginacaoApi> recuperaDadosPaginados(Long rootId, Integer tamanhoPagina, Integer pagina);

}
