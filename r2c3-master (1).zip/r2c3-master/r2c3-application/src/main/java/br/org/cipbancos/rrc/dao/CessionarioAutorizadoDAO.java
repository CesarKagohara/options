package br.org.cipbancos.rrc.dao;

import java.util.List;

import br.org.cipbancos.rrc.vo.CessionarioAutorizado;
import br.org.cipbancos.rrc.vo.DominioVO;

public interface CessionarioAutorizadoDAO {

    List<CessionarioAutorizado> getCessionariosPorIdOp(Long idOp);

    int excluirCessionariosPorIdOp(Long idOp);

    int incluirCessionariosBatch(List<CessionarioAutorizado> listaCessionarios);


}
