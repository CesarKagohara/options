package br.org.cipbancos.rrc.bean.rrc0021;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLong;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoConsultaNegcRecbvl;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

import java.io.Serializable;

@XStreamAlias("Grupo_RRC0021_NegcRecbvl")
public class GrupoRRC0021NegcRecbvl extends ErrorCodeBean implements GrupoConsultaNegcRecbvl, Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdentdOp")
    private SPBLong identdOp;

    @XStreamAlias("CNPJ_CNPJBase_CPFUsuFinalRecbdr")
    private SPBString cNPJCNPJBaseCPFUsuFinalRecbdr;

    @XStreamAlias("CNPJ_CNPJBase_CPFTitlar")
    private SPBString cNPJCNPJBaseCPFTitlar;

    @XStreamOmitField
    private Boolean filtroConstituido;

    public SPBLong getIdentdOp() {
        return identdOp;
    }

    public void setIdentdOp(SPBLong identdOp) {
        this.identdOp = identdOp;
    }

    public SPBString getcNPJCNPJBaseCPFUsuFinalRecbdr() {
        return cNPJCNPJBaseCPFUsuFinalRecbdr;
    }

    public void setcNPJCNPJBaseCPFUsuFinalRecbdr(SPBString cNPJCNPJBaseCPFUsuFinalRecbdr) {
        this.cNPJCNPJBaseCPFUsuFinalRecbdr = cNPJCNPJBaseCPFUsuFinalRecbdr;
    }

    public SPBString getcNPJCNPJBaseCPFTitlar() {
        return cNPJCNPJBaseCPFTitlar;
    }

    public void setcNPJCNPJBaseCPFTitlar(SPBString cNPJCNPJBaseCPFTitlar) {
        this.cNPJCNPJBaseCPFTitlar = cNPJCNPJBaseCPFTitlar;
    }

    public Boolean isFiltroConstituido() {
        return filtroConstituido;
    }

    public void setFiltroConstituido(Boolean filtroConstituido) {
        this.filtroConstituido = filtroConstituido;
    }
}
