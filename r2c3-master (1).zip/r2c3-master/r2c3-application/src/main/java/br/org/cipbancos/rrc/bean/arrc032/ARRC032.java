package br.org.cipbancos.rrc.bean.arrc032;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@XStreamAlias("ARRC032")
public class ARRC032 extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamAlias("SitProc")
    private SPBString sitProc;

    @XStreamAlias("GrdProc")
    private SPBString grdProc;

    @XStreamAlias("Grupo_ARRC032_Arq")
    private GrupoARRC032Arq grupoARRC032Arq;

    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public SPBString getSitProc() {
        return sitProc;
    }

    public void setSitProc(SPBString sitProc) {
        this.sitProc = sitProc;
    }

    public GrupoARRC032Arq getGrupoARRC032Arq() {
        return grupoARRC032Arq;
    }

    public void setGrupoARRC032Arq(GrupoARRC032Arq grupoARRC032Arq) {
        this.grupoARRC032Arq = grupoARRC032Arq;
    }

    public SPBString getGrdProc() {
        return grdProc;
    }

    public void setGrdProc(SPBString grdProc) {
        this.grdProc = grdProc;
    }
}
