package br.org.cipbancos.rrc.bean.rrc0005;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;

@XStreamAlias("Grupo_RRC0005R1_NegcRecbvlActo")
public class GrupoRRC0005R1NegcRecbvlActo extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0005R1_RegRecbvl")
    private List<GrupoRRC0005R1RegRecbvl> listaGrupoRRC0005R1RegRecbvl = new ArrayList<>();

    @XStreamImplicit(itemFieldName = "Grupo_RRC0005R1_Constitr")
    private List<GrupoRRC0005R1Constitr> listaGrupoRRC0005R1Constitr = new ArrayList<>();

    public List<GrupoRRC0005R1RegRecbvl> getListaGrupoRRC0005R1RegRecbvl() {
        return listaGrupoRRC0005R1RegRecbvl;
    }

    public void setListaGrupoRRC0005R1RegRecbvl(List<GrupoRRC0005R1RegRecbvl> listaGrupoRRC0005R1RegRecbvl) {
        this.listaGrupoRRC0005R1RegRecbvl = listaGrupoRRC0005R1RegRecbvl;
    }

    public List<GrupoRRC0005R1Constitr> getListaGrupoRRC0005R1Constitr() {
        return listaGrupoRRC0005R1Constitr;
    }

    public void setListaGrupoRRC0005R1Constitr(List<GrupoRRC0005R1Constitr> listaGrupoRRC0005R1Constitr) {
        this.listaGrupoRRC0005R1Constitr = listaGrupoRRC0005R1Constitr;
    }

}
