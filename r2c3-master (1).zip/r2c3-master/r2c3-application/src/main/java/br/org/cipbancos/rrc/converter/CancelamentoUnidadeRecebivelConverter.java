package br.org.cipbancos.rrc.converter;

import java.util.Date;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import br.org.cipbancos.rrc.funcional.Converter;
import br.org.cipbancos.rrc.vo.CancelamentoUnidadeRecebivel;

/**
 * Classe utilitária para converter informações de Cancelamento Unidades Recebíveis de entrada para realizar,
 * inserções no BD e conversões de Entrada para Retorno.
 *
 * @author anderson.martins
 * @since 1.0
 */
public class CancelamentoUnidadeRecebivelConverter {

    private CancelamentoUnidadeRecebivelConverter() {}

    /**
     * Popula os parametros utilizados para buscar um CancelamentoUnidadeRecebivel no BD.
     * @return Um conjunto de parametros para setar as informações no ElSql.
     */
    public static Converter<CancelamentoUnidadeRecebivel, MapSqlParameterSource> emIdOperacaoCancelamentoParaBuscarCancelamentoUnidadeRecebivel() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();

            parametros.addValue("identificadorOperacaoCancelamento", origem.getIdentificadorOperacaoCancelamento());

            return parametros;
        };
    }


    /**
     * Popula os parametros utilizados para inserir um CancelamentoUnidadeRecebivel no BD.
     * @return Um conjunto de parametros para setar as informações no ElSql.
     */
    public static Converter<CancelamentoUnidadeRecebivel, MapSqlParameterSource> emInsercaoCancelamentoUnidadeRecebivel() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();

            parametros.addValue("codigoArranjoPagamento", origem.getCodigoArranjoPagamento());
            parametros.addValue("dataPrevistaLiquidacao", origem.getDataPrevistaLiquidacao());
            parametros.addValue("identificadorOperacaoCancelamento", origem.getIdentificadorOperacaoCancelamento());
            parametros.addValue("numeroCpfCnpjTitular", origem.getNumeroCpfCnpjTitular());
            parametros.addValue("numeroCnpjCredenciadora", origem.getNumeroCnpjCredenciadora());
            parametros.addValue("numeroCpfCnpjUsuarioFinalRecebedor", origem.getNumeroCpfCnpjUsuarioFinalRecebedor());
            parametros.addValue("indicadorConstituir", origem.getIndicadorConstituir());
            parametros.addValue("numeroValorCancelado", origem.getNumeroValorCancelado());
            parametros.addValue("dhIncl", new java.sql.Timestamp(new Date().getTime()));
            parametros.addValue("dhUltAlt", new java.sql.Timestamp(new Date().getTime()));

            return parametros;
        };
    }
}
