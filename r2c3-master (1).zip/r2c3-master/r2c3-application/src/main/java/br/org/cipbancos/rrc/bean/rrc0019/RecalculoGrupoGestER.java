package br.org.cipbancos.rrc.bean.rrc0019;

import java.util.LinkedList;
import java.util.List;

import br.org.cipbancos.rrc.bean.GrupoGestER;
import br.org.cipbancos.rrc.bean.GrupoTitlar;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilio;

public class RecalculoGrupoGestER implements GrupoGestER {

    private List<GrupoTitlar> listGrupoTitlar;

    public RecalculoGrupoGestER(List<OperacaoTitularDomicilio> opTitularDomomicilioList) {
        listGrupoTitlar = new LinkedList();
        for (OperacaoTitularDomicilio operacaoTitularDomicilio : opTitularDomomicilioList) {
            listGrupoTitlar.add(new RecalculoGrupoTitlar(operacaoTitularDomicilio));
        }
    }

    @Override
    public List<GrupoTitlar> getListaGrupoTitlar() {
        return listGrupoTitlar;
    }

    @Override
    public void setErrorCode(String errorCode) {
        throw new UnsupportedOperationException("Read only");
    }

}
