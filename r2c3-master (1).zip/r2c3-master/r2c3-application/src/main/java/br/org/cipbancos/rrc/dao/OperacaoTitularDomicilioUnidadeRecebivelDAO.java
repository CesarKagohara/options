package br.org.cipbancos.rrc.dao;

/**
 * Classe responsável por toda a manipulação de dados da tabela OP.
 */

import br.org.cipbancos.rrc.handler.recalcpart.vo.OpUsuarioFinal;
import br.org.cipbancos.rrc.vo.Operacao;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilio;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilioUnidadeRecebivel;
import br.org.cipbancos.rrc.vo.UnidadeRecebivel;

import java.util.Date;
import java.util.List;

public interface OperacaoTitularDomicilioUnidadeRecebivelDAO {

    /**
     * Busca no BD a Operacao Titular Domicilio Unidade Recebivel
     *
     * @param operacaoTitularDomicilioUnidadeRecebivel A ser buscada
     * @return Operacao Titular Domicilio Unidade Recebivel
     */
    OperacaoTitularDomicilioUnidadeRecebivel buscar(
            OperacaoTitularDomicilioUnidadeRecebivel operacaoTitularDomicilioUnidadeRecebivel);

    /**
     * Busca no BD a Operacao Titular Domicilio Unidade Recebivel
     *
     * @param operacaoTitularDomicilio Que contem a Operacao Titular Domicilio Unidade Recebivel
     * @return uma lista de Operacao Titular Domicilio Unidade Recebivel
     */
    List<OperacaoTitularDomicilioUnidadeRecebivel> buscarPeloTitularDomicilio(OperacaoTitularDomicilio operacaoTitularDomicilio);

    /**
     *
     * @param listaOperacaoTitularDomicilioUnidadeRecebivel
     */
    void inserir(List<OperacaoTitularDomicilioUnidadeRecebivel> listaOperacaoTitularDomicilioUnidadeRecebivel);

    /**
     * Busca a Operação Titular Domicilio de uma UR.
     *
     * @param operacao Informada.
     * @param usuarioFinal Associado a Operação.
     * @return uma Operação Titular de UR comtemplando essa situação.
     */
    OperacaoTitularDomicilioUnidadeRecebivel buscarPorOperacaoEUsuarioFinal(Operacao operacao, String usuarioFinal);

    /**
     * Busca Unidade Recebível por Id.
     * @param idOp
     * @param idOperacaoTitular
     * @return
     */
    List<OperacaoTitularDomicilioUnidadeRecebivel> buscarOpTitularUnidadeRecebivelPorId(Long idOp, Long idOperacaoTitular);

    List<OpUsuarioFinal> obterUsuariosFinaisPorIdOp(List<Long> idOp);



    /**
     * Busca a Operação Titular Domicilio de uma UR.
     *
     * @param idOp
     * @param nrCpfCnpjUsurioFinlRecbdr Associado a Operação.
     * @return uma Operação Titular de UR comtemplando essa situação.
     */
    OperacaoTitularDomicilioUnidadeRecebivel buscarPorIdOpUsuarioFinal(Long idOp, String nrCpfCnpjUsurioFinlRecbdr);

    void remover(OperacaoTitularDomicilio operacaoTitularDomicilio, UnidadeRecebivel ur);

    List<String> buscarNrCnpjCreddrPorIdOp(Long idOp);

    List<OperacaoTitularDomicilioUnidadeRecebivel> buscarPorRecebivel(Date dtRef, String nrCnpjCreddr, String cdArrjPgto, String cpfCnpjRecebedor, Date dtPrevtLiquid, String nrCpfCnpjTitlar);

    List<String> buscarCnpjsUsuFinalRecbrPorCnpjTitular(String nrCpfCnpjTitlar);

}
