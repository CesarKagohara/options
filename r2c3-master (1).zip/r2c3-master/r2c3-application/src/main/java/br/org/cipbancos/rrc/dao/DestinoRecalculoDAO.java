package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.rrc.vo.DestinoRecalculoVO;

import java.util.List;
import java.util.Set;

public interface DestinoRecalculoDAO {

    void inserirDestinoRecalculoPorLote(List<DestinoRecalculoVO> destinoRecalculoVOS);
}
