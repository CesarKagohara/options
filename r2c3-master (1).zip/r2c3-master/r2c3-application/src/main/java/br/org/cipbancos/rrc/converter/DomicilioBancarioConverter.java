package br.org.cipbancos.rrc.converter;

import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001DomclBanc;
import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001DomclBancRecsdo;
import br.org.cipbancos.rrc.funcional.Converter;

/**
 * Classe utilitária para converter informações de Unidades Recebíveis de entrada para realizar,
 * inserções no BD e conversões de Entrada para Retorno.
 *
 * @author otavio.ferreira
 * @since 1.0
 */
public class DomicilioBancarioConverter {

    private DomicilioBancarioConverter() {
    }

    /**
     * Popula um Domicílio Bancário, caso ele esteja recusado.
     */
    public static Converter<GrupoARRC001DomclBanc, GrupoARRC001DomclBancRecsdo> emDomicilioBancarioRecusado() {
        return origem -> {
            GrupoARRC001DomclBancRecsdo destino = new GrupoARRC001DomclBancRecsdo();

            destino.setcNPJCPFTitlarCt(origem.getcNPJCPFTitlarCt());
            destino.setiSPBBcoRecbdr(origem.getiSPBBcoRecbdr());
            destino.setTpCt(origem.getTpCt());
            destino.setAg(origem.getAg());

            if (null != origem.getCt()) destino.setCt(origem.getCt());

            if (null != origem.getCtPgto()) destino.setCtPgto(origem.getCtPgto());

            destino.setVlrPrevtLiquid(origem.getVlrPrevtLiquid());
            destino.setDtEftLiquid(origem.getDtEftLiquid());
            destino.setVlrEftLiquid(origem.getVlrEftLiquid());
            destino.setIdentdOp(origem.getIdentdOp());

            return destino;
        };
    }
}
