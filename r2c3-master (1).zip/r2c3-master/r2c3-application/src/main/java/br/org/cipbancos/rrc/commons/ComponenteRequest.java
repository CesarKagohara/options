package br.org.cipbancos.rrc.commons;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import br.org.cipbancos.atlante.api.handler.Context;
import br.org.cipbancos.atlante.output.http.OutputRequestHTTP;

//import br.org.cipbancos.atlante.api.handler.RemoteOutputCallBack;
//import br.org.cipbancos.atlante.api.handler.RemoteOutputHandleHttpCallback;

//import br.org.cip.arche.commons.api.http.dispatcher.HttpRequest;

//@Component
public class ComponenteRequest {

    private static final Logger LOG = LoggerFactory.getLogger(ComponenteRequest.class);

    @Autowired
    private OutputRequestHTTP outputRequestHTTP;


    public void requisicaoComCallback(Context ctx, Integer ispb, String dataType, List<Object> records) {

        /*RemoteOutputHandleHttpCallback<List<HttpRequest<Object>>> remote =
                new RemoteOutputHandleHttpCallback<List<HttpRequest<Object>>>(new BatchId(ctx.getBatchId()),
                dataType, ChannelType.JSON_SERVICE, new Destination(ispb),
                "MES01", new RemoteOutputCallBack<List<HttpRequest<Object>>>() {
            @Override
            public void callBack(List<HttpRequest<Object>> requests) {
                HttpRequest<Object> request = requests.get(0);
                if (request.getResponse() != null && !HttpStatus.OK.equals(request.getResponse().getStatus())) {
                    //TODO: Verificar se quer que faça com exceção ou não
                    tratativaErro(
                            "A requisicao para o participante " + ispb + " na url "
                                    + request.getUrl() + " retornou status " + request.getResponse()
                                    .getStatus() + ", com o body " + request.getResponse().getBody(), null);
                }
            }

        });
        records.forEach(remote::addRecord);
        outputRequestHTTP.processAsSubBatch(remote);*/
    }

    public void requisicaoSemCallback(Context ctx, Integer ispb, String dataType, List<Object> records) {
        /*RemoteOutputHandle rho =
                new RemoteOutputHandle(dataType, ChannelType.JSON_SERVICE,
                        new Destination(ispb), "MES01",
                        new BatchId(ctx.getBatchId()),
                        null, new CustomTransportType('H'));

        records.forEach(rho::addRecord);
        outputRequestHTTP.processAsSubBatch(rho);*/

    }

    /**
     *
     * @param message
     * @param exception
     */
    private void tratativaErro(String message, Throwable exception) {
        if (exception == null) {
            LOG.error(message);
        }
        else {
            LOG.error(message, exception);
        }
    }
}
