package br.org.cipbancos.rrc.bean.arrc022;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_ARRC022RET_NegcRecbvlActo")
public class GrupoARRC022RETNegcRecbvlActo extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdentdNegcRecbvl")
    private SPBString identdNegcRecbvl;

    @XStreamAlias("IdentdOp")
    private SPBString identdOp;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC022RET_RegRecbvl")
    private List<GrupoARRC022RETRegRecbvl> listagrupoARRC022RETRegRecbvl = new ArrayList<>();

    @XStreamImplicit(itemFieldName = "Grupo_ARRC022RET_Constitr")
    private List<GrupoARRC022RETConstitr> listagrupoARRC022RETConstitr = new ArrayList<>();

    public SPBString getIdentdNegcRecbvl() {
        return identdNegcRecbvl;
    }

    public void setIdentdNegcRecbvl(SPBString identdNegcRecbvl) {
        this.identdNegcRecbvl = identdNegcRecbvl;
    }

    public SPBString getIdentdOp() {
        return identdOp;
    }

    public void setIdentdOp(SPBString identdOp) {
        this.identdOp = identdOp;
    }

    public List<GrupoARRC022RETRegRecbvl> getListagrupoARRC022RETRegRecbvl() {
        return listagrupoARRC022RETRegRecbvl;
    }

    public void setListagrupoARRC022RETRegRecbvl(List<GrupoARRC022RETRegRecbvl> listagrupoARRC022RETRegRecbvl) {
        this.listagrupoARRC022RETRegRecbvl = listagrupoARRC022RETRegRecbvl;
    }

    public List<GrupoARRC022RETConstitr> getListagrupoARRC022RETConstitr() {
        return listagrupoARRC022RETConstitr;
    }

    public void setListagrupoARRC022RETConstitr(List<GrupoARRC022RETConstitr> listagrupoARRC022RETConstitr) {
        this.listagrupoARRC022RETConstitr = listagrupoARRC022RETConstitr;
    }
}
