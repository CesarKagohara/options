package br.org.cipbancos.rrc.bean.rrc0019;

import br.org.cip.api.r2c3.model.Contrato;
import br.org.cip.api.r2c3.model.NotificacaoPosContratada;

import br.org.cipbancos.rrc.interop.helper.HeaderReception;

public interface GrupoNegcRecbvlInterop {

    default Contrato getContrato() {
        return null;
    }

    default void setContrato(Contrato contrato) {

    }

    default NotificacaoPosContratada getNotificacaoPosContratada() {
        return null;
    }

    default void setNotificacaoPosContratada(NotificacaoPosContratada notificacaoPosContratada) {

    }

    default HeaderReception getHeaderReception() {
        return null;
    }

    default void setHeaderReception(HeaderReception headerReception) {

    }

}
