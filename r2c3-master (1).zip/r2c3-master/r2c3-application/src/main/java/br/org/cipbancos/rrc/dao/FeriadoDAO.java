package br.org.cipbancos.rrc.dao;

import java.util.Date;
import java.util.List;

public interface FeriadoDAO {

    boolean isFeriado(Date date);

    List<Date> obtemFeriados();

}
