package br.org.cipbancos.rrc.bean.rrc0019;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.GrupoTitlar0019;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import br.org.cip.api.r2c3.model.Contrato;

@XStreamAlias("Grupo_RRC0019_Titlar")
public class GrupoRRC0019Titlar extends ErrorCodeBean implements GrupoTitlar0019 {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CNPJBase_CPFTitlar")
    private SPBString cNPJCNPJBaseCPFTitlar;

    @XStreamAlias("Vlr_PercTotOpUniddRecbvl")
    private SPBBigDecimal vlrPercTotOpUniddRecbvl;

    @XStreamAlias("DtIniOp")
    private SPBLocalDate dtIniOp;

    @XStreamAlias("DtFimOp")
    private SPBLocalDate dtFimOp;

    @XStreamAlias("CNPJ_CPFTitlarCt")
    private SPBString cNPJCPFTitlarCt;

    @XStreamAlias("ISPBBcoRecbdr")
    private SPBString iSPBBcoRecbdr;

    @XStreamAlias("TpCt")
    private SPBString tpCt;

    @XStreamAlias("Ag")
    private SPBString ag;

    @XStreamAlias("Ct")
    private SPBString ct;

    @XStreamAlias("CtPgto")
    private SPBString ctPgto;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0019_CreddrSub")
    private List<GrupoRRC0019CreddrSub> listagrupoRRC0019CreddrSub = new ArrayList<>();

    @XStreamImplicit(itemFieldName = "Grupo_RRC0019_ArrajPgto")
    private List<GrupoRRC0019ArrajPgto> listagrupoRRC0019ArrajPgto = new ArrayList<>();

    @XStreamImplicit(itemFieldName = "Grupo_RRC0019_UsuFinalRecbdr")
    private List<GrupoRRC0019UsuFinalRecbdr> listagrupoRRC0019UsuFinalRecbdr = new ArrayList<>();

    @XStreamOmitField
    private Set<String> credsAlcGeral = new HashSet<>();

    public SPBString getcNPJCNPJBaseCPFTitlar() {
        return cNPJCNPJBaseCPFTitlar;
    }

    public void setcNPJCNPJBaseCPFTitlar(SPBString cNPJCNPJBaseCPFTitlar) {
        this.cNPJCNPJBaseCPFTitlar = cNPJCNPJBaseCPFTitlar;
    }

    public SPBBigDecimal getVlrPercTotOpUniddRecbvl() {
        return vlrPercTotOpUniddRecbvl;
    }

    public void setVlrPercTotOpUniddRecbvl(SPBBigDecimal vlrPercTotOpUniddRecbvl) {
        this.vlrPercTotOpUniddRecbvl = vlrPercTotOpUniddRecbvl;
    }

    public SPBLocalDate getDtIniOp() {
        return dtIniOp;
    }

    public void setDtIniOp(SPBLocalDate dtIniOp) {
        this.dtIniOp = dtIniOp;
    }

    public SPBLocalDate getDtFimOp() {
        return dtFimOp;
    }

    public void setDtFimOp(SPBLocalDate dtFimOp) {
        this.dtFimOp = dtFimOp;
    }

    public SPBString getCNPJCPFTitlarCt() {
        return cNPJCPFTitlarCt;
    }

    public void setcNPJCPFTitlarCt(SPBString cNPJCPFTitlarCt) {
        this.cNPJCPFTitlarCt = cNPJCPFTitlarCt;
    }

    public SPBString getISPBBcoRecbdr() {
        return iSPBBcoRecbdr;
    }

    public void setiSPBBcoRecbdr(SPBString iSPBBcoRecbdr) {
        this.iSPBBcoRecbdr = iSPBBcoRecbdr;
    }

    public SPBString getTpCt() {
        return tpCt;
    }

    public void setTpCt(SPBString tpCt) {
        this.tpCt = tpCt;
    }

    public SPBString getAg() {
        return ag;
    }

    public void setAg(SPBString ag) {
        this.ag = ag;
    }

    public SPBString getCt() {
        return ct;
    }

    public void setCt(SPBString ct) {
        this.ct = ct;
    }

    public SPBString getCtPgto() {
        return ctPgto;
    }

    public void setCtPgto(SPBString ctPgto) {
        this.ctPgto = ctPgto;
    }

    public List<GrupoRRC0019CreddrSub> getListagrupoRRC0019CreddrSub() {
        return listagrupoRRC0019CreddrSub;
    }

    public void setListagrupoRRC0019CreddrSub(List<GrupoRRC0019CreddrSub> listagrupoRRC0019CreddrSub) {
        this.listagrupoRRC0019CreddrSub = listagrupoRRC0019CreddrSub;
    }

    public List<GrupoRRC0019ArrajPgto> getListagrupoRRC0019ArrajPgto() {
        return listagrupoRRC0019ArrajPgto;
    }

    public void setListagrupoRRC0019ArrajPgto(List<GrupoRRC0019ArrajPgto> listagrupoRRC0019ArrajPgto) {
        this.listagrupoRRC0019ArrajPgto = listagrupoRRC0019ArrajPgto;
    }

    public List<GrupoRRC0019UsuFinalRecbdr> getListagrupoRRC0019UsuFinalRecbdr() {
        return listagrupoRRC0019UsuFinalRecbdr;
    }

    public void setListagrupoRRC0019UsuFinalRecbdr(List<GrupoRRC0019UsuFinalRecbdr> listagrupoRRC0019UsuFinalRecbdr) {
        this.listagrupoRRC0019UsuFinalRecbdr = listagrupoRRC0019UsuFinalRecbdr;
    }

    @Override
    public List getListaGrupoCreddrSub() {
        return getListagrupoRRC0019CreddrSub();
    }

    @Override
    public List getListaGrupoArrajPgto() {
        return getListagrupoRRC0019ArrajPgto();
    }

    @Override
    public List getListaGrupoUsuFinalRecbdr() {
        return getListagrupoRRC0019UsuFinalRecbdr();
    }

    public Set<String> getCredsAlcGeral() {
        if(credsAlcGeral == null) {
            credsAlcGeral = new HashSet<>();
        }
        return credsAlcGeral;
    }

    public void setCredsAlcGeral(Set<String> credsAlcGeral) {
        this.credsAlcGeral = credsAlcGeral;
    }

    @Override
    public String toString() {
        return "GrupoRRC0019Titlar{" +
                "cNPJCNPJBaseCPFTitlar=" + cNPJCNPJBaseCPFTitlar +
                ", vlrPercTotOpUniddRecbvl=" + vlrPercTotOpUniddRecbvl +
                ", dtIniOp=" + dtIniOp +
                ", dtFimOp=" + dtFimOp +
                ", cNPJCPFTitlarCt=" + cNPJCPFTitlarCt +
                ", iSPBBcoRecbdr=" + iSPBBcoRecbdr +
                ", tpCt=" + tpCt +
                ", ag=" + ag +
                ", ct=" + ct +
                ", ctPgto=" + ctPgto +
                ", listagrupoRRC0019CreddrSub=" + listagrupoRRC0019CreddrSub +
                ", listagrupoRRC0019ArrajPgto=" + listagrupoRRC0019ArrajPgto +
                ", listagrupoRRC0019UsuFinalRecbdr=" + listagrupoRRC0019UsuFinalRecbdr +
                '}';
    }
}
