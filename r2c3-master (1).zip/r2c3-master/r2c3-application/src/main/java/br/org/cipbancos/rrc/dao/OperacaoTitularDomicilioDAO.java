package br.org.cipbancos.rrc.dao;

/**
 * Classe responsável por toda a manipulação de dados da tabela OP.
 */

import java.util.List;

import br.org.cipbancos.rrc.vo.Operacao;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilio;

public interface OperacaoTitularDomicilioDAO {

    /**
     * Busca no BD a Operacao Titular de Domicilio
     *
     * @param operacao A ser buscada
     * @return Uma lista de Operações TItulares de Domicílio
     */
    List<OperacaoTitularDomicilio> buscar(Operacao operacao);

    /**
     * Busca no BD a Operacao Titular de Domicilio por Arranjo
     *
     * @param operacao A ser buscada
     * @param arranjo A ser buscado
     * @return Uma lista de Operações TItulares de Domicílio
     */
    OperacaoTitularDomicilio buscarPorArranjo(Operacao operacao, String arranjo);

    /**
     * Busca no BD a Operacao Titular de Domicilio por Titular
     *
     * @param operacao A ser buscada
     * @param nrCpfCnpjTitlar A ser buscado
     * @return Uma lista de Operações TItulares de Domicílio
     */
    OperacaoTitularDomicilio buscarPorTitular(Operacao operacao, String nrCpfCnpjTitlar);

    OperacaoTitularDomicilio buscarPorTitularSemArranjoPagamento(Operacao operacao, String nrCpfCnpjTitlar);

    void inserir(OperacaoTitularDomicilio operacaoTitularDomicilio);

    void inserirOnConflictDoNothing(OperacaoTitularDomicilio operacaoTitularDomicilio);

    void atualizar(OperacaoTitularDomicilio operacaoTitularDomicilio);

    void atualizaSituacaoPorIdOp(Long idOp, String icSit);

    Long obterProximaSeqOpTitularDomicilio();

}
