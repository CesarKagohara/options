package br.org.cipbancos.rrc.converter;

import br.org.cipbancos.rrc.funcional.Converter;
import br.org.cipbancos.rrc.vo.OperacaoRenegociacao;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import java.util.Date;

/**
 * Classe utilitária para converter informações de op?cancelt de entrada para realizar,
 * inserções no BD e conversões de Entrada para Retorno.
 *
 * @author anderson.martins
 * @since 1.0
 */
public class OperacaoRenegociacaoConverter {

    private OperacaoRenegociacaoConverter() {}

    /**
     * Popula os parametros utilizados para inserir um OperacaoCancelamento no BD.
     * @return Um conjunto de parametros para setar as informações no ElSql.
     */
    public static Converter<OperacaoRenegociacao, MapSqlParameterSource> emInsercaoOperacaoRenegociacao() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();
            parametros.addValue("identificadorOperacaoOrigem", origem.getIdentificadorOperacaoOrigem());
            parametros.addValue("identificadorOperacaoRenegociacao", origem.getIdentificadorOperacaoRenegociacao());
            parametros.addValue("dhIncl", new java.sql.Timestamp(new Date().getTime()));
            return parametros;
        };
    }
}
