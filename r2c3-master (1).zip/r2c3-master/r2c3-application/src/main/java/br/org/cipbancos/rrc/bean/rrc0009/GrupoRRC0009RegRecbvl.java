package br.org.cipbancos.rrc.bean.rrc0009;

import java.io.Serializable;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBInteger;
import com.thoughtworks.xstream.annotations.XStreamAlias;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBLocalDate;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

public class GrupoRRC0009RegRecbvl  implements Serializable {

    @XStreamAlias("PriorddNegcRecbvl")
    private SPBInteger priorddNegcRecbvl;

    @XStreamAlias("CNPJCreddrSub")
    private SPBString cnpjCreddrSub;

    @XStreamAlias("CNPJ_CPFUsuFinalRecbdr")
    private SPBString cnpjCpfUsuFinalRecbdr;

    @XStreamAlias("CNPJ_CPFTitular")
    private SPBString cnpjCpfTitular;

    @XStreamAlias("CodInstitdrArrajPgto")
    private SPBString codInstitdrArrajPgto;

    @XStreamAlias("DtPrevtLiquid")
    private SPBLocalDate dtPrevtLiquid;

    @XStreamAlias("VlrNegcd")
    private SPBBigDecimal vlrNegcd;

    public SPBInteger getPriorddNegcRecbvl() {
        return priorddNegcRecbvl;
    }

    public void setPriorddNegcRecbvl(SPBInteger priorddNegcRecbvl) {
        this.priorddNegcRecbvl = priorddNegcRecbvl;
    }

    public SPBString getCnpjCreddrSub() {
        return cnpjCreddrSub;
    }

    public void setCnpjCreddrSub(SPBString cnpjCreddrSub) {
        this.cnpjCreddrSub = cnpjCreddrSub;
    }

    public SPBString getCnpjCpfUsuFinalRecbdr() {
        return cnpjCpfUsuFinalRecbdr;
    }

    public void setCnpjCpfUsuFinalRecbdr(SPBString cnpjCpfUsuFinalRecbdr) {
        this.cnpjCpfUsuFinalRecbdr = cnpjCpfUsuFinalRecbdr;
    }

    public SPBString getCnpjCpfTitular() {
        return cnpjCpfTitular;
    }

    public void setCnpjCpfTitular(SPBString cnpjCpfTitular) {
        this.cnpjCpfTitular = cnpjCpfTitular;
    }

    public SPBString getCodInstitdrArrajPgto() {
        return codInstitdrArrajPgto;
    }

    public void setCodInstitdrArrajPgto(SPBString codInstitdrArrajPgto) {
        this.codInstitdrArrajPgto = codInstitdrArrajPgto;
    }

    public SPBLocalDate getDtPrevtLiquid() {
        return dtPrevtLiquid;
    }

    public void setDtPrevtLiquid(SPBLocalDate dtPrevtLiquid) {
        this.dtPrevtLiquid = dtPrevtLiquid;
    }

    public SPBBigDecimal getVlrNegcd() {
        return vlrNegcd;
    }

    public void setVlrNegcd(SPBBigDecimal vlrNegcd) {
        this.vlrNegcd = vlrNegcd;
    }
}
