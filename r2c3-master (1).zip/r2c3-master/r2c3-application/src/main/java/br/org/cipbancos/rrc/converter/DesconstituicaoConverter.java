package br.org.cipbancos.rrc.converter;

import org.apache.commons.lang3.StringUtils;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBInteger;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.rrc0012.RRC0012;
import br.org.cipbancos.rrc.bean.rrc0012.RRC0012R1;
import br.org.cipbancos.rrc.funcional.Converter;

/**
 * Classe utilitária para converter informações de Negociações.
 *
 * @author otavio.ferreira
 * @since 1.0
 */
public class DesconstituicaoConverter {

    private DesconstituicaoConverter() {}

    public static Converter<RRC0012, RRC0012R1> emRRC0012R1(Long idDesconstituicao) {
        return origem -> {
            RRC0012R1 destino = new RRC0012R1();

            destino.setcNPJCNPJBaseCPFTitlar(origem.getcNPJCNPJBaseCPFTitlar());
            destino.setCodMsg(new SPBString("RRC0012R1"));
            destino.setIdentdCtrlReqSolicte(origem.getIdentdCtrlReqSolicte());
            destino.setIdentdOp(new SPBString(StringUtils.leftPad(origem.getIdentdOp().getValue(), 19, "0")));
            destino.setIdentdOpDescstcNegcRecbvl(new SPBString(StringUtils.leftPad(idDesconstituicao.toString(), 19,
                    "0")));
            destino.setSitPedDescstcNegcRecbvl(new SPBInteger(1));
            destino.setSitRetReq(new SPBString("001"));
            destino.setIdentdPartPrincipal(origem.getIdentdPartPrincipal());
            destino.setIdentdPartAdmtd(origem.getIdentdPartAdmtd());

            return destino;
        };
    }
}
