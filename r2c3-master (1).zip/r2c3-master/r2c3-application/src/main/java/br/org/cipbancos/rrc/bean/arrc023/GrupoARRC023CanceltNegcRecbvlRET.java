package br.org.cipbancos.rrc.bean.arrc023;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

@XStreamAlias("Grupo_ARRC023RET_CanceltNegcRecbvl")
public class GrupoARRC023CanceltNegcRecbvlRET extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("SitRetReq")
    private SPBString sitRetReq;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC023RET_CanceltNegcRecbvlActo")
    private List<GrupoARRC023CanceltNegcRecbvlActoRET> listaGrupoARRC023RETCanceltNegcRecbvlActo = new ArrayList<GrupoARRC023CanceltNegcRecbvlActoRET>();

    @XStreamImplicit(itemFieldName = "Grupo_ARRC023RET_CanceltNegcRecbvlRecsdo")
    private List<GrupoARRC023CanceltNegcRecbvlRecsdoRET> listaGrupoARRC023RETCanceltNegcRecbvlRecsdo = new ArrayList<GrupoARRC023CanceltNegcRecbvlRecsdoRET>();

    public SPBString getSitRetReq() {
        return sitRetReq;
    }

    public void setSitRetReq(SPBString sitRetReq) {
        this.sitRetReq = sitRetReq;
    }

    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public List<GrupoARRC023CanceltNegcRecbvlActoRET> getListaGrupoARRC023RETCanceltNegcRecbvlActo() {
        return listaGrupoARRC023RETCanceltNegcRecbvlActo;
    }

    public void setListaGrupoARRC023RETCanceltNegcRecbvlActo(List<GrupoARRC023CanceltNegcRecbvlActoRET> listaGrupoARRC023RETCanceltNegcRecbvlActo) {
        this.listaGrupoARRC023RETCanceltNegcRecbvlActo = listaGrupoARRC023RETCanceltNegcRecbvlActo;
    }

    public List<GrupoARRC023CanceltNegcRecbvlRecsdoRET> getListaGrupoARRC023RETCanceltNegcRecbvlRecsdo() {
        return listaGrupoARRC023RETCanceltNegcRecbvlRecsdo;
    }

    public void setListaGrupoARRC023RETCanceltNegcRecbvlRecsdo(List<GrupoARRC023CanceltNegcRecbvlRecsdoRET> listaGrupoARRC023RETCanceltNegcRecbvlRecsdo) {
        this.listaGrupoARRC023RETCanceltNegcRecbvlRecsdo = listaGrupoARRC023RETCanceltNegcRecbvlRecsdo;
    }
}
