package br.org.cipbancos.rrc.dao;

import java.util.Date;

public interface DataDAO {

    Date obterDataHoraCorrente();

}
