package br.org.cipbancos.rrc.bean.rrc0009;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.SPBInteger;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

public class GrupoRRC0009DomiclBanc implements Serializable {

    @XStreamAlias("CNPJ_CPFTitlarCt")
    private SPBString cnpjCpfTitlarCt;

    @XStreamAlias("ISPBBcoRecbdr")
    private SPBString ispbBcoRecbdr;

    @XStreamAlias("TpCt")
    private SPBString tpCt;

    @XStreamAlias("Ag")
    private SPBInteger ag;

    @XStreamAlias("Ct")
    private SPBString ct;

    @XStreamAlias("CtPgto")
    private SPBString ctPgto;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0009_RegRecbvl")
    private List<GrupoRRC0009RegRecbvl> grupoRRC0009RegRecbvl = new ArrayList<>();

    @XStreamImplicit(itemFieldName = "Grupo_RRC0009_Constitr")
    private List<GrupoRRC0009Constitr> grupoRRC0009Constitr = new ArrayList<>();

    public SPBString getCnpjCpfTitlarCt() {
        return cnpjCpfTitlarCt;
    }

    public void setCnpjCpfTitlarCt(SPBString cnpjCpfTitlarCt) {
        this.cnpjCpfTitlarCt = cnpjCpfTitlarCt;
    }

    public SPBString getIspbBcoRecbdr() {
        return ispbBcoRecbdr;
    }

    public void setIspbBcoRecbdr(SPBString ispbBcoRecbdr) {
        this.ispbBcoRecbdr = ispbBcoRecbdr;
    }

    public SPBString getTpCt() {
        return tpCt;
    }

    public void setTpCt(SPBString tpCt) {
        this.tpCt = tpCt;
    }

    public SPBInteger getAg() {
        return ag;
    }

    public void setAg(SPBInteger ag) {
        this.ag = ag;
    }

    public SPBString getCt() {
        return ct;
    }

    public void setCt(SPBString ct) {
        this.ct = ct;
    }

    public SPBString getCtPgto() {
        return ctPgto;
    }

    public void setCtPgto(SPBString ctPgto) {
        this.ctPgto = ctPgto;
    }

    public List<GrupoRRC0009RegRecbvl> getGrupoRRC0009RegRecbvl() {
        return grupoRRC0009RegRecbvl;
    }

    public void setGrupoRRC0009RegRecbvl(List<GrupoRRC0009RegRecbvl> grupoRRC0009RegRecbvl) {
        this.grupoRRC0009RegRecbvl = grupoRRC0009RegRecbvl;
    }

    public List<GrupoRRC0009Constitr> getGrupoRRC0009Constitr() {
        return grupoRRC0009Constitr;
    }

    public void setGrupoRRC0009Constitr(List<GrupoRRC0009Constitr> grupoRRC0009Constitr) {
        this.grupoRRC0009Constitr = grupoRRC0009Constitr;
    }
}
