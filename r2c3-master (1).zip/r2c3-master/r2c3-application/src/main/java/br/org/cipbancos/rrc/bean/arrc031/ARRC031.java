package br.org.cipbancos.rrc.bean.arrc031;

import java.io.Serializable;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import java.util.ArrayList;
import java.util.List;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("ARRC031")
public class ARRC031 extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("IdentdPartPrincipal")
    private SPBString identdPartPrincipal;

    @XStreamAlias("IdentdPartAdmtd")
    private SPBString identdPartAdmtd;

    @XStreamAlias("GrdProc")
    private SPBString grdProc;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC031_NegcRecbvl")
    private List<GrupoARRC031NegcRecbvl> listagrupoARRC031NegcRecbvl = new ArrayList<GrupoARRC031NegcRecbvl>();

    public SPBString getIdentdPartPrincipal() {
        return identdPartPrincipal;
    }

    public void setIdentdPartPrincipal(SPBString identdPartPrincipal) {
        this.identdPartPrincipal = identdPartPrincipal;
    }

    public SPBString getIdentdPartAdmtd() {
        return identdPartAdmtd;
    }

    public void setIdentdPartAdmtd(SPBString identdPartAdmtd) {
        this.identdPartAdmtd = identdPartAdmtd;
    }

    public void setGrdProc(SPBString grdProc) {
        this.grdProc = grdProc;
    }

    public SPBString getGrdProc() {
        return grdProc;
    }


    public List<GrupoARRC031NegcRecbvl> getListagrupoARRC031NegcRecbvl() {
        return listagrupoARRC031NegcRecbvl;
    }

    public void setListagrupoARRC031NegcRecbvl(List<GrupoARRC031NegcRecbvl> listagrupoARRC031NegcRecbvl) {
        this.listagrupoARRC031NegcRecbvl = listagrupoARRC031NegcRecbvl;
    }

}
