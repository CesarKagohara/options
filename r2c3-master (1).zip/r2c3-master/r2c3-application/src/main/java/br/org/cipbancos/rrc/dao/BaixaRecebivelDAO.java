package br.org.cipbancos.rrc.dao;

import br.org.cipbancos.rrc.vo.BaixaRecebivel;

import java.util.List;

public interface BaixaRecebivelDAO {

    /**
     * Grava no BD as Baixas de recebiveis
     *
     * @param baixas lista de Baixa Recabível para serem inseridas
     *
     */
    int[] inserir(List<BaixaRecebivel> baixas);

    /**
     * Atualiza no BD as Baixas de recebiveis
     *
     * @param baixaRecebivel Baixa Recabível Recabível para ser atualizada.
     *
     */
    void atualizar(BaixaRecebivel baixaRecebivel);

    /**
     * Exclui no BD as Baixas de recebiveis
     *
     * @param idBaixaRecbv Baixa Recabível Recabível para ser excluída.
     */
    void excluir(Long idBaixaRecbv);

    /**
     * Busca no BD as Baixas de recebiveis
     *
     * @param idBaixaRecbv Baixa Recabível Recabível para ser buscada.
     */
    BaixaRecebivel buscar(Long idBaixaRecbv);
}
