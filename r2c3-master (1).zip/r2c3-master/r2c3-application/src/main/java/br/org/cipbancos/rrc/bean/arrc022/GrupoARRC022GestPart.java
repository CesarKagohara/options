package br.org.cipbancos.rrc.bean.arrc022;

import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;
import br.org.cipbancos.rrc.bean.GrupoGestPart;

@XStreamAlias("Grupo_ARRC022_GestPart")
public class GrupoARRC022GestPart extends ErrorCodeBean implements GrupoGestPart {

    private static final long serialVersionUID = 1L;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC022_Titlar")
    private List<GrupoARRC022TitlarGestPart> listagrupoARRC022Titlar = new ArrayList<GrupoARRC022TitlarGestPart>();

    public List<GrupoARRC022TitlarGestPart> getListagrupoARRC022Titlar() {
        return listagrupoARRC022Titlar;
    }

    public void setListagrupoARRC022Titlar(List<GrupoARRC022TitlarGestPart> listagrupoARRC022Titlar) {
        this.listagrupoARRC022Titlar = listagrupoARRC022Titlar;
    }

    @Override
    public List getListaGrupoTitlar() {
        return getListagrupoARRC022Titlar();
    }
}
