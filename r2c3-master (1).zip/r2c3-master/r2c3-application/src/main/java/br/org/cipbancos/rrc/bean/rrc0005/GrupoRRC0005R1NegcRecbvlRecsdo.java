package br.org.cipbancos.rrc.bean.rrc0005;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;

@XStreamAlias("Grupo_RRC0005R1_NegcRecbvlRecsdo")
public class GrupoRRC0005R1NegcRecbvlRecsdo extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamImplicit(itemFieldName = "Grupo_RRC0005R1_UniddRecbvlDisp")
    private List<GrupoRRC0005R1UniddRecbvlDisp> listagrupoRRC0005R1UniddRecbvlDisp = new ArrayList<>();

    public List<GrupoRRC0005R1UniddRecbvlDisp> getListagrupoRRC0005R1UniddRecbvlDisp() {
        return listagrupoRRC0005R1UniddRecbvlDisp;
    }

    public void setListagrupoRRC0005R1UniddRecbvlDisp(List<GrupoRRC0005R1UniddRecbvlDisp> listagrupoRRC0005R1UniddRecbvlDisp) {
        this.listagrupoRRC0005R1UniddRecbvlDisp = listagrupoRRC0005R1UniddRecbvlDisp;
    }

}
