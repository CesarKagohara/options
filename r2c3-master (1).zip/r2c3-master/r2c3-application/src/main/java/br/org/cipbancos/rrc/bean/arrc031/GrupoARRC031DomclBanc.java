package br.org.cipbancos.rrc.bean.arrc031;

import br.org.cipbancos.atlante.xmlbinder.spb.*;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@XStreamAlias("Grupo_ARRC031_DomclBanc")
public class GrupoARRC031DomclBanc extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamAlias("CNPJ_CPFTitlarCt")
    private SPBString cNPJCPFTitlarCt;

    @XStreamAlias("ISPBBcoRecbdr")
    private SPBString iSPBBcoRecbdr;

    @XStreamAlias("TpCt")
    private SPBString tpCt;

    @XStreamAlias("Ag")
    private SPBString ag;

    @XStreamAlias("Ct")
    private SPBString ct;

    @XStreamAlias("CtPgto")
    private SPBString ctPgto;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC031_Constitr")
    private List<GrupoARRC031Constitr> listaGrupoARRC031Constitr = new ArrayList<>();

    public void setcNPJCPFTitlarCt(SPBString cNPJCNPJBaseCPFTitlar) {
        this.cNPJCPFTitlarCt = cNPJCNPJBaseCPFTitlar;
    }

    public void setiSPBBcoRecbdr(SPBString iSPBBcoRecbdr) {
        this.iSPBBcoRecbdr = iSPBBcoRecbdr;
    }

    public void setTpCt(SPBString tpCt) {
        this.tpCt = tpCt;
    }

    public void setAg(SPBString ag) {
        this.ag = ag;
    }

    public void setCt(SPBString ct) {
        this.ct = ct;
    }

    public void setCtPgto(SPBString ctPgto) {
        this.ctPgto = ctPgto;
    }

    public void setListaGrupoARRC031Constitr(List<GrupoARRC031Constitr> listaGrupoARRC031Constitr) {
        this.listaGrupoARRC031Constitr = listaGrupoARRC031Constitr;
    }

    public SPBString getcNPJCPFTitlarCt() {
        return cNPJCPFTitlarCt;
    }

    public SPBString getiSPBBcoRecbdr() {
        return iSPBBcoRecbdr;
    }

    public SPBString getTpCt() {
        return tpCt;
    }

    public SPBString getAg() {
        return ag;
    }

    public SPBString getCt() {
        return ct;
    }

    public SPBString getCtPgto() {
        return ctPgto;
    }

    public List<GrupoARRC031Constitr> getListaGrupoARRC031Constitr() {
        return listaGrupoARRC031Constitr;
    }
}