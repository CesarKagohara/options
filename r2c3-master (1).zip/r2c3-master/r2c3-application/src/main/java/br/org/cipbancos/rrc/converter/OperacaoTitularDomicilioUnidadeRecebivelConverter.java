package br.org.cipbancos.rrc.converter;

import java.util.Date;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import br.org.cipbancos.atlante.api.ContextPropertyKeys;
import br.org.cipbancos.atlante.api.handler.Context;
import br.org.cipbancos.rrc.bean.GrupoRegRecbvl;
import br.org.cipbancos.rrc.bean.GrupoRegRecbvl0005;
import br.org.cipbancos.rrc.bean.GrupoRegRecbvl0019;
import br.org.cipbancos.rrc.enums.Constantes;
import br.org.cipbancos.rrc.enums.TipoFuncionalidade;
import br.org.cipbancos.rrc.funcional.Converter;
import br.org.cipbancos.rrc.vo.DomicilioStageVO;
import br.org.cipbancos.rrc.vo.Operacao;
import br.org.cipbancos.rrc.vo.OperacaoTitularDomicilioUnidadeRecebivel;
import br.org.cipbancos.rrc.vo.RegistroRecebivelDomicilioTitularGestaoParticipante;

public class OperacaoTitularDomicilioUnidadeRecebivelConverter {

    private OperacaoTitularDomicilioUnidadeRecebivelConverter() {
    }

    /**
     * Popula a chave primária para a Fracao de Unidade Recebível no BD.
     */
    public static Converter<OperacaoTitularDomicilioUnidadeRecebivel, MapSqlParameterSource> popularChavePrimaria() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();
            parametros.addValue("idPartPrincipal", origem.getIdPartPrincipal());
            parametros.addValue("nrCnpjCreddr", origem.getNrCnpjCreddr());
            parametros.addValue("nr_cpf_cnpj_usurio_finl_recbdr", origem.getNrCpfCnpjUsurioFinlRecbdr());
            parametros.addValue("cd_arrj_pgto", origem.getCdArrjPgto());
            parametros.addValue("dt_prevt_liquid", origem.getDtPrevtLiquid());
            parametros.addValue("id_op", origem.getIdOperacao());
            return parametros;
        };
    }

    /**
     * Popula um Domicilio Stage em Fracao de Unidade Recebível Operação.
     */
    public static Converter<DomicilioStageVO, OperacaoTitularDomicilioUnidadeRecebivel>
    fracaoUROperacaoEmOperacaoTitularDomicilioUR() {
        return origem -> {
            OperacaoTitularDomicilioUnidadeRecebivel destino = new OperacaoTitularDomicilioUnidadeRecebivel();
            destino.setIdPartPrincipal(origem.getIdPartPrincipal());
            destino.setNrCpfCnpjUsurioFinlRecbdr(origem.getNumeroCpfCnpjUsuarioRecebedor());
            destino.setCdArrjPgto(origem.getCodigoArranjoPagamento());
            destino.setDtPrevtLiquid(origem.getDataEfetivaLiquidacao());
            destino.setIdOperacao(origem.getIdentificadorOperacao());
            destino.setNrCnpjCreddr(origem.getNumeroCnpjCredenciadora());
            return destino;
        };
    }

    public static Converter<OperacaoTitularDomicilioUnidadeRecebivel, MapSqlParameterSource>
    emOperacaoTitularDomicilioURParaInsercao() {
        return origem -> {
            MapSqlParameterSource parametros = new MapSqlParameterSource();
            parametros.addValue("nr_cnpj_creddr", origem.getNrCnpjCreddr());
            parametros.addValue("nr_cpf_cnpj_usurio_finl_recbdr", origem.getNrCpfCnpjUsurioFinlRecbdr());
            parametros.addValue("cd_arrj_pgto", origem.getCdArrjPgto());
            parametros.addValue("dt_prevt_liquid", origem.getDtPrevtLiquid());
            parametros.addValue("id_op", origem.getIdOperacao());
            parametros.addValue("id_op_titlar_domcl", origem.getIdOpTitlarDomcl());
            parametros.addValue("nr_cpf_cnpj_titlar", origem.getNrCpfCnpjTitlar());
            parametros.addValue("nr_vlr_liquid_antec", origem.getNrVlAntecNRegtd());
            parametros.addValue("dt_antec", origem.getDtAntec());
            parametros.addValue("nr_vl_antec_n_regtd", origem.getNrVlAntecNRegtd());
            parametros.addValue("dt_liquid_antec", origem.getDtLiquidAntec());
            parametros.addValue("nr_vlr_tot_op_unidd_recbv", origem.getNrVlrTotOpUniddRecbv());
            parametros.addValue("id_part_principal", origem.getIdPartPrincipal());
            parametros.addValue("id_part_admtd", origem.getIdPartAdmtd());
            parametros.addValue("id_part_origdr", origem.getIdPartAdmtd());
            parametros.addValue("dt_ref_sist_incl", origem.getDtRefSistIncl());
            parametros.addValue("dt_ref_sist_ult_alt", origem.getDtRefSistUltAlt());
            parametros.addValue("id_atl_root", origem.getIdAtlRoot());
            parametros.addValue("nm_arq_nuop_api", origem.getNmArqNuopApi());
            parametros.addValue("idFuncdd", origem.getIdFuncdd());
            parametros.addValue("dh_incl", origem.getDhIncl());
            parametros.addValue("dh_ult_alt", origem.getDhUltAlt());
            return parametros;
        };
    }

    /**
     * Popula um Domicilio Stage em Fracao de Unidade Recebível Operação.
     */
    public static Converter<GrupoRegRecbvl, OperacaoTitularDomicilioUnidadeRecebivel>
    registroRecebivelEmOperacaoTitularDomicilioUR(Context context, Operacao operacao, Long idOpTitlarDomcl, String cnpjCredenciadora) {
        return origem -> {
            OperacaoTitularDomicilioUnidadeRecebivel destino = new OperacaoTitularDomicilioUnidadeRecebivel();

            destino.setIdOperacao(operacao.getIdOp());
            destino.setIdOpTitlarDomcl(idOpTitlarDomcl);
            destino.setDtPrevtLiquid(origem.getDtPrevtLiquid().getValue().toDate());
            destino.setNrCpfCnpjTitlar(origem.getCNPJCPFTitular().getValue());
            destino.setNrCpfCnpjUsurioFinlRecbdr(origem.getCNPJCPFUsuFinalRecbdr().getValue());
            if (origem instanceof GrupoRegRecbvl0019) {
                destino.setNrCnpjCreddr(((GrupoRegRecbvl0019)origem).getCNPJCreddrSub().getValue());
            } else {
                destino.setNrCnpjCreddr(cnpjCredenciadora);
            }
            destino.setCdArrjPgto(origem.getCodInstitdrArrajPgto().getValue());
            destino.setNrVlrTotOpUniddRecbv(origem.getVlrPercNegcd().getValue());
            destino.setDhIncl(new Date());
            destino.setDhUltAlt(new Date());
            destino.setIdPartPrincipal(operacao.getIdPartPrincipal());
            destino.setIdPartAdmtd(operacao.getIdPartAdmtd());
            destino.setIdPartOrigdr(operacao.getIdPartAdmtd());
            destino.setIdAtlRoot(context.getRootId());
            String nmNuopApi = (String) context.getProperties().get(ContextPropertyKeys.LOGICAL_IDENTIFIER);
            if (null == nmNuopApi || nmNuopApi.isEmpty()) {
                nmNuopApi = (String) context.getProperties().get(ContextPropertyKeys.PHYSICAL_IDENTIFIER);
            }
            destino.setNmArqNuopApi(nmNuopApi);
            destino.setDtRefSistIncl(context.getBatchReferenceDate());
            destino.setDtRefSistUltAlt(context.getBatchReferenceDate());
            destino.setIdFuncdd(operacao.getIdFuncdd());

            if (origem instanceof GrupoRegRecbvl0005) {
                destino.setDtLiquidAntec((null == ((GrupoRegRecbvl0005)origem).getDtEftLiquidAntec() ?
                        null : ((GrupoRegRecbvl0005)origem).getDtEftLiquidAntec().getValue().toDate()));
                destino.setNrVlrLiquidAntec((null == ((GrupoRegRecbvl0005)origem).getVlrEftLiquidAntec() ?
                        null : ((GrupoRegRecbvl0005)origem).getVlrEftLiquidAntec().getValue()));
                destino.setDtAntec((null == ((GrupoRegRecbvl0005)origem).getDtAntec() ?
                        null : ((GrupoRegRecbvl0005)origem).getDtAntec().getValue().toDate()));
                destino.setNrVlAntecNRegtd((null == ((GrupoRegRecbvl0005)origem).getVlrAntecNRegtd() ?
                        null : ((GrupoRegRecbvl0005)origem).getVlrAntecNRegtd().getValue()));
            }

            return destino;
        };
    }
}
