package br.org.cipbancos.rrc.bean.arrc022;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import br.org.cipbancos.atlante.xmlbinder.spb.ErrorCodeBean;

@XStreamAlias("Grupo_ARRC022RET_GestPart")
public class GrupoARRC022RETGestPart extends ErrorCodeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @XStreamImplicit(itemFieldName = "Grupo_ARRC022RET_Titlar")
    private List<GrupoARRC022RETTitlarGestPart> listagrupoARRC022Titlar = new ArrayList<>();

    public List<GrupoARRC022RETTitlarGestPart> getListagrupoARRC022Titlar() {
        return listagrupoARRC022Titlar;
    }

    public void setListagrupoARRC022Titlar(List<GrupoARRC022RETTitlarGestPart> listagrupoARRC022Titlar) {
        this.listagrupoARRC022Titlar = listagrupoARRC022Titlar;
    }

}
