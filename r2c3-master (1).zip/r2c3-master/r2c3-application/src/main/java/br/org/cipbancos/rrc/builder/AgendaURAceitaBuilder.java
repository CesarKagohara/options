package br.org.cipbancos.rrc.builder;

import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001UniddRecbvl;
import br.org.cipbancos.rrc.bean.arrc001.GrupoARRC001UniddRecbvlActo;
import br.org.cipbancos.rrc.converter.UnidadeRecebivelArquivoConverter;

/**
 * Classe responsável por montar a estrutura de uma Unidade Recebível Aceita no arquivo RET.
 *
 * @author otavio.ferreira
 * @since 1.0
 */
public class AgendaURAceitaBuilder {

    private GrupoARRC001UniddRecbvlActo urAceita;

    /**
     * Monta a estrutura basica da Unidade Recebível Aceita.
     *
     * @param unidade Unidade Recebível que veio na entrada.
     */
    public AgendaURAceitaBuilder montaURAceita(GrupoARRC001UniddRecbvl unidade) {
        urAceita = UnidadeRecebivelArquivoConverter.emUnidadeRecebivelAceita().convert(unidade);
        return this;
    }

    /**
     * Constroi e retona a UR que foi montada nas chamadas anteriores.
     *
     * @return Uma nova Unidade Recebível aceita.
     */
    public GrupoARRC001UniddRecbvlActo build() {
        return urAceita;
    }

}
