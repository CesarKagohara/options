package br.org.cipbancos.rrc.controller.servicos.cip.financiadoras;

import static br.org.cipbancos.rrc.util.R2C3SPBUtil.getBigDecimalAsDouble;
import static br.org.cipbancos.rrc.util.R2C3SPBUtil.getValueLocalDateTimeAsOffsetDateTime;
import static br.org.cipbancos.rrc.util.R2C3SPBUtil.getValueOrNull;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.zip.GZIPInputStream;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import br.org.cipbancos.atlante.api.ApplicationErrorAPIException;
import br.org.cipbancos.atlante.api.handler.BatchContext;
import br.org.cipbancos.atlante.api.handler.Context;
import br.org.cipbancos.atlante.api.handler.ContextLocator;
import br.org.cipbancos.atlante.config.HttpTransportConfig;
import br.org.cipbancos.atlante.session.AtlanteSession;
import br.org.cipbancos.atlante.util.PartyUtility;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBBigDecimal;
import br.org.cipbancos.atlante.xmlbinder.spb.SPBString;
import br.org.cipbancos.rrc.bean.SPBBean;
import br.org.cipbancos.rrc.bean.rrc0019.RRC0019ApiGestaoParticipante;
import br.org.cipbancos.rrc.bean.rrc0020.GrupoRRC0020RegRecbvl;
import br.org.cipbancos.rrc.bean.rrc0020.RRC0020;
import br.org.cipbancos.rrc.bean.rrc0021.GrupoRRC0021R1NegcRecbvl;
import br.org.cipbancos.rrc.bean.rrc0021.RRC0021;
import br.org.cipbancos.rrc.bean.rrc0021.RRC0021R1;
import br.org.cipbancos.rrc.bean.rrc0025.RRC0025;
import br.org.cipbancos.rrc.converter.SPBConverter;
import br.org.cipbancos.rrc.dominio.ErroValidacao;
import br.org.cipbancos.rrc.enums.Constantes;
import br.org.cipbancos.rrc.enums.DateTimeUtils;
import br.org.cipbancos.rrc.enums.IndicadorSimNao;
import br.org.cipbancos.rrc.enums.ParametroConfiguracao;
import br.org.cipbancos.rrc.enums.TipoFuncionalidade;
import br.org.cipbancos.rrc.handler.rrc0021.RRC0021Handler;
import br.org.cipbancos.rrc.handler.rrc0025.RRC0025Handler;
import br.org.cipbancos.rrc.negocio.ConjuntoUnidadeRecebivelDisponivelNegocio;
import br.org.cipbancos.rrc.negocio.OperacaoNegocio;
import br.org.cipbancos.rrc.negocio.ParametroConfiguracaoSistemaNegocio;
import br.org.cipbancos.rrc.negocio.RegistroOperacaoStageNegocio;
import br.org.cipbancos.rrc.util.CpfCnpjUtil;
import br.org.cipbancos.rrc.util.DateUtil;
import br.org.cipbancos.rrc.util.ListUtil;
import br.org.cipbancos.rrc.vo.FracaoUnidadeRecebivelOperacao;
import br.org.cipbancos.rrc.vo.GrupoRegOpStg;
import br.org.cipbancos.rrc.vo.ParticipanteVO;
import br.org.cipbancos.rrc.vo.ResultadoPaginado;

import br.org.cipbancos.rrc.handler.PaginacaoHandler;
import br.org.cipbancos.rrc.util.PaginacaoUtil;
import br.org.cip.api.r2c3.FinanciadoraApi;
import br.org.cip.api.r2c3.model.ConjuntoUnidadesRecebiveisChave;
import br.org.cip.api.r2c3.model.Erro;
import br.org.cip.api.r2c3.model.MessageListArrayOutput;
import br.org.cip.api.r2c3.model.OperacaoCancelamentoFinanciadora;
import br.org.cip.api.r2c3.model.OperacaoCredenciadoraUnidadesRecebiveis;
import br.org.cip.api.r2c3.model.OperacaoERFinanciadora;
import br.org.cip.api.r2c3.model.OperacaoFinanciadora;
import br.org.cip.api.r2c3.model.OperacaoFinanciadoraBase;
import br.org.cip.api.r2c3.model.OperacaoPartFinanciadora;
import br.org.cip.api.r2c3.model.RecusaDesconstituicaoGarantiaFinanciadora;
import br.org.cip.api.r2c3.model.UnidadeRecebivelAConstituirOperacaoFinanciadora;
import br.org.cip.api.r2c3.model.UnidadeRecebivelDisponivelFinanciadora;
import br.org.cip.api.r2c3.model.UnidadeRecebivelOperacaoCancelamento;
import br.org.cip.api.r2c3.model.UnidadeRecebivelOperacaoFinanciadora;
import br.org.cip.api.r2c3.model.UnidadeRecebivelPreviaOperacaoFinanciadora;
import br.org.cip.arche.commons.library.exceptions.ArcConditionalException;

@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS)
@Controller
public class FinanciadoraController implements FinanciadoraApi {

    public static final String DATATYPE_RRC0021 = "RRC0021";
    private static final Logger LOG = LoggerFactory.getLogger(FinanciadoraController.class);

    @Autowired
    private RRC0025Handler rrc0025Handler;

    @Autowired
    private RRC0021Handler rrc0021Handler;

    @Autowired
    private RegistroOperacaoStageNegocio registroOperacaoStageNegocio;

    @Autowired
    private ConjuntoUnidadeRecebivelDisponivelNegocio conjuntoUnidadeRecebivelDisponivelNegocio;

    @Autowired
    private ParametroConfiguracaoSistemaNegocio parametroSistemaNegocio;

    @Autowired
    private OperacaoNegocio operacaoNegocio;

    @Autowired
    private PaginacaoHandler paginacaoHandler;

    @Autowired
    private PaginacaoUtil paginacaoUtil;

    private Context getContext() {
        return ContextLocator.getContext();
    }

    @Override
    public ResponseEntity<Void> deleteFinanciadoraOperacoesIdentdOp(String xJwsSignature, String identdOp, OperacaoCancelamentoFinanciadora operacaoCancelamentoFinanciadora, String acceptEncoding, String contentEncoding) {
        LOG.info("Payload enviado no evento", operacaoCancelamentoFinanciadora);
        LOG.info("Titular enviado no payload", operacaoCancelamentoFinanciadora.getCnpjOuCnpjBaseOuCpfTitlar());
        LOG.info("URs enviadas no payload", operacaoCancelamentoFinanciadora.getUnidadesRecebiveis());
        if (operacaoCancelamentoFinanciadora.getCnpjOuCnpjBaseOuCpfTitlar() != null && CollectionUtils.isNotEmpty(
                operacaoCancelamentoFinanciadora.getUnidadesRecebiveis())) {
            LOG.info("Se titular e URs estiverem preenchidos deveria disparar o erro ERRC0164");
        }
        Context ctx = getContext();
        RRC0020 rrc0020 = criarRRC0020(ctx, identdOp, operacaoCancelamentoFinanciadora);
        BatchContext batchContext = ctx.createBatch(TipoFuncionalidade.RRC0020.getValue());
        batchContext.addJob().addRecord(rrc0020);
        return new ResponseEntity<>(HttpStatus.ACCEPTED);
    }

    //Os objectos da API têm mais informações que os beans do mq
    private RRC0020 criarRRC0020(Context ctx, String identdOp, OperacaoCancelamentoFinanciadora operacaoCancelamentoFinanciadora) {
        RRC0020 rrc0020 = new RRC0020();
        rrc0020.setCodMsg(new SPBString(TipoFuncionalidade.RRC0020.getValue()));
        rrc0020.setIdentdOp(new SPBString(identdOp));
        rrc0020.setIdentdPartPrincipal(new SPBString(PartyUtility.partyIdToIspb(ctx.getPartyId())));
        String partyAdmin = PartyUtility.partyIdToIspb(
                Integer.valueOf(ctx.getProperties().get(HttpTransportConfig.HEADER_PARTY_ADMIN_ID).toString()));
        rrc0020.setIdentdPartAdmtd(new SPBString(partyAdmin));
        rrc0020.setIdentdNegcRecbvl(new SPBString(operacaoCancelamentoFinanciadora.getIdentdNegcRecbvl()));
        rrc0020.setIndrLiquidOp(new SPBString(operacaoCancelamentoFinanciadora.getIndrLiquidOp()));

        List<GrupoRRC0020RegRecbvl> grupoRRC0020RegRecbvlList= new ArrayList<>();

        if(operacaoCancelamentoFinanciadora.getUnidadesRecebiveis()!=null) {
            for (UnidadeRecebivelOperacaoCancelamento unidadeRecebivelOperacaoCancelamento : operacaoCancelamentoFinanciadora.getUnidadesRecebiveis()) {
                GrupoRRC0020RegRecbvl grupoRRC0020RegRecbvl= new GrupoRRC0020RegRecbvl();
                grupoRRC0020RegRecbvl.setCnpjCreddrSub(new SPBString(unidadeRecebivelOperacaoCancelamento.getCnpjCreddrSub()));
                grupoRRC0020RegRecbvl.setCnpjCpfTitularVenddNegcdrRecbvl(new SPBString(unidadeRecebivelOperacaoCancelamento.getCnpjOuCpfTitularVenddOuNegcdrRecbv()));
                grupoRRC0020RegRecbvl.setCnpjCpfUsuFinalRecbdr(new SPBString(unidadeRecebivelOperacaoCancelamento.getCnpjOuCpfUsuFinalRecbdr()));
                grupoRRC0020RegRecbvl.setCodInstitdrArrajPgto(new SPBString(unidadeRecebivelOperacaoCancelamento.getCodInstitdrArrajPgto()));
                grupoRRC0020RegRecbvl.setDtPrevtLiquid(SPBConverter.dateToSPBLocalDate(Date.from(unidadeRecebivelOperacaoCancelamento.getDtPrevtLiquid().atStartOfDay(ZoneId.systemDefault()).toInstant())));
                grupoRRC0020RegRecbvl.setVlrNegcdCancel(new SPBBigDecimal(new BigDecimal(unidadeRecebivelOperacaoCancelamento.getVlrNegcdCancel()).setScale(2, RoundingMode.HALF_DOWN)));
                grupoRRC0020RegRecbvl.setVlrPercNegcdConstitrCancel(new SPBBigDecimal(new BigDecimal(unidadeRecebivelOperacaoCancelamento.getVlrPercNegcdConstitrCancel()).setScale(2, RoundingMode.HALF_DOWN)));

                grupoRRC0020RegRecbvlList.add(grupoRRC0020RegRecbvl);
            }
        }

        rrc0020.setListaGrupoRRC0020RegRecbvl(grupoRRC0020RegRecbvlList);

        if (operacaoCancelamentoFinanciadora.getCnpjOuCnpjBaseOuCpfTitlar() != null) {
            rrc0020.setCnpjCnpjBaseCpfTitlar(
                    new SPBString(operacaoCancelamentoFinanciadora.getCnpjOuCnpjBaseOuCpfTitlar()));
        }

        rrc0020.setIndrCancelVlrTotal(new SPBString(operacaoCancelamentoFinanciadora.getIndrCancelVlrTotal()));


        rrc0020.setIndrCancelCessConstitr(
                new SPBString(operacaoCancelamentoFinanciadora.getIndrCancelCessConstitr()));

        return rrc0020;
    }

    @Override
    public ResponseEntity<Void> postFinanciadoraOperacoesIdentdOpRecusasDesconstituicaoGarantia(String xJwsSignature, String identdOp, RecusaDesconstituicaoGarantiaFinanciadora recusaDesconstituicaoGarantiaFinanciadora, String acceptEncoding, String contentEncoding) {
        String mensagem = "Iniciando processamento do Recusa de Solicitação de Desconstituição de Garantia RRC0025 via HTTP. RecusaDesconstituicaoGarantiaFinanciadora {}, IdentdOp {}.";
        LOG.info(mensagem, recusaDesconstituicaoGarantiaFinanciadora, identdOp);
        Context ctx = getContext();
        RRC0025 rrc0025 = new RRC0025();
        rrc0025.setIdentdPartPrincipal(new SPBString(PartyUtility.partyIdToIspb(ctx.getPartyId())));
        String partyAdmin = PartyUtility.partyIdToIspb(
                Integer.valueOf(ctx.getProperties().get(HttpTransportConfig.HEADER_PARTY_ADMIN_ID).toString()));
        rrc0025.setIdentdPartAdmtd(new SPBString(partyAdmin));
        if (identdOp != null) {
            rrc0025.setIdentdOp(new SPBString(identdOp));
        }
        rrc0025.setCodMsg(new SPBString(TipoFuncionalidade.RRC0025.getValue()));
        if (recusaDesconstituicaoGarantiaFinanciadora.getIdentdNegcRecbvl() != null) {
            rrc0025.setIdentdNegcRecbvl(new SPBString(recusaDesconstituicaoGarantiaFinanciadora.getIdentdNegcRecbvl()));
        }
        if (recusaDesconstituicaoGarantiaFinanciadora.getCnpjOuCnpjBaseOuCpfTitlar() != null) {
            rrc0025.setCNPJCNPJBaseCPFTitlar(
                    new SPBString(recusaDesconstituicaoGarantiaFinanciadora.getCnpjOuCnpjBaseOuCpfTitlar()));
        }
        if (recusaDesconstituicaoGarantiaFinanciadora.getIdentdOpDescstcNegcRecbvl() != null) {
            rrc0025.setIdentdOpDescstcNegcRecbvl(
                    new SPBString(recusaDesconstituicaoGarantiaFinanciadora.getIdentdOpDescstcNegcRecbvl()));
        }
        if (recusaDesconstituicaoGarantiaFinanciadora.getSitPedDescstcNegcRecbvl() != null) {
            rrc0025.setSitPedDescstcNegcRecbvl(
                    new SPBString(recusaDesconstituicaoGarantiaFinanciadora.getSitPedDescstcNegcRecbvl().toString()));
        }
        rrc0025Handler.process(rrc0025, ctx);
        List<Object> httpRecords = AtlanteSession.getSession().getHttpRecords();

        if (httpRecords != null && !httpRecords.isEmpty()) {
            Object o = httpRecords.get(0);
            if (o instanceof Erro) {
                return new ResponseEntity(o, HttpStatus.BAD_REQUEST);
            }
        }
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<ConjuntoUnidadesRecebiveisChave> postFinanciadoraConjuntosUnidadesRecebiveis(String xJwsSignature, String acceptEncoding, String contentEncoding) {
        Long id = registroOperacaoStageNegocio.inserirRegOp(PartyUtility.partyIdToIspb(getContext().getPartyId()));
        ConjuntoUnidadesRecebiveisChave conjunto = new ConjuntoUnidadesRecebiveisChave();
        conjunto.setIdentdConjUniddRecbvl(String.format("%019d", id));
        return new ResponseEntity<>(conjunto, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> postFinanciadoraConjuntosUnidadesRecebiveisIdentdConjUniddRecbvlLotesUnidadesRecebiveis(String xJwsSignature, String identdConjUniddRecbvl, List<UnidadeRecebivelPreviaOperacaoFinanciadora> listaUnidadeRecebivelPreviaOperacaoFinanciadora, String acceptEncoding, String contentEncoding) {
        try {
            Long id = registroOperacaoStageNegocio.validarIdOp(getContext().getPartyId(), identdConjUniddRecbvl);
            if (listaUnidadeRecebivelPreviaOperacaoFinanciadora != null) {
                List<GrupoRegOpStg> grupos = new ArrayList<>();
                for (UnidadeRecebivelPreviaOperacaoFinanciadora ur : listaUnidadeRecebivelPreviaOperacaoFinanciadora) {
                    GrupoRegOpStg grupo = new GrupoRegOpStg();
                    grupo.setIdRegOpStg(id);
                    grupo.setNrCnpjRegrDest(Constantes.CNPJ_R2C3);
                    grupo.setNrCpfCnpjTitular(ur.getCnpjOuCpfTitlar());
                    grupo.setNrCpfCnpjBaseTitular(ur.getCnpjOuCnpjBaseOuCpfTitlar());
                    grupo.setNrCpfCnpjTitularCt(ur.getCnpjOuCpfTitlarCt());
                    grupo.setCdIspbBcoRecbdr(ur.getIspbBcoRecbdr());
                    grupo.setCdTpCt(ur.getTpCt());
                    if (ur.getAg() != null) {
                        grupo.setNrAg(ur.getAg().intValue());
                    }
                    if (ur.getCt() != null) {
                        grupo.setNrCt(ur.getCt().longValue());
                    }
                    if (ur.getCtPgto() != null) {
                        grupo.setNrCtPgto(ur.getCtPgto().setScale(0, RoundingMode.FLOOR).toString());
                    }
                    grupo.setNrCnpjCreddr(ur.getCnpjCreddrSub());
                    grupo.setNrCpfCnpjUsurioFinlRecbdr(ur.getCnpjOuCpfUsuFinalRecbdr());
                    grupo.setCdArrjPgto(ur.getCodInstitdrArrajPgto());
                    grupo.setDtPrevtLiquid(
                            Date.from(ur.getDtPrevtLiquid().atStartOfDay(ZoneId.systemDefault()).toInstant()));
                    grupo.setNrVlPcNegcd(new BigDecimal(ur.getVlrOuPercNegcd())); // Verificar padronização de nomes
                    grupos.add(grupo);
                }
                if (!grupos.isEmpty()) {
                    Integer tamanhoQuebra = parametroSistemaNegocio.getIntParam(
                            ParametroConfiguracao.TAMANHO_QUEBRA_INSERT_GRUPO_REG_OP_STG);
                    List<List<GrupoRegOpStg>> gruposRanges = ListUtil.split(grupos, tamanhoQuebra);
                    for (List<GrupoRegOpStg> gruposRange : gruposRanges) {
                        registroOperacaoStageNegocio.inserirGrupoRegOp(gruposRange, getContext().getBatchReferenceDate());
                    }
                }
            }
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (IllegalArgumentException e) {

            LOG.info("ERRO HTTP 412 PRECONDITION FAILED - FinanciadoraController -> postFinanciadoraConjuntosUnidadesRecebiveisIdentdConjUniddRecbvlLotesUnidadesRecebiveis - IllegalArgumentException: {}.", e.getMessage());

            Erro erro = new Erro();
            erro.setDataHora(OffsetDateTime.now());
            MessageListArrayOutput mensagem = new MessageListArrayOutput();
            mensagem.campo("identdConjUniddRecbvl");
            mensagem.conteudo(identdConjUniddRecbvl);
            mensagem.mensagem(e.getMessage());
            mensagem.codigo(ErroValidacao.ERRC9999.getFormattedValue());
            erro.addMensagensItem(mensagem);

            return new ResponseEntity(erro, HttpStatus.PRECONDITION_FAILED);
        }
    }

    @Override
    public ResponseEntity<Void> postFinanciadoraOperacoes(String xJwsSignature, OperacaoFinanciadoraBase operacaoFinanciadoraBase, String acceptEncoding, String contentEncoding) {
        Integer partyId = getContext().getPartyId();

        LOG.info("Inicio postFinanciadoraOperacoes para Participante principal: {} ", partyId);
        return processFinanciadoraOperacoes(operacaoFinanciadoraBase, 'I', null);
    }

    @Override
    public ResponseEntity<Void> putFinanciadoraOperacoesIdentdOp(String xJwsSignature, String identdOp, OperacaoFinanciadoraBase operacaoFinanciadoraBase, String acceptEncoding, String contentEncoding) {
        String mensagem = "Início put financiadora operações identdOp via HTTP, OperacaoFinanciadoraBase {}, IdentdOp {}.";
        LOG.info(mensagem, operacaoFinanciadoraBase, identdOp);
        return processFinanciadoraOperacoes(operacaoFinanciadoraBase, 'A', identdOp);
    }

    private ResponseEntity<Void> processFinanciadoraOperacoes(OperacaoFinanciadoraBase operacaoFinanciadoraBase, char indrIA, String identdOp) {
        try {
            Integer partyAdmin = Integer.valueOf(
                    getContext().getProperties().get(HttpTransportConfig.HEADER_PARTY_ADMIN_ID).toString());

            Integer partyId = getContext().getPartyId();
            ParticipanteVO participanteVO = registroOperacaoStageNegocio.validarParticipante(partyAdmin);
            Long idOp = null;
            SPBBean bean;
            if (operacaoFinanciadoraBase instanceof OperacaoERFinanciadora) {
                OperacaoERFinanciadora operacao = (OperacaoERFinanciadora) operacaoFinanciadoraBase;
                bean = registroOperacaoStageNegocio.converterOperacaoFinanciadoraBaseParaRRC0019(partyId, participanteVO, operacao, indrIA, null, identdOp, getContext().getBatchReferenceDate());
            } else {
                OperacaoPartFinanciadora operacao = (OperacaoPartFinanciadora) operacaoFinanciadoraBase;
                idOp = registroOperacaoStageNegocio.validarIdOp(getContext().getPartyId(), operacao.getIdentdConjUniddRecbvl());
                bean = new RRC0019ApiGestaoParticipante(partyId, participanteVO, operacao, indrIA, idOp, identdOp, getContext().getBatchReferenceDate());
            }

            // Enviar bean para processamento assincrono
            LOG.info("Criando batch assincrono para RRC0019 principal: {} administrado: {} ", partyId, partyAdmin);
            BatchContext batchContext = getContext().createLateBatch(TipoFuncionalidade.RRC0019.getValue());
            List<SPBBean> records = new ArrayList<>();
            records.add(bean);
            batchContext.addJob().addRecord(records);

            return new ResponseEntity<>(HttpStatus.ACCEPTED);
        } catch (IllegalArgumentException e) {

            LOG.info("ERRO HTTP 412 PRECONDITION FAILED - FinanciadoraController -> processFinanciadoraOperacoes - IllegalArgumentException: {}.", e.getMessage());

            Erro erro = new Erro();
            erro.setDataHora(OffsetDateTime.now());
            MessageListArrayOutput mensagem = new MessageListArrayOutput();
            mensagem.campo("identdOp");
            mensagem.conteudo(identdOp);
            mensagem.mensagem(e.getMessage());
            mensagem.codigo(ErroValidacao.ERRC9999.getFormattedValue());
            erro.addMensagensItem(mensagem);

            return new ResponseEntity(erro, HttpStatus.PRECONDITION_FAILED);
        }
    }

    @Override
    public ResponseEntity<List<UnidadeRecebivelOperacaoFinanciadora>> getFinanciadoraOperacoesIdentdOpUnidadesRecebiveis(String xJwsSignature, String identdOp, String acceptEncoding, String contentEncoding, Integer numeroPagina, Integer tamanhoPagina, Long identificadorTransacao) {
        String mensagem = "Início get financiradora Operacoes IdentdOp unidades recebíveis. identdOp {}, Página {}, Tamanho {}";
        LOG.info(mensagem, identdOp, numeroPagina, tamanhoPagina);

        Object o;
        Context ctx = getContext();

        Integer partyAdmin = Integer.valueOf(getContext().getProperties().get(HttpTransportConfig.HEADER_PARTY_ADMIN_ID).toString());
        Long idTransacao = Optional.ofNullable(identificadorTransacao).orElse(ctx.getRootId());
        List<FracaoUnidadeRecebivelOperacao> listaFracoes = new ArrayList<>();

        String habilitaSnapshot = parametroSistemaNegocio.getStringParam(ParametroConfiguracao.HABILITA_RRC0019_SNAPSHOT);
        /*
            se habilitar snapshot
         */
        if (habilitaSnapshot.equals("S")) {
            String tipoSnapshot = parametroSistemaNegocio.getStringParam(ParametroConfiguracao.RRC0019_SNAPSHOT_TIPO);
            /*
            se  snapshot for do tipo FILESYSTEM
            */
            if (tipoSnapshot.equals("FILESYSTEM")) {
                File diretorio = new File(parametroSistemaNegocio.getStringParam(ParametroConfiguracao.ARQ_RECORD_OUTPUT_DATA_DIRETORIO)
                        + System.getProperty("file.separator")+ DateUtil.format(getContext().getBatchReferenceDate(), "yyyyMMdd"));

                String nomeArquivo = identdOp + "_fracoesConstituidas.json";
                File json = new File(diretorio, nomeArquivo);
                /*
                    achou o arquivo ?
                 */
                if (json.exists()) {
                    ObjectMapper objectMapper = new ObjectMapper()
                            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
                            .registerModule(new JavaTimeModule());
                    try (
                            FileInputStream fis = new FileInputStream(json);
                            GZIPInputStream gfis = new GZIPInputStream(fis);
                    ) {
                        UnidadeRecebivelOperacaoFinanciadora[] urs = objectMapper.readValue(gfis, UnidadeRecebivelOperacaoFinanciadora[].class);
                        o = Arrays.asList(urs);
                    } catch (IOException e) {
                        throw new IllegalArgumentException(e);
                    }
                }
                /*
                    não achou ? metodo tradicional
                 */
                else {
                    RRC0021 rrc0021 = new RRC0021(DATATYPE_RRC0021, PartyUtility.partyIdToIspb(getContext().getPartyId()),
                            PartyUtility.partyIdToIspb(partyAdmin), identdOp, true);
                    rrc0021.setCompletavel(false);

                    rrc0021Handler.processSPB(rrc0021, getContext());

                    o = AtlanteSession.getSession().getHttpRecords().get(0);
                }
            }
            /*
             se  snapshot for diferente de  FILESYSTEM
            */
            else {
                List<String> jsons = operacaoNegocio.buscarJsonFotoFracoesConstituidas(Long.parseLong(identdOp), 0, 100);
                if (jsons != null && !jsons.isEmpty()) {
                    ObjectMapper objectMapper = new ObjectMapper()
                            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
                            .registerModule(new JavaTimeModule());

                    try {
                        List<UnidadeRecebivelOperacaoFinanciadora> resultado = new ArrayList<>();
                        for (int i = 0; i < jsons.size(); i++) {
                            resultado.add(objectMapper.readValue(jsons.get(i), UnidadeRecebivelOperacaoFinanciadora.class));
                        }
                        o = resultado;
                    } catch (IOException e) {
                        throw new IllegalArgumentException(e);
                    }
                } else {
                    RRC0021 rrc0021 = new RRC0021(DATATYPE_RRC0021, PartyUtility.partyIdToIspb(getContext().getPartyId()),
                            PartyUtility.partyIdToIspb(partyAdmin), identdOp, true);
                    rrc0021.setCompletavel(false);

                    rrc0021Handler.processSPB(rrc0021, getContext());

                    o = AtlanteSession.getSession().getHttpRecords().get(0);
                }
            }
        } else {
            RRC0021 rrc0021 = new RRC0021(DATATYPE_RRC0021, PartyUtility.partyIdToIspb(getContext().getPartyId()),
                    PartyUtility.partyIdToIspb(partyAdmin), identdOp, true);
            rrc0021.setCompletavel(false);

            rrc0021Handler.processSPB(rrc0021, getContext());

            o = AtlanteSession.getSession().getHttpRecords().get(0);
        }

        if(!Optional.ofNullable(identificadorTransacao).isPresent()) {
            if (o instanceof List) {
                listaFracoes = (List) o;
                paginacaoHandler.insereDadosAPaginar(listaFracoes, ctx.getRootId());
                if (CollectionUtils.isEmpty(listaFracoes)) {
                    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
                }
            } else if (o instanceof Erro) {
                return new ResponseEntity(o, HttpStatus.PRECONDITION_FAILED);
            }else {
                throw new ApplicationErrorAPIException(o, new ArcConditionalException());
            }
        } else{
            listaFracoes = paginacaoHandler.paginadosFracaoUnidadeRecebilOperacao(idTransacao, tamanhoPagina, numeroPagina);
        }
        ResultadoPaginado resultadoPaginado = converteToGrupoRRC0021R1NegcRecbvl(listaFracoes, identdOp, mensagem, numeroPagina, tamanhoPagina, idTransacao);
        return new ResponseEntity<>(resultadoPaginado.getLista(), resultadoPaginado.getLinkHeader(), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<List<UnidadeRecebivelAConstituirOperacaoFinanciadora>> getFinanciadoraOperacoesIdentdOpUnidadesRecebiveisAConstituir(String xJwsSignature, String identdOp, String acceptEncoding, String contentEncoding, Integer numeroPagina, Integer tamanhoPagina, Long identificadorTransacao) {
        Context ctx = getContext();
        Long idTransacao = Optional.ofNullable(identificadorTransacao).orElse(ctx.getRootId());

        String mensagem = "Início get financiradora Operacoes IdentdOp unidades recebíveis. identdOp {}, Página {}, Tamanho {}";
        LOG.info(mensagem, identdOp, numeroPagina, tamanhoPagina);
        Integer partyAdmin = Integer.valueOf(
                getContext().getProperties().get(HttpTransportConfig.HEADER_PARTY_ADMIN_ID).toString());
        RRC0021 rrc0021 = new RRC0021(DATATYPE_RRC0021, PartyUtility.partyIdToIspb(getContext().getPartyId()),
                PartyUtility.partyIdToIspb(partyAdmin), identdOp, false);
        rrc0021.setCompletavel(false);
        Object o;
        if(!Optional.ofNullable(identificadorTransacao).isPresent()) {
            rrc0021Handler.processSPB(rrc0021, getContext());
            o = AtlanteSession.getSession().getHttpRecords().get(0);
            if (o instanceof List) {
                paginacaoHandler.insereDadosAPaginar(o, ctx.getRootId());
            }
            if (o instanceof Erro) {
                LOG.info("Sem retorno após esperar 60 segundos.");
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        }else {
            o = paginacaoHandler.paginadosFracaoUnidadeRecebilOperacao(idTransacao, tamanhoPagina, numeroPagina);
        }


        if (o instanceof List) {
            List<UnidadeRecebivelAConstituirOperacaoFinanciadora> resultado = new ArrayList<>();
            for (FracaoUnidadeRecebivelOperacao fracao : (List<FracaoUnidadeRecebivelOperacao>) o) {
                UnidadeRecebivelAConstituirOperacaoFinanciadora ur = new UnidadeRecebivelAConstituirOperacaoFinanciadora();
                ur.setCnpjCreddrSub(fracao.getNrCnpjCreddr());
                ur.setCnpjOuCnpjBaseOuCpfTitlar(fracao.getNrCpfCnpjTitlar());
                ur.setCnpjOuCnpjBaseOuCpfUsuFinalRecbdr(fracao.getNrCpfCnpjUsurioFinlRecbdr());
                ur.setCnpjOuCpfTitlarCt(fracao.getNrCpfCnpjTitlarCt());
                ur.setCodInstitdrArrajPgto(fracao.getCdArrjPgto());
                ur.setTpCt(fracao.getIcTpCt());
                if (fracao.getNrAg() != null) {
                    ur.setAg(new BigDecimal(fracao.getNrAg()));
                }
                if (fracao.getNrCt() != null) {
                    ur.setCt(new BigDecimal(fracao.getNrCt()));
                }
                if (fracao.getNrCtPgto() != null) {
                    ur.setCtPgto(new BigDecimal(fracao.getNrCtPgto()));
                }
                if (fracao.getDtPrevtLiquid() != null) {
                    ur.setDtPrevtLiquid(DateTimeUtils.toLocalDate(fracao.getDtPrevtLiquid()));
                }
                if (fracao.getCdIspbBcoRecbdr() != null) {
                    ur.setIspbBcoRecbdr(PartyUtility.partyIdToIspb(fracao.getCdIspbBcoRecbdr().intValue()));
                }
                if (fracao.getNrPridd() != null) {
                    ur.setPriorddNegcRecbvl(new BigDecimal(fracao.getNrPridd()));
                }
                if (fracao.getNrVlrPrevtLiquid() != null) {
                    ur.setVlrPercNegcdConstitr(fracao.getNrVlrPrevtLiquid().doubleValue());
                }
                resultado.add(ur);
            }
            if (resultado.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            String uri = "/v1/financiadora/operacoes/" + identdOp + "/unidades-recebiveis-a-constituir" + "?identificadorTransacao=" + idTransacao;
            ResultadoPaginado resultadoPaginado = paginacaoUtil.paginar(resultado, numeroPagina, tamanhoPagina, uri, idTransacao);
            return new ResponseEntity<>(resultadoPaginado.getLista(), resultadoPaginado.getLinkHeader(), HttpStatus.OK);
        } else if (o instanceof Erro) {

            LOG.info("ERRO HTTP 412 PRECONDITION FAILED - FinanciadoraController -> getFinanciadoraOperacoesIdentdOpUnidadesRecebiveisAConstituir - Erro: {}.", o.toString());

            return new ResponseEntity(o, HttpStatus.PRECONDITION_FAILED);
        }

        throw new ApplicationErrorAPIException(o, new ArcConditionalException());
    }

    @Override
    public ResponseEntity<List<OperacaoFinanciadora>> getFinanciadoraOperacoes(String xJwsSignature, String acceptEncoding, String contentEncoding, String cnpjOuCnpjBaseOuCpfUsuFinalRecbdr, String cnpjOuCnpjBaseOuCpfTitlar, Integer numeroPagina, Integer tamanhoPagina, Long identificadorTransacao) {
        Context ctx = getContext(); //novo
        Integer partyAdmin = Integer.valueOf(ctx.getProperties().get(HttpTransportConfig.HEADER_PARTY_ADMIN_ID).toString());
        RRC0021 rrc0021 = new RRC0021(DATATYPE_RRC0021, PartyUtility.partyIdToIspb(getContext().getPartyId()),
                PartyUtility.partyIdToIspb(partyAdmin), cnpjOuCnpjBaseOuCpfTitlar,
                cnpjOuCnpjBaseOuCpfUsuFinalRecbdr);
        rrc0021.setPaginacao(numeroPagina, tamanhoPagina);

        Long idTransacao = Optional.ofNullable(identificadorTransacao).orElse(ctx.getRootId()); // novo

        Object o;

        if(!Optional.ofNullable(identificadorTransacao).isPresent()) {
            rrc0021Handler.processSPB(rrc0021, getContext());
            o = AtlanteSession.getSession().getHttpRecords().get(0);
            if (o instanceof List) {
                paginacaoHandler.insereDadosAPaginar(o, ctx.getRootId());
            }else if (o instanceof Erro) {
                return new ResponseEntity(o, HttpStatus.PRECONDITION_FAILED);
            }
        }else{
            o = paginacaoHandler.paginadosFinanciadoraOperacoes(idTransacao, tamanhoPagina, numeroPagina);
        }

        if (o instanceof RRC0021R1) {
            RRC0021R1 e = (RRC0021R1) o;

            List<GrupoRRC0021R1NegcRecbvl> listGrupo = new LinkedList<>();
            listGrupo.addAll(e.getListagrupoRRC0021R1NegcRecbvl());

            List<OperacaoFinanciadora> resultado = listGrupo.stream().map(this::convertOperacaoFinanciadora).collect(
                    Collectors.toList());

            if (resultado.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            // TODO - Refatorar para utilizar os valores direto do Request
            String uri = "/financiadora/operacoes?identificadorTransacao=" + idTransacao;
            if (cnpjOuCnpjBaseOuCpfUsuFinalRecbdr != null) {
                uri += "&cnpjOuCnpjBaseOuCpfUsuFinalRecbdr=" + cnpjOuCnpjBaseOuCpfUsuFinalRecbdr;
            }
            if (cnpjOuCnpjBaseOuCpfTitlar != null) {
                uri += "&cnpjOuCnpjBaseOuCpfTitlar=" + cnpjOuCnpjBaseOuCpfTitlar;
            }
            ResultadoPaginado resultadoPaginado = paginacaoUtil.paginar(resultado, numeroPagina, tamanhoPagina, uri, idTransacao);
            return new ResponseEntity<>(resultadoPaginado.getLista(), resultadoPaginado.getLinkHeader(), HttpStatus.OK);
        } else if (o instanceof Erro) {
            return new ResponseEntity(o, HttpStatus.PRECONDITION_FAILED);
        } else if (o instanceof List) {
            List<FracaoUnidadeRecebivelOperacao> resultado = (List<FracaoUnidadeRecebivelOperacao>) o;
            List<OperacaoFinanciadora> retorno;
            retorno = resultado.stream().map(this::converteToGrupoRRC0021R1NegcRecbvl).collect(Collectors.toList());
            if (retorno.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            Boolean completo = !resultado.get(0).isCompleto();
            // TODO - Refatorar para utilizar os valores direto do Request
            String uri = "/financiadora/operacoes?identificadorTransacao=" + idTransacao;
            if (cnpjOuCnpjBaseOuCpfUsuFinalRecbdr != null) {
                uri += "&cnpjOuCnpjBaseOuCpfUsuFinalRecbdr=" + cnpjOuCnpjBaseOuCpfUsuFinalRecbdr;
            }
            if (cnpjOuCnpjBaseOuCpfTitlar != null) {
                uri += "&cnpjOuCnpjBaseOuCpfTitlar=" + cnpjOuCnpjBaseOuCpfTitlar;
            }
            ResultadoPaginado resultadoPaginado = paginacaoUtil.paginar(retorno, numeroPagina, tamanhoPagina, uri, idTransacao);
            return new ResponseEntity<>(resultadoPaginado.getLista(), resultadoPaginado.getLinkHeader(), HttpStatus.OK);
        }

        throw new ApplicationErrorAPIException(o, new ArcConditionalException());
    }



    @Override
    public ResponseEntity<OperacaoFinanciadora> getFinanciadoraOperacoesIdentdOp(String xJwsSignature, String identdOp, String acceptEncoding, String contentEncoding, Long identificadorTransacao) {
        String partyAdmin = (String) getContext().getProperties().get(HttpTransportConfig.HEADER_PARTY_ADMIN_ID);
        RRC0021 rrc0021 = new RRC0021(DATATYPE_RRC0021, PartyUtility.partyIdToIspb(getContext().getPartyId()), partyAdmin, identdOp);

        rrc0021Handler.processSPB(rrc0021, getContext());

        Object o = AtlanteSession.getSession().getHttpRecords().get(0);

        String uri = "/financiadora/operacoes/" + identdOp;

        if (o instanceof RRC0021R1) {
            RRC0021R1 rrc0021r = (RRC0021R1) o;

            List<GrupoRRC0021R1NegcRecbvl> listGrupo = new LinkedList<>();
            listGrupo.addAll(rrc0021r.getListagrupoRRC0021R1NegcRecbvl());

            Optional<GrupoRRC0021R1NegcRecbvl> foundObj = listGrupo.stream().filter(
                    x -> x.getIdentdOp().getValue().equals(identdOp)).findFirst();

            if (foundObj.isPresent()) {

                ResultadoPaginado resultadoPaginado = ListUtil.paginar(listGrupo, 1, 1, uri);
                return new ResponseEntity(resultadoPaginado.getLista(), resultadoPaginado.getLinkHeader(),
                        HttpStatus.OK);

            } else {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
        } else if (o instanceof Erro) {
            return new ResponseEntity(o, HttpStatus.PRECONDITION_FAILED);
        } else if (o instanceof List) {
            List<FracaoUnidadeRecebivelOperacao> listaFracoes = (List<FracaoUnidadeRecebivelOperacao>) o;
            if (CollectionUtils.isEmpty(listaFracoes)) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            } else {
                OperacaoFinanciadora retorno = converteToGrupoRRC0021R1NegcRecbvl(listaFracoes.get(0));
                return new ResponseEntity(retorno, HttpStatus.OK);
            }
        }

        throw new ApplicationErrorAPIException(o, new ArcConditionalException());
    }

    @Override
    public ResponseEntity<List<UnidadeRecebivelDisponivelFinanciadora>> getFinanciadoraUnidadesRecebiveisDisponiveis(String xJwsSignature, String identdConjUniddRecbvlDisp, String acceptEncoding, String contentEncoding, Integer numeroPagina, Integer tamanhoPagina, Long identificadorTransacao) {
        Long id;
        String ispb = PartyUtility.partyIdToIspb(getContext().getPartyId());
        Long idTransacao = Optional.ofNullable(identificadorTransacao).orElse(getContext().getRootId());
        try {
            id = Long.parseLong(identdConjUniddRecbvlDisp);
        } catch (NumberFormatException e) {

            LOG.info("ERRO HTTP 412 PRECONDITION FAILED - FinanciadoraController -> getFinanciadoraUnidadesRecebiveisDisponiveis - NumberFormatException: {}.", e.getMessage());

            Erro erro = new Erro();
            erro.setDataHora(OffsetDateTime.now());
            MessageListArrayOutput mensagem = new MessageListArrayOutput();
            mensagem.campo("identdConjUniddRecbvlDisp");
            mensagem.conteudo(identdConjUniddRecbvlDisp);
            mensagem.mensagem(e.getMessage());
            mensagem.codigo(ErroValidacao.ERRC9999.getFormattedValue());
            erro.addMensagensItem(mensagem);

            return new ResponseEntity(erro, HttpStatus.PRECONDITION_FAILED);
        }

        List<UnidadeRecebivelDisponivelFinanciadora> resultado = null;

        if(!Optional.ofNullable(identificadorTransacao).isPresent()){
            resultado = conjuntoUnidadeRecebivelDisponivelNegocio.buscarUnidadeRecebivelDisponivelFinanciadoraPorId(ispb, id);
        } else {
            resultado = conjuntoUnidadeRecebivelDisponivelNegocio.buscarUnidadeRecebivelDisponivelFinanciadoraPorId(ispb, id, numeroPagina, tamanhoPagina);
        }
        if (resultado.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        String uri = "/financiadora/unidades-recebiveis-disponiveis?identdConjUniddRecbvlDisp="
                + identdConjUniddRecbvlDisp;
        ResultadoPaginado resultadoPaginado = ListUtil.paginar(resultado, numeroPagina, tamanhoPagina, uri);
        return new ResponseEntity<>(resultadoPaginado.getLista(), resultadoPaginado.getLinkHeader(), HttpStatus.OK);
    }

    private OperacaoFinanciadora convertOperacaoFinanciadora(GrupoRRC0021R1NegcRecbvl oper) {

        OperacaoFinanciadora operacaoFinanciadora = new OperacaoFinanciadora();
        //        operacaoFinanciadora.setIdentdCIPOpOrRenegcDiv();
        operacaoFinanciadora.setCnpjER(getValueOrNull(oper.getCNPJER()));
        operacaoFinanciadora.setIndrActeUniddRecbvlReserv(getValueOrNull(oper.getIndrActeUniddRecbvlReserv()));
        operacaoFinanciadora.setIndrAlcancContrtoCreddrSub(getValueOrNull(oper.getIndrAlcancContrtoCreddrSub()));
        operacaoFinanciadora.setIndrAutcCess(getValueOrNull(oper.getIndrAutcCess()));
        operacaoFinanciadora.setIdentdNegcRecbvl(getValueOrNull(oper.getIdentdNegcRecbvl()));
        operacaoFinanciadora.setIdentdOp(getValueOrNull(oper.getIdentdOp()));
        operacaoFinanciadora.setDtHrIncl(getValueLocalDateTimeAsOffsetDateTime(oper.getDtHrIncl()));
        operacaoFinanciadora.setDtVencOp(DateTimeUtils.toLocalDate(getValueOrNull(oper.getDtVencOp())));
        operacaoFinanciadora.setIndrActeIncondlOp(getValueOrNull(oper.getIndrActeIncondlOp()));
        operacaoFinanciadora.setIndrGestER(getValueOrNull(oper.getIndrGestER()));
        operacaoFinanciadora.setIndrRegrDivs(getValueOrNull(oper.getIndrRegrDivs()));
        operacaoFinanciadora.setIndrSitOp(getValueOrNull(oper.getIndrSitOp()));
        operacaoFinanciadora.setIndrTpNegc(getValueOrNull(oper.getIndrTpNegc()));
        operacaoFinanciadora.setVlrGar(getBigDecimalAsDouble(oper.getVlrGar()));
        operacaoFinanciadora.setVlrTotLimOuSldDevdr(getBigDecimalAsDouble(oper.getVlrTotLimSldDevdr()));

        if (operacaoFinanciadora.getIdentdOp() != null) {
            try {
                OperacaoCredenciadoraUnidadesRecebiveis operacaoCredenciadoraUnidadesRecebiveis = new OperacaoCredenciadoraUnidadesRecebiveis();
                String uri = "/financiadora/operacoes/" + operacaoFinanciadora.getIdentdOp() + "/unidades-recebiveis";
                if(oper.isCompleto()) {
                    operacaoCredenciadoraUnidadesRecebiveis.setHref(new URI(uri));
                }
                operacaoFinanciadora.setUnidadesRecebiveis(operacaoCredenciadoraUnidadesRecebiveis);
            } catch (URISyntaxException use) {
                // Do noting!
            }

            try {
                OperacaoCredenciadoraUnidadesRecebiveis operacaoCredenciadoraUnidadesRecebiveisAConstituir = new OperacaoCredenciadoraUnidadesRecebiveis();
                String uri = "/financiadora/operacoes/" + operacaoFinanciadora.getIdentdOp() + "/unidades-recebiveis-a-constituir";
                if(oper.isCompleto()) {
                    operacaoCredenciadoraUnidadesRecebiveisAConstituir.setHref(new URI(uri));
                }
                operacaoFinanciadora.setUnidadesRecebiveisAConstituir(operacaoCredenciadoraUnidadesRecebiveisAConstituir);
            } catch (URISyntaxException use) {
                // Do noting!
            }
        }

        return operacaoFinanciadora;
    }
    private OperacaoFinanciadora converteToGrupoRRC0021R1NegcRecbvl(FracaoUnidadeRecebivelOperacao listaFracoes) {
        return convertOperacaoFinanciadora(montarGrupoRRC0021R1NegcRecbvl(listaFracoes));
    }

    private ResultadoPaginado converteToGrupoRRC0021R1NegcRecbvl(List<FracaoUnidadeRecebivelOperacao> listaFracoes, String identdOp, String mensagem, Integer numeroPagina, Integer tamanhoPagina, Long identificadorTransacao) {
        List<UnidadeRecebivelOperacaoFinanciadora> resultado = new ArrayList<>();
        for (FracaoUnidadeRecebivelOperacao fracao : listaFracoes) {
            UnidadeRecebivelOperacaoFinanciadora ur = new UnidadeRecebivelOperacaoFinanciadora();
            ur.setCnpjCreddrSub(fracao.getNrCnpjCreddr());
            ur.setCnpjOuCnpjBaseOuCpfTitlar(fracao.getNrCpfCnpjTitlar());
            ur.setCnpjOuCpfUsuFinalRecbdr(fracao.getNrCpfCnpjUsurioFinlRecbdr());
            ur.setCnpjOuCpfTitlarCt(fracao.getNrCpfCnpjTitlarCt());
            ur.setCodInstitdrArrajPgto(fracao.getCdArrjPgto());
            ur.setTpCt(fracao.getIcTpCt());
            if (fracao.getNrAg() != null) {
                ur.setAg(new BigDecimal(fracao.getNrAg()));
            }
            if (fracao.getNrCt() != null) {
                ur.setCt(new BigDecimal(fracao.getNrCt()));
            }
            if (fracao.getNrCtPgto() != null) {
                ur.setCtPgto(new BigDecimal(fracao.getNrCtPgto()));
            }
            if (fracao.getDtPrevtLiquid() != null) {
                ur.setDtPrevtLiquid(DateTimeUtils.toLocalDate(fracao.getDtPrevtLiquid()));
            }
            if (fracao.getCdIspbBcoRecbdr() != null) {
                ur.setIspbBcoRecbdr(PartyUtility.partyIdToIspb(fracao.getCdIspbBcoRecbdr().intValue()));
            }
            if (fracao.getNrPridd() != null) {
                ur.setPriorddNegcRecbvl(new BigDecimal(fracao.getNrPridd()));
            }
            if (fracao.getNrVlrPrevtLiquid() != null) {
                ur.setVlrNegcd(fracao.getNrVlrPrevtLiquid().doubleValue());
            }
            resultado.add(ur);
        }
        String uri = "/financiadora/operacoes/" + identdOp + "/unidades-recebiveis"
                + "?identificadorTransacao=" + ((identificadorTransacao == null)?"":identificadorTransacao.toString());

        ResultadoPaginado resultadoPaginado = paginacaoUtil.paginar(resultado, numeroPagina, tamanhoPagina, uri, identificadorTransacao);
        mensagem = mensagem + "resultado paginado {}";
        LOG.info(mensagem, identdOp, numeroPagina, tamanhoPagina, resultadoPaginado);

        return resultadoPaginado;
    }

    private GrupoRRC0021R1NegcRecbvl montarGrupoRRC0021R1NegcRecbvl(FracaoUnidadeRecebivelOperacao item) {

        GrupoRRC0021R1NegcRecbvl grupoRRC0021R1NegcRecbvl = new GrupoRRC0021R1NegcRecbvl();

        if (item.getOperacao() != null) {
            grupoRRC0021R1NegcRecbvl.setCNPJER(
                    new SPBString(CpfCnpjUtil.formataCnpj(item.getOperacao().getNrCnpjRegtdr())));
            grupoRRC0021R1NegcRecbvl.setIdentdNegcRecbvl(new SPBString(item.getOperacao().getIdNegcRecbvExtn()));
            grupoRRC0021R1NegcRecbvl.setIdentdOp(new SPBString(item.getOperacao().getIdOp().toString()));
            grupoRRC0021R1NegcRecbvl.setIndrTpNegc(new SPBString(item.getOperacao().getIcTpNegc()));
            grupoRRC0021R1NegcRecbvl.setDtVencOp(SPBConverter.dateToSPBLocalDate((item.getOperacao().getDtVencOp())));
            grupoRRC0021R1NegcRecbvl.setVlrTotLimSldDevdr(
                    new SPBBigDecimal(item.getOperacao().getNrLimConcdSldDevdr()));
            grupoRRC0021R1NegcRecbvl.setVlrGar(new SPBBigDecimal(
                    (item.getOperacao().getNrVlrGar() != null) ? item.getOperacao().getNrVlrGar() : BigDecimal.ZERO));
            grupoRRC0021R1NegcRecbvl.setIndrGestER(new SPBString(item.getOperacao().getIcGesteNtRegtdr()));
            grupoRRC0021R1NegcRecbvl.setIndrRegrDivs(new SPBString(item.getOperacao().getIcRegrDivs()));
            grupoRRC0021R1NegcRecbvl.setIndrAlcancContrtoCreddrSub(
                    new SPBString(item.getOperacao().getIcAlcccontrto()));
            grupoRRC0021R1NegcRecbvl.setIndrActeIncondlOp(new SPBString(item.getOperacao().getIcActeOp()));
            //grupoRRC0021R1NegcRecbvl.setIdentdCIPOpOrRenegcDiv(new SPBString(item.getOperacao().get));
            grupoRRC0021R1NegcRecbvl.setIndrActeUniddRecbvlReserv(new SPBString(IndicadorSimNao.NAO.getValue()));
            grupoRRC0021R1NegcRecbvl.setDtHrIncl(SPBConverter
                    .dateTimeToSPBLocalDateTime(item.getOperacao().getDhIncl().toDateTime(), "yyyy-MM-dd'T'HH:mm:ss"));
            grupoRRC0021R1NegcRecbvl.setIndrSitOp(new SPBString(item.getOperacao().getIcSit()));
            grupoRRC0021R1NegcRecbvl.setIndrAutcCess(new SPBString(item.getOperacao().getIcAutcCess()));
            grupoRRC0021R1NegcRecbvl.setCompleto(item.isCompleto());
        }

        return grupoRRC0021R1NegcRecbvl;
    }
}