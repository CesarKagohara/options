#!/usr/bin/env bash

version=`xmlstarlet sel -N 'x=http://maven.apache.org/POM/4.0.0' -t -m /x:project/x:properties -v x:r2c3-version pom.xml`
echo "Building version $version ..."
sh dist.sh

# Nome do container do WebSphere
was_container=docker_jboss_1

# Obtém o nome do installer gerado à partir do dist
installer=$(basename target/*installer*)

echo "Copying installer ${installer} to docker container ${was_container}:/home/atlante/install/"
docker cp target/${installer} ${was_container}:/tmp/

echo "Copying atlante-config files"
docker cp atlante-config/atlante-config.xml ${was_container}:/opt/atlante/config/
docker cp atlante-config/atlante-config-component-scan.xml ${was_container}:/opt/atlante/config/
docker cp atlante-config/input-config-ft.xml ${was_container}:/opt/atlante/config/
docker cp atlante-config/input-config-mq.xml ${was_container}:/opt/atlante/config/
docker cp atlante-config/interpel-config.xml ${was_container}:/opt/atlante/config/
docker cp atlante-config/output-config.xml ${was_container}:/opt/atlante/config/
docker cp atlante-config/output-config-ft.xml ${was_container}:/opt/atlante/config/
docker cp atlante-config/output-config-mq.xml ${was_container}:/opt/atlante/config/
docker cp atlante-config/priority-config.xml ${was_container}:/opt/atlante/config/
docker cp atlante-config/processor-config.xml ${was_container}:/opt/atlante/config/
docker cp atlante-config/processor-config-ft.xml ${was_container}:/opt/atlante/config/
docker cp atlante-config/processor-config-mq.xml ${was_container}:/opt/atlante/config/
docker cp atlante-config/scheduler-config.xml ${was_container}:/opt/atlante/config/
docker cp atlante-config/worker-config.xml ${was_container}:/opt/atlante/config/
docker cp atlante-config/worker-listener-config.xml ${was_container}:/opt/atlante/config/
docker cp atlante-config/r2c3-data-sources-config.xml ${was_container}:/opt/atlante/config/

echo "Copying dynamic-configuration files"
docker exec -ti -u atlante ${was_container} rm -Rf /opt/atlante/config/dynamic-configuration
docker cp atlante-config/dynamic-configuration ${was_container}:/opt/atlante/config/

echo "Copying API rebatedor files"
docker cp r2c3-api-rebatedor/start_servers.sh ${was_container}:/tmp
docker cp r2c3-api-rebatedor/stop_servers.sh ${was_container}:/tmp
docker cp r2c3-api-rebatedor/target/r2c3-api-rebatedor-$version.jar ${was_container}:/tmp
docker cp r2c3-api-rebatedor/target/r2c3-api-rebatedor-$version.jar ${was_container}:/tmp

echo "Installing at ${was_container} docker container..."
docker exec -ti -u atlante ${was_container} sh +x /tmp/${installer}

echo "Permissions..."
docker exec -ti -u atlante ${was_container} chmod -Rf 775 /opt/atlante/config
docker exec -u root ${was_container} bash -c 'chmod 770 /opt/atlante/tester-lib'
docker exec -u root ${was_container} bash -c 'chmod 770 /opt/atlante/tester-lib/*'

echo "Stopping docker container..."
docker container stop ${was_container}

echo "Cleaning JaCoCo reports..."
rm -Rf r2c3-tests/jacoco.exec r2c3-tests/jacoco-jboss.xml

echo "Starting docker container..."
docker container start ${was_container}

#scp /home/cip/proj/r2c3/target/r2c3-1.2.14-20201018-installer.sh  atlante@172.28.37.143:~/
