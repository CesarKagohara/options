# Descrição

Programa responsáve por servir de rebatedor (mock) da base centralizada e das outras registradoras (CERC e TAG)

# Execução

Copiar os arquivo start_servers.sh e stop_servers.sh para dentro da pasta docker_jboss_1:/tmp.

# Atualização

Para atualizar o rebatedor, pode ser interrompido o processamento (/tmp/stop_servers.sh) e em seguida executado mvn package

 