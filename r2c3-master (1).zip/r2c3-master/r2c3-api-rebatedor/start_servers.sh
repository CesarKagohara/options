#!/bin/bash
source /opt/atlante/tester-lib/atlante-tester-components.sh

REBATEDOR_BILATERAL_API=`find /home/proj/r2c3-api-rebatedor/target/dependency/ -name api-r2c3-bilateral-*.jar`
REBATEDOR_CENTRALIZADORA_API=`find /home/proj/r2c3-api-rebatedor/target/dependency/ -name api-r2c3-centralizadora-*.jar`
REBATEDOR_API=`find /home/proj/r2c3-api-rebatedor/target/ -name r2c3-api-rebatedor-*.jar`
EXTRA_SERVER_JARS="$REBATEDOR_API:$REBATEDOR_CENTRALIZADORA_API:$REBATEDOR_BILATERAL_API"
#Esse comando gera a SPOCK_CLASSPATH
configureComponents "r2c3-application" "/opt/atlante/" "/opt/atlante/config/"

## inicializa o server do atlante tester com os parametros: PORTA ISPB PARTY_NAME e DEBUG_PORT
#startAtlanteTesterServer "/atlante-tester" 9091 00000000 "Banco do Brasil" 5011
#startAtlanteTesterServer 9092 90708060 "Banco Itau" 5012
#startAtlanteTesterServer "/atlante-tester" 9093 11111111 "Sample Authorization Server" 5011
startAtlanteTesterServer "/atlante-tester" 9093 31345107 "TAG" 5013
startAtlanteTesterServer "/atlante-tester" 9094 23399607 "CERC" 5014
startAtlanteTesterServer "/atlante-tester" 9095 22222222 "CENTRALIZADORA" 5015
