package br.org.cipbancos.atlante.tester.components.r2c3.oauth;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import br.org.cipbancos.atlante.api.AtlanteClientCredentials;

@Component
public class R2C3ClientCredentialsRebatedor implements AtlanteClientCredentials {

    @Override
    public Map<String, Object> getApplicationData(Integer partyId) {
        Map<String, Object> params = new HashMap<>();
        params.put("partyId", partyId);
        return params;
    }

    @Override
    public Integer getPartyId(Map<String, Object> map) {
        return Integer.valueOf(map.get("partyId").toString());
    }
}
