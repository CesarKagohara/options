package br.org.cipbancos.atlante.tester.components.r2c3.controller;

import br.org.cip.api.r2c3.model.*;
import br.org.cipbancos.atlante.tester.components.r2c3.config.Constantes;
import br.org.cipbancos.atlante.tester.components.r2c3.dao.OperacaoDAO;
import br.org.cipbancos.atlante.tester.components.r2c3.dao.RebatedorParamSistDAO;
import br.org.cipbancos.atlante.tester.components.r2c3.negocio.CallBackNegocio;
import br.org.cipbancos.atlante.tester.components.r2c3.util.HeaderGeneratorID;
import br.org.cipbancos.atlante.tester.components.r2c3.util.HeaderReception;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/agenda")
public class AgendaController {

    private static final Logger LOG = LoggerFactory.getLogger(AgendaController.class);

    @Autowired
    private CallBackNegocio callBackNegocio;

    @Autowired
    private RebatedorParamSistDAO rebatedorParamSistDAO;

    @Autowired
    private OperacaoDAO operacaoDAO;

    public AgendaController() {
        LOG.debug("AGENDA CONTROLLER");
    }

    @PostMapping("/posicao")
    public ResponseEntity<GenericResponse> postAgendaPosicao(@RequestHeader(value="idControleRequisicao", required=true) String idControleRequisicao, @RequestHeader(value="idControleRecepcao", required=true) String idControleRecepcao, @RequestHeader(value="idControleResposta", required=true) String idControleResposta, @RequestHeader(value="Accept-Encoding", required=false) String acceptEncoding, @RequestHeader(value="Content-Encoding", required=false) String contentEncoding, @Valid @RequestBody(required = false) AgendaPosicao agendaPosicao) {
        LOG.debug("/agenda/posicao = {}", agendaPosicao);
        return ResponseEntity.ok(new GenericResponse());
    }

    @PostMapping
    public ResponseEntity<GenericResponse> agendaPost(@RequestHeader HttpHeaders headers,
                                                      @RequestBody Agenda agenda, HttpServletResponse response) {
        LOG.debug("AGENDA Post");
        LOG.debug(agenda.toString());

        response.addHeader(Constantes.ID_CONTROLE_RECEP, UUID.randomUUID().toString());
        response.addHeader(Constantes.ID_CONTROLE_REQ, headers.getFirst(Constantes.ID_CONTROLE_REQ));
        return ResponseEntity.ok(new GenericResponse());
    }

    @PostMapping("/rejeitar/{idAgenda}")
    public ResponseEntity<GenericResponse> agendaRejeitarPost(@RequestHeader HttpHeaders headers, @PathVariable String idAgenda,
                                                              @RequestBody AgendaRejeitar agendaRejeitar) {

        LOG.debug("AGENDARejeitar/{}", idAgenda);
        LOG.debug(agendaRejeitar.toString());
        return ResponseEntity.ok(new GenericResponse());
    }

    @PostMapping("/online")
    public ResponseEntity<List<AgendaOnlineResponse>> agendaOnlinePost(@RequestHeader HttpHeaders headers, @RequestHeader(value="idControleRequisicao", required=true) String idControleRequisicao, String acceptEncoding, String contentEncoding, @RequestBody(required = false) List<AgendaOnline> agendasOnline, HttpServletResponse response) {
        System.out.println("### POST AGENDA ONLINE ####");
        System.out.println("THREAD: "+Thread.currentThread().getName());
        LOG.info(agendasOnline.toString());

        List<AgendaOnlineResponse> agendasRespostas = new ArrayList<>();
        for (AgendaOnline agendaOnline : agendasOnline) {
            AgendaOnlineResponse agendaOnlineResponse = new AgendaOnlineResponse();
            agendaOnlineResponse.setIdBatch(agendaOnline.getIdBatch());
            agendaOnlineResponse.setCpfCnpjOriginador(agendaOnline.getCpfCnpjOriginador());
            agendaOnlineResponse.setCpfCnpjTitular(agendaOnline.getCpfCnpjTitular());
            agendaOnlineResponse.setCpfCnpjCredenciadora(agendaOnline.getCpfCnpjCredenciadora());
            agendaOnlineResponse.setArranjo(agendaOnline.getArranjo());
            agendaOnlineResponse.setIdAnuencia(agendaOnline.getIdAnuencia());
            agendaOnlineResponse.setIdContrato(agendaOnline.getIdEfeitoContrato());
            agendaOnlineResponse.setDataInicio(agendaOnline.getDataInicio());
            agendaOnlineResponse.setDataFim(agendaOnline.getDataFim());
            if (agendaOnline.getCpfCnpjOriginador() == null) {
                agendaOnlineResponse.setCpfCnpjOriginador("14670601000116");
            }
            if (agendaOnline.getCpfCnpjTitular() == null) {
                agendaOnlineResponse.setCpfCnpjTitular(agendaOnline.getCpfCnpjOriginador());
            }
            agendasRespostas.add(agendaOnlineResponse);
        }

        HeaderReception headerReception = new HeaderReception(idControleRequisicao, HeaderGeneratorID.generate());

        boolean recusarAgenda = rebatedorParamSistDAO.buscarBooleanPorNmParamSist("CERC_RECUSAR_PEDIDO_AGENDA");
        if (recusarAgenda) {
            for (AgendaOnlineResponse agendasResposta : agendasRespostas) {
                List<String> erros = new ArrayList<>();
                erros.add("003");
                agendasResposta.setErros(erros);
            }
            return new ResponseEntity<>(agendasRespostas, headerReception.getHttpHeaders(), HttpStatus.PRECONDITION_FAILED);
        }

        headers = new HttpHeaders();
        headers.put(Constantes.ID_CONTROLE_RECEP, Collections.singletonList(UUID.randomUUID().toString()));
        headers.put(Constantes.ID_CONTROLE_RESP, Collections.singletonList(UUID.randomUUID().toString()));
        headers.put(Constantes.ID_CONTROLE_CONF, Collections.singletonList(UUID.randomUUID().toString()));
        headers.put(Constantes.ID_CONTROLE_REQ, Collections.singletonList(idControleRequisicao));
        System.out.println(headers);

        boolean gerarAgendaVazia = rebatedorParamSistDAO.buscarBooleanPorNmParamSist("GERAR_AGENDA_VAZIA");
        if (gerarAgendaVazia) {
            List<AgendaPosicao> agendas = new ArrayList<>();
            for (AgendaOnline agendaOnline : agendasOnline) {
                AgendaPosicao agendaPosicao = new AgendaPosicao();
                DadosControle dadosControle = new DadosControle();
                dadosControle.setDataCriacao(LocalDate.of(2020, 1, 10));
                dadosControle.setDataReferencia(LocalDate.of(2020, 1, 10));
                dadosControle.setIdBatch(agendaOnline.getIdBatch());
                agendaPosicao.setDadosControle(dadosControle);
                agendaPosicao.setEfeitosContratos(new ArrayList<>());
                agendaPosicao.setRecebiveis(new ArrayList<>());
                agendas.add(agendaPosicao);
            }
            callBackNegocio.postAgendaPosicaoAsync(agendas, headers);
            return new ResponseEntity<>(agendasRespostas, headerReception.getHttpHeaders(), HttpStatus.OK);
        }

        String idEfeitoContratoGravame = null;
        int contadorEfeitoGravame = 0;
        int gerarEfeitoContratoGravameQtd = rebatedorParamSistDAO.buscarIntPorNmParamSist("AGENDA_ONLINE_ENVIAR_EFEITO_CONTRATO_GRAVAME_QTD");
        if (gerarEfeitoContratoGravameQtd > 0) {
            idEfeitoContratoGravame = operacaoDAO.buscarIdEfeitoContrato("OG");
            if (idEfeitoContratoGravame == null) {
                idEfeitoContratoGravame = UUID.randomUUID().toString();
            }
        }

        String idEfeitoContratoCessao = null;
        int contadorEfeitoCessao = 0;
        int gerarEfeitoContratoCessaoQtd = rebatedorParamSistDAO.buscarIntPorNmParamSist("AGENDA_ONLINE_ENVIAR_EFEITO_CONTRATO_CESSAO_QTD");
        if (gerarEfeitoContratoCessaoQtd > 0) {
            idEfeitoContratoCessao = operacaoDAO.buscarIdEfeitoContrato("TC");
            if (idEfeitoContratoCessao == null) {
                idEfeitoContratoCessao = UUID.randomUUID().toString();
            }
        }

        List<AgendaPosicao> agendas = new ArrayList<>();
        for (AgendaOnline agendaOnline : agendasOnline) {
            AgendaPosicao agendaPosicao = new AgendaPosicao();
            DadosControle dadosControle = new DadosControle();
            dadosControle.setDataCriacao(LocalDate.of(2020, 1, 10));
            dadosControle.setDataReferencia(LocalDate.of(2020, 1, 10));
            dadosControle.setIdBatch(agendaOnline.getIdBatch());
            agendaPosicao.setDadosControle(dadosControle);

            List<Recebivel> recebivelList = new ArrayList<>();
            List<EfeitoContrato> efeitosContratos = new ArrayList<>();

            agendaPosicao.setRecebiveis(recebivelList);
            agendaPosicao.setEfeitosContratos(efeitosContratos);

            Recebivel agendaRecebiveisVO = new Recebivel();
            List<DataLiquidacao> dataLiquidacaoList = new ArrayList<>();

            boolean gerarAgendaComErro = rebatedorParamSistDAO.buscarBooleanPorNmParamSist("GERAR_AGENDA_COM_ERRO");
            boolean gerarAgendaComErroJson = rebatedorParamSistDAO.buscarBooleanPorNmParamSist("GERAR_AGENDA_COM_ERRO_JSON");
            String gerarAgendaArranjoComErro = rebatedorParamSistDAO.buscarStringPorNmParamSist("GERAR_AGENDA_ARRANJO_COM_ERRO");
            int qtd = rebatedorParamSistDAO.buscarIntPorNmParamSist("AGENDA_ONLINE_ENVIAR_QTD_DATA_LIQUIDACAO");
            String dtInicialParam = rebatedorParamSistDAO.buscarStringPorNmParamSist("AGENDA_ONLINE_DATA_INICIO_AGENDA");
            LocalDate dtInicio = LocalDate.parse(dtInicialParam);

            String credenciadorasSemAgendaParam = rebatedorParamSistDAO.buscarStringPorNmParamSist("AGENDA_ONLINE_CRED_SEM_AGENDA");

            Set<String> credenciadorasSemAgenda = Arrays.stream(credenciadorasSemAgendaParam.split("[,]"))
                    .map(String::trim)
                    .collect(Collectors.toSet());
            if(credenciadorasSemAgenda.contains(agendaOnline.getCpfCnpjCredenciadora())){
                agendas.add(agendaPosicao);
                continue;
            }
            BigDecimal vlrLiquid = rebatedorParamSistDAO.buscarBigDecimalPorNmParamSist("AGENDA_ONLINE_FRACAO_VALOR_LIQUIDACAO");
            for (int i = 0; i < qtd; i++) {
                dtInicio = dtInicio.plusDays(1);
                DataLiquidacao dataLiquidacao = new DataLiquidacao();
                dataLiquidacao.setDataPrevistaLiquidacao(dtInicio);
                dataLiquidacao.setValorConstituidoTotal(vlrLiquid);
                dataLiquidacao.setValorConstituidoPreContratado(BigDecimal.ZERO);
                dataLiquidacao.setLiquidacoes(new ArrayList<>());

                Liquidacao liquidacao = new Liquidacao();
                liquidacao.setDomicilios(new ArrayList<>());
                if (gerarEfeitoContratoGravameQtd > contadorEfeitoGravame) {
                    liquidacao.setTipoObrigacao(Liquidacao.TipoObrigacaoEnum.EFEITOCONTRATADO);
                    liquidacao.setIdEfeitoContrato(idEfeitoContratoGravame);
                    liquidacao.setIndicadorOrdemEfeito(1);
                    contadorEfeitoGravame++;
                } else if (gerarEfeitoContratoCessaoQtd > contadorEfeitoCessao) {
                    liquidacao.setTipoObrigacao(Liquidacao.TipoObrigacaoEnum.EFEITOCONTRATADO);
                    liquidacao.setIdEfeitoContrato(idEfeitoContratoCessao);
                    liquidacao.setIndicadorOrdemEfeito(1);
                    contadorEfeitoCessao++;
                } else {
                    liquidacao.setTipoObrigacao(Liquidacao.TipoObrigacaoEnum.SALDOLIVRE);
                }

                String titularConta = agendaOnline.getCpfCnpjTitular() != null ? agendaOnline.getCpfCnpjTitular() : agendaOnline.getCpfCnpjOriginador();
                if (gerarAgendaComErro || gerarAgendaArranjoComErro.equals(agendaOnline.getArranjo())) {
                    titularConta = "77999999999988";
                }

                Domicilio domicilioVO = new Domicilio();
                domicilioVO.setTipoConta(Domicilio.TipoContaEnum.CC);
                domicilioVO.setAgencia("123");
                if (gerarAgendaComErroJson) {
                    domicilioVO.setAgencia("123 4    6");
                }
                domicilioVO.setConta("1234");
                domicilioVO.setDigitoConta("0");
                domicilioVO.setIspb("00000000");
                domicilioVO.setTipoDocumento(titularConta.length() == 14 ? Domicilio.TipoDocumentoEnum.CNPJ : Domicilio.TipoDocumentoEnum.CPF);
                domicilioVO.setDocumentoTitularConta(titularConta);
                domicilioVO.setValorLiquidacao(vlrLiquid);
                if (gerarAgendaComErro) {
                    domicilioVO.setDocumentoTitularConta("12345678901234");
                }
                liquidacao.getDomicilios().add(domicilioVO);

                dataLiquidacao.getLiquidacoes().add(liquidacao);
                dataLiquidacaoList.add(dataLiquidacao);
            }
            agendaRecebiveisVO.setArranjo(agendaOnline.getArranjo());
            agendaRecebiveisVO.setCnpjCredenciadora(agendaOnline.getCpfCnpjCredenciadora());
            agendaRecebiveisVO.setCpfCnpjOriginador(agendaOnline.getCpfCnpjOriginador());
            agendaRecebiveisVO.setIdAnuencia(agendaOnline.getIdAnuencia());
            agendaRecebiveisVO.setDatas(dataLiquidacaoList);
            recebivelList.add(agendaRecebiveisVO);

            if (idEfeitoContratoGravame != null) {
                EfeitoContrato efeitoContrato = new EfeitoContrato();
                efeitoContrato.setCpfCnpjTitularContrato("00000000000191");
                efeitoContrato.setIdEfeitoContrato(idEfeitoContratoGravame);
                efeitoContrato.setTipoEfeito(EfeitoContrato.TipoEfeitoEnum.GARANTIA);
                efeitoContrato.setDataVencimentoEfeito(dtInicio);
                efeitoContrato.setSaldoDevedorOuLimite(BigDecimal.TEN);
                efeitoContrato.setValorASerMantido(BigDecimal.ONE);
                efeitoContrato.setRegraDivisao(EfeitoContrato.RegraDivisaoEnum.VALORFIXO);
                efeitoContrato.setRegraReparticao(EfeitoContrato.RegraReparticaoEnum.INDIVIDUAL);
                efeitosContratos.add(efeitoContrato);
            }
            if (idEfeitoContratoCessao != null) {
                EfeitoContrato efeitoContrato = new EfeitoContrato();
                efeitoContrato.setCpfCnpjTitularContrato("00000000000191");
                efeitoContrato.setIdEfeitoContrato(idEfeitoContratoCessao);
                efeitoContrato.setTipoEfeito(EfeitoContrato.TipoEfeitoEnum.ALTERACAOTITULARIDADE);
                efeitoContrato.setDataVencimentoEfeito(dtInicio);
                efeitoContrato.setSaldoDevedorOuLimite(BigDecimal.TEN);
                efeitoContrato.setValorASerMantido(BigDecimal.ONE);
                efeitoContrato.setRegraDivisao(EfeitoContrato.RegraDivisaoEnum.VALORFIXO);
                efeitoContrato.setRegraReparticao(EfeitoContrato.RegraReparticaoEnum.INDIVIDUAL);
                efeitosContratos.add(efeitoContrato);
            }
            if (!efeitosContratos.isEmpty()) {
                agendaPosicao.setEfeitosContratos(efeitosContratos);
            }
            agendas.add(agendaPosicao);
        }

        callBackNegocio.postAgendaPosicaoAsync(agendas, headers);
        return new ResponseEntity<>(agendasRespostas, headerReception.getHttpHeaders(), HttpStatus.OK);
    }
}