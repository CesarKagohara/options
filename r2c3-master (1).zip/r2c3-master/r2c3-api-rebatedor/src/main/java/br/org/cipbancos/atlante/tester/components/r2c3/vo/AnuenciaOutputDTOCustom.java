package br.org.cipbancos.atlante.tester.components.r2c3.vo;

import br.org.cip.api.r2c3.model.BaseOutputComRetornoDTOOfAnuenciaOutputDTO;

public class AnuenciaOutputDTOCustom extends BaseOutputComRetornoDTOOfAnuenciaOutputDTO {
    String teste = "TESTE";

    public String getTeste() {
        return teste;
    }

    public void setTeste(String teste) {
        this.teste = teste;
    }
}
