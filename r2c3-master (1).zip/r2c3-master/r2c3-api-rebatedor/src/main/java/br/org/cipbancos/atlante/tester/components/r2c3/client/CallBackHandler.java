package br.org.cipbancos.atlante.tester.components.r2c3.client;

import org.springframework.http.HttpHeaders;

import br.org.cip.arche.commons.api.http.dispatcher.HttpCallBackHandler;
import br.org.cip.arche.commons.api.http.dispatcher.HttpRequest;
import br.org.cip.arche.commons.api.http.dispatcher.HttpResponse;
import br.org.cip.arche.commons.api.http.dispatcher.exception.CallBackException;

public class  CallBackHandler<RETORNO> extends HttpCallBackHandler<RETORNO> {
    boolean finish = false;
    private RETORNO response;
    private HttpHeaders requestHeaders;
    @Override
    public void request(HttpRequest<RETORNO> request) {
        System.out.println(request);
//        //request.getHeaders().set("x-jws-signature","Teste.Teste.Teste");//
//        request.getHeaders().put("id-controle-requisicao", this.requestHeaders.get("id-controle-requisicao"));
//        request.getHeaders().put("id-controle-recepcao", this.requestHeaders.get("id-controle-recepcao"));
//        request.getHeaders().put("id-controle-resposta", Collections.singletonList(UUID.randomUUID().toString()));
    }

    public void response(HttpResponse<RETORNO> response) {
        this.response = response.getBody();
        System.out.println(response);
        finish = true;
    }
    public void error(CallBackException callbackException) {
        //callbackException.printStackTrace();
        System.out.println(callbackException);
        finish = true;
    }
    @Override
    public boolean finished() {
        return this.finish;
    }

    public RETORNO getResponse() {
        return response;
    }

    public void setResponse(RETORNO response) {
        this.response = response;
    }

    public HttpHeaders getRequestHeaders() {
        return requestHeaders;
    }

    public void setRequestHeaders(HttpHeaders requestHeaders) {
        this.requestHeaders = requestHeaders;
    }


}
