package br.org.cipbancos.atlante.tester.components.r2c3.controller;

import br.org.cip.api.r2c3.model.*;
import br.org.cip.api.r2c3.model.MapaServicoOutputDTO.StatusEnum;
import br.org.cipbancos.atlante.tester.components.r2c3.dao.RebatedorParamSistDAO;
import br.org.cipbancos.atlante.tester.components.r2c3.util.Constantes;
import br.org.cipbancos.atlante.tester.components.r2c3.utils.GeraCpfCnpj;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.*;

@RestController
@RequestMapping()
public class CentralizadoraController {

    private static final Logger LOG = LoggerFactory.getLogger(CentralizadoraController.class);
    private static final String FORMATO_DATA_HORA_T = "yyyy-MM-dd'T'HH:mm:ss";
    private static final SimpleDateFormat conversor = new SimpleDateFormat(FORMATO_DATA_HORA_T);

    @Autowired
    private RebatedorParamSistDAO rebatedorParamSistDAO;

    @PostMapping("/api/opt")
    public ResponseEntity<List<BaseOutputComRetornoDTOOfAnuenciaOutputDTO>> insertAnuenciaUsingPOST(String acceptEncoding, String contentEncoding, @RequestBody(required = false) List<AnuenciaOptInInputDTO> anuencias) {
        System.out.println(" ****** CENTRALIZADORA POST /api/opt ******* ");

        if (rebatedorParamSistDAO.buscarBooleanPorNmParamSist("BASE_CENTRALIZADA_POST_OPT_RETORNAR_NOT_FOUND")) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        boolean hasMultistatus = false;
        List<BaseOutputComRetornoDTOOfAnuenciaOutputDTO> dtos = new ArrayList<>();
        for (AnuenciaOptInInputDTO anuencia : anuencias) {
            if(anuencia.getDocumentoUsuarioFinalRecebedorOuTitular().length() == 8) {
                return new ResponseEntity<>(dtos, HttpStatus.BAD_REQUEST);
            }
            BaseOutputComRetornoDTOOfAnuenciaOutputDTO dto = new BaseOutputComRetornoDTOOfAnuenciaOutputDTO();
            RetornoDTO retornoDTO = new RetornoDTO();
            retornoDTO.setCodigo(HttpStatus.OK.value());
            retornoDTO.setDescricao("SUCESSO");
            dto.setRetorno(retornoDTO);

            AnuenciaOutputDTO anuenciaOutputDTO = new AnuenciaOutputDTO();
            anuenciaOutputDTO.setCodigoControleOptIn(UUID.randomUUID());
            anuenciaOutputDTO.setDocumentoUsuarioFinalRecebedorOuTitular(anuencia.getDocumentoUsuarioFinalRecebedorOuTitular());
            anuenciaOutputDTO.setCnpjCredenciadora(anuencia.getCnpjCredenciadora());
            anuenciaOutputDTO.setArranjoPagamentoId(anuencia.getArranjoPagamentoId());
            anuenciaOutputDTO.setStatus(AnuenciaOutputDTO.StatusEnum.ATIVO);
            anuenciaOutputDTO.setTipoDocumentoCredor(null);
            anuenciaOutputDTO.setDocumentoCredor("12345678901234");
            anuenciaOutputDTO.setTipoDocumentoCredor(AnuenciaOutputDTO.TipoDocumentoCredorEnum.CNPJ);
            dto.setItem(anuenciaOutputDTO);

            if(anuencia.getDocumentoUsuarioFinalRecebedorOuTitular().equals("47789857546832")) {
                hasMultistatus = true;
            }

            dtos.add(dto);
        }

        if(hasMultistatus) {
            dtos.get(0).getRetorno().setCodigo(HttpStatus.BAD_REQUEST.value());
            dtos.get(0).getRetorno().setDescricao("O Arranjo de pagamento está Inatavo na Base centralizada");

            return new ResponseEntity<>(dtos, HttpStatus.MULTI_STATUS);
        }

        return new ResponseEntity<>(dtos, HttpStatus.OK);
    }

    @PutMapping("/api/opt")
    public ResponseEntity<List<BaseOutputComRetornoDTOOfAnuenciaOutputDTO>> updateAnuenciaUsingPUT(String acceptEncoding, String contentEncoding, @RequestBody(required = false) List<AnuenciaOptOutInputDTO> anuencias) {
        System.out.println(" ****** CENTRALIZADORA PUT /api/opt ******* ");

        List<BaseOutputComRetornoDTOOfAnuenciaOutputDTO> dtos = new ArrayList<>();
        for (AnuenciaOptOutInputDTO anuencia : anuencias) {
            BaseOutputComRetornoDTOOfAnuenciaOutputDTO dto = new BaseOutputComRetornoDTOOfAnuenciaOutputDTO();
            RetornoDTO retornoDTO = new RetornoDTO();
            retornoDTO.setCodigo(HttpStatus.OK.value());
            retornoDTO.setDescricao("SUCESSO");
            dto.setRetorno(retornoDTO);

            AnuenciaOutputDTO anuenciaOutputDTO = new AnuenciaOutputDTO();
            anuenciaOutputDTO.setCodigoControleOptIn(anuencia.getCodigoControleOptIn());
            anuenciaOutputDTO.setTipo(AnuenciaOutputDTO.TipoEnum.OPTIN);
            anuenciaOutputDTO.setEntidadeRegistradoraCnpj(Constantes.CNPJ_R2C3_REGISTRADORA);
            anuenciaOutputDTO.setStatus(AnuenciaOutputDTO.StatusEnum.INATIVO);
            anuenciaOutputDTO.setDataUltimaAtualizacao(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX").format(new Date()));
            dto.setItem(anuenciaOutputDTO);

            dtos.add(dto);
        }
        return new ResponseEntity<>(dtos, HttpStatus.OK);
    }

//    @GetMapping("/api/arranjo/query")
//    public ResponseEntity<BaseOutputComPaginacaoDTOOfAnuenciaOutputDTO> anuenciaUsingGET(@RequestParam(required = false) Integer pagina, @RequestParam(required = false) Integer tamanhoPagina) {
//
//        System.out.println(" ****** CENTRALIZADORA GET /api/opt INICIO ******* ");
//        return;
//    }

    @GetMapping("/api/opt")
    public ResponseEntity<BaseOutputComPaginacaoDTOOfAnuenciaOutputDTO> anuenciaUsingGET(@RequestParam(required = false) Integer pagina, @RequestParam(required = false) Integer tamanhoPagina) {
        System.out.println(" ****** CENTRALIZADORA GET /api/opt INICIO ******* ");
        boolean carga_d_menos_um = rebatedorParamSistDAO.buscarBooleanPorNmParamSist("CARGA_D_MENOS_UM");
        String arranjo[] = {"ACC","BCC","BCD","BVV", "CAC", "CBC", "CBD", "CBP",
                "CZC","DCC", "ECC", "ECD", "GCC", "HCC", "JCC", "MCC", "MCD", "MCP", "OCD", "SCC", "SCD", "VCC", "VCD", "VCP", "VDC", "VIA", "VIC", "VID",
        };
        List<AnuenciaOutputDTO> anuencias = new ArrayList<>();
        PaginacaoDTO paginacaoDTO = null;
        BaseOutputComPaginacaoDTOOfAnuenciaOutputDTO dto = null;
        Integer tamanhoLaco = rebatedorParamSistDAO.buscarBigDecimalPorNmParamSist("TAMANHO_LACO_REBATEDOR").intValue();
        if(carga_d_menos_um){
            for(int ji = 0; ji<tamanhoLaco;ji++) {
                String cnpjTitular = GeraCpfCnpj.cnpj(false);
                for (int i = 0; i < 28; i++) {
                    AnuenciaOutputDTO anuenciaOutputDTO = new AnuenciaOutputDTO();
                    anuenciaOutputDTO.setCodigoControleOptIn(UUID.randomUUID());
                    anuenciaOutputDTO.setDocumentoUsuarioFinalRecebedorOuTitular(cnpjTitular);
                    anuenciaOutputDTO.setCnpjCredenciadora(Constantes.CNPJ_R2C3_REGISTRADORA);
                    anuenciaOutputDTO.setArranjoPagamentoId(arranjo[i].toUpperCase(Locale.ROOT));
                    anuenciaOutputDTO.setTipo(AnuenciaOutputDTO.TipoEnum.OPTIN);
                    anuenciaOutputDTO.setStatus(AnuenciaOutputDTO.StatusEnum.ATIVO);
                    anuenciaOutputDTO.setDataCriacao("2020-01-09T16:21:47.758-03:00");
                    anuenciaOutputDTO.setDataInicio("2020-01-01T16:21:47.758-03:00");
                    anuenciaOutputDTO.setDataFim("2030-01-10T16:21:47.758-03:00");
                    anuenciaOutputDTO.setDataUltimaAtualizacao("2020-01-09T16:21:47.758-03:00");
                    anuenciaOutputDTO.setEntidadeRegistradoraCnpj("23399607000191");
                    anuencias.add(anuenciaOutputDTO);
                }
                Integer total1 = Math.toIntExact(28L * tamanhoLaco);
                paginacaoDTO = new PaginacaoDTO();
                paginacaoDTO.setPagina(pagina);
                paginacaoDTO.setTamanhoPagina(tamanhoPagina);
                paginacaoDTO.setTotalItens(total1.longValue());
                int total = (int)Math.ceil((total1.longValue() / tamanhoPagina));
                paginacaoDTO.setTotalPaginas(total == 0 ? 1 : total);
                dto = new BaseOutputComPaginacaoDTOOfAnuenciaOutputDTO();
                dto.setItens(this.getPaginacao(anuencias, pagina, tamanhoPagina));
                dto.setPaginacao(paginacaoDTO);
                // return this.getPaginacao()

            }
        }else {

            AnuenciaOutputDTO anuenciaOutputDTO = new AnuenciaOutputDTO();
            anuenciaOutputDTO.setCodigoControleOptIn(UUID.randomUUID());
            anuenciaOutputDTO.setDocumentoUsuarioFinalRecebedorOuTitular("14670601000116");
            anuenciaOutputDTO.setCnpjCredenciadora(Constantes.CNPJ_R2C3_REGISTRADORA);
            anuenciaOutputDTO.setArranjoPagamentoId("VCC");
            anuenciaOutputDTO.setTipo(AnuenciaOutputDTO.TipoEnum.OPTIN);
            anuenciaOutputDTO.setStatus(AnuenciaOutputDTO.StatusEnum.ATIVO);
            anuenciaOutputDTO.setDataCriacao("2020-01-10T16:21:47.758-03:00");
            anuenciaOutputDTO.setDataInicio("2020-01-01T16:21:47.758-03:00");
            anuenciaOutputDTO.setDataFim("2030-01-10T16:21:47.758-03:00");
            anuenciaOutputDTO.setDataUltimaAtualizacao("2020-01-10T16:21:47.758-03:00");
            anuenciaOutputDTO.setEntidadeRegistradoraCnpj("23399607000191");
            anuencias.add(anuenciaOutputDTO);

            paginacaoDTO = new PaginacaoDTO();
            paginacaoDTO.setPagina(1);
            paginacaoDTO.setTamanhoPagina(1);
            paginacaoDTO.setTotalItens(1L);
            paginacaoDTO.setTotalPaginas(1);
            dto = new BaseOutputComPaginacaoDTOOfAnuenciaOutputDTO();
            dto.setItens(anuencias);
            dto.setPaginacao(paginacaoDTO);
        }


        

        System.out.println(" ****** CENTRALIZADORA GET /api/opt FIM ******* ");

        return new ResponseEntity<>(dto, HttpStatus.OK);
    }

    @GetMapping("/api/opt/{codigoControleOptIn}")
    public ResponseEntity<AnuenciaOutputDTO> getAnuenciaByIdUsingGET(@PathVariable("codigoControleOptIn") String codigoControleOptIn) {
        System.out.println(" ****** CENTRALIZADORA GET /api/opt/{codigoControleOptIn} INICIO ******* ");

        AnuenciaOutputDTO anuenciaOutputDTO = new AnuenciaOutputDTO();
        anuenciaOutputDTO.setCodigoControleOptIn(UUID.fromString(codigoControleOptIn));
        anuenciaOutputDTO.setDocumentoUsuarioFinalRecebedorOuTitular("75045669135029");
        anuenciaOutputDTO.setCnpjCredenciadora("10440482000154");
        anuenciaOutputDTO.setArranjoPagamentoId("MCC");
        anuenciaOutputDTO.setTipo(AnuenciaOutputDTO.TipoEnum.OPTIN);
        anuenciaOutputDTO.setEntidadeRegistradoraCnpj("23399607000191");
        anuenciaOutputDTO.setStatus(AnuenciaOutputDTO.StatusEnum.ATIVO);
        anuenciaOutputDTO.setDataInicio("2021-02-22T00:00:00.000-03:00");
        anuenciaOutputDTO.setDataFim("2025-12-31T00:00:00.000-03:00");
        anuenciaOutputDTO.setDataCriacao("2021-02-24T14:18:02.000-03:00");
        anuenciaOutputDTO.setDataUltimaAtualizacao("2021-02-24T14:18:02.000-03:00");

        System.out.println(" ****** CENTRALIZADORA GET /api/opt/{codigoControleOptIn} FIM ******* ");

        return new ResponseEntity<>(anuenciaOutputDTO, HttpStatus.OK);
    }

    @GetMapping("/api/ec/{documentoEstabelecimentoComercial}")
    public ResponseEntity<List<EstabelecimentoComercialOutputDTO>> getEstabelecimentoComercialUsingGET(@PathVariable("documentoEstabelecimentoComercial") String documentoEstabelecimentoComercial) {
        return getEstabelecimentoComercialUsingGETComArranjo(documentoEstabelecimentoComercial, null);
    }

    @GetMapping("/api/ec/{documentoEstabelecimentoComercial}/{arranjoPagamento}")
    public ResponseEntity<List<EstabelecimentoComercialOutputDTO>> getEstabelecimentoComercialUsingGETComArranjo(@PathVariable("documentoEstabelecimentoComercial") String documentoEstabelecimentoComercial, @PathVariable("arranjoPagamento") String arranjoPagamento) {

        System.out.println("============ getEstabelecimentoComercialUsingGET INICIO ========== ");
        System.out.println("== " + documentoEstabelecimentoComercial + " == ");
        System.out.println("== " + arranjoPagamento + " == ");

        if ("99650366000173".equals(documentoEstabelecimentoComercial)) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        if (rebatedorParamSistDAO.buscarBooleanPorNmParamSist("BASE_CENTRALIZADA_GET_EC_RETORNAR_NOT_FOUND")) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        List<EstabelecimentoComercialOutputDTO> listaEC = new ArrayList<>();
        String[] arranjos = {"SCC","CBD","BCD","BCC","CAC","ECC","DCC","VCP","VDC","MCC","ACC","ECD","CBP","OCD","CZC","HCC","JCC","VID","VCC","BVV","MCP","GCC","SCD","VCD","VIC","VIA","CBC","MCD"};
        if (arranjoPagamento != null) {
            arranjos = new String[1];
            arranjos[0] = arranjoPagamento;
        }

        int numFilial = 1;
        String entidadeRegistradoraCnpj = rebatedorParamSistDAO.buscarStringPorNmParamSist("BASE_CENTRALIZADA_GET_EC_ENTIDADE_REGISTRADORA_CNPJ");
        for (String arranjo : arranjos) {
            EstabelecimentoComercialOutputDTO estabelecimento = new EstabelecimentoComercialOutputDTO();
            estabelecimento.setArranjoPagamentoId(arranjo);
            estabelecimento.setDataCriacao("2020-01-10T16:21:47.758-03:00");
            estabelecimento.setDataInicio("2020-01-01T16:21:47.758-03:00");
            estabelecimento.setDataFim("2030-01-10T16:21:47.758-03:00");
            estabelecimento.setDataUltimaAtualizacao("2020-01-10T16:21:47.758-03:00");
            if(documentoEstabelecimentoComercial.length() == 8) {
                documentoEstabelecimentoComercial = GeraCpfCnpj.cnpj(documentoEstabelecimentoComercial + String.format("%06d", numFilial++), false);
            }
            estabelecimento.setDocumentoEstabelecimentoComercial(documentoEstabelecimentoComercial);
            estabelecimento.setEntidadeRegistradoraCnpj(entidadeRegistradoraCnpj);
            estabelecimento.setStatus(EstabelecimentoComercialOutputDTO.StatusEnum.ATIVO);
            estabelecimento.setTipoDocumentoEstabelecimentoComercial(EstabelecimentoComercialOutputDTO.TipoDocumentoEstabelecimentoComercialEnum.CNPJ);
            listaEC.add(estabelecimento);
        }

        System.out.println(listaEC);

        System.out.println("============ getEstabelecimentoComercialUsingGET FIM ========== ");

        return new ResponseEntity<>(listaEC, HttpStatus.OK);
    }

    @PostMapping("/api/ec")
    public ResponseEntity<List<BaseOutputComRetornoDTOOfEstabelecimentoComercialOutputDTO>> insertEstabelecimentoComercialUsingPOST(@RequestBody List<EstabelecimentoComercialInputDTO> estabelecimentos) {
        System.out.println(" ****** CENTRALIZADORA POST /api/ec ******* ");

        List<BaseOutputComRetornoDTOOfEstabelecimentoComercialOutputDTO> rets = new ArrayList<>();

        for (EstabelecimentoComercialInputDTO dto : estabelecimentos) {
            BaseOutputComRetornoDTOOfEstabelecimentoComercialOutputDTO b = new BaseOutputComRetornoDTOOfEstabelecimentoComercialOutputDTO();
            RetornoDTO r = new RetornoDTO();
            r.setCodigo(HttpStatus.OK.value());
            r.setDescricao("SUCESSO");
            EstabelecimentoComercialOutputDTO e = new EstabelecimentoComercialOutputDTO();

            e.setTipoDocumentoEstabelecimentoComercial(EstabelecimentoComercialOutputDTO.
                    TipoDocumentoEstabelecimentoComercialEnum.fromValue(dto.getTipoDocumentoEstabelecimentoComercial().getValue()));
            e.setDocumentoEstabelecimentoComercial(dto.getDocumentoEstabelecimentoComercial());
            e.setArranjoPagamentoId(dto.getArranjoPagamentoId());
            e.setEntidadeRegistradoraCnpj(Constantes.CNPJ_R2C3_REGISTRADORA);
            e.setStatus(EstabelecimentoComercialOutputDTO.StatusEnum.ATIVO);
            e.setDataInicio(dto.getDataInicio());
            e.setDataFim(dto.getDataInicio());
            e.setDataCriacao(dto.getDataInicio());
            e.setDataUltimaAtualizacao(dto.getDataInicio());

            b.setRetorno(r);
            b.setItem(e);

            rets.add(b);

            System.out.println(dto.toString());
            System.out.println("EC :" + dto.getDocumentoEstabelecimentoComercial() + " incluido com sucesso!!!");
        }

        return new ResponseEntity<>(rets, HttpStatus.OK);
    }

    @PutMapping("/api/ec")
    public ResponseEntity<List<BaseOutputComRetornoDTOOfEstabelecimentoComercialOutputDTO>> updateEstabelecimentoComercialUsingPUT(@RequestBody List<EstabelecimentoComercialInputDTO> estabelecimentos) {
        System.out.println(" ****** CENTRALIZADORA PUT /api/ec ******* ");

        List<BaseOutputComRetornoDTOOfEstabelecimentoComercialOutputDTO> rets = new ArrayList<>();

        for (EstabelecimentoComercialInputDTO dto : estabelecimentos) {
            BaseOutputComRetornoDTOOfEstabelecimentoComercialOutputDTO b = new BaseOutputComRetornoDTOOfEstabelecimentoComercialOutputDTO();
            RetornoDTO r = new RetornoDTO();
            r.setCodigo(200);
            r.setDescricao("SUCESSO");
            EstabelecimentoComercialOutputDTO e = new EstabelecimentoComercialOutputDTO();

            e.setTipoDocumentoEstabelecimentoComercial(EstabelecimentoComercialOutputDTO.
                    TipoDocumentoEstabelecimentoComercialEnum.fromValue(dto.getTipoDocumentoEstabelecimentoComercial().getValue()));
            e.setDocumentoEstabelecimentoComercial(dto.getDocumentoEstabelecimentoComercial());
            e.setArranjoPagamentoId(dto.getArranjoPagamentoId());
            e.setEntidadeRegistradoraCnpj(Constantes.CNPJ_R2C3_REGISTRADORA);
            e.setStatus(EstabelecimentoComercialOutputDTO.StatusEnum.ATIVO);
            e.setDataInicio(dto.getDataInicio());
            e.setDataFim(dto.getDataInicio());
            e.setDataCriacao(dto.getDataInicio());
            e.setDataUltimaAtualizacao(dto.getDataInicio());


            b.setRetorno(r);
            b.setItem(e);

            rets.add(b);

            System.out.println(dto.toString());
            System.out.println("EC :" + dto.getDocumentoEstabelecimentoComercial() + " atualizado com sucesso!!!");
        }

        return new ResponseEntity<>(rets, HttpStatus.OK);
    }

    @PostMapping("/retornos-registro-operacao")
    public ResponseEntity<GenericResponse> postContratoRegistro(HttpServletRequest httpServletRequest, HttpServletResponse response) {
        return new ResponseEntity<>(HttpStatus.ACCEPTED);
    }

    @PostMapping("/api/credor")
    public ResponseEntity<List<BaseOutputComRetornoDTOOfCredorOutputDTO>> insertCredorUsingPOST(String acceptEncoding, String contentEncoding, @RequestBody(required = false) List<CredorInputDTO> credores) {
        System.out.println(" ****** CENTRALIZADORA POST /api/credor ******* ");

        List<BaseOutputComRetornoDTOOfCredorOutputDTO> dtos = new ArrayList<>();
        for (CredorInputDTO credor : credores) {
            BaseOutputComRetornoDTOOfCredorOutputDTO dto = new BaseOutputComRetornoDTOOfCredorOutputDTO();
            RetornoDTO retornoDTO = new RetornoDTO();
            retornoDTO.setCodigo(HttpStatus.OK.value());
            retornoDTO.setDescricao("SUCESSO");
            dto.setRetorno(retornoDTO);

            CredorOutputDTO credorOutputDTO = new CredorOutputDTO();
            credorOutputDTO.setTipoDocumentoCredor(CredorOutputDTO.TipoDocumentoCredorEnum.fromValue(credor.getTipoDocumentoCredor().getValue()));
            credorOutputDTO.setDocumentoCredor(credor.getDocumentoCredor());
            credorOutputDTO.setRazaoSocialCredor(credor.getRazaoSocialCredor());
            credorOutputDTO.setEntidadeRegistradoraCnpj(Constantes.CNPJ_R2C3_REGISTRADORA);
            credorOutputDTO.setStatus(CredorOutputDTO.StatusEnum.fromValue(credor.getStatus().getValue()));
            credorOutputDTO.setDataInicio(credor.getDataInicio());
            credorOutputDTO.setDataFim(credor.getDataFim());
            credorOutputDTO.setDataCriacao(conversor.format(new Date()));
            credorOutputDTO.setDataUltimaAtualizacao(conversor.format(new Date()));
            dto.setItem(credorOutputDTO);

            dtos.add(dto);
        }
        if (CollectionUtils.isNotEmpty(dtos)) {
            dtos.get(0).getRetorno().setCodigo(HttpStatus.BAD_REQUEST.value());
            dtos.get(0).getRetorno().setDescricao("Relacionamento Entidade Registradora x Credor já existente");
        }
        return new ResponseEntity<>(dtos, HttpStatus.MULTI_STATUS);
    }

    @PutMapping("/api/credor")
    public ResponseEntity<List<BaseOutputComRetornoDTOOfCredorOutputDTO>> updateCredorUsingPUT(String acceptEncoding, String contentEncoding, @RequestBody(required = false) List<CredorInputDTO> credores) {
        System.out.println(" ****** CENTRALIZADORA PUT /api/credor ******* ");
        SimpleDateFormat conversor = new SimpleDateFormat(FORMATO_DATA_HORA_T);

        List<BaseOutputComRetornoDTOOfCredorOutputDTO> dtos = new ArrayList<>();
        for (CredorInputDTO credor : credores) {
            BaseOutputComRetornoDTOOfCredorOutputDTO dto = new BaseOutputComRetornoDTOOfCredorOutputDTO();
            RetornoDTO retornoDTO = new RetornoDTO();
            retornoDTO.setCodigo(HttpStatus.OK.value());
            retornoDTO.setDescricao("SUCESSO");
            dto.setRetorno(retornoDTO);

            CredorOutputDTO credorOutputDTO = new CredorOutputDTO();
            credorOutputDTO.setTipoDocumentoCredor(CredorOutputDTO.TipoDocumentoCredorEnum.fromValue(credor.getTipoDocumentoCredor().getValue()));
            credorOutputDTO.setDocumentoCredor(credor.getDocumentoCredor());
            credorOutputDTO.setRazaoSocialCredor(credor.getRazaoSocialCredor());
            credorOutputDTO.setEntidadeRegistradoraCnpj(Constantes.CNPJ_R2C3_REGISTRADORA);
            credorOutputDTO.setStatus(CredorOutputDTO.StatusEnum.fromValue(credor.getStatus().getValue()));
            credorOutputDTO.setDataInicio(credor.getDataInicio());
            credorOutputDTO.setDataFim(credor.getDataFim());
            credorOutputDTO.setDataCriacao(conversor.format(new Date()));
            credorOutputDTO.setDataUltimaAtualizacao(conversor.format(new Date()));
            dto.setItem(credorOutputDTO);

            dtos.add(dto);
        }
        if (CollectionUtils.isNotEmpty(dtos)) {
            dtos.get(0).getRetorno().setCodigo(HttpStatus.BAD_REQUEST.value());
            dtos.get(0).getRetorno().setDescricao("Relacionamento Entidade Registradora x Credor não encontrado");
        }
        return new ResponseEntity<>(dtos, HttpStatus.MULTI_STATUS);
    }

    @GetMapping("/api/credor/query")
    public ResponseEntity<BaseOutputComPaginacaoDTOOfCredorOutputDTO> queryCredorUsingGET(
        @RequestParam(required = false) String cnpjRegistradora, @RequestParam(required = false) String dataCriacao,
        @RequestParam(required = false) String dataFim, @RequestParam(required = false) String dataInicio,
        @RequestParam(required = false) String dataUltimaAtualizacao, @RequestParam(required = false) String documentoCredor,
        @RequestParam(required = false) Integer pagina, @RequestParam(required = false) String razaoSocialCredor,
        @RequestParam(required = false) String status, @RequestParam(required = false) Integer tamanhoPagina) {

        System.out.println(" ****** CENTRALIZADORA GET /api/credor/query ******* ");
        System.out.println(" ====================================================== ");
        System.out.println(" dataUltimaAtualizacao -> " + dataUltimaAtualizacao);
        System.out.println(" ====================================================== ");

        BaseOutputComPaginacaoDTOOfCredorOutputDTO rets = new BaseOutputComPaginacaoDTOOfCredorOutputDTO();

        CredorOutputDTO item = new CredorOutputDTO();
        item.setTipoDocumentoCredor(CredorOutputDTO.TipoDocumentoCredorEnum.CNPJ);
        item.setDocumentoCredor("60746948000112");
        item.setRazaoSocialCredor("Banco Bradesco S.A.");
        item.setEntidadeRegistradoraCnpj(Constantes.CNPJ_R2C3_REGISTRADORA);
        item.setStatus(CredorOutputDTO.StatusEnum.INATIVO);
        item.setDataInicio("2020-12-22T00:00:00.000Z");
        item.setDataFim(null);
        item.setDataCriacao("2020-12-09T01:55:04.058Z");
        item.setDataUltimaAtualizacao("2020-12-09T01:55:04.058Z");
        rets.addItensItem(item);

        item = new CredorOutputDTO();
        item.setTipoDocumentoCredor(CredorOutputDTO.TipoDocumentoCredorEnum.CNPJ);
        item.setDocumentoCredor("30306294000145");
        item.setRazaoSocialCredor("BANCO BTG PACTUAL S.A.");
        item.setEntidadeRegistradoraCnpj("23399607000191");
        item.setStatus(CredorOutputDTO.StatusEnum.INATIVO);
        item.setDataInicio("2021-02-05T21:27:33.074Z");
        item.setDataFim(null);
        item.setDataCriacao("2020-10-29T14:48:58.625Z");
        item.setDataUltimaAtualizacao(conversor.format(new Date()));
        rets.addItensItem(item);

        item = new CredorOutputDTO();
        item.setTipoDocumentoCredor(CredorOutputDTO.TipoDocumentoCredorEnum.CNPJ);
        item.setDocumentoCredor("40626407000143");
        item.setRazaoSocialCredor("Banco DAYCOVAL - BANCO DO BANCO DA DAYCOVAL BANCO BANCO - Banco DAYCOVAL - BANCO DO BANCO DA DAYCOVAL BANCO BANCO");
        item.setEntidadeRegistradoraCnpj("23399607000191");
        item.setStatus(CredorOutputDTO.StatusEnum.ATIVO);
        item.setDataInicio("2021-02-05T17:24:43.450Z");
        item.setDataFim(null);
        item.setDataCriacao("2021-02-08T16:13:56.668Z");
        item.setDataUltimaAtualizacao("2021-02-08T16:13:56.668Z");
        rets.addItensItem(item);

        PaginacaoDTO paginacaoDTO = new PaginacaoDTO();
        paginacaoDTO.setPagina(1);
        paginacaoDTO.setTamanhoPagina(500);
        paginacaoDTO.setTotalPaginas(1);
        paginacaoDTO.setTotalItens(3L);
        rets.setPaginacao(paginacaoDTO);

        return new ResponseEntity<>(rets, HttpStatus.OK);
    }

    @PostMapping("/api/ic")
    public ResponseEntity<List<BaseOutputComRetornoDTOOfInstituicaoCredenciadoraOutputDTO>> insertInstituicaoCredenciadoraUsingPOST(String acceptEncoding, String contentEncoding, @RequestBody(required = false) List<InstituicaoCredenciadoraInputDTO> credenciadoras) {
        System.out.println(" ****** CENTRALIZADORA POST /api/ic ******* ");

        List<BaseOutputComRetornoDTOOfInstituicaoCredenciadoraOutputDTO> dtos = new ArrayList<>();
        for (InstituicaoCredenciadoraInputDTO credor : credenciadoras) {
            BaseOutputComRetornoDTOOfInstituicaoCredenciadoraOutputDTO dto = new BaseOutputComRetornoDTOOfInstituicaoCredenciadoraOutputDTO();
            RetornoDTO retornoDTO = new RetornoDTO();
            retornoDTO.setCodigo(HttpStatus.OK.value());
            retornoDTO.setDescricao("SUCESSO");
            dto.setRetorno(retornoDTO);

            InstituicaoCredenciadoraOutputDTO credorOutputDTO = new InstituicaoCredenciadoraOutputDTO();
            credorOutputDTO.setCnpjCredenciadora(credor.getCnpjCredenciadora());
            credorOutputDTO.setRazaoSocialCredenciadora(credor.getRazaoSocialCredenciadora());
            credorOutputDTO.setEntidadeRegistradoraCnpj(Constantes.CNPJ_R2C3_REGISTRADORA);
            credorOutputDTO.setStatus(InstituicaoCredenciadoraOutputDTO.StatusEnum.fromValue(credor.getStatus().getValue()));
            credorOutputDTO.setDataInicio(credor.getDataInicio());
            credorOutputDTO.setDataFim(credor.getDataFim());
            credorOutputDTO.setDataCriacao(conversor.format(new Date()));
            credorOutputDTO.setDataUltimaAtualizacao(conversor.format(new Date()));
            dto.setItem(credorOutputDTO);

            dtos.add(dto);
        }
        if (CollectionUtils.isNotEmpty(dtos)) {
            dtos.get(0).getRetorno().setCodigo(HttpStatus.BAD_REQUEST.value());
            dtos.get(0).getRetorno().setDescricao("Relacionamento Entidade Registradora x Instituição Credenciadora já existente");
        }
        return new ResponseEntity<>(dtos, HttpStatus.MULTI_STATUS);
    }

    @PutMapping("/api/ic")
    public ResponseEntity<List<BaseOutputComRetornoDTOOfInstituicaoCredenciadoraOutputDTO>> updateInstituicaoCredenciadoraUsingPUT(String acceptEncoding, String contentEncoding, @RequestBody(required = false) List<InstituicaoCredenciadoraInputDTO> credenciadoras) {
        System.out.println(" ****** CENTRALIZADORA PUT /api/ic ******* ");
        SimpleDateFormat conversor = new SimpleDateFormat(FORMATO_DATA_HORA_T);

        List<BaseOutputComRetornoDTOOfInstituicaoCredenciadoraOutputDTO> dtos = new ArrayList<>();
        for (InstituicaoCredenciadoraInputDTO credor : credenciadoras) {
            BaseOutputComRetornoDTOOfInstituicaoCredenciadoraOutputDTO dto = new BaseOutputComRetornoDTOOfInstituicaoCredenciadoraOutputDTO();
            RetornoDTO retornoDTO = new RetornoDTO();
            retornoDTO.setCodigo(HttpStatus.OK.value());
            retornoDTO.setDescricao("SUCESSO");
            dto.setRetorno(retornoDTO);

            InstituicaoCredenciadoraOutputDTO credorOutputDTO = new InstituicaoCredenciadoraOutputDTO();
            credorOutputDTO.setCnpjCredenciadora(credor.getCnpjCredenciadora());
            credorOutputDTO.setRazaoSocialCredenciadora(credor.getRazaoSocialCredenciadora());
            credorOutputDTO.setEntidadeRegistradoraCnpj(Constantes.CNPJ_R2C3_REGISTRADORA);
            credorOutputDTO.setStatus(InstituicaoCredenciadoraOutputDTO.StatusEnum.fromValue(credor.getStatus().getValue()));
            credorOutputDTO.setDataInicio(credor.getDataInicio());
            credorOutputDTO.setDataFim(credor.getDataFim());
            credorOutputDTO.setDataCriacao(conversor.format(new Date()));
            credorOutputDTO.setDataUltimaAtualizacao(conversor.format(new Date()));
            dto.setItem(credorOutputDTO);

            dtos.add(dto);
        }
        if (CollectionUtils.isNotEmpty(dtos)) {
            dtos.get(0).getRetorno().setCodigo(HttpStatus.BAD_REQUEST.value());
            dtos.get(0).getRetorno().setDescricao("Relacionamento Entidade Registradora x Instituição Credenciadora não encontrado");
        }
        return new ResponseEntity<>(dtos, HttpStatus.MULTI_STATUS);
    }

    @GetMapping("/api/ic/query")
    public ResponseEntity<BaseOutputComPaginacaoDTOOfInstituicaoCredenciadoraOutputDTO> queryInstituicaoCredenciadoraUsingGET(
            @RequestParam(required = false) String cnpjCredenciadora, @RequestParam(required = false) String cnpjRegistradora,
            @RequestParam(required = false) String dataCriacao, @RequestParam(required = false) String dataFim,
            @RequestParam(required = false) String dataInicio, @RequestParam(required = false) String dataUltimaAtualizacao,
            @RequestParam(required = false) Integer pagina, @RequestParam(required = false) String razaoSocialCredenciadora,
            @RequestParam(required = false) String status, @RequestParam(required = false) Integer tamanhoPagina) {

        System.out.println(" ****** CENTRALIZADORA GET /api/ic/query ******* ");
        System.out.println(" ====================================================== ");
        System.out.println(" dataUltimaAtualizacao -> " + dataUltimaAtualizacao);
        System.out.println(" ====================================================== ");

        BaseOutputComPaginacaoDTOOfInstituicaoCredenciadoraOutputDTO rets = new BaseOutputComPaginacaoDTOOfInstituicaoCredenciadoraOutputDTO();

        InstituicaoCredenciadoraOutputDTO item = new InstituicaoCredenciadoraOutputDTO();
        item.setCnpjCredenciadora("01027058000191");
        item.setRazaoSocialCredenciadora("CIELO");
        item.setEntidadeRegistradoraCnpj(Constantes.CNPJ_R2C3_REGISTRADORA);
        item.setStatus(InstituicaoCredenciadoraOutputDTO.StatusEnum.INATIVO);
        item.setDataInicio("2020-10-25T00:00:00.000Z");
        item.setDataFim(null);
        item.setDataCriacao("2020-12-10T00:43:24.722Z");
        item.setDataUltimaAtualizacao("2020-12-10T00:43:24.722Z");
        rets.addItensItem(item);

        item = new InstituicaoCredenciadoraOutputDTO();
        item.setCnpjCredenciadora("16814330000150");
        item.setRazaoSocialCredenciadora("BERLIN");
        item.setEntidadeRegistradoraCnpj("23399607000191");
        item.setStatus(InstituicaoCredenciadoraOutputDTO.StatusEnum.INATIVO);
        item.setDataInicio("2021-01-21T00:00:00.000Z");
        item.setDataFim(null);
        item.setDataCriacao("2021-01-09T22:22:47.245Z");
        item.setDataUltimaAtualizacao("2021-01-09T22:22:47.245Z");
        rets.addItensItem(item);

        item = new InstituicaoCredenciadoraOutputDTO();
        item.setCnpjCredenciadora("25238191000155");
        item.setRazaoSocialCredenciadora("BELLUNO MEIOS DE PAGAMENTO E SOLUCOES EM TECNOLOGIA LTDA.");
        item.setEntidadeRegistradoraCnpj("31345107000103");
        item.setStatus(InstituicaoCredenciadoraOutputDTO.StatusEnum.ATIVO);
        item.setDataInicio("2020-12-01T12:15:42.438Z");
        item.setDataFim(null);
        item.setDataCriacao("2020-12-19T19:21:44.991Z");
        item.setDataUltimaAtualizacao("2020-12-19T19:21:44.991Z");
        rets.addItensItem(item);

        PaginacaoDTO paginacaoDTO = new PaginacaoDTO();
        paginacaoDTO.setPagina(1);
        paginacaoDTO.setTamanhoPagina(500);
        paginacaoDTO.setTotalPaginas(1);
        paginacaoDTO.setTotalItens(3L);
        rets.setPaginacao(paginacaoDTO);

        return new ResponseEntity<>(rets, HttpStatus.OK);
    }

    @GetMapping("/api/er/setup")
    public ResponseEntity<List<MapaServicoOutputDTO>> consultarMapaServicosUsingGET() {
    	Map<String, String> mapTipoServicoPath = new HashMap<>();
        mapTipoServicoPath.put("AUTENTICACAO", "/oauth/token");
        mapTipoServicoPath.put("ENVIO_AGENDA_BATCH", "/api/v1/agenda");
        mapTipoServicoPath.put("INFORME_CONTESTACAO", "/api/v1/contestacao");
        mapTipoServicoPath.put("NOTIFICACAO_ANUENCIA", "/api/v1/notificacao/anuencia");
        mapTipoServicoPath.put("NOTIFICACAO_EVENTO_POS_CONTRATADA", "/api/v1/notificacao/pos_contratada");
        mapTipoServicoPath.put("NOTIFICACAO_EVENTO_RECEBIVEL", "/api/v1/notificacao/anuencia");
        mapTipoServicoPath.put("REJEICAO_AGENDA", "/api/v1/agenda/rejeitar/{idagenda}");
        mapTipoServicoPath.put("RESPOSTA_CANCELAMENTO_CONTRATO", "/api/v1/contrato/cancelamento/resposta");
        mapTipoServicoPath.put("RESPOSTA_EFEITO_CONTRATO", "/api/v1/contrato");
        mapTipoServicoPath.put("RESPOSTA_POSICAO_AGENDA_ONLINE", "/api/v1/agenda/posicao");
        mapTipoServicoPath.put("SOLICITACAO_AGENDA_ONLINE", "/api/v1/agenda/online");
        mapTipoServicoPath.put("SOLICITACAO_CANCELAMENTO_CONTRATO", "/api/v1/contrato/cancelamento");
        mapTipoServicoPath.put("SOLICITACAO_EFEITO_CONTRATO", "/api/v1/contrato");
        mapTipoServicoPath.put("SOLICITACAO_REENVIO_AGENDA", "/api/v1/NAO_TEM");

        Map<String, String>  mapCnpjsHosts = new HashMap<>();
        mapCnpjsHosts.put("04391007000132", "https://apiimfhext.cipr2c3.org.br");
        mapCnpjsHosts.put("23399607000191", "http://10.238.0.26");
        mapCnpjsHosts.put("31345107000103", "https://interop.nonprod.taginfraestrutura.com.br");
        mapCnpjsHosts.put("84184243000117", "http://localhost:8080");

    	String data = "2020-10-22T22:03:35";

    	List<MapaServicoOutputDTO> res = new ArrayList<MapaServicoOutputDTO>();

    	mapCnpjsHosts.forEach((cnpj, host) -> {
    		mapTipoServicoPath.forEach((tipoServico, path) -> {
    			MapaServicoOutputDTO item = new MapaServicoOutputDTO();
    			item.setTipoServicoId(tipoServico);
    			item.setUrlServico(host + path);
    			item.setEntidadeRegistradoraCnpj(cnpj);
    			item.setStatus(StatusEnum.ATIVO);
    			item.setDataInicio(data);
    			item.setDataCriacao(data);
    			item.setDataUltimaAtualizacao(data);

    			res.add(item);
    		});
    	});

    	return new ResponseEntity<>(res, HttpStatus.OK);
    }

    @GetMapping("/api/ec-ic/query")
    public ResponseEntity<BaseOutputComPaginacaoDTOOfEstabelecimentoComercialCredenciadoraOutputDTO> queryEcIcUsingGET(
            @RequestParam(required = false) String cnpjCredenciadora, @RequestParam(required = false) String cnpjRegistradora,
            @RequestParam(required = false) String dataCriacao, @RequestParam(required = false) String dataFim,
            @RequestParam(required = false) String dataInicio, @RequestParam(required = false) String dataUltimaAtualizacao,
            @RequestParam(required = false) String documentoUsuarioFinalRecebedorOuTitular,
            @RequestParam(required = false) Integer pagina, @RequestParam(required = false) String status,
            @RequestParam(required = false) Integer tamanhoPagina) {

        System.out.println(" ****** CENTRALIZADORA GET /api/ec-ic/query ******* ");
        System.out.println(" ====================================================== ");
        System.out.println(" dataUltimaAtualizacao -> " + dataUltimaAtualizacao);
        System.out.println(" ====================================================== ");

        BaseOutputComPaginacaoDTOOfEstabelecimentoComercialCredenciadoraOutputDTO rets = new BaseOutputComPaginacaoDTOOfEstabelecimentoComercialCredenciadoraOutputDTO();

        EstabelecimentoComercialCredenciadoraOutputDTO item = new EstabelecimentoComercialCredenciadoraOutputDTO();
        item.setCnpjCredenciadora("01027058000191");
        item.setEntidadeRegistradoraCnpj(Constantes.CNPJ_R2C3_REGISTRADORA);
        item.setDocumentoEstabelecimentoComercial("04278209000171");
        item.setStatus(EstabelecimentoComercialCredenciadoraOutputDTO.StatusEnum.ATIVO);
        item.setDataInicio("2020-10-25T00:00:00.000Z");
        item.setDataFim(null);
        item.setDataCriacao("2020-12-10T00:43:24.722Z");
        item.setDataUltimaAtualizacao("2020-12-10T00:43:24.722Z");
        rets.addItensItem(item);

        item = new EstabelecimentoComercialCredenciadoraOutputDTO();
        item.setCnpjCredenciadora("16814330000150");
        item.setEntidadeRegistradoraCnpj("23399607000191");
        item.setDocumentoEstabelecimentoComercial("04278209000173");
        item.setStatus(EstabelecimentoComercialCredenciadoraOutputDTO.StatusEnum.ATIVO);
        item.setDataInicio("2021-01-21T00:00:00.000Z");
        item.setDataFim(null);
        item.setDataCriacao("2021-01-09T22:22:47.245Z");
        item.setDataUltimaAtualizacao("2021-01-09T22:22:47.245Z");
        rets.addItensItem(item);

        item = new EstabelecimentoComercialCredenciadoraOutputDTO();
        item.setCnpjCredenciadora("25238191000155");
        item.setEntidadeRegistradoraCnpj("31345107000103");
        item.setDocumentoEstabelecimentoComercial("04278209000174");
        item.setStatus(EstabelecimentoComercialCredenciadoraOutputDTO.StatusEnum.ATIVO);
        item.setDataInicio("2020-12-01T12:15:42.438Z");
        item.setDataFim(null);
        item.setDataCriacao("2020-12-19T19:21:44.991Z");
        item.setDataUltimaAtualizacao("2020-12-19T19:21:44.991Z");
        rets.addItensItem(item);

        PaginacaoDTO paginacaoDTO = new PaginacaoDTO();
        paginacaoDTO.setPagina(1);
        paginacaoDTO.setTamanhoPagina(500);
        paginacaoDTO.setTotalPaginas(1);
        paginacaoDTO.setTotalItens(3L);
        rets.setPaginacao(paginacaoDTO);

        return new ResponseEntity<>(rets, HttpStatus.OK);
    }

    @PostMapping("/api/ec-ic")
    public ResponseEntity<List<BaseOutputComRetornoDTOOfEstabelecimentoComercialCredenciadoraOutputDTO>> saveNewUsingPOST(String acceptEncoding, String contentEncoding,
            @RequestBody(required = false) List<RegistradoraEstabelecimentoComercialCredenciadoraDTO> ecCreddr) {
        System.out.println(" ****** CENTRALIZADORA POST /api/ec-ic ******* ");

        List<BaseOutputComRetornoDTOOfEstabelecimentoComercialCredenciadoraOutputDTO> dtos = new ArrayList<>();
        for (RegistradoraEstabelecimentoComercialCredenciadoraDTO credor : ecCreddr) {
            BaseOutputComRetornoDTOOfEstabelecimentoComercialCredenciadoraOutputDTO dto = new BaseOutputComRetornoDTOOfEstabelecimentoComercialCredenciadoraOutputDTO();
            RetornoDTO retornoDTO = new RetornoDTO();
            retornoDTO.setCodigo(HttpStatus.OK.value());
            retornoDTO.setDescricao("SUCESSO");
            dto.setRetorno(retornoDTO);

            EstabelecimentoComercialCredenciadoraOutputDTO creddrEcOutputDTO = new EstabelecimentoComercialCredenciadoraOutputDTO();
            creddrEcOutputDTO.setDocumentoEstabelecimentoComercial(credor.getDocumentoEstabelecimentoComercial());
            creddrEcOutputDTO.setCnpjCredenciadora(credor.getCnpjCredenciadora());
            creddrEcOutputDTO.setEntidadeRegistradoraCnpj(Constantes.CNPJ_R2C3_REGISTRADORA);
            creddrEcOutputDTO.setStatus(EstabelecimentoComercialCredenciadoraOutputDTO.StatusEnum.fromValue(credor.getStatus().getValue()));
            creddrEcOutputDTO.setDataInicio(credor.getDataInicio());
            creddrEcOutputDTO.setDataFim(credor.getDataFim());
            creddrEcOutputDTO.setDataCriacao(conversor.format(new Date()));
            creddrEcOutputDTO.setDataUltimaAtualizacao(conversor.format(new Date()));
            dto.setItem(creddrEcOutputDTO);

            dtos.add(dto);
        }
        if (CollectionUtils.isNotEmpty(dtos)) {
            dtos.get(0).getRetorno().setCodigo(HttpStatus.BAD_REQUEST.value());
            dtos.get(0).getRetorno().setDescricao("Relacionamento Entidade Estabelecimento x Credenciador já existente");
        }
        return new ResponseEntity<>(dtos, HttpStatus.MULTI_STATUS);
    }

    @PostMapping("/api/ic/arranjo")
    public ResponseEntity<List<BaseOutputComRetornoDTOOfInstituicaoCredenciadoraArranjoPagamentoOutputDTO>> inserirRelacaoICArranjoUsingPOST(String acceptEncoding, String contentEncoding,
            @RequestBody(required = false) List<InstituicaoCredenciadoraArranjoPagamentoInputDTO> creddrArrj) {
        System.out.println(" ****** CENTRALIZADORA POST /api/ic/arranjo ******* ");

        List<BaseOutputComRetornoDTOOfInstituicaoCredenciadoraArranjoPagamentoOutputDTO> dtos = new ArrayList<>();
        for (InstituicaoCredenciadoraArranjoPagamentoInputDTO crddArr : creddrArrj) {
            BaseOutputComRetornoDTOOfInstituicaoCredenciadoraArranjoPagamentoOutputDTO dto = new BaseOutputComRetornoDTOOfInstituicaoCredenciadoraArranjoPagamentoOutputDTO();
            RetornoDTO retornoDTO = new RetornoDTO();
            retornoDTO.setCodigo(HttpStatus.OK.value());
            retornoDTO.setDescricao("SUCESSO");
            dto.setRetorno(retornoDTO);

            InstituicaoCredenciadoraArranjoPagamentoOutputDTO creddrArrjOutputDTO = new InstituicaoCredenciadoraArranjoPagamentoOutputDTO();
            creddrArrjOutputDTO.setArranjoPagamentoId(crddArr.getArranjoPagamentoId());
            creddrArrjOutputDTO.setCnpjCredenciadora(crddArr.getCnpjCredenciadora());
            creddrArrjOutputDTO.setEntidadeRegistradoraCnpj(Constantes.CNPJ_R2C3_REGISTRADORA);
            creddrArrjOutputDTO.setStatus(InstituicaoCredenciadoraArranjoPagamentoOutputDTO.StatusEnum.fromValue(crddArr.getStatus().getValue()));
            creddrArrjOutputDTO.setDataInicio(crddArr.getDataInicio());
            creddrArrjOutputDTO.setDataFim(crddArr.getDataFim());
            creddrArrjOutputDTO.setDataCriacao(conversor.format(new Date()));
            creddrArrjOutputDTO.setDataUltimaAtualizacao(conversor.format(new Date()));
            dto.setItem(creddrArrjOutputDTO);

            dtos.add(dto);
        }
        if (CollectionUtils.isNotEmpty(dtos)) {
            dtos.get(0).getRetorno().setCodigo(HttpStatus.BAD_REQUEST.value());
            dtos.get(0).getRetorno().setDescricao("Relacionamento Entidade Credenciador x Arranjo já existente");
        }
        return new ResponseEntity<>(dtos, HttpStatus.MULTI_STATUS);
    }

    @PutMapping("/api/ec-ic")
    public ResponseEntity<List<BaseOutputComRetornoDTOOfEstabelecimentoComercialCredenciadoraOutputDTO>> updateUsingPUT(String acceptEncoding, String contentEncoding,
            @RequestBody(required = false) List<RegistradoraEstabelecimentoComercialCredenciadoraDTO> ecCreddr) {
        System.out.println(" ****** CENTRALIZADORA POST /api/ec-ic ******* ");

        List<BaseOutputComRetornoDTOOfEstabelecimentoComercialCredenciadoraOutputDTO> dtos = new ArrayList<>();
        for (RegistradoraEstabelecimentoComercialCredenciadoraDTO credor : ecCreddr) {
            BaseOutputComRetornoDTOOfEstabelecimentoComercialCredenciadoraOutputDTO dto = new BaseOutputComRetornoDTOOfEstabelecimentoComercialCredenciadoraOutputDTO();
            RetornoDTO retornoDTO = new RetornoDTO();
            retornoDTO.setCodigo(HttpStatus.OK.value());
            retornoDTO.setDescricao("SUCESSO");
            dto.setRetorno(retornoDTO);

            EstabelecimentoComercialCredenciadoraOutputDTO creddrEcOutputDTO = new EstabelecimentoComercialCredenciadoraOutputDTO();
            creddrEcOutputDTO.setDocumentoEstabelecimentoComercial(credor.getDocumentoEstabelecimentoComercial());
            creddrEcOutputDTO.setCnpjCredenciadora(credor.getCnpjCredenciadora());
            creddrEcOutputDTO.setEntidadeRegistradoraCnpj(Constantes.CNPJ_R2C3_REGISTRADORA);
            creddrEcOutputDTO.setStatus(EstabelecimentoComercialCredenciadoraOutputDTO.StatusEnum.fromValue(credor.getStatus().getValue()));
            creddrEcOutputDTO.setDataInicio(credor.getDataInicio());
            creddrEcOutputDTO.setDataFim(credor.getDataFim());
            creddrEcOutputDTO.setDataCriacao(conversor.format(new Date()));
            creddrEcOutputDTO.setDataUltimaAtualizacao(conversor.format(new Date()));
            dto.setItem(creddrEcOutputDTO);

            dtos.add(dto);
        }
        return new ResponseEntity<>(dtos, HttpStatus.OK);
    }

    @PutMapping("/api/ic/arranjo")
    public ResponseEntity<List<BaseOutputComRetornoDTOOfInstituicaoCredenciadoraArranjoPagamentoOutputDTO>> alterarRelacaoICArranjoUsingPUT(
            String acceptEncoding, String contentEncoding,
            @RequestBody(required = false) List<InstituicaoCredenciadoraArranjoPagamentoInputDTO> creddrArrj) {
        System.out.println(" ****** CENTRALIZADORA POST /api/ic/arranjo ******* ");

        List<BaseOutputComRetornoDTOOfInstituicaoCredenciadoraArranjoPagamentoOutputDTO> dtos = new ArrayList<>();
        for (InstituicaoCredenciadoraArranjoPagamentoInputDTO crddArr : creddrArrj) {
            BaseOutputComRetornoDTOOfInstituicaoCredenciadoraArranjoPagamentoOutputDTO dto = new BaseOutputComRetornoDTOOfInstituicaoCredenciadoraArranjoPagamentoOutputDTO();
            RetornoDTO retornoDTO = new RetornoDTO();
            retornoDTO.setCodigo(HttpStatus.OK.value());
            retornoDTO.setDescricao("SUCESSO");
            dto.setRetorno(retornoDTO);

            InstituicaoCredenciadoraArranjoPagamentoOutputDTO creddrArrjOutputDTO = new InstituicaoCredenciadoraArranjoPagamentoOutputDTO();
            creddrArrjOutputDTO.setArranjoPagamentoId(crddArr.getArranjoPagamentoId());
            creddrArrjOutputDTO.setCnpjCredenciadora(crddArr.getCnpjCredenciadora());
            creddrArrjOutputDTO.setEntidadeRegistradoraCnpj(Constantes.CNPJ_R2C3_REGISTRADORA);
            creddrArrjOutputDTO.setStatus(InstituicaoCredenciadoraArranjoPagamentoOutputDTO.StatusEnum.fromValue(crddArr.getStatus().getValue()));
            creddrArrjOutputDTO.setDataInicio(crddArr.getDataInicio());
            creddrArrjOutputDTO.setDataFim(crddArr.getDataFim());
            creddrArrjOutputDTO.setDataCriacao(conversor.format(new Date()));
            creddrArrjOutputDTO.setDataUltimaAtualizacao(conversor.format(new Date()));
            dto.setItem(creddrArrjOutputDTO);

            dtos.add(dto);
        }
        return new ResponseEntity<>(dtos, HttpStatus.OK);
    }

    @GetMapping("/api/ic/arranjo/query")
    public ResponseEntity<BaseOutputComPaginacaoDTOOfInstituicaoCredenciadoraArranjoPagamentoOutputDTO> queryCredenciadoraArranjoDePagamentoUsingGET(
            @RequestParam(required = false) String cnpjCredenciadora, @RequestParam(required = false) String cnpjRegistradora,
            @RequestParam(required = false) String dataCriacao, @RequestParam(required = false) String dataFim,
            @RequestParam(required = false) String dataInicio, @RequestParam(required = false) String dataUltimaAtualizacao,
            @RequestParam(required = false) Integer pagina, @RequestParam(required = false) String status,
            @RequestParam(required = false) Integer tamanhoPagina) {

        System.out.println(" ****** CENTRALIZADORA GET /api/ec-ic/query ******* ");
        System.out.println(" ====================================================== ");
        System.out.println(" dataUltimaAtualizacao -> " + dataUltimaAtualizacao);
        System.out.println(" ====================================================== ");

        BaseOutputComPaginacaoDTOOfInstituicaoCredenciadoraArranjoPagamentoOutputDTO rets = new BaseOutputComPaginacaoDTOOfInstituicaoCredenciadoraArranjoPagamentoOutputDTO();

        InstituicaoCredenciadoraArranjoPagamentoOutputDTO item = new InstituicaoCredenciadoraArranjoPagamentoOutputDTO();
        item.setCnpjCredenciadora("01027058000191");
        item.setEntidadeRegistradoraCnpj(Constantes.CNPJ_R2C3_REGISTRADORA);
        item.setArranjoPagamentoId("VCC");
        item.setStatus(InstituicaoCredenciadoraArranjoPagamentoOutputDTO.StatusEnum.ATIVO);
        item.setDataInicio("2020-10-25T00:00:00.000Z");
        item.setDataFim(null);
        item.setDataCriacao("2020-12-10T00:43:24.722Z");
        item.setDataUltimaAtualizacao("2020-12-10T00:43:24.722Z");
        rets.addItensItem(item);

        item = new InstituicaoCredenciadoraArranjoPagamentoOutputDTO();
        item.setCnpjCredenciadora("16814330000150");
        item.setEntidadeRegistradoraCnpj("23399607000191");
        item.setArranjoPagamentoId("MCC");
        item.setStatus(InstituicaoCredenciadoraArranjoPagamentoOutputDTO.StatusEnum.ATIVO);
        item.setDataInicio("2021-01-21T00:00:00.000Z");
        item.setDataFim(null);
        item.setDataCriacao("2021-01-09T22:22:47.245Z");
        item.setDataUltimaAtualizacao("2021-01-09T22:22:47.245Z");
        rets.addItensItem(item);

        item = new InstituicaoCredenciadoraArranjoPagamentoOutputDTO();
        item.setCnpjCredenciadora("25238191000155");
        item.setEntidadeRegistradoraCnpj("31345107000103");
        item.setArranjoPagamentoId("ECC");
        item.setStatus(InstituicaoCredenciadoraArranjoPagamentoOutputDTO.StatusEnum.ATIVO);
        item.setDataInicio("2020-12-01T12:15:42.438Z");
        item.setDataFim(null);
        item.setDataCriacao("2020-12-19T19:21:44.991Z");
        item.setDataUltimaAtualizacao("2020-12-19T19:21:44.991Z");
        rets.addItensItem(item);

        PaginacaoDTO paginacaoDTO = new PaginacaoDTO();
        paginacaoDTO.setPagina(1);
        paginacaoDTO.setTamanhoPagina(500);
        paginacaoDTO.setTotalPaginas(1);
        paginacaoDTO.setTotalItens(3L);
        rets.setPaginacao(paginacaoDTO);

        return new ResponseEntity<>(rets, HttpStatus.OK);
    }

    private static <T> List<T> getPaginacao(List<T> fonte, int numeroPagina, int tamanhoPagina ){
        Integer tamanhoTotalLista = fonte.size();
        if(tamanhoPagina <= 0 || numeroPagina <= 0){
            return fonte;
        }
        int indicePagina = (numeroPagina-1) * tamanhoPagina;
        if(fonte == null || tamanhoTotalLista < indicePagina){
            return Collections.emptyList();
        }
        return fonte.subList(indicePagina, Math.min(indicePagina+tamanhoPagina,tamanhoTotalLista ));
    }
}