package br.org.cipbancos.atlante.tester.components.r2c3.dao.rowmapper;

import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import br.org.cipbancos.atlante.tester.components.r2c3.vo.FracaoVO;

public class FracaoVORowMapper {

    public static RowMapper<FracaoVO> popular() {
        return (rs, rowNum) -> mapRow(rs);
    }

    public static FracaoVO mapRow(ResultSet rs) throws SQLException {
        FracaoVO vo = new FracaoVO();
        vo.setIdFracao(new BigInteger(rs.getString("ID_FRACAO_UNIDD_RECBV_OP")));
        vo.setDtPrevistaLiquidacao(rs.getTimestamp("DT_PREVT_LIQUID").toLocalDateTime().toLocalDate());
        vo.setIdUnidadeRecebivel(rs.getLong("ID_UNIDD_RECBV"));
        vo.setIdPartCred(rs.getInt("ID_PART_CREDDR"));
        vo.setNrCnpjCredr(rs.getString("NR_CNPJ_CREDDR"));
        vo.setArranjo(rs.getString("CD_ARRJ_PGTO"));
        vo.setNrCpfCnpjUsuarioFinalRecebedor(rs.getString("NR_CPF_CNPJ_USURIO_FINL_RECBDR"));
        vo.setNrCpfCnpjTitular(rs.getString("NR_CPF_CNPJ_TITLAR"));
        vo.setVlrLivre(rs.getBigDecimal("NR_VLR_PREVT_LIQUID"));
        return vo;
    }


}