package br.org.cipbancos.atlante.tester.components.r2c3.negocio;

import br.org.cip.api.r2c3.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import br.org.cipbancos.atlante.tester.components.r2c3.client.RestClientCallBack;
import br.org.cipbancos.atlante.tester.components.r2c3.dao.RebatedorParamSistDAO;
import br.org.cipbancos.atlante.tester.components.tl.ThreadLocalData;

import java.util.List;

/**
 * Aqui fica o processamento comum para o envio das respostas das solicitações
 */
@Component
public class CallBackNegocio {

    private final String BASE_URL = "http://localhost:8080";
    private static final Logger LOG = LoggerFactory.getLogger(CallBackNegocio.class);

    @Autowired
    private RebatedorParamSistDAO rebatedorParamSistDAO;

    @Autowired
    private RestClientCallBack<ContratoPatch, GenericResponseContrato> contratoPatchClient;

    @Autowired
    private RestClientCallBack<CancelamentoResposta, GenericResponse> contratoCancelamentoPostClient;

    @Autowired
    private RestClientCallBack<AgendaPosicao, GenericResponse> agendaPosicaoPostClient;

    public void patchContratoAsync(ContratoPatch contratoPatch, HttpHeaders requestHeaders) {
        Integer ispbDest = ThreadLocalData.getPartyId();
        new Thread(() -> {
            try {
                ThreadLocalData.setPartyId(ispbDest);
                LOG.info("THREAD: "+Thread.currentThread().getName());
                LOG.info("############## AGUARDANDO {} SEGUNDOS PARA MANDAR O RETORNO ##################", this.getTimeOut());
                Thread.sleep(this.getTimeOut());
                LOG.info("############## DISPARANDO O CALLBACK ##################");
                GenericResponseContrato response = contratoPatchClient.doPatch(this.BASE_URL +"/api/v1/contrato",
                        contratoPatch,
                        requestHeaders,
                        GenericResponseContrato.class);
            }
            catch (InterruptedException e) {
                Thread.currentThread().interrupt();

            }
        }).start();
    }

    public void postContratoCancelamentoRespostaAsync(CancelamentoResposta cancelamento, HttpHeaders requestHeaders) {
        Integer ispbDest = ThreadLocalData.getPartyId();
        new Thread(() -> {
            try {
                ThreadLocalData.setPartyId(ispbDest);
                LOG.info("THREAD: "+Thread.currentThread().getName());
                LOG.info("############## AGUARDANDO {} SEGUNDOS PARA MANDAR O RETORNO ##################", this.getTimeOut());
                Thread.sleep(this.getTimeOut());
                LOG.info("############## DISPARANDO O CALLBACK ##################");
                GenericResponse response = contratoCancelamentoPostClient.doPost(this.BASE_URL +"/api/v1/contrato/cancelamento/resposta",
                        cancelamento,
                        requestHeaders,
                        GenericResponse.class);
                LOG.info("Resposta recebida: "+ response.toString());
            }
            catch (InterruptedException e) {
                Thread.currentThread().interrupt();

            }
        }).start();
    }

    public void postAgendaPosicaoAsync(List<AgendaPosicao> agendasPosicao, HttpHeaders requestHeaders) {
        Integer ispbDest = ThreadLocalData.getPartyId();
        String gerarAgendaArranjoComTimeout = rebatedorParamSistDAO.buscarStringPorNmParamSist("GERAR_AGENDA_ARRANJO_COM_TIMEOUT");
        new Thread(() -> {
            for (AgendaPosicao agendaPosicao : agendasPosicao) {
                try {
                    ThreadLocalData.setPartyId(ispbDest);
                    LOG.info("THREAD: " + Thread.currentThread().getName());
                    LOG.info("############## AGUARDANDO {} SEGUNDOS PARA MANDAR O RETORNO ##################", this.getTimeOut());
                    Thread.sleep(this.getTimeOut());
                    if (!gerarAgendaArranjoComTimeout.trim().equals("")) {
                        boolean encontrouArranjo = false;
                        for (Recebivel recebivel : agendaPosicao.getRecebiveis()) {
                            if (recebivel.getArranjo().equals(gerarAgendaArranjoComTimeout)) {
                                encontrouArranjo = true;
                            }
                        }
                        if (encontrouArranjo) {
                            Thread.sleep(60000);
                        }
                    }
                    LOG.info("############## DISPARANDO O CALLBACK ##################");
                    GenericResponse response = agendaPosicaoPostClient.doPost(this.BASE_URL +"/api/v1/agenda/posicao",
                            agendaPosicao,
                            requestHeaders,
                            GenericResponse.class);
                    LOG.info("Resposta recebida: "+ response.toString());
                }
                catch (InterruptedException e) {
                    Thread.currentThread().interrupt();

                }
            }
        }).start();
    }

    public Integer getTimeOut() {
        return rebatedorParamSistDAO.buscarIntPorNmParamSist("DELAY_RESPONSE");
    }
}
