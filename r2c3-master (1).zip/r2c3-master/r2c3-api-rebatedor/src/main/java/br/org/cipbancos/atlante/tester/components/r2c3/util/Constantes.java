package br.org.cipbancos.atlante.tester.components.r2c3.util;

import java.util.Map;

public class Constantes {

    public static final String CNPJ_R2C3 = "29011780000157";
    public static final String CNPJ_R2C3_REGISTRADORA = "04391007000132";
    public static final Integer ISPB_R2C3 = Integer.valueOf(CNPJ_R2C3.substring(0, 8));
    public static final Integer ISPB_R2C3_REGISTRADORA = Integer.valueOf(CNPJ_R2C3_REGISTRADORA.substring(0, 8));

    public static final int LIMITE_BATCH_UPDATE = 3500;
    public static final String MES01 = "MES01";
    public static final String X_CIP_CORRELATION_LOGICAL_ID = "X-CIP-Correlation-Logical-Id";
    public static final String X_CIP_DEST_PART_ID = "X-CIP-Dest-Party-Id";
    public static final String X_CIP_DEST_PARTY_ADMIN_ID = "X-CIP-Dest-Party-Admin-Id";
    public static final String ATLANTE_LOGICAL_ID = "atlante.logicalid";
    public static final String IDENTD_PART_PRINCIPAL = "IdentdPartPrincipal";
    public static final String IDENTD_PART_ADMTD = "IdentdPartAdmtd";
    public static final String ID_SOLICITACAO = "ID_SOLICITACAO";
    public static final String CONTRATO = "CONTRATO";
    public static final String STEP = "STEP";

    // HTTP HEADERS
    public static final String HEADER_ID_CONTROLE_REQUISICAO = "idControleRequisicao";
    public static final String HEADER_ID_CONTROLE_RECEPCAO = "idControleRecepcao";
    public static final String HEADER_ID_CONTROLE_RESPOSTA = "idControleResposta";
    public static final String HEADER_ID_CONTROLE_CONFIRMACAO = "idControleConfirmacao";
    public static final String HEADER_ID_BATCH = "idbatch";

    public static final String UUID_PATTERN = "\\b[0-9a-f]{8}\\b-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-\\b[0-9a-f]{12}\\b";

    public static Map<String,String> mapCredenciadoras;
}
