package br.org.cipbancos.atlante.tester.components.r2c3.util;

import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.io.Serializable;
import java.util.Arrays;

public class HeaderRequest implements Serializable {

    protected MultiValueMap<String, String> headers;

    private String idControleRequisicao;

    public HeaderRequest(String idControleRequisicao) {
        this.idControleRequisicao = idControleRequisicao;
        this.headers = new LinkedMultiValueMap<>();
        this.headers.put(Constantes.HEADER_ID_CONTROLE_REQUISICAO, Arrays.asList(this.idControleRequisicao));
    }

    public String getIdControleRequisicao() {
        return idControleRequisicao;
    }

    public MultiValueMap<String, String> getHttpHeaders(){
       return this.headers;
    }
}
