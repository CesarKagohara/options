package br.org.cipbancos.atlante.tester.components.r2c3.negocio;

import br.org.cip.api.r2c3.model.*;
import br.org.cipbancos.atlante.tester.components.r2c3.config.filter.RebatedorFilter;
import br.org.cipbancos.atlante.tester.components.r2c3.dao.DominioArranjoDAO;
import br.org.cipbancos.atlante.tester.components.r2c3.dao.FracaoDAO;
import br.org.cipbancos.atlante.tester.components.r2c3.dao.RebatedorParamSistDAO;
import br.org.cipbancos.atlante.tester.components.r2c3.util.HashUtil;
import br.org.cipbancos.atlante.tester.components.r2c3.vo.FracaoVO;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.UUID;

@Component
public class ContratoNegocio {

    @Autowired
    @Qualifier("namedTemplateAtlante")
    NamedParameterJdbcTemplate namedTemplate;

    @Autowired
    RebatedorFilter rebatedorFilter;

    @Autowired
    DominioArranjoDAO dominioArranjoDAO;

    @Autowired
    FracaoDAO fracaoDao;

    @Autowired
    RebatedorParamSistDAO rebatedorParamSistDAO;

    public ContratoPatch createContratoPatch(Contrato contrato) {
        ContratoPatch contratoPatch = new ContratoPatch();

        DadosControleContrato dadosControle = new DadosControleContrato();
        dadosControle.setDataCriacao(LocalDate.of(2020, 1, 10));
        dadosControle.setDataReferencia(LocalDate.of(2020, 1, 10));
        dadosControle.setIdEfeitoContrato(UUID.randomUUID().toString());
        dadosControle.setIdEfeitoContratosRenegociados(new ArrayList<>());

        contratoPatch.dadosControle(dadosControle);
        contratoPatch.idContratoExterno(contrato.getDadosControle().getIdEfeitoContrato());
        contratoPatch.setIndicadorStatus(1);
        if(rebatedorParamSistDAO.buscarBooleanPorNmParamSist("BUSCAR_FRACOES_BANCO")) {

            contratoPatch.setGrupoEfeitos(montarGrupoEfeitosPeloBanco(contrato.getGrupoEfeitos(), contrato.getRegraDivisao()));
        } else {
            contratoPatch.setGrupoEfeitos(contrato.getGrupoEfeitos());
            for (GrupoEfeito grupoEfeito : contratoPatch.getGrupoEfeitos()) {
                for (RecebivelAbrangido recebivelAbrangido : grupoEfeito.getRecebiveisAbrangidos()) {
                    if (recebivelAbrangido.getIndicadorOrdemEfeito() == null) {
                        BigDecimal fatorValor = new BigDecimal(
                                rebatedorParamSistDAO.buscarStringPorNmParamSist("FATOR_VALOR_FRACOES_INTP008"));
                        recebivelAbrangido.setValorComprometido(recebivelAbrangido
                                .getValorComprometido().multiply(fatorValor).setScale(2, BigDecimal.ROUND_HALF_EVEN));
                        recebivelAbrangido.setIndicadorOrdemEfeito(new BigDecimal(new Random().nextInt(10)));
                    }
                }
            }
        }

        return contratoPatch;
    }

    public ContratoPatch createContratoPatchPerf(Contrato contrato) {
        ContratoPatch contratoPatch = new ContratoPatch();
        contratoPatch.dadosControle(new DadosControleContrato().dataCriacao(LocalDate.of(2020, 10, 1))
                .dataReferencia(LocalDate.of(2020, 10, 1))
                .idEfeitoContrato(contrato.getIdContratoExterno()).idEfeitoContratosRenegociados(new ArrayList<>())
                .addIdEfeitoContratosRenegociadosItem(UUID.randomUUID().toString()));

        contratoPatch.idContratoExterno(contrato.getDadosControle().getIdEfeitoContrato())
                .setIndicadorStatus(1);
        contratoPatch.grupoEfeitos(contrato.getGrupoEfeitos());

        contratoPatch.getGrupoEfeitos().forEach(t -> {
            for (RecebivelAbrangido recebiveisAbrangido : t.getRecebiveisAbrangidos()) {
                recebiveisAbrangido.setIndicadorOrdemEfeito(new BigDecimal(1L));
            }
        });

        return contratoPatch;
    }

    public Contrato createContratoPost(AgendaPosicao agendaPosicao) {
        Contrato contrato = new Contrato();

        contrato.dadosControle(new DadosControleContrato().dataCriacao(LocalDate.of(2020, 10, 1))
                .dataReferencia(LocalDate.of(2020, 10, 1))
                .idEfeitoContrato(contrato.getIdContratoExterno()).idEfeitoContratosRenegociados(new ArrayList<>())
                .addIdEfeitoContratosRenegociadosItem(UUID.randomUUID().toString()));

        contrato.setTipoEfeito(Contrato.TipoEfeitoEnum.GARANTIA);
        contrato.setTipoOnus(Contrato.TipoOnusEnum.CESSAOFIDUCIARIA);
        contrato.setTipoOperacao(Contrato.TipoOperacaoEnum.CRIACAO);
        contrato.setDataVencimentoEfeito(LocalDate.of(2025, 10, 1));
        contrato.setSaldoDevedorOuLimite(new BigDecimal(1L));
        contrato.setValorASerMantido(new BigDecimal(1L));
        contrato.setRegraDivisao(Contrato.RegraDivisaoEnum.VALORFIXO);
        contrato.setRegraReparticao(Contrato.RegraReparticaoEnum.INDIVIDUAL);
        contrato.setIdContratoExterno(UUID.randomUUID().toString());
        contrato.setCpfCnpjCredor("000000000000161");

        List<GrupoEfeito> grupoEfeitoList = new ArrayList<>();

        agendaPosicao.getRecebiveis().forEach(recebivel -> {
            GrupoEfeito ge = new GrupoEfeito();
            List<RecebivelAbrangido> recebivelAbrangidoList = new ArrayList<>();

            ge.setArranjo(recebivel.getArranjo());
            ge.setCnpjCredenciadora(recebivel.getCnpjCredenciadora());
            ge.setCpfCnpjOriginador(recebivel.getCpfCnpjOriginador());
            ge.setCpfCnpjTitular(recebivel.getCpfCnpjOriginador());
            recebivel.getDatas().forEach(t -> {
                RecebivelAbrangido recebivelAbrangido = new RecebivelAbrangido();
                recebivelAbrangido.setValorComprometido(new BigDecimal(1L));
                recebivelAbrangido.setIndicadorOrdemEfeito(new BigDecimal(t.getLiquidacoes().get(0).getIndicadorOrdemEfeito()).plus());
                recebivelAbrangido.setDataPrevistaLiquidacao(t.getDataPrevistaLiquidacao());
                Domicilio domicilio = t.getLiquidacoes().get(0).getDomicilios().get(0);
                DomicilioRecebivel domicilioRecebivel = new DomicilioRecebivel();
                domicilioRecebivel.setAgencia(domicilio.getAgencia());
                domicilioRecebivel.setConta(domicilio.getConta());
                domicilioRecebivel.setDigitoConta(domicilio.getDigitoConta());
                domicilioRecebivel.setDocumentoTitularConta(domicilio.getDocumentoTitularConta());
                domicilioRecebivel.setIspb(domicilio.getIspb());
                domicilioRecebivel.setTipoConta(DomicilioRecebivel.TipoContaEnum.fromValue(domicilio.getTipoConta().getValue()));
                domicilioRecebivel.setTipoDocumento(DomicilioRecebivel.TipoDocumentoEnum.fromValue(domicilio.getTipoDocumento().getValue()));
                ge.setDomicilio(domicilioRecebivel);
                recebivelAbrangidoList.add(recebivelAbrangido);
            });

            ge.setRecebiveisAbrangidos(recebivelAbrangidoList);
            grupoEfeitoList.add(ge);
        });
        contrato.setGrupoEfeitos(grupoEfeitoList);

        return contrato;
    }


    public CancelamentoResposta createCancelamentoResposta(Cancelamento cancelamentoRequest) {
        CancelamentoResposta cancelamento = new CancelamentoResposta();
        cancelamento.setDataCriacao(LocalDate.now());
        cancelamento.setDataReferencia(LocalDate.parse("2020-01-01", DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        cancelamento.setIdBatch(rebatedorFilter.getIdControleRequisicao());
        cancelamento.setIdEfeitoContrato(UUID.randomUUID().toString());
        return cancelamento;
    }

    public List<GrupoEfeito> montarGrupoEfeitosPeloBanco(List<GrupoEfeito> grupoEfeitosPost, Contrato.RegraDivisaoEnum regraDivisao) {
        List<GrupoEfeito> grupoEfeitosPatch = new ArrayList<>();
        List<FracaoVO> fracoesConsumidas = new ArrayList<>();
        for (GrupoEfeito grupoEfeito : grupoEfeitosPost) {
            GrupoEfeito grupoEfeitoPatch = new GrupoEfeito();
            BeanUtils.copyProperties(grupoEfeito,grupoEfeitoPatch);
            grupoEfeitoPatch.setRecebiveisAbrangidos(new ArrayList<>());
            FracaoVO fracaoVO = null;
            for (RecebivelAbrangido recebivel : grupoEfeito.getRecebiveisAbrangidos()) {
                RecebivelAbrangido recebivelAbrangido = new RecebivelAbrangido();
                BeanUtils.copyProperties(recebivel,recebivelAbrangido);

                recebivelAbrangido.setIndicadorOrdemEfeito(new BigDecimal(new Random().nextInt(10) + 1));
                Date dtPrevistaLiquidacaoInterop = Date.from(
                        recebivel.getDataPrevistaLiquidacao().atStartOfDay(ZoneId.systemDefault()).toInstant());
                Long idUr = HashUtil.generateHashCode(grupoEfeito.getCpfCnpjOriginador(),
                        dominioArranjoDAO.getArranjoFromInterop(grupoEfeito.getArranjo()),
                        dtPrevistaLiquidacaoInterop);
                String cnpjCredr = grupoEfeito.getCnpjCredenciadora();
                fracaoVO = fracaoDao.buscarFracao(cnpjCredr, idUr, grupoEfeito.getCpfCnpjTitular());

                if(fracaoVO == null) {
                    if(regraDivisao.equals(Contrato.RegraDivisaoEnum.PORCENTAGEM)) {
                        recebivelAbrangido.setValorComprometido(new BigDecimal(100));
                    } else {
                        recebivelAbrangido.setValorComprometido(BigDecimal.ZERO);
                    }
                }
                else if (!fracoesConsumidas.contains(fracaoVO)) {
                    fracoesConsumidas.add(fracaoVO);
                    if(fracaoVO.getVlrLivre().compareTo(recebivel.getValorComprometido()) < 0) {
                        recebivelAbrangido.setValorComprometido(fracaoVO.getVlrLivre());
                    }
                    BigDecimal fatorValor = new BigDecimal(
                            rebatedorParamSistDAO.buscarStringPorNmParamSist("FATOR_VALOR_FRACOES_INTP008"));

                    BigDecimal vlrRecebível = recebivelAbrangido
                            .getValorComprometido()
                            .multiply(fatorValor).setScale(2, BigDecimal.ROUND_HALF_EVEN);
                    recebivelAbrangido.setValorComprometido(vlrRecebível);
                    if(rebatedorParamSistDAO.buscarStringPorNmParamSist("FRACIONAR_RETORNO_INTP008").equals("S")) {
                        RecebivelAbrangido recebivelAbrangido2 = new RecebivelAbrangido();
                        BeanUtils.copyProperties(recebivel,recebivelAbrangido2);
                        recebivelAbrangido2.setValorComprometido(recebivelAbrangido.getValorComprometido().multiply(new BigDecimal("0.8")).setScale(2));
                        recebivelAbrangido2.setIndicadorOrdemEfeito(recebivelAbrangido.getIndicadorOrdemEfeito().add(BigDecimal.ONE).setScale(0));
                        grupoEfeitoPatch.getRecebiveisAbrangidos().add(recebivelAbrangido2);
                        recebivelAbrangido.setValorComprometido(recebivelAbrangido.getValorComprometido().multiply(new BigDecimal("0.2")).setScale(2));
                    } else {
                        recebivelAbrangido.setValorComprometido(recebivelAbrangido.getValorComprometido());
                    }


                }

                grupoEfeitoPatch.getRecebiveisAbrangidos().add(recebivelAbrangido);
            }
            grupoEfeitosPatch.add(grupoEfeitoPatch);
        }
        return grupoEfeitosPatch;
    }
}
