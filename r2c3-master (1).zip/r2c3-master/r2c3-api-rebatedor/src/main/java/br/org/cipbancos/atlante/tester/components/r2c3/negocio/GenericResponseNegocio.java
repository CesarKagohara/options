package br.org.cipbancos.atlante.tester.components.r2c3.negocio;

import br.org.cip.api.r2c3.model.*;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Component
public class GenericResponseNegocio {

    public GenericResponseContrato getContratoErroPostResponse(List<String> erros) {
        GenericResponseContrato response = new GenericResponseContrato();
        response.setErros(erros);
        return response;
    }

    public GenericResponseContrato getContratoPostResponse(Contrato contrato) {
        return new GenericResponseContrato();
    }

    public GenericResponseContrato getContratoCancelamentoResponse(Cancelamento cancelamento) {
        GenericResponseContrato genericResponseContrato = new GenericResponseContrato();
        String idEfeitoContrato = UUID.randomUUID().toString();
        genericResponseContrato.setDadosControle(new DadosControleContrato());
        genericResponseContrato.getDadosControle().setDataReferencia(LocalDate.parse("2020-01-01"));
        genericResponseContrato.getDadosControle().setIdEfeitoContrato(idEfeitoContrato);

        return genericResponseContrato;
    }

    public GenericResponseContrato getContratoPatchResponse(ContratoPatch contrato) {
        return new GenericResponseContrato();
    }
}
