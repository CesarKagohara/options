package br.org.cipbancos.atlante.tester.components.r2c3.config;

public class Constantes {
   public static final String ID_CONTROLE_REQ = "idControleRequisicao";
   public static final String ID_CONTROLE_RECEP = "idControleRecepcao";
   public static final String ID_CONTROLE_RESP = "idControleResposta";
   public static final String ID_CONTROLE_CONF = "idControleConfirmacao";

   private Constantes(){}
}
