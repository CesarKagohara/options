package br.org.cipbancos.atlante.tester.components.r2c3.config.filter;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import br.org.cipbancos.atlante.tester.components.r2c3.config.Constantes;

@Component
@Order(-1)
public class RebatedorFilter implements Filter {
    private static final Logger LOG = LoggerFactory.getLogger(RebatedorFilter.class);


    private String step;

    private String idControleRequisicao = null;
    private String idControleRecepcao = null;
    private String idControleResposta = null;
    private String idControleConfirmacao = null;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        LOG.info("##########################################");
        LOG.info("################FILTER####################");
        LOG.info("##########################################");
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest)request;
        this.idControleRequisicao = req.getHeader(Constantes.ID_CONTROLE_REQ);
        this.idControleRecepcao   = req.getHeader(Constantes.ID_CONTROLE_RECEP);
        this.idControleResposta   = req.getHeader(Constantes.ID_CONTROLE_RESP);
        /**
         * Se disponível, o id controle confirmacao estará na response
         */
        HttpServletResponse res = (HttpServletResponse) response;
        this.idControleConfirmacao = res.getHeader(Constantes.ID_CONTROLE_CONF);
        LOG.info("Requisicao de entrada: : {}", req.getRequestURI());
        LOG.info("Requisicao de entrada: : {}", req.getHeaderNames());


        if(this.idControleRequisicao != null && this.idControleRecepcao == null) {
            this.step = "STEP_1";
        }
        if(this.idControleResposta != null) {
            this.step = "STEP_2";
            res.addHeader(Constantes.ID_CONTROLE_CONF, UUID.randomUUID().toString());
        }

        LOG.info("HEADERS DE CONTROLE:");
        LOG.info(Constantes.ID_CONTROLE_REQ +":" + this.idControleRequisicao);
        LOG.info(Constantes.ID_CONTROLE_RECEP +":" + this.idControleRecepcao);
        LOG.info(Constantes.ID_CONTROLE_RESP +":" + this.idControleResposta);

        chain.doFilter(request, response);
        LOG.info("Committing a transaction for req : {}", req.getRequestURI());
    }

    @Override
    public void destroy() {

    }

    public String getIdControleRequisicao() {
        return idControleRequisicao;
    }

    public void setIdControleRequisicao(String idControleRequisicao) {
        this.idControleRequisicao = idControleRequisicao;
    }

    public String getIdControleRecepcao() {
        return idControleRecepcao;
    }

    public void setIdControleRecepcao(String idControleRecepcao) {
        this.idControleRecepcao = idControleRecepcao;
    }

    public String getIdControleResposta() {
        return idControleResposta;
    }

    public void setIdControleResposta(String idControleResposta) {
        this.idControleResposta = idControleResposta;
    }

    public String getStep() {
        return step;
    }

    public void setStep(String step) {
        this.step = step;
    }

    // other methods
}
