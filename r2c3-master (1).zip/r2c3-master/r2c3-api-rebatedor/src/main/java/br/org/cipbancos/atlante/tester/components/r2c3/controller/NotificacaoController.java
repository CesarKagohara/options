package br.org.cipbancos.atlante.tester.components.r2c3.controller;

import br.org.cip.api.r2c3.model.GenericResponseNotificacao;
import br.org.cip.api.r2c3.model.NotificacaoPosContratada;
import br.org.cip.api.r2c3.model.OneOfOptInOptOut;
import br.org.cip.api.r2c3.model.Penhora;

import br.org.cipbancos.atlante.tester.components.r2c3.util.Constantes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;

@RestController
@RequestMapping("/notificacao")
public class NotificacaoController {

    private static final Logger LOG = LoggerFactory.getLogger(NotificacaoController.class);

    @PostMapping("/anuencia")
    public ResponseEntity<GenericResponseNotificacao> postNotificacaoAnuencia(@RequestHeader(value="idControleRequisicao") String idControleRequisicao, String acceptEncoding, String contentEncoding, @RequestBody(required = false) OneOfOptInOptOut oneOfOptInOptOut) {
        LOG.info("Iniciando o recebimento do POST /notificacao/anuencia");
        GenericResponseNotificacao genericResponseNotificacao = new GenericResponseNotificacao();
        genericResponseNotificacao.setIdComunicacao(oneOfOptInOptOut.getIdComunicacao());

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.put(Constantes.HEADER_ID_CONTROLE_REQUISICAO, Arrays.asList(idControleRequisicao));

        return new ResponseEntity<>(genericResponseNotificacao, headers, HttpStatus.OK);
    }

    @PostMapping("/pos_contratada")
    public ResponseEntity<GenericResponseNotificacao> postPosContratada(@RequestHeader(value="idControleRequisicao") String idControleRequisicao, String acceptEncoding, String contentEncoding, @RequestBody(required = false) NotificacaoPosContratada notificacaoPosContratada) {
       GenericResponseNotificacao genericResponseNotificacao = new GenericResponseNotificacao();
       genericResponseNotificacao.setIdComunicacao(notificacaoPosContratada.getIdComunicacao());
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.put(Constantes.HEADER_ID_CONTROLE_REQUISICAO, Arrays.asList(idControleRequisicao));
        return new ResponseEntity<>(genericResponseNotificacao, headers, HttpStatus.OK);
    }

    @PostMapping("/penhora")
    public ResponseEntity<GenericResponseNotificacao> postPenhora(@RequestHeader(value="idControleRequisicao") String idControleRequisicao, String acceptEncoding, String contentEncoding, @RequestBody(required = false) Penhora notificacaoPenhora) {
        GenericResponseNotificacao genericResponseNotificacao = new GenericResponseNotificacao();
        genericResponseNotificacao.setIdComunicacao(notificacaoPenhora.getDadosControle().getIdComunicacao());
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.put(Constantes.HEADER_ID_CONTROLE_REQUISICAO, Arrays.asList(idControleRequisicao));
        return new ResponseEntity<>(genericResponseNotificacao, headers, HttpStatus.OK);
    }
}
