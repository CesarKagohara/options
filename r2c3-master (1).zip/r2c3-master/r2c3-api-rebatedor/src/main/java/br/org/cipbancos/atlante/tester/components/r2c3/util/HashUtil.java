package br.org.cipbancos.atlante.tester.components.r2c3.util;

import org.apache.commons.lang3.StringUtils;

import java.util.Date;

public final class HashUtil {

    public static long DATA_CONVENCAO_IN_MILLIS;

    protected static Date DATA_CONVENCAO;

    static {
        DATA_CONVENCAO_IN_MILLIS = DateUtil.parseData("2019-06-27", "yyyy-MM-dd").getTime();
        DATA_CONVENCAO = DateUtil.parseData("2019-06-27", "yyyy-MM-dd");
    }


    public static Long generateHashCode(String nrCpfCnpjUsurioFinlRecbdr, String cdArrjPgto, Date dtPrevtLiqui) {
        if (nrCpfCnpjUsurioFinlRecbdr.length() > 11) {
            nrCpfCnpjUsurioFinlRecbdr = nrCpfCnpjUsurioFinlRecbdr.substring(0, nrCpfCnpjUsurioFinlRecbdr.length() - 2);
        }

        int numDt = obterDiferencaEmDiasDataConvecaoVersusDataPrevistaLiquidacao(dtPrevtLiqui);
        return Long.parseLong(Integer.parseInt(cdArrjPgto) + StringUtils.rightPad(nrCpfCnpjUsurioFinlRecbdr, 12, '0') + String.format("%05d", numDt));
    }

    public static int obterDiferencaEmDiasDataConvecaoVersusDataPrevistaLiquidacao(Date dataPrevistaLiquidacao){
        return DateUtil.obterDiferencaDeDatasEmDias(DATA_CONVENCAO, dataPrevistaLiquidacao);
    }
}
