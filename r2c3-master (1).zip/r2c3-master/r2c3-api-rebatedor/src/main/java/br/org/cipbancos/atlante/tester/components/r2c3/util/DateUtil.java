package br.org.cipbancos.atlante.tester.components.r2c3.util;

import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.joda.time.Months;
import org.joda.time.Years;

/**
 * Classe utilitaria para trabalhar com data
 * 
 * @author rodrigo.almeida.ext
 */
public class DateUtil {

    public static final String FORMATO_DATA_HORA = "yyyy-MM-dd HH:mm:ss";
    public static final String FORMATO_DATA = "yyyy-MM-dd";
    public static final String FORMATO_DATA_SEM_SEPARADOR = "yyyyMMdd";
    public static final String FORMATO_MES_DIA_SEM_SEPARADOR = "MMdd";
    public static final String FORMATO_DEMANA_MES_MES_HR_ZONA_ANO = "E MMM dd HH:mm:ss Z yyyy";

    /**
     * Metodo de formatacao de um {Date} de acordo com o padrao informado
     * Ex.: dd/MM/YYYY - 10/05/2010 dd-MM-YYYY - 10-05-2010
     * 
     * @param dtRef
     * @param pattern
     * @return
     */
    public static String format(Date dtRef, String pattern) {
        SimpleDateFormat sdt = new SimpleDateFormat(pattern);
        return sdt.format(dtRef);
    }

    /**
     * Método para obter uma lista de datas que estão dentro do período entre a
     * dataInicio e a dataFim
     * 
     * @param dataInicio
     *            Data inicial do range
     * @param dataFim
     *            Data final
     * @return
     */
    public static List<Date> obterRangeDeDatas(Date dataInicio, Date dataFim) {
        List<Date> range = new ArrayList<Date>();

        if (dataInicio != null && dataFim != null) {
            if (dataInicio.compareTo(dataFim) <= 0) {

                Calendar dataCorrente = Calendar.getInstance();
                dataCorrente.setTime(dataInicio);
                dataCorrente.set(Calendar.HOUR_OF_DAY, 0);
                dataCorrente.set(Calendar.MINUTE, 0);
                dataCorrente.set(Calendar.SECOND, 0);

                while (dataCorrente.getTime().compareTo(dataFim) <= 0) {
                    range.add(dataCorrente.getTime());
                    dataCorrente.add(Calendar.DAY_OF_MONTH, 1);
                    dataCorrente.set(Calendar.HOUR_OF_DAY, 0);
                    dataCorrente.set(Calendar.MINUTE, 0);
                    dataCorrente.set(Calendar.SECOND, 0);
                }
            }
        }
        return range;
    }

    /**
     * Método para formatar uma data na representação dd/MM/yyyy
     * 
     * @param date
     * @return
     */
    public static String formatDate(Date date) {
        return new SimpleDateFormat("dd/MM/yyyy").format(date);
    }

    /**
     * Método para obter a data atual sem hora, minuto, segundo e milisegundo
     * Não Utilizar este método, obter a data atual do DataCorrenteNegocio.class
     * 
     * @return
     */
    @Deprecated
    public static Date obterDataAtualSemHora() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    public static Calendar obterCalendarSemHora(Date date) {
        Calendar dt = Calendar.getInstance();
        dt.setTime(date);
        dt.set(Calendar.HOUR_OF_DAY, 0);
        dt.set(Calendar.MINUTE, 0);
        dt.set(Calendar.SECOND, 0);
        dt.set(Calendar.MILLISECOND, 0);
        return dt;
    }

    public static Date adicionarDias(Date date, int qtdeDias) {
        Calendar dt = Calendar.getInstance();
        dt.setTime(date);
        dt.add(Calendar.DAY_OF_MONTH, qtdeDias);
        return dt.getTime();
    }

    public static Date removerDias(Date date, int qtdeDias) {
        Calendar dt = Calendar.getInstance();
        dt.setTime(date);
        dt.add(Calendar.DAY_OF_MONTH, -qtdeDias);
        return dt.getTime();
    }

    public static void zerarHora(Calendar data) {
        data.set(Calendar.HOUR_OF_DAY, 0);
        data.set(Calendar.MINUTE, 0);
        data.set(Calendar.SECOND, 0);
        data.set(Calendar.MILLISECOND, 0);
    }

    public static Date zerarHora(Date date) {
        Calendar data = Calendar.getInstance();
        data.setTime(date);
        zerarHora(data);
        return data.getTime();
    }
    /**
     * Método para incrementar dia na data atual sem hora, minuto, segundo e milisegundo
     * 
     * @return
     */
    public static Date incrementarDataAtualSemHora(int dias) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, +dias);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    /**
     * Contrói o objeto Date com a data atual, e hora informada por parâmetro
     * A hora deve ser informada no padrão HH:mm
     * 
     * @param hora
     * @param data
     * @return
     */
    public static Date construirDataComHoraEspecifica(String hora, Date data) {
        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(data);

        try {
            // Formato apenas com horas e minutos
            String format = "HH:mm";

            // Formato com horas, minutos e segundos
            if (StringUtils.length(hora) == 8) {
                format = "HH:mm:ss";
            }

            Date date = new SimpleDateFormat(format).parse(hora);
            Calendar cal1 = Calendar.getInstance();
            cal1.setTime(date);

            cal2.set(Calendar.HOUR_OF_DAY, cal1.get(Calendar.HOUR_OF_DAY));
            cal2.set(Calendar.MINUTE, cal1.get(Calendar.MINUTE));
            cal2.set(Calendar.SECOND, cal1.get(Calendar.SECOND));
        }
        catch (Exception ex) {
            throw new  IllegalArgumentException("Valor informado não é uma hora válida (HH:mm): " + hora);
        }

        return cal2.getTime();
    }

    /**
     * Constrói uma data data a data e hora
     * 
     * @param hora
     * @param data
     * @return
     */
    public static Date construirDataComHoraEspecifica(Date hora, Date data) {
        return construirDataComHoraEspecifica(new SimpleDateFormat("HH:mm").format(hora), data);
    }

    /**
     * Constrói uma data com a hora informada no argumento
     * 
     * @param date
     * @param time
     * @return
     */
    public static Date construirDataComHoraEspecifica(Date date, Time time) {
        return construirDataComHoraEspecifica(time.toString(), date);
    }

    /**
     * Retorna a quantidade de dias corridos entre as datas informadas
     * 
     * @param dataInicio
     * @param dataFim
     * @return Integer
     */
    public static Integer getNumDiasCorridos(LocalDate dataInicio, LocalDate dataFim) {
        return Days.daysBetween(dataInicio, dataFim).getDays();
    }

    /**
     * Retorna a quantidade de meses entre as datas informadas, considerando dias corridos
     * 
     * @param dataInicio
     * @param dataFim
     * @return Integer
     */
    public static Integer getNumMesesDiasCorridos(LocalDate dataInicio, LocalDate dataFim) {
        return Months.monthsBetween(dataInicio, dataFim).getMonths();
    }

    /**
     * Retorna a quantidade de anos entre as datas informadas, considerando dias corridos
     * 
     * @param dataInicio
     * @param dataFim
     * @return Integer
     */
    public static Integer getNumAnosDiasCorridos(LocalDate dataInicio, LocalDate dataFim) {
        return Years.yearsBetween(dataInicio, dataFim).getYears();
    }

    /**
     * Retorna data conforme formato passado.
     */
    public static String formataData(Date data, String formato) {
        SimpleDateFormat conversor = new SimpleDateFormat(formato);
        return conversor.format(data);
    }

    /**
     * Converte uma String no formato de data, para um LocalDate
     * 
     * @param data
     * @return
     */
    public static LocalDate parseLocalDate(String data) {
        return toLocalDate(parseData(data));
    }

    public static Date parseData(String data) {
        if (StringUtils.isBlank(data)) {
            return null;
        }
        try {
            return new SimpleDateFormat(FORMATO_DATA).parse(data);
        }
        catch (ParseException e) {
            throw new RuntimeException("Erro no parse da data", e);
        }
    }

    public static Date parseData(String data, Locale locale, String formatoData) {
        if (StringUtils.isBlank(data)) {
            return null;
        }
        try {
            return new SimpleDateFormat(formatoData, locale).parse(data);
        }
        catch (ParseException e) {
            throw new RuntimeException("Erro no parse da data", e);
        }
    }

    public static LocalDate toLocalDate(Date date) {
        if (date != null) {
            return LocalDate.fromDateFields(convertToUtilDate(date));
        }
        else {
            return null;
        }
    }

    public static LocalDateTime toLocalDateTime(Date date) {
        if (date != null) {
            return LocalDateTime.fromDateFields(convertToUtilDate(date));
        }
        else {
            return null;
        }
    }

    private static Date convertToUtilDate(Date date) {
        if (date instanceof java.sql.Date) {
            return new Date(date.getTime());
        }
        else {
            return date;
        }
    }

    /**
     * Formata um Date em uma String sem separador YYYYMMDD
     * 
     * @param date
     * @return
     */
    public static String formataDataSemSeparador(Date date) {
        return new SimpleDateFormat(FORMATO_DATA_SEM_SEPARADOR).format(date);
    }

    /**
     * Formata um Date em uma String sem separador YYYYMMDD
     * 
     * @param date
     * @return
     */
    public static String formataMesDiaSemSeparador(Date date) {
        return new SimpleDateFormat(FORMATO_MES_DIA_SEM_SEPARADOR).format(date);
    }

    /**
     * Método para obter a diferença em dias entre duas datas
     * 
     * @param dataInicial
     * @param dataFinal
     * @return
     */
    public static int obterDiferencaDeDatasEmDias(Date dataInicial, Date dataFinal) {
        return Days.daysBetween(new DateTime(dataInicial), new DateTime(dataFinal)).getDays();
    }

    /**
     * Método para verificar se dada a data, a mesma é um final de semana
     * 
     * @param date
     * @return
     */
    public static boolean ehFinalDeSemana(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
        return dayOfWeek == Calendar.SUNDAY || dayOfWeek == Calendar.SATURDAY;
    }

    public static Date parseData(String data, String pattern) {
        if (StringUtils.isBlank(data) || StringUtils.isBlank(pattern)) {
            return null;
        }
        try {
            return new SimpleDateFormat(pattern).parse(data);
        }
        catch (ParseException e) {
            throw new RuntimeException("Erro no parse da data", e);
        }
    }

    public static java.time.LocalDate locaDatefromDate(Date date ) {
        return java.time.Instant.ofEpochMilli(date.getTime())
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
    }

    public static java.time.LocalDate locaDatefromDate(java.sql.Date date ) {
        return java.time.Instant.ofEpochMilli(date.getTime())
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
    }

    public static java.time.LocalDateTime locaDateTimefromDate(Date date ) {
        return java.time.Instant.ofEpochMilli(date.getTime())
                .atZone(ZoneId.systemDefault())
                .toLocalDateTime();
    }

    public static java.time.LocalDateTime locaDateTimefromDate(java.sql.Date date ) {
        return java.time.Instant.ofEpochMilli(date.getTime())
                .atZone(ZoneId.systemDefault())
                .toLocalDateTime();
    }

    public static boolean sameDay(Date date1, Date date2) {
        if (date1 == date2) {
            return true;
        }
        if (date1 == null) {
            return false;
        }
        if (date2 == null) {
            return false;
        }
        return format(date1, "dd/MM/yyyy").equals(format(date2, "dd/MM/yyyy"));
    }


    public static Iterable<Date> range(Date dataInicio, Date dataFim) {
        final Date dInicioSemHora = zerarHora(dataInicio);
        return () -> Stream
                .iterate(dInicioSemHora, d -> adicionarDias(d, 1))
                .limit(obterDiferencaDeDatasEmDias(dInicioSemHora, dataFim) + 1l)
                .iterator();
    }

    public static java.time.LocalDate toJavaTimeLocalDate(Date date) {
        if (date != null) {
            return java.time.Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDate();
        }
        else {
            return null;
        }
    }

    public static java.time.LocalDateTime toJavaTimeLocalDateTime(Date date) {
        if (date != null) {
            return java.time.Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDateTime();
        }
        else {
            return null;
        }
    }

    public static String convertDateTime(Date data) {
        if(data != null){
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
            return sdf.format(Date.from(toJavaTimeLocalDateTime(data).atZone(ZoneId.systemDefault()).toInstant()));
        }

        return StringUtils.EMPTY;
    }

    public static Integer getNumDiasCorridos(Date inicio, Date fim) {
        return getNumDiasCorridos(toLocalDate(inicio), toLocalDate(fim));
    }

    public static boolean isDataDentroLimite30DiasAPartirDeReferencia(Date dtRef, Date dtConsulta) {
        Date dataLimite = DateUtil.adicionarDias(dtRef, 30);
        return dtConsulta.before(dataLimite);
    }

    public static boolean between(Date dt, Date dtIni, Date dtFim) {
        if (dt == null || dtIni == null || dtFim == null) {
            return false;
        }
        if (dt.after(dtFim)) {
            return false;
        }
        if (dt.before(dtIni)) {
            return false;
        }
        return true;
    }

    public static DateTime getCurrentDate() {
        return DateTime.now();
    }
}
