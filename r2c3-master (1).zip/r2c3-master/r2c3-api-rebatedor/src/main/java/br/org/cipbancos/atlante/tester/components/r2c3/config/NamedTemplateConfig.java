package br.org.cipbancos.atlante.tester.components.r2c3.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

@Configuration
public class NamedTemplateConfig {

    @Bean(name = "namedTemplateAtlante")
    @DependsOn("atlanteDataSource")
    public NamedParameterJdbcTemplate namedTemplate(
            @Qualifier("atlanteDataSource") DataSource abcDataSource ) {
        return new NamedParameterJdbcTemplate(abcDataSource);
    }

}
