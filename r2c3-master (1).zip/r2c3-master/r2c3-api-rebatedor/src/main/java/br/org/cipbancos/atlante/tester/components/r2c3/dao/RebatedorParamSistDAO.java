package br.org.cipbancos.atlante.tester.components.r2c3.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
public class RebatedorParamSistDAO {

    @Autowired
    @Qualifier("namedTemplateAtlante")
    NamedParameterJdbcTemplate namedTemplate;

    public String buscarStringPorNmParamSist(String nmParamSist) {
        String sql = "select ct_rebatedor_param_sist from rrc_own.rebatedor_param_sist where nm_rebatedor_param_sist = :nmParamSist";

        MapSqlParameterSource param = new MapSqlParameterSource("nmParamSist",nmParamSist);

        return namedTemplate.queryForObject(sql, param, String.class);
    }

    public int buscarIntPorNmParamSist(String nmParamSist) {
        return Integer.parseInt(buscarStringPorNmParamSist(nmParamSist));
    }

    public boolean buscarBooleanPorNmParamSist(String nmParamSist) {
        return Boolean.parseBoolean(buscarStringPorNmParamSist(nmParamSist));
    }

    public BigDecimal buscarBigDecimalPorNmParamSist(String nmParamSist) {
        return new BigDecimal(buscarStringPorNmParamSist(nmParamSist));
    }
}