package br.org.cipbancos.atlante.tester.components.r2c3.util;

import java.util.UUID;

public abstract class HeaderGeneratorID {

    public static String generate(){
        return UUID.randomUUID().toString();
    }

}
