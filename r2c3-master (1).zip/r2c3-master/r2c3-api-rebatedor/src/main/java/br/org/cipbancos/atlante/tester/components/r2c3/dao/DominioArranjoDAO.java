package br.org.cipbancos.atlante.tester.components.r2c3.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class DominioArranjoDAO {

    @Autowired
    @Qualifier("namedTemplateAtlante")
    NamedParameterJdbcTemplate namedTemplate;

    public String getArranjoFromInterop(String cdArranjoInterop) {
        String sql = "SELECT CD_ARRJ_PGTO FROM rrc_own.DOMN_ARRJ_PGTO "
                + " WHERE CD_DOMN_ARRJ_PGTO_INTRDD = :cdArranjoInterop AND IC_SIT = 'A'";

        return namedTemplate.queryForObject(sql,
                new MapSqlParameterSource("cdArranjoInterop", cdArranjoInterop), String.class);
    }


}
