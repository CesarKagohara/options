package br.org.cipbancos.atlante.tester.components.r2c3.client;

import br.org.cip.arche.commons.api.http.dispatcher.DispatcherHttp;
import br.org.cip.arche.commons.api.http.dispatcher.HttpCallBackHandler;
import br.org.cip.arche.commons.api.http.dispatcher.HttpRequest;
import br.org.cipbancos.atlante.tester.components.r2c3.config.filter.RebatedorFilter;
import br.org.cipbancos.atlante.tester.components.tl.ThreadLocalData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

@Service
public class RestClientCallBack<REQUEST, RESPONSE> {

    @Autowired
    DispatcherHttp dispatcherHttp;

    @Autowired
    RebatedorFilter rebatedorFilter;

    HttpHeaders headers = new HttpHeaders();

    public RestClientCallBack() {
        //headers padrões
        headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        ThreadLocalData.setUrlLogin("http://localhost:8080/oauth/token");
    }

//    private HttpHeaders buildHeaders() {
//        if(StringUtils.isNotBlank(rebatedorFilter.getIdControleRequisicao())){
//            addHeader(Constantes.ID_CONTROLE_REQ, rebatedorFilter.getIdControleRequisicao());
//        }
//        if(StringUtils.isNotBlank(rebatedorFilter.getIdControleRecepcao())){
//            addHeader(Constantes.ID_CONTROLE_RECEP, rebatedorFilter.getIdControleRecepcao());
//        }
//        if(StringUtils.isNotBlank(rebatedorFilter.getIdControleResposta())){
//            addHeader(Constantes.ID_CONTROLE_RESP, rebatedorFilter.getIdControleResposta());
//        }
//        return this.headers;
//
//    }
    public void addHeader(String key, String value) {
        if(!this.headers.containsKey(key)) {
            headers.add(key, value);
        }
    }

    public RESPONSE doPost(String url, REQUEST request, HttpHeaders requestHeaders, Class<RESPONSE> clazz) throws InterruptedException {
        return doRequest(url, request, clazz,  HttpMethod.POST, requestHeaders);
    }
    public RESPONSE doPatch(String url, REQUEST request, HttpHeaders requestHeaders, Class<RESPONSE> clazz) throws InterruptedException {
        return doRequest(url, request, clazz,  HttpMethod.PATCH, requestHeaders);
    }

    public RESPONSE doRequest(String url, REQUEST request, Class<RESPONSE> clazz, HttpMethod method, HttpHeaders requestHeaders) throws InterruptedException {

        CallBackHandler<RESPONSE> handler = new CallBackHandler<>();
        handler.setRequestHeaders(requestHeaders);
        HttpRequest<RESPONSE> httpRequest = new HttpRequest<RESPONSE>(
                method,
                url,
                request,
                requestHeaders,
                0,
                300000L,
                500L,
                (HttpCallBackHandler) handler);
        httpRequest.setContextUri("/api/v1");
        httpRequest.setWaitFinish(true);

        dispatcherHttp.call(httpRequest, clazz);
        int countWait = 0;
        while(!handler.finished() && countWait<10) {
            Thread.sleep(1000L);
            countWait++;
        }
        return handler.getResponse();
    }
}
