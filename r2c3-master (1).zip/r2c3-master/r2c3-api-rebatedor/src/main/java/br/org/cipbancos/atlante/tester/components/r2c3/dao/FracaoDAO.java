package br.org.cipbancos.atlante.tester.components.r2c3.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import br.org.cipbancos.atlante.tester.components.r2c3.dao.rowmapper.FracaoVORowMapper;
import br.org.cipbancos.atlante.tester.components.r2c3.vo.FracaoVO;

@Repository
public class FracaoDAO {

    @Autowired
    @Qualifier("namedTemplateAtlante")
    NamedParameterJdbcTemplate namedTemplate;

    public FracaoVO buscarFracao(String nrCpfCnpjCredr, Long idUnidadeRecebivel, String nrCpfCnpjTitular) {
        String sql = "select * from rrc_own.fracao_unidd_recbv_op_000 "
                + "where nr_cnpj_creddr = :nrCpfCnpjCredr "
                + "  and id_unidd_recbv = :idUnidadeRecebivel"
                + "  and (nr_cpf_cnpj_titlar = :nrCpfCnpjTitular"
                + "  or nr_cpf_cnpj_titlar_ant = :nrCpfCnpjTitular)"
                + "  and ic_sit = 'A'"
                + "  and id_op = 0 LIMIT 1";

        MapSqlParameterSource param = new MapSqlParameterSource();
        param.addValue("nrCpfCnpjCredr"    , nrCpfCnpjCredr);
        param.addValue("idUnidadeRecebivel", idUnidadeRecebivel);
        param.addValue("nrCpfCnpjTitular", nrCpfCnpjTitular);
        try {
            return namedTemplate.queryForObject(sql, param, FracaoVORowMapper.popular());
        } catch(EmptyResultDataAccessException ex) {
            return null;
        }
    }
}