package br.org.cipbancos.atlante.tester.components.r2c3.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class OperacaoDAO {

    @Autowired
    @Qualifier("namedTemplateAtlante")
    NamedParameterJdbcTemplate namedTemplate;

    public String buscarIdEfeitoContrato(String icTpNegc) {
        String sql = "select id_efet_contrto_intrdd from rrc_own.op where ic_tp_negc = :icTpNegc limit 1";

        MapSqlParameterSource param = new MapSqlParameterSource();
        param.addValue("icTpNegc" , icTpNegc);
        try {
            return namedTemplate.queryForObject(sql, param, String.class);
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }
}