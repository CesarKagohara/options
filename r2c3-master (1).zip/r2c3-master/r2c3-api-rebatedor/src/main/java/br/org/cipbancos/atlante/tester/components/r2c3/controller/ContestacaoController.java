package br.org.cipbancos.atlante.tester.components.r2c3.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.org.cipbancos.atlante.tester.components.r2c3.util.HeaderGeneratorID;
import br.org.cipbancos.atlante.tester.components.r2c3.util.HeaderReception;

import br.org.cip.api.r2c3.model.ContestacaoInterop;
import br.org.cip.api.r2c3.model.ContestacaoResponse;

@RestController
@RequestMapping("/contestacao")
public class ContestacaoController {

    private static final Logger LOG = LoggerFactory.getLogger(ContestacaoController.class);

    @PostMapping()
    public ResponseEntity<List<ContestacaoResponse>> postContestacao(@RequestHeader(value = "idControleRequisicao", required = true) String idControleRequisicao, String acceptEncoding, String contentEncoding, @RequestBody(required = false) List<ContestacaoInterop> contestacoes) {
        List<ContestacaoResponse> responseList = new ArrayList<>();
        for (ContestacaoInterop contestacao : contestacoes) {
            ContestacaoResponse contestacaoResponse = new ContestacaoResponse();
            contestacaoResponse.setIdContestacao(contestacao.getIdContestacao());
            contestacaoResponse.setCnpjRecebedora(contestacao.getCnpjRecebedora());
            contestacaoResponse.setCpfCnpj(contestacao.getCpfCnpjUsuarioFinalRecebedorOuTitular());
            contestacaoResponse.setCpfCnpjDestino(contestacao.getCpfCnpjDestino());
            responseList.add(contestacaoResponse);
        }
        HeaderReception headerReception = new HeaderReception(idControleRequisicao, HeaderGeneratorID.generate());
        return new ResponseEntity<>(responseList, headerReception.getHttpHeaders(), HttpStatus.OK);
    }
}
