package br.org.cipbancos.atlante.tester.components.r2c3.controller;

import br.org.cip.api.r2c3.model.*;
import br.org.cipbancos.atlante.tester.components.r2c3.config.Constantes;
import br.org.cipbancos.atlante.tester.components.r2c3.config.filter.RebatedorFilter;
import br.org.cipbancos.atlante.tester.components.r2c3.dao.RebatedorParamSistDAO;
import br.org.cipbancos.atlante.tester.components.r2c3.negocio.CallBackNegocio;
import br.org.cipbancos.atlante.tester.components.r2c3.negocio.ContratoNegocio;
import br.org.cipbancos.atlante.tester.components.r2c3.negocio.GenericResponseNegocio;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/contrato")
public class ContratoController {

    @Autowired
    GenericResponseNegocio genericResponseNegocio;

    @Autowired
    ContratoNegocio contratoNegocio;

    @Autowired
    CallBackNegocio callBackNegocio;

    @Autowired
    RebatedorFilter rebatedorFilter;

    @Autowired
    RebatedorParamSistDAO rebatedorParamSistDAO;

    private static final Logger LOG = LoggerFactory.getLogger(ContratoController.class);

    public ContratoController() {
        LOG.debug("CONTRATO CONTROLLER");
    }
    /**
     * contrato
     * - post
     * - patch
     */
    @PostMapping()
    public ResponseEntity<GenericResponseContrato> contratoPost(
            @RequestHeader HttpHeaders headers,
            @RequestBody Contrato contrato, HttpServletResponse response) {

        String idControleRequisicao = headers.getFirst(Constantes.ID_CONTROLE_REQ);
        response.setHeader(Constantes.ID_CONTROLE_RECEP, UUID.randomUUID().toString());
        response.setHeader(Constantes.ID_CONTROLE_REQ, idControleRequisicao);

        boolean recusarContrato = rebatedorParamSistDAO.buscarBooleanPorNmParamSist("CERC_RECUSAR_CONTRATO");
        if (recusarContrato) {
            List<String> erros = new ArrayList<>();
            erros.add("003");
            return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED)
                    .body(genericResponseNegocio.getContratoErroPostResponse(erros));
        }

        System.out.println("### POST CONTRATO ####");
        System.out.println("THREAD: "+Thread.currentThread().getName());

        headers = new HttpHeaders();
        headers.put(Constantes.ID_CONTROLE_RECEP, Collections.singletonList(UUID.randomUUID().toString()));
        headers.put(Constantes.ID_CONTROLE_RESP, Collections.singletonList(UUID.randomUUID().toString()));
        headers.put(Constantes.ID_CONTROLE_CONF, Collections.singletonList(UUID.randomUUID().toString()));
        headers.put(Constantes.ID_CONTROLE_REQ, Collections.singletonList(idControleRequisicao));
        System.out.println(headers);

        ContratoPatch contratoPatch = contratoNegocio.createContratoPatch(contrato);
        callBackNegocio.patchContratoAsync(contratoPatch, headers);
        System.out.println("FIM!");

        return ResponseEntity.status(HttpStatus.ACCEPTED)
                .body(genericResponseNegocio.getContratoPostResponse(contrato));

    }

    @PostMapping("/cancelamento/resposta")
    public ResponseEntity<GenericResponse> postContratoCancelamentoResposta( @RequestHeader HttpHeaders headers,
            @RequestBody CancelamentoResposta cancelamentoResposta, HttpServletResponse response){
        GenericResponse resposta = new GenericResponse();
        resposta.setDadosControle(new DadosControle());
        resposta.getDadosControle().setDataCriacao(cancelamentoResposta.getDataCriacao());
        resposta.getDadosControle().setDataReferencia(cancelamentoResposta.getDataReferencia());
        resposta.getDadosControle().setIdBatch(cancelamentoResposta.getIdBatch());
        return new ResponseEntity<>(resposta, headers, HttpStatus.OK);
    }

    @PostMapping("/cancelamento")
    public ResponseEntity<GenericResponseContrato> contratoCancelmentoPost(
            @RequestHeader HttpHeaders headers,
            @RequestBody Cancelamento cancelamento, HttpServletResponse response) {

        System.out.println("### POST CONTRATO/CANCELAMENTO/RESPOSTA ####");
        System.out.println("THREAD: "+Thread.currentThread().getName());

        String idRecebimento = UUID.randomUUID().toString();

        rebatedorFilter.setIdControleRecepcao(idRecebimento);
        rebatedorFilter.setIdControleResposta(UUID.randomUUID().toString());
        //para o callback

        String idControleRequisicao = headers.getFirst(Constantes.ID_CONTROLE_REQ);

        headers = new HttpHeaders();
        headers.put(Constantes.ID_CONTROLE_RECEP, Collections.singletonList(UUID.randomUUID().toString()));
        headers.put(Constantes.ID_CONTROLE_RESP, Collections.singletonList(UUID.randomUUID().toString()));
        headers.put(Constantes.ID_CONTROLE_CONF, Collections.singletonList(UUID.randomUUID().toString()));
        headers.put(Constantes.ID_CONTROLE_REQ, Collections.singletonList(idControleRequisicao));
        System.out.println(headers);

        CancelamentoResposta cancelamentoResposta = contratoNegocio.createCancelamentoResposta(cancelamento);
        callBackNegocio.postContratoCancelamentoRespostaAsync(cancelamentoResposta, headers);
        System.out.println("FIM!");

        return ResponseEntity.status(HttpStatus.ACCEPTED)
                .body(genericResponseNegocio.getContratoCancelamentoResponse(cancelamento));

    }

    /**
     * Aqui são recebidas as respostas das solicitações feitas
     * @param contratoPatch
     * @return
     */
    @PatchMapping()
    public ResponseEntity<GenericResponseContrato> contratoPatch(@RequestBody ContratoPatch contratoPatch) {
        return ResponseEntity.status(HttpStatus.OK)
                .body(genericResponseNegocio.getContratoPatchResponse(contratoPatch));
    }
}
