package br.org.cipbancos.atlante.tester.components.r2c3.vo;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.Objects;

public class FracaoVO {

    private BigInteger idFracao;
    private String nrCnpjCredr;
    private String nrCpfCnpjUsuarioFinalRecebedor;
    private String nrCpfCnpjTitular;
    private Integer idPartCred;
    private LocalDate dtPrevistaLiquidacao;
    private BigDecimal vlrLivre;
    private Long idUnidadeRecebivel;
    private String arranjo;

    public BigInteger getIdFracao() {
        return idFracao;
    }

    public void setIdFracao(BigInteger idFracao) {
        this.idFracao = idFracao;
    }

    public String getNrCnpjCredr() {
        return nrCnpjCredr;
    }

    public void setNrCnpjCredr(String nrCnpjCredr) {
        this.nrCnpjCredr = nrCnpjCredr;
    }

    public String getNrCpfCnpjUsuarioFinalRecebedor() {
        return nrCpfCnpjUsuarioFinalRecebedor;
    }

    public void setNrCpfCnpjUsuarioFinalRecebedor(String nrCpfCnpjUsuarioFinalRecebedor) {
        this.nrCpfCnpjUsuarioFinalRecebedor = nrCpfCnpjUsuarioFinalRecebedor;
    }

    public String getNrCpfCnpjTitular() {
        return nrCpfCnpjTitular;
    }

    public void setNrCpfCnpjTitular(String nrCpfCnpjTitular) {
        this.nrCpfCnpjTitular = nrCpfCnpjTitular;
    }

    public Integer getIdPartCred() {
        return idPartCred;
    }

    public void setIdPartCred(Integer idPartCred) {
        this.idPartCred = idPartCred;
    }

    public LocalDate getDtPrevistaLiquidacao() {
        return dtPrevistaLiquidacao;
    }

    public void setDtPrevistaLiquidacao(LocalDate dtPrevistaLiquidacao) {
        this.dtPrevistaLiquidacao = dtPrevistaLiquidacao;
    }

    public BigDecimal getVlrLivre() {
        return vlrLivre;
    }

    public void setVlrLivre(BigDecimal vlrLivre) {
        this.vlrLivre = vlrLivre;
    }

    public Long getIdUnidadeRecebivel() {
        return idUnidadeRecebivel;
    }

    public void setIdUnidadeRecebivel(Long idUnidadeRecebivel) {
        this.idUnidadeRecebivel = idUnidadeRecebivel;
    }

    public String getArranjo() {
        return arranjo;
    }

    public void setArranjo(String arranjo) {
        this.arranjo = arranjo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        FracaoVO fracaoVO = (FracaoVO)o;
        return Objects.equals(idPartCred, fracaoVO.idPartCred) && Objects.equals(idUnidadeRecebivel,
                fracaoVO.idUnidadeRecebivel);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPartCred, idUnidadeRecebivel);
    }
}
