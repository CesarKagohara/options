package br.org.cipbancos.atlante.tester.components.r2c3.util;

import java.util.Arrays;

public class HeaderReception extends HeaderRequest{

    private String idControleRecepcao;

    public HeaderReception(String idControleRequisicao, String idControleRecepcao) {
        super(idControleRequisicao);
        this.idControleRecepcao = idControleRecepcao;
        this.headers.put(Constantes.HEADER_ID_CONTROLE_RECEPCAO, Arrays.asList(this.idControleRecepcao));
    }

    public String getIdControleRecepcao() {
        return idControleRecepcao;
    }
}
