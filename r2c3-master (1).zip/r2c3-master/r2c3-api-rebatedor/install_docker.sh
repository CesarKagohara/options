#!/usr/bin/env bash

version=" 1.54.1-SNAPSHOT"

# Nome do container do WebSphere
was_container=docker_jboss_1

  echo "Building API rebatedor $version ..."
mvn clean install

echo "Copying API rebatedor files"
docker cp start_servers.sh ${was_container}:/tmp
docker cp stop_servers.sh ${was_container}:/tmp
docker cp target/r2c3-api-rebatedor-$version.jar ${was_container}:/tmp
docker cp target/r2c3-api-rebatedor-$version.jar ${was_container}:/tmp
docker cp target/r2c3-api-rebatedor-$version.jar ${was_container}:/tmp
