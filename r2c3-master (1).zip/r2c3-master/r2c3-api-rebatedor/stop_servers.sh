#!/bin/bash

source /opt/atlante/tester-lib/atlante-tester-components.sh
configureComponents "r2c3-application" "/opt/atlante" "/opt/atlante/config"

## Para o server do atlante tester com os parametros: ISPB, NOME PARTY_NAME e WAIT_TIME
#stopAtlanteTesterServer 00000000 "Banco do Brasil" 3
#stopAtlanteTesterServer 90708060 "Banco Itau" 3
#stopAtlanteTesterServer 11111111 "Sample Authorization Server" 3
stopAtlanteTesterServer 31345107 "TAG" 3
stopAtlanteTesterServer 23399607 "CERC" 3
stopAtlanteTesterServer 22222222 "CENTRALIZADORA" 3
