## Tickets (RTC, EV ou nome da atividade)

EV123456 - ***** Indicar o evento tratado *****
RTC12345 - ***** Indicar o RTC tratado *****

## Evidência dos testes unitarios

```
[INFO] r2c3 1.5.16-SNAPSHOT ............................... SUCCESS [  8.099 s]
[INFO] r2c3-application ................................... SUCCESS [02:10 min]
[INFO] r2c3-tests ......................................... SUCCESS [ 19.845 s]
[INFO] r2c3-api-rebatedor 1.5.16-SNAPSHOT ................. SUCCESS [  7.757 s]
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
[INFO] Total time: 02:58 min
[INFO] Finished at: 2020-11-09T15:44:03-02:00
[INFO] ------------------------------------------------------------------------
```

## Evidência dos testes integrados

```
-- Succeeded: 73, Failed: 0, Skipped: 0

== Test SUCCESSFUL ===================================================
-- Succeeded: 73
-- Failed: 0
-- Skipped: 0
-- Total: 73
-- Time: 364105 ms
-- End Date: 2021-03-22 10:07:13
```

## Evidência do teste INTEGRADO do evento

```
-- Test finished: envio de RRC0019 para gravame com periodo de 10 dias(integration.RRC0019.AceitoGravame)
-- Succeeded: 1, Failed: 0, Skipped: 0

== Test SUCCESSFUL ===================================================
-- Succeeded: 1
-- Failed: 0
-- Skipped: 0
-- Total: 1
-- Time: 17240 ms
-- End Date: 2021-03-22 10:12:25
```

## Nome do teste UNITARIO do evento

```
br.org.cipbancos.rrc.handler.rrc0019.RRC0019HandlerTest#inclusao_GestaoRegistradora_ComValor_ComAceiteIncondicional_ComUmaURNaoEncontrada
```

## Funcionalidades impactadas

- Inclusão e alteração Gravame

## Tabelas e/ou colunas impactadas

- OP, FRACAO_UNIDD_RECBV_OP

## Configurações do ambiente

- Ajustar arquivo /config/dynamic-confiigurations/splitter-config.json


/label ~bugfix