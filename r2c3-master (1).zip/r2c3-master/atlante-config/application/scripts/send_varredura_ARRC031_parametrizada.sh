#!/bin/bash

printHelpAndExit() {
  echo "Utilização: $0 [-g <Grade>] "
  echo "            -g <Grade> Numero da grade de processamento. Ex. 1"
  exit $1
}

if [ $# -eq 0 ] ; then
  printHelpAndExit 0
fi

GRADE=""
while getopts 'g:' OPTION
do
  case $OPTION in
  g) GRADE="$OPTARG"
     ;;
  ?) printHelpAndExit
     ;;
  esac
done

atlante_home=$ATLANTE_HOME
if [[ -z $atlante_home ]]
then
  atlante_home="/opt/atlante"
fi

XML_DATE=`date '+%Y%m%d%H%M%S'`
XML_NAME="V_ACCC602_Parametro_$XML_DATE.xml"
XML="<DOC xmlns=\"http://www.cip-bancos.org.br/MES/Ativar_varredura.xsd\">
    <BCMSG>
        <NUOp>04391007200905021234567</NUOp>
    </BCMSG>
    <SISMSG>
        <R2C3AtivarVarredura>
            <CodMsg>V_ARRC031</CodMsg>"
if [ "$GRADE" != "" ]
then
XML="$XML
            <Parametro>
                <Nome>GrdProc</Nome>
                <Valor>$GRADE</Valor>
            </Parametro>"
fi
XML="$XML
        </R2C3AtivarVarredura>
    </SISMSG>
</DOC>"

echo "Estimulo parametrizado para Grade = $GRADE"
echo $XML
echo $XML > /tmp/$XML_NAME

$atlante_home/bin/send_varredura.sh -w /tmp/$XML_NAME

rm /tmp/$XML_NAME