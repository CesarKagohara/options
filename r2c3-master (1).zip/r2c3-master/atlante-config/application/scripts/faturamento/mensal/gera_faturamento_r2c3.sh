#!/bin/sh

DirAppl=/MIFS/rrc/faturamento/mensal
DirScript=${DirAppl}/query

#Verifica se há parametros
if [[ ${params} -eq 0 ]];
then
   #Def. Arquivos e tabelas
   ArqSQlFile=${DirScript}/query_faturamento.sql
else
   echo 'Consulta com Parametros'
   #Def. Arquivos e tabelas
   cp ${DirScript}/query_faturamento_param.sql.sql ${DirScript}/TMP0.sql
   sed -e 's/DTINI/'$DTINI'/g' ${DirScript}/TMP0.sql > ${DirScript}/TMP1.sql
   sed -e 's/DTFIM/'${DTFIM}'/g' ${DirScript}/TMP1.sql > ${DirScript}/TMP2.sql
   ArqSQlFile=${DirScript}/TMP2.sql
fi

psql -h ciprrchintdb01.cip-core.local -p 5432 -d rrci -U rrc_own -f query/query_faturamento.sql -w

cat Dados/header.csv > faturamento_r2c3.csv
cat Dados/faturamento.csv >> faturamento_r2c3.csv

nbLines=$(cat -n faturamento_r2c3.csv | tail -n 1 | cut -f1 | xargs)
echo 99';'$nbLines >  Dados/footer.csv

cat Dados/footer.csv >> faturamento_r2c3.csv

mv faturamento_r2c3.csv R2C3_FAT01_`date '+%Y%m%d'`.csv

zip -r9 R2C3_FAT01_`date '+%Y%m%d'` *.csv;