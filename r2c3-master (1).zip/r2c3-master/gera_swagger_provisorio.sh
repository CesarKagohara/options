#!/bin/bash
#Antes de executar este shell, coloque os seguintes arquivos no diretório ~/lib
# - atlante-Installer-5.1.9.sh
# - openapi-generator-cli-4.3.1.jar
# - atlante-utils

# Exemplo:
# ./gera_swagger_provisorio.sh utilitarios/swagger/r2c3-api_0.0.5_20200904.yaml
BASEDIR=$(dirname "$0")
SWAGGER_PATH_FILE=${BASEDIR}/$1
SWAGGER_FILE=$(basename "$SWAGGER_PATH_FILE")
VERSION=$(echo "$SWAGGER_FILE" | cut -d_ -f2)
SWAGGER_OUTPUT=/tmp/output-swagger
SWAGGER_HOME=$(dirname "${SWAGGER_PATH_FILE}")
ARTIFACT_ID=$(xmlstarlet sel -t -v "_:project/_:artifactId" ${SWAGGER_HOME}/api-r2c3.xml)

export ATLANTE_HOME=~/opt/atlante-r2c3-teste

echo "Gerando $ARTIFACT_ID Swagger na versao: $VERSION"

${SWAGGER_HOME}/set_version_swagger.sh ${VERSION}

rm -Rf ${SWAGGER_OUTPUT}
mkdir -p ${ATLANTE_HOME}
mkdir -p ${SWAGGER_OUTPUT}

if [ ! -f ${ATLANTE_HOME}/lib/openapi-generator-cli-4.3.1.jar ]; then
  chmod +x ~/lib/atlante-Installer-5.1.9.sh
  ~/lib/atlante-Installer-5.1.9.sh
  rm ${ATLANTE_HOME}/lib/openapi-generator-cli-4.2.3.jar
  cp ~/lib/openapi-generator-cli-4.3.1.jar ${ATLANTE_HOME}/lib/
  cp ~/lib/atlante-utils ${ATLANTE_HOME}/bin/
fi

${ATLANTE_HOME}/bin/atlante-utils api-interfaces --openapi-file ${SWAGGER_PATH_FILE} --output-dir ${SWAGGER_OUTPUT}

#Colocando path raiz no codigo gerado /v1
BASE_ENDPOINT=$(cat ${SWAGGER_PATH_FILE} | grep -oP 'default: \K(/.*)' | head -1)
PATTERN='@RequestMapping(value = "'
find ${SWAGGER_OUTPUT} -type f -print0 | xargs -0 sed  -i "s|$PATTERN|@RequestMapping\(value = \"$BASE_ENDPOINT|g"
mvn clean install -f ${SWAGGER_OUTPUT}/pom.xml

mvn install:install-file -DgroupId=br.org.cip.api.r2c3 \
  -DartifactId=${ARTIFACT_ID} \
  -Dversion=${VERSION} \
  -Dpackaging=jar \
  -Dfile=${SWAGGER_OUTPUT}/target/api-r2c3-${VERSION}.jar \
  -DpomFile=${SWAGGER_HOME}/api-r2c3.xml

mvn install:install-file -DgroupId=br.org.cip.api.r2c3 \
  -DartifactId=${ARTIFACT_ID} \
  -Dversion=${VERSION} \
  -Dpackaging=java-source \
  -Dfile=${SWAGGER_OUTPUT}/target/api-r2c3-${VERSION}-sources.jar \
  -DgeneratePom=false